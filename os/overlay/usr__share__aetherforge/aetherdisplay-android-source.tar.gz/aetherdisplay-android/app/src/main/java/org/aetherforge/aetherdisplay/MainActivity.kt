package org.aetherforge.aetherdisplay

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AetherDisplayBridge(), "AetherDisplayNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/bootstrap.html")
    }

    inner class AetherDisplayBridge {
        @JavascriptInterface
        fun getDisplayMetricsJson(): String {
            val metrics = resources.displayMetrics
            val densityDpi = metrics.densityDpi
            val scaledDensity = metrics.scaledDensity
            val xdpi = metrics.xdpi
            val ydpi = metrics.ydpi
            val widthPixels = metrics.widthPixels
            val heightPixels = metrics.heightPixels
            return """{\"densityDpi\":$densityDpi,\"scaledDensity\":$scaledDensity,\"xdpi\":$xdpi,\"ydpi\":$ydpi,\"widthPixels\":$widthPixels,\"heightPixels\":$heightPixels}"""
        }

        @JavascriptInterface
        fun setPanelBrightness(value: Int) {
            val clamped = value.coerceIn(0, 100)
            runOnUiThread {
                window.attributes.screenBrightness = clamped / 100.0f
            }
        }
    }
}
