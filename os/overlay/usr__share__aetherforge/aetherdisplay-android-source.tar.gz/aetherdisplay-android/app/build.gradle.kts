plugins { id("com.android.application"); kotlin("android") }

android {
    namespace = "org.aetherforge.aetherdisplay"
    compileSdk = 36
    defaultConfig { applicationId = "org.aetherforge.aetherdisplay"; minSdk = 24; targetSdk = 36; versionCode = 10246; versionName = "10.2.47" }
}
