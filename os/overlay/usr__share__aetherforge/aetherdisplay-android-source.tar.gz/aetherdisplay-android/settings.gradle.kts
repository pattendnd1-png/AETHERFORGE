rootProject.name = "AetherDisplay"
include(":app")
