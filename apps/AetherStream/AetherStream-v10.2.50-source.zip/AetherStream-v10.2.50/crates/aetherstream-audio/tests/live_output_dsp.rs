use aetherstream_audio::{LiveDspPlan, LiveDspProcessor};
use aetherstream_core::{OutputDeviceClass, OutputDspProfile, OutputEnhancement};

const RATE: f32 = 48_000.0;

fn sine(frequency: f32, frames: usize) -> Vec<f32> {
    (0..frames)
        .map(|frame| {
            let phase = std::f32::consts::TAU * frequency * frame as f32 / RATE;
            phase.sin() * 0.1
        })
        .collect()
}

fn rms(samples: &[f32]) -> f32 {
    let sum = samples.iter().map(|sample| sample * sample).sum::<f32>();
    (sum / samples.len() as f32).sqrt()
}

fn gain_db(input: &[f32], output: &[f32]) -> f32 {
    20.0 * (rms(output) / rms(input)).log10()
}

fn render(profile: &OutputDspProfile, input: &[f32]) -> Vec<f32> {
    let plan = LiveDspPlan::compile(profile, RATE, 1).unwrap();
    let mut dsp = LiveDspProcessor::new(plan, 1, 480).unwrap();
    let mut output = Vec::with_capacity(input.len());
    for &sample in input {
        output.push(dsp.process_sample(0, sample));
    }
    output
}

#[test]
fn live_bass_boost_measures_in_target_band_without_lifting_presence_band() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.bass = OutputEnhancement::enabled(6.0, 90.0, 0.707_106_77);
    profile.clarity.enabled = false;
    profile.limiter.enabled = false;

    let bass = sine(70.0, 48_000);
    let presence = sine(2_000.0, 48_000);
    let bass_out = render(&profile, &bass);
    let presence_out = render(&profile, &presence);

    assert!(gain_db(&bass[4_800..], &bass_out[4_800..]) > 3.5);
    assert!(gain_db(&presence[4_800..], &presence_out[4_800..]).abs() < 1.0);
}

#[test]
fn live_clarity_boost_measures_in_target_band_without_lifting_bass_band() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.bass.enabled = false;
    profile.clarity = OutputEnhancement::enabled(6.0, 3_000.0, 0.9);
    profile.limiter.enabled = false;

    let clarity = sine(3_000.0, 48_000);
    let bass = sine(100.0, 48_000);
    let clarity_out = render(&profile, &clarity);
    let bass_out = render(&profile, &bass);

    assert!(gain_db(&clarity[4_800..], &clarity_out[4_800..]) > 4.5);
    assert!(gain_db(&bass[4_800..], &bass_out[4_800..]).abs() < 1.0);
}

#[test]
fn bypass_is_effectively_unity() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker);
    profile.bypassed = true;
    let input = sine(777.0, 16_000);
    let output = render(&profile, &input);
    let max_error = input
        .iter()
        .zip(output.iter())
        .map(|(a, b)| (a - b).abs())
        .fold(0.0_f32, f32::max);
    assert!(max_error < 1.0e-7);
}

#[test]
fn new_plan_crossfades_instead_of_jumping_in_one_sample() {
    let flat = OutputDspProfile::factory(OutputDeviceClass::Custom);
    let mut boosted = flat.clone();
    boosted.bass = OutputEnhancement::enabled(12.0, 90.0, 0.707_106_77);
    boosted.limiter.enabled = false;

    let flat_plan = LiveDspPlan::compile(&flat, RATE, 1).unwrap();
    let boosted_plan = LiveDspPlan::compile(&boosted, RATE, 1).unwrap();
    let mut dsp = LiveDspProcessor::new(flat_plan, 1, 480).unwrap();
    for sample in sine(90.0, 2_000) {
        let _ = dsp.process_sample(0, sample);
    }
    dsp.begin_transition(boosted_plan);
    assert!(dsp.transition_samples_remaining() > 0);
    let first = dsp.process_sample(0, 0.1);
    assert!(first.abs() < 0.3);
}

#[test]
fn live_plan_accepts_thirty_one_parametric_eq_bands_within_section_budget() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.set_parametric_eq_band_count(31);
    profile.bass.enabled = false;
    profile.clarity.enabled = false;
    profile.gaming.enabled = false;
    let plan = LiveDspPlan::compile(&profile, 96_000.0, 2).unwrap();
    assert_eq!(plan.section_count, 31);
}

#[test]
fn live_plan_preserves_but_skips_parametric_bands_above_current_nyquist_guard() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    for band in &mut profile.parametric_eq {
        band.enabled = false;
    }
    profile.parametric_eq[0].enabled = true;
    profile.parametric_eq[0].frequency_hz = 35_000.0;
    profile.bass.enabled = false;
    profile.clarity.enabled = false;
    profile.gaming.enabled = false;
    let at_48k = LiveDspPlan::compile(&profile, 48_000.0, 2).unwrap();
    let at_96k = LiveDspPlan::compile(&profile, 96_000.0, 2).unwrap();
    assert_eq!(at_48k.section_count, 0);
    assert_eq!(at_96k.section_count, 1);
    assert_eq!(profile.parametric_eq[0].frequency_hz, 35_000.0);
}
