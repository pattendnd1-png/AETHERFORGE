use aetherstream_audio::{LiveDspPlan, SharedOutputDspReader, SharedOutputDspWriter};
use aetherstream_core::{OutputDeviceClass, OutputDspProfile};
use std::io::{Seek, SeekFrom, Write};
use std::time::{SystemTime, UNIX_EPOCH};

fn temp_path() -> std::path::PathBuf {
    std::env::temp_dir().join(format!(
        "aetherstream-output-dsp-{}-{}.shm",
        std::process::id(),
        SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
    ))
}

#[test]
fn shared_plan_round_trip_preserves_compiled_dsp() {
    let path = temp_path();
    let mut writer = SharedOutputDspWriter::open_or_create(&path).unwrap();
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::TvSpeaker);
    profile.bass.enabled = true;
    profile.bass.amount_db = 4.0;
    let plan = LiveDspPlan::compile(&profile, 48_000.0, 2).unwrap();
    let generation = writer.publish(&plan);
    let reader = SharedOutputDspReader::try_open(&path).unwrap();
    let (seen_generation, seen) = reader.snapshot().unwrap();
    assert_eq!(seen_generation, generation);
    assert_eq!(seen, plan);
    let _ = std::fs::remove_file(path);
}

#[test]
fn generation_advances_for_live_parameter_updates() {
    let path = temp_path();
    let mut writer = SharedOutputDspWriter::open_or_create(&path).unwrap();
    let first = LiveDspPlan::compile(
        &OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker),
        48_000.0,
        2,
    )
    .unwrap();
    let mut second_profile = OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker);
    second_profile.clarity.enabled = true;
    second_profile.clarity.amount_db = 5.0;
    let second = LiveDspPlan::compile(&second_profile, 48_000.0, 2).unwrap();
    let generation_a = writer.publish(&first);
    let generation_b = writer.publish(&second);
    assert!(generation_b > generation_a);
    let _ = std::fs::remove_file(path);
}


#[test]
fn reader_rejects_invalid_magic() {
    let path = temp_path();
    let writer = SharedOutputDspWriter::open_or_create(&path).unwrap();
    drop(writer);
    let mut file = std::fs::OpenOptions::new().write(true).open(&path).unwrap();
    file.seek(SeekFrom::Start(0)).unwrap();
    file.write_all(&0_u32.to_ne_bytes()).unwrap();
    drop(file);
    assert!(SharedOutputDspReader::try_open(&path).is_err());
    let _ = std::fs::remove_file(path);
}
