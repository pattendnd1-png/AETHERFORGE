use aetherstream_audio::OutputDspProcessor;
use aetherstream_core::{
    OutputDeviceClass, OutputDspProfile, OutputEnhancement, OutputFilter, OutputFilterKind,
};

const RATE: f32 = 48_000.0;

fn sine(frequency: f32, frames: usize) -> Vec<f32> {
    (0..frames)
        .map(|frame| {
            let phase = std::f32::consts::TAU * frequency * frame as f32 / RATE;
            phase.sin() * 0.2
        })
        .collect()
}

fn rms(samples: &[f32]) -> f32 {
    let sum = samples.iter().map(|sample| sample * sample).sum::<f32>();
    (sum / samples.len() as f32).sqrt()
}

fn process_mono(profile: OutputDspProfile, input: &[f32]) -> Vec<f32> {
    let mut output = input.to_vec();
    let mut processor = OutputDspProcessor::new(profile, RATE, 1).unwrap();
    processor.process_interleaved(&mut output).unwrap();
    output
}

#[test]
fn high_pass_strongly_reduces_sub_cutoff_energy() {
    let input = sine(50.0, 48_000);
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.filters = vec![OutputFilter::high_pass(200.0, 24)];
    let output = process_mono(profile, &input);
    assert!(rms(&output[4_800..]) < rms(&input[4_800..]) * 0.15);
}

#[test]
fn low_pass_strongly_reduces_high_frequency_energy() {
    let input = sine(10_000.0, 24_000);
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.filters = vec![OutputFilter::low_pass(2_000.0, 24)];
    let output = process_mono(profile, &input);
    assert!(rms(&output[2_400..]) < rms(&input[2_400..]) * 0.15);
}

#[test]
fn band_pass_is_a_mid_pass_and_rejects_distant_bands() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    let mut mid = OutputFilter::new(OutputFilterKind::BandPass, 1_000.0);
    mid.q = 1.0;
    profile.filters = vec![mid];

    let center = process_mono(profile.clone(), &sine(1_000.0, 24_000));
    let low = process_mono(profile.clone(), &sine(80.0, 24_000));
    let high = process_mono(profile, &sine(10_000.0, 24_000));
    assert!(rms(&center[2_400..]) > rms(&low[2_400..]) * 4.0);
    assert!(rms(&center[2_400..]) > rms(&high[2_400..]) * 2.0);
}

#[test]
fn bass_and_clarity_stages_raise_their_target_bands() {
    let mut flat = OutputDspProfile::factory(OutputDeviceClass::Custom);
    flat.preamp_db = -6.0;

    let mut bass = flat.clone();
    bass.bass = OutputEnhancement::enabled(6.0, 90.0, 0.707_106_77);
    let bass_flat = process_mono(flat.clone(), &sine(80.0, 24_000));
    let bass_boosted = process_mono(bass, &sine(80.0, 24_000));
    assert!(rms(&bass_boosted[2_400..]) > rms(&bass_flat[2_400..]) * 1.20);

    let mut clarity = flat.clone();
    clarity.clarity = OutputEnhancement::enabled(6.0, 3_000.0, 0.9);
    let clarity_flat = process_mono(flat, &sine(3_000.0, 24_000));
    let clarity_boosted = process_mono(clarity, &sine(3_000.0, 24_000));
    assert!(rms(&clarity_boosted[2_400..]) > rms(&clarity_flat[2_400..]) * 1.20);
}

#[test]
fn limiter_never_exceeds_configured_ceiling() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.preamp_db = 18.0;
    profile.limiter.enabled = true;
    profile.limiter.ceiling_dbfs = -1.0;
    let input = vec![0.95; 4_096];
    let output = process_mono(profile, &input);
    let ceiling = 10.0_f32.powf(-1.0 / 20.0);
    assert!(output.iter().all(|sample| sample.abs() <= ceiling + 1.0e-5));
}

#[test]
fn channel_state_is_isolated() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.filters = vec![OutputFilter::low_pass(2_000.0, 24)];
    let mut stereo = vec![0.0; 4_096];
    stereo[0] = 1.0;
    let mut processor = OutputDspProcessor::new(profile, RATE, 2).unwrap();
    processor.process_interleaved(&mut stereo).unwrap();
    assert!(stereo.iter().skip(1).step_by(2).all(|sample| sample.abs() < 1.0e-7));
}

#[test]
fn gaming_mode_overlay_boosts_detail_and_reduces_low_mid_masking() {
    let mut flat = OutputDspProfile::factory(OutputDeviceClass::Custom);
    flat.preamp_db = -6.0;

    let mut gaming = flat.clone();
    gaming.gaming.enabled = true;

    let flat_detail = process_mono(flat.clone(), &sine(2_800.0, 24_000));
    let gaming_detail = process_mono(gaming.clone(), &sine(2_800.0, 24_000));
    assert!(rms(&gaming_detail[2_400..]) > rms(&flat_detail[2_400..]) * 1.08);

    let flat_mud = process_mono(flat, &sine(300.0, 24_000));
    let gaming_mud = process_mono(gaming, &sine(300.0, 24_000));
    assert!(rms(&gaming_mud[2_400..]) < rms(&flat_mud[2_400..]) * 0.96);
}
