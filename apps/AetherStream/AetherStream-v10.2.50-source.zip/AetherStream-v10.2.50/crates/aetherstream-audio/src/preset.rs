use crate::DspGraph;use serde::{Deserialize,Serialize};
#[derive(Clone,Debug,PartialEq,Serialize,Deserialize)]pub struct DspPreset{pub schema_version:u16,pub id:String,pub name:String,pub graph:DspGraph}
