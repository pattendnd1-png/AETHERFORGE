use aetherstream_core::AetherStreamAction;

#[derive(Clone, Debug, PartialEq)]
pub struct MixerStrip {
    pub bus: String,
    pub gain_db: f32,
    pub muted: bool,
    pub soloed: bool,
    pub monitor: bool,
    pub meter_dbfs: Option<f32>,
    pub dsp_preset: Option<String>,
    pub destinations: Vec<String>,
    pub recording_armed: bool,
}

impl MixerStrip {
    #[must_use]
    pub fn new(bus: impl Into<String>, gain_db: f32) -> Self {
        Self {
            bus: bus.into(),
            gain_db,
            muted: false,
            soloed: false,
            monitor: false,
            meter_dbfs: None,
            dsp_preset: None,
            destinations: Vec::new(),
            recording_armed: false,
        }
    }

    #[must_use]
    pub fn set_gain(&self, gain_db: f32) -> AetherStreamAction {
        AetherStreamAction::AudioGain {
            bus: self.bus.clone(),
            gain_db,
        }
    }

    #[must_use]
    pub fn set_muted(&self, muted: bool) -> AetherStreamAction {
        AetherStreamAction::AudioMute {
            bus: self.bus.clone(),
            muted,
        }
    }

    #[must_use]
    pub fn set_soloed(&self, soloed: bool) -> AetherStreamAction {
        AetherStreamAction::AudioSolo {
            bus: self.bus.clone(),
            soloed,
        }
    }

    #[must_use]
    pub fn set_monitor(&self, enabled: bool) -> AetherStreamAction {
        AetherStreamAction::AudioMonitor {
            bus: self.bus.clone(),
            enabled,
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct MixerProjection {
    pub strips: Vec<MixerStrip>,
}

impl MixerProjection {
    #[must_use]
    pub fn broadcast_default() -> Self {
        Self {
            strips: ["Mic", "Game", "Discord", "Music", "Alerts", "Monitor", "Stream Master"]
                .into_iter()
                .map(|name| MixerStrip::new(name, 0.0))
                .collect(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mic_strip_gain_change_emits_audio_action() {
        let strip = MixerStrip::new("Mic", -5.0);
        assert_eq!(
            strip.set_gain(-3.0),
            AetherStreamAction::AudioGain {
                bus: "Mic".into(),
                gain_db: -3.0,
            }
        );
    }

    #[test]
    fn broadcast_projection_exposes_single_canonical_bus_set() {
        let projection = MixerProjection::broadcast_default();
        assert_eq!(projection.strips.len(), 7);
        assert_eq!(projection.strips[0].bus, "Mic");
        assert_eq!(projection.strips[6].bus, "Stream Master");
    }
}
