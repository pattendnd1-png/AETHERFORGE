use aetherstream_core::LinkedOutputConfig;
use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::sync::{Mutex, OnceLock};

pub const LINKED_SINK_NAME: &str = "aetherstream_linked_hdmi_bluetooth";
pub const LINKED_SINK_DESCRIPTION: &str = "AetherForge_Linked_HDMI_Bluetooth";
const LINKED_NAMESPACE_PREFIX: &str = "aetherstream_linked_";
static LINKED_OUTPUT_APPLY_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

pub fn linked_output_config_path() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_CONFIG_HOME") {
        PathBuf::from(dir).join("aetherstream/linked-output.conf")
    } else if let Some(home) = std::env::var_os("HOME") {
        PathBuf::from(home).join(".config/aetherstream/linked-output.conf")
    } else {
        PathBuf::from("/tmp/aetherstream-linked-output.conf")
    }
}

pub fn save_linked_output_config(config: &LinkedOutputConfig) -> Result<(), String> {
    let path = linked_output_config_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|error| format!("create linked output config dir: {error}"))?;
    }
    let body = format!(
        "enabled={}\nmaster_normalized_10k={}\nhdmi_trim_db_x100={}\nbluetooth_trim_db_x100={}\nhdmi_node_name={}\nbluetooth_node_name={}\n",
        config.enabled,
        config.master_normalized_10k,
        config.hdmi_trim_db_x100,
        config.bluetooth_trim_db_x100,
        config.hdmi_node_name.as_deref().unwrap_or(""),
        config.bluetooth_node_name.as_deref().unwrap_or("")
    );
    fs::write(path, body).map_err(|error| format!("write linked output config: {error}"))
}

pub fn load_linked_output_config() -> Result<Option<LinkedOutputConfig>, String> {
    let path = linked_output_config_path();
    if !path.is_file() {
        return Ok(None);
    }
    let text = fs::read_to_string(path).map_err(|error| format!("read linked output config: {error}"))?;
    let mut config = LinkedOutputConfig::default();
    for line in text.lines() {
        let Some((key, value)) = line.split_once('=') else { continue; };
        match key {
            "enabled" => config.enabled = value == "true",
            "master_normalized_10k" => config.master_normalized_10k = value.parse().unwrap_or(config.master_normalized_10k),
            "hdmi_trim_db_x100" => config.hdmi_trim_db_x100 = value.parse().unwrap_or(config.hdmi_trim_db_x100),
            "bluetooth_trim_db_x100" => config.bluetooth_trim_db_x100 = value.parse().unwrap_or(config.bluetooth_trim_db_x100),
            "hdmi_node_name" => config.hdmi_node_name = (!value.is_empty()).then(|| value.to_owned()),
            "bluetooth_node_name" => config.bluetooth_node_name = (!value.is_empty()).then(|| value.to_owned()),
            _ => {}
        }
    }
    Ok(Some(config))
}


#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct LinkedOutputTopology {
    pub linked_sink_count: usize,
    pub member_count: usize,
    pub hdmi_route_count: usize,
    pub bluetooth_route_count: usize,
    pub extraneous_virtual_sinks: usize,
    pub extraneous_virtual_sources: usize,
    pub duplicate_output_routes: usize,
    pub orphan_links: usize,
    pub combine_module_count: usize,
    pub extraneous_linked_modules: usize,
}

impl LinkedOutputTopology {
    pub fn is_exact(&self) -> bool {
        self.linked_sink_count == 1
            && self.member_count == 2
            && self.hdmi_route_count == 1
            && self.bluetooth_route_count == 1
            && self.extraneous_virtual_sinks == 0
            && self.extraneous_virtual_sources == 0
            && self.duplicate_output_routes == 0
            && self.orphan_links == 0
            && self.combine_module_count == 1
            && self.extraneous_linked_modules == 0
    }

    pub fn is_disabled_clean(&self) -> bool {
        self.linked_sink_count == 0
            && self.member_count == 0
            && self.extraneous_virtual_sinks == 0
            && self.extraneous_virtual_sources == 0
            && self.duplicate_output_routes == 0
            && self.orphan_links == 0
            && self.combine_module_count == 0
            && self.extraneous_linked_modules == 0
    }

    pub fn has_any_linked_graph(&self) -> bool {
        self.linked_sink_count > 0
            || self.member_count > 0
            || self.extraneous_virtual_sinks > 0
            || self.extraneous_virtual_sources > 0
            || self.combine_module_count > 0
            || self.extraneous_linked_modules > 0
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct ModuleLine {
    index: String,
    name: String,
    args: String,
}

fn parse_module_lines(text: &str) -> Vec<ModuleLine> {
    text.lines()
        .filter_map(|line| {
            let mut fields = line.split_whitespace();
            let index = fields.next()?.to_owned();
            let name = fields.next()?.to_owned();
            let args = fields.collect::<Vec<_>>().join(" ");
            Some(ModuleLine { index, name, args })
        })
        .collect()
}

fn parse_short_names(text: &str) -> Vec<String> {
    text.lines()
        .filter_map(|line| line.split_whitespace().nth(1).map(str::to_owned))
        .collect()
}

fn module_sink_members(args: &str) -> Vec<String> {
    args.split_whitespace()
        .find_map(|part| part.strip_prefix("sinks="))
        .map(|value| {
            value
                .split(',')
                .map(str::trim)
                .filter(|value| !value.is_empty())
                .map(str::to_owned)
                .collect()
        })
        .unwrap_or_default()
}

pub fn inspect_linked_output_topology_from_text(
    modules_text: &str,
    sinks_text: &str,
    sources_text: &str,
    expected_hdmi: &str,
    expected_bluetooth: &str,
) -> LinkedOutputTopology {
    let modules = parse_module_lines(modules_text);
    let sink_names = parse_short_names(sinks_text);
    let source_names = parse_short_names(sources_text);
    let linked_modules = modules
        .iter()
        .filter(|module| module.args.contains(LINKED_NAMESPACE_PREFIX) || module.args.contains(LINKED_SINK_NAME))
        .collect::<Vec<_>>();
    let combine_modules = linked_modules
        .iter()
        .filter(|module| module.name == "module-combine-sink" && module.args.contains(LINKED_SINK_NAME))
        .copied()
        .collect::<Vec<_>>();
    let members = combine_modules
        .iter()
        .flat_map(|module| module_sink_members(&module.args))
        .collect::<Vec<_>>();
    let hdmi_route_count = members.iter().filter(|member| member.as_str() == expected_hdmi).count();
    let bluetooth_route_count = members.iter().filter(|member| member.as_str() == expected_bluetooth).count();
    let mut seen = std::collections::BTreeSet::new();
    let duplicate_output_routes = members.iter().filter(|member| !seen.insert((*member).clone())).count();
    let missing_member_links = members
        .iter()
        .filter(|member| !sink_names.iter().any(|sink| sink == *member))
        .count();
    let linked_sink_count = sink_names.iter().filter(|name| name.as_str() == LINKED_SINK_NAME).count();
    let module_sink_mismatch = usize::from(combine_modules.len() != linked_sink_count);
    let allowed_monitor = format!("{LINKED_SINK_NAME}.monitor");
    LinkedOutputTopology {
        linked_sink_count,
        member_count: members.len(),
        hdmi_route_count,
        bluetooth_route_count,
        extraneous_virtual_sinks: sink_names
            .iter()
            .filter(|name| name.starts_with(LINKED_NAMESPACE_PREFIX) && name.as_str() != LINKED_SINK_NAME)
            .count(),
        extraneous_virtual_sources: source_names
            .iter()
            .filter(|name| name.starts_with(LINKED_NAMESPACE_PREFIX) && name.as_str() != allowed_monitor)
            .count(),
        duplicate_output_routes,
        orphan_links: missing_member_links + module_sink_mismatch,
        combine_module_count: combine_modules.len(),
        extraneous_linked_modules: linked_modules.len().saturating_sub(combine_modules.len()),
    }
}

pub fn inspect_linked_output_topology(
    expected_hdmi: &str,
    expected_bluetooth: &str,
) -> Result<LinkedOutputTopology, String> {
    let modules = output("pactl", &["list", "modules", "short"])?;
    let sinks = output("pactl", &["list", "sinks", "short"])?;
    let sources = output("pactl", &["list", "sources", "short"])?;
    Ok(inspect_linked_output_topology_from_text(
        &modules,
        &sinks,
        &sources,
        expected_hdmi,
        expected_bluetooth,
    ))
}

pub fn linked_output_topology_healthy(config: &LinkedOutputConfig) -> bool {
    if !config.enabled {
        return inspect_linked_output_topology("", "")
            .map(|topology| topology.is_disabled_clean())
            .unwrap_or(false);
    }
    let Some(hdmi) = config.hdmi_node_name.as_deref().filter(|value| !value.trim().is_empty()) else {
        return false;
    };
    let Some(bluetooth) = config.bluetooth_node_name.as_deref().filter(|value| !value.trim().is_empty()) else {
        return false;
    };
    inspect_linked_output_topology(hdmi, bluetooth)
        .map(|topology| topology.is_exact())
        .unwrap_or(false)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LinkedPhysicalSink {
    pub node_id: u32,
    pub node_name: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LinkedOutputApplyResult {
    pub enabled: bool,
    pub hdmi_node_name: Option<String>,
    pub bluetooth_node_name: Option<String>,
    pub latency_compensated: bool,
    pub topology: LinkedOutputTopology,
}

fn output(program: &str, args: &[&str]) -> Result<String, String> {
    let result = Command::new(program)
        .args(args)
        .output()
        .map_err(|error| format!("{program} {args:?}: {error}"))?;
    if !result.status.success() {
        return Err(format!(
            "{program} {args:?} failed: {}",
            String::from_utf8_lossy(&result.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&result.stdout).into_owned())
}

fn parse_node_ids(text: &str) -> Vec<u32> {
    text.lines()
        .filter_map(|line| {
            let token = line
                .trim()
                .trim_start_matches('*')
                .split_whitespace()
                .next()?
                .trim_end_matches('.');
            token.parse::<u32>().ok()
        })
        .collect()
}

fn parse_quoted(text: &str, key: &str) -> Option<String> {
    text.lines().find_map(|line| {
        if !line.contains(key) {
            return None;
        }
        let (_, value) = line.split_once('=')?;
        let value = value.trim().trim_matches('"').trim();
        (!value.is_empty()).then(|| value.to_owned())
    })
}

fn available_sinks() -> Result<Vec<(LinkedPhysicalSink, String)>, String> {
    let listing = output("wpctl", &["list", "audio", "sinks"])?;
    let mut sinks = Vec::new();
    for node_id in parse_node_ids(&listing) {
        let node_id_text = node_id.to_string();
        let inspect = output("wpctl", &["inspect", node_id_text.as_str()])?;
        let Some(node_name) = parse_quoted(&inspect, "node.name") else {
            continue;
        };
        if node_name.starts_with("aetherstream.") || node_name == LINKED_SINK_NAME {
            continue;
        }
        sinks.push((LinkedPhysicalSink { node_id, node_name }, inspect));
    }
    Ok(sinks)
}

fn resolve_exact_or_match(
    exact: Option<&str>,
    predicate: impl Fn(&str, &str) -> bool,
    kind: &str,
) -> Result<LinkedPhysicalSink, String> {
    let sinks = available_sinks()?;
    if let Some(exact) = exact.map(str::trim).filter(|value| !value.is_empty()) {
        return sinks
            .into_iter()
            .find(|(sink, _)| sink.node_name == exact)
            .map(|(sink, _)| sink)
            .ok_or_else(|| format!("configured {kind} sink {exact:?} is not available"));
    }
    sinks
        .into_iter()
        .find(|(sink, inspect)| predicate(&sink.node_name, inspect))
        .map(|(sink, _)| sink)
        .ok_or_else(|| format!("no physical {kind} sink is currently available"))
}

pub fn resolve_hdmi_sink(exact: Option<&str>) -> Result<LinkedPhysicalSink, String> {
    resolve_exact_or_match(
        exact,
        |node_name, inspect| {
            let lower = inspect.to_ascii_lowercase();
            node_name.starts_with("alsa_output.")
                && (lower.contains("hdmi") || lower.contains("displayport"))
        },
        "HDMI/DisplayPort",
    )
}

pub fn resolve_bluetooth_sink(exact: Option<&str>) -> Result<LinkedPhysicalSink, String> {
    resolve_exact_or_match(
        exact,
        |node_name, inspect| {
            node_name.starts_with("bluez_output.")
                || inspect.contains("api.bluez5.address")
                || inspect.contains("api.bluez5.codec")
        },
        "Bluetooth",
    )
}

fn linked_module_indices(modules: &str) -> Vec<String> {
    parse_module_lines(modules)
        .into_iter()
        .filter_map(|module| {
            let linked = module.args.contains(LINKED_NAMESPACE_PREFIX) || module.args.contains(LINKED_SINK_NAME);
            let removable = matches!(
                module.name.as_str(),
                "module-combine-sink" | "module-loopback" | "module-null-sink" | "module-remap-sink" | "module-virtual-sink"
            );
            (linked && removable).then_some(module.index)
        })
        .collect()
}

fn unload_existing_linked_modules() -> Result<(), String> {
    let modules = output("pactl", &["list", "modules", "short"])?;
    for index in linked_module_indices(&modules) {
        output("pactl", &["unload-module", &index])?;
    }
    Ok(())
}

fn trim_percent(db_x100: i16) -> String {
    let db = f32::from(db_x100.clamp(-1_200, 0)) / 100.0;
    let percent = 100.0 * 10.0_f32.powf(db / 20.0);
    format!("{percent:.2}%")
}

fn master_percent(normalized_10k: u16) -> String {
    format!("{:.2}%", f32::from(normalized_10k.min(15_000)) / 100.0)
}

pub fn linked_output_present() -> bool {
    output("pactl", &["list", "modules", "short"])
        .map(|text| text.lines().any(|line| line.contains("module-combine-sink") && line.contains(LINKED_SINK_NAME)))
        .unwrap_or(false)
}

pub fn apply_linked_output(config: &LinkedOutputConfig) -> Result<LinkedOutputApplyResult, String> {
    let _apply_guard = LINKED_OUTPUT_APPLY_LOCK
        .get_or_init(|| Mutex::new(()))
        .lock()
        .map_err(|_| "linked output apply lock poisoned".to_owned())?;
    if config.master_normalized_10k > 15_000 {
        return Err("linked output master volume out of range".into());
    }
    if !(-1_200..=0).contains(&config.hdmi_trim_db_x100)
        || !(-1_200..=0).contains(&config.bluetooth_trim_db_x100)
    {
        return Err("linked output trims must be between -12.00 dB and 0.00 dB".into());
    }

    if !config.enabled {
        unload_existing_linked_modules()?;
        if let Some(hdmi) = config.hdmi_node_name.as_deref().filter(|value| !value.trim().is_empty()) {
            let _ = output("pactl", &["set-default-sink", hdmi]);
        }
        let disabled_topology = inspect_linked_output_topology("", "")?;
        if !disabled_topology.is_disabled_clean() {
            return Err(format!("linked output topology validation failed while disabling: {disabled_topology:?}"));
        }
        save_linked_output_config(config)?;
        return Ok(LinkedOutputApplyResult {
            enabled: false,
            hdmi_node_name: config.hdmi_node_name.clone(),
            bluetooth_node_name: config.bluetooth_node_name.clone(),
            latency_compensated: false,
            topology: disabled_topology,
        });
    }

    let hdmi = resolve_hdmi_sink(config.hdmi_node_name.as_deref())?;
    let bluetooth = resolve_bluetooth_sink(config.bluetooth_node_name.as_deref())?;
    if hdmi.node_name == bluetooth.node_name {
        return Err("HDMI and Bluetooth sinks resolved to the same PipeWire node".into());
    }

    // Resolve both physical endpoints before replacing an existing linked module.
    // If Bluetooth is temporarily unavailable, the current HDMI path is left intact.
    unload_existing_linked_modules()?;
    let sinks = format!("sinks={},{}", hdmi.node_name, bluetooth.node_name);
    output(
        "pactl",
        &[
            "load-module",
            "module-combine-sink",
            &format!("sink_name={LINKED_SINK_NAME}"),
            &format!("sink_properties=device.description={LINKED_SINK_DESCRIPTION}"),
            sinks.as_str(),
            "latency_compensate=true",
        ],
    )?;
    output("pactl", &["set-sink-volume", hdmi.node_name.as_str(), trim_percent(config.hdmi_trim_db_x100).as_str()])?;
    output("pactl", &["set-sink-volume", bluetooth.node_name.as_str(), trim_percent(config.bluetooth_trim_db_x100).as_str()])?;
    output("pactl", &["set-default-sink", LINKED_SINK_NAME])?;
    output("pactl", &["set-sink-volume", LINKED_SINK_NAME, master_percent(config.master_normalized_10k).as_str()])?;

    let topology = inspect_linked_output_topology(&hdmi.node_name, &bluetooth.node_name)?;
    if !topology.is_exact() {
        let _ = unload_existing_linked_modules();
        let _ = output("pactl", &["set-default-sink", hdmi.node_name.as_str()]);
        return Err(format!("linked output topology validation failed: {topology:?}"));
    }

    let persisted = LinkedOutputConfig {
        enabled: true,
        hdmi_node_name: Some(hdmi.node_name.clone()),
        bluetooth_node_name: Some(bluetooth.node_name.clone()),
        ..config.clone()
    };
    save_linked_output_config(&persisted)?;
    Ok(LinkedOutputApplyResult {
        enabled: true,
        hdmi_node_name: Some(hdmi.node_name),
        bluetooth_node_name: Some(bluetooth.node_name),
        latency_compensated: true,
        topology,
    })
}

pub fn refresh_linked_output_levels(config: &LinkedOutputConfig) -> Result<(), String> {
    let _apply_guard = LINKED_OUTPUT_APPLY_LOCK
        .get_or_init(|| Mutex::new(()))
        .lock()
        .map_err(|_| "linked output apply lock poisoned".to_owned())?;
    if !config.enabled || !linked_output_topology_healthy(config) {
        return Ok(());
    }
    let hdmi = resolve_hdmi_sink(config.hdmi_node_name.as_deref())?;
    let bluetooth = resolve_bluetooth_sink(config.bluetooth_node_name.as_deref())?;
    if hdmi.node_name == bluetooth.node_name {
        return Err("HDMI and Bluetooth sinks resolved to the same PipeWire node".into());
    }
    output(
        "pactl",
        &["set-sink-volume", hdmi.node_name.as_str(), trim_percent(config.hdmi_trim_db_x100).as_str()],
    )?;
    output(
        "pactl",
        &[
            "set-sink-volume",
            bluetooth.node_name.as_str(),
            trim_percent(config.bluetooth_trim_db_x100).as_str(),
        ],
    )?;
    output(
        "pactl",
        &["set-sink-volume", LINKED_SINK_NAME, master_percent(config.master_normalized_10k).as_str()],
    )?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trim_is_attenuation_only_and_master_is_common() {
        assert_eq!(trim_percent(0), "100.00%");
        assert_eq!(trim_percent(-600), "50.12%");
        assert_eq!(master_percent(7_000), "70.00%");
    }

    #[test]
    fn node_id_parser_accepts_wpctl_list_shapes() {
        assert_eq!(parse_node_ids("52 sink\n* 61. sink\nnoise\n"), vec![52, 61]);
    }

    #[test]
    fn exact_linked_topology_requires_one_sink_and_two_unique_members() {
        let modules = "77 module-combine-sink sink_name=aetherstream_linked_hdmi_bluetooth sinks=alsa_output.hdmi,bluez_output.speaker latency_compensate=true 1\n";
        let sinks = "51 alsa_output.hdmi driver RUNNING\n52 bluez_output.speaker driver RUNNING\n53 aetherstream_linked_hdmi_bluetooth module-combine-sink RUNNING\n";
        let sources = "71 aetherstream_linked_hdmi_bluetooth.monitor module-combine-sink IDLE\n";
        let topology = inspect_linked_output_topology_from_text(modules, sinks, sources, "alsa_output.hdmi", "bluez_output.speaker");
        assert!(topology.is_exact(), "{topology:?}");
    }

    #[test]
    fn duplicate_or_loopback_routes_are_rejected() {
        let modules = concat!(
            "77 module-combine-sink sink_name=aetherstream_linked_hdmi_bluetooth sinks=alsa_output.hdmi,bluez_output.speaker latency_compensate=true 1\n",
            "78 module-combine-sink sink_name=aetherstream_linked_hdmi_bluetooth sinks=alsa_output.hdmi,bluez_output.speaker latency_compensate=true 1\n",
            "79 module-loopback sink=aetherstream_linked_hdmi_bluetooth source=foo 1\n",
        );
        let sinks = "51 alsa_output.hdmi driver RUNNING\n52 bluez_output.speaker driver RUNNING\n53 aetherstream_linked_hdmi_bluetooth module-combine-sink RUNNING\n";
        let topology = inspect_linked_output_topology_from_text(modules, sinks, "", "alsa_output.hdmi", "bluez_output.speaker");
        assert!(!topology.is_exact());
        assert!(topology.duplicate_output_routes > 0);
        assert!(topology.extraneous_linked_modules > 0);
    }
}

