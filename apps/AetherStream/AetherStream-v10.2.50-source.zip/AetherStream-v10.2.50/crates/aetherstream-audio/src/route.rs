use crate::LogicalAudioDeviceId;use serde::{Deserialize,Serialize};
#[derive(Clone,Debug,Eq,PartialEq,Serialize,Deserialize)]pub struct AudioRoute{pub id:String,pub source:LogicalAudioDeviceId,pub destination:LogicalAudioDeviceId,pub dsp_preset:Option<String>,pub enabled:bool}
#[derive(Clone,Debug,Eq,PartialEq)]pub struct TransientNode{pub node_name:String,pub logical_id:LogicalAudioDeviceId}
pub struct AudioRouteRestorer;impl AudioRouteRestorer{pub fn match_reconnected<'a>(wanted:&LogicalAudioDeviceId,nodes:&'a[TransientNode])->Option<&'a TransientNode>{nodes.iter().find(|node|&node.logical_id==wanted)}}
#[cfg(test)]mod tests{use super::*;#[test]fn reconnect_matches_logical_identity_not_node_name(){let id=LogicalAudioDeviceId("hyperx-solocast-serial".into());let nodes=vec![TransientNode{node_name:"alsa_input.usb-99".into(),logical_id:id.clone()}];assert_eq!(AudioRouteRestorer::match_reconnected(&id,&nodes).unwrap().node_name,"alsa_input.usb-99");}}
