use aetherstream_core::{
    OutputDspProfile, OutputDspProfileError, OutputEnhancement, OutputFilter, OutputFilterKind,
    OutputGamingMode, OutputParametricEqBand, ParametricEqBandKind,
};
use thiserror::Error;

pub const MAX_LIVE_SECTIONS: usize = 64;
pub const MAX_LIVE_CHANNELS: usize = 32;

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct LiveBiquadCoefficients {
    pub b0: f32,
    pub b1: f32,
    pub b2: f32,
    pub a1: f32,
    pub a2: f32,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct LiveDspPlan {
    pub bypassed: bool,
    pub channels: u8,
    pub preamp_linear: f32,
    pub output_gain_linear: f32,
    pub limiter_enabled: bool,
    pub limiter_ceiling_linear: f32,
    pub section_count: u8,
    pub sections: [LiveBiquadCoefficients; MAX_LIVE_SECTIONS],
}

#[derive(Clone, Debug, Error, PartialEq)]
pub enum LiveDspPlanError {
    #[error(transparent)]
    InvalidProfile(#[from] OutputDspProfileError),
    #[error("live DSP supports at most {MAX_LIVE_CHANNELS} channels")]
    TooManyChannels,
    #[error("profile expands beyond the {MAX_LIVE_SECTIONS}-section realtime limit")]
    TooManySections,
    #[error("processor channel count does not match compiled plan")]
    ChannelMismatch,
}

impl LiveDspPlan {
    pub fn compile(
        profile: &OutputDspProfile,
        sample_rate_hz: f32,
        channels: usize,
    ) -> Result<Self, LiveDspPlanError> {
        profile.validate(sample_rate_hz, channels)?;
        if channels > MAX_LIVE_CHANNELS {
            return Err(LiveDspPlanError::TooManyChannels);
        }

        let mut plan = Self {
            bypassed: profile.bypassed,
            channels: channels as u8,
            preamp_linear: db_to_linear(profile.preamp_db),
            output_gain_linear: db_to_linear(profile.output_gain_db),
            limiter_enabled: profile.limiter.enabled,
            limiter_ceiling_linear: db_to_linear(profile.limiter.ceiling_dbfs),
            section_count: 0,
            sections: [LiveBiquadCoefficients::default(); MAX_LIVE_SECTIONS],
        };

        for filter in profile.filters.iter().filter(|filter| filter.enabled) {
            append_filter_sections(&mut plan, filter, sample_rate_hz)?;
        }
        for band in &profile.parametric_eq {
            append_parametric_eq(&mut plan, band, sample_rate_hz)?;
        }
        append_enhancement(
            &mut plan,
            &profile.bass,
            OutputFilterKind::LowShelf,
            sample_rate_hz,
        )?;
        append_enhancement(
            &mut plan,
            &profile.clarity,
            OutputFilterKind::Peak,
            sample_rate_hz,
        )?;
        append_gaming(&mut plan, &profile.gaming, sample_rate_hz)?;
        Ok(plan)
    }

    fn push(&mut self, coefficients: LiveBiquadCoefficients) -> Result<(), LiveDspPlanError> {
        let index = usize::from(self.section_count);
        if index >= MAX_LIVE_SECTIONS {
            return Err(LiveDspPlanError::TooManySections);
        }
        self.sections[index] = coefficients;
        self.section_count = self.section_count.saturating_add(1);
        Ok(())
    }
}

#[derive(Clone, Copy, Debug)]
struct BiquadState {
    z1: f32,
    z2: f32,
}

impl BiquadState {
    const ZERO: Self = Self { z1: 0.0, z2: 0.0 };
}

#[derive(Clone, Debug)]
struct ProcessorBank {
    plan: LiveDspPlan,
    states: [[BiquadState; MAX_LIVE_CHANNELS]; MAX_LIVE_SECTIONS],
}

impl ProcessorBank {
    fn new(plan: LiveDspPlan) -> Self {
        Self {
            plan,
            states: [[BiquadState::ZERO; MAX_LIVE_CHANNELS]; MAX_LIVE_SECTIONS],
        }
    }

    #[inline]
    fn process(&mut self, channel: usize, input: f32) -> f32 {
        if self.plan.bypassed {
            return input;
        }

        let mut value = input * self.plan.preamp_linear;
        for index in 0..usize::from(self.plan.section_count) {
            let coefficients = self.plan.sections[index];
            let state = &mut self.states[index][channel];
            let output = coefficients.b0.mul_add(value, state.z1);
            state.z1 = coefficients
                .b1
                .mul_add(value, state.z2 - coefficients.a1 * output);
            state.z2 = coefficients.b2 * value - coefficients.a2 * output;
            value = output;
        }
        value *= self.plan.output_gain_linear;
        if self.plan.limiter_enabled {
            value = soft_limit(value, self.plan.limiter_ceiling_linear);
        }
        if value.is_finite() { value } else { 0.0 }
    }
}

#[derive(Clone, Debug)]
pub struct LiveDspProcessor {
    channels: usize,
    smoothing_samples: usize,
    banks: [ProcessorBank; 2],
    active_bank: usize,
    transition_samples_remaining: usize,
}

impl LiveDspProcessor {
    pub fn new(
        plan: LiveDspPlan,
        channels: usize,
        smoothing_samples: usize,
    ) -> Result<Self, LiveDspPlanError> {
        if usize::from(plan.channels) != channels {
            return Err(LiveDspPlanError::ChannelMismatch);
        }
        let bank = ProcessorBank::new(plan);
        Ok(Self {
            channels,
            smoothing_samples: smoothing_samples.max(1),
            banks: [bank.clone(), bank],
            active_bank: 0,
            transition_samples_remaining: 0,
        })
    }

    pub fn begin_transition(&mut self, plan: LiveDspPlan) {
        if usize::from(plan.channels) != self.channels {
            return;
        }
        let pending = 1 - self.active_bank;
        self.banks[pending] = ProcessorBank::new(plan);
        self.transition_samples_remaining = self.smoothing_samples;
    }

    #[must_use]
    pub const fn transition_samples_remaining(&self) -> usize {
        self.transition_samples_remaining
    }

    #[must_use]
    pub fn process_sample(&mut self, channel: usize, input: f32) -> f32 {
        if channel >= self.channels {
            return input;
        }
        if self.transition_samples_remaining == 0 {
            return self.banks[self.active_bank].process(channel, input);
        }

        let pending_bank = 1 - self.active_bank;
        let (active, pending) = if self.active_bank == 0 {
            let (left, right) = self.banks.split_at_mut(1);
            (&mut left[0], &mut right[0])
        } else {
            let (left, right) = self.banks.split_at_mut(1);
            (&mut right[0], &mut left[0])
        };
        let old = active.process(channel, input);
        let new = pending.process(channel, input);
        let completed = self
            .smoothing_samples
            .saturating_sub(self.transition_samples_remaining)
            .saturating_add(1);
        let mix = (completed as f32 / self.smoothing_samples as f32).clamp(0.0, 1.0);
        let output = old + (new - old) * mix;
        self.transition_samples_remaining = self.transition_samples_remaining.saturating_sub(1);
        if self.transition_samples_remaining == 0 {
            self.active_bank = pending_bank;
        }
        output
    }
}

fn append_enhancement(
    plan: &mut LiveDspPlan,
    enhancement: &OutputEnhancement,
    kind: OutputFilterKind,
    sample_rate_hz: f32,
) -> Result<(), LiveDspPlanError> {
    if !enhancement.enabled || enhancement.amount_db.abs() <= f32::EPSILON {
        return Ok(());
    }
    let filter = OutputFilter {
        enabled: true,
        kind,
        frequency_hz: enhancement.frequency_hz,
        gain_db: enhancement.amount_db,
        q: enhancement.q,
        slope_db_per_octave: 12,
    };
    append_filter_sections(plan, &filter, sample_rate_hz)
}

fn append_gaming(
    plan: &mut LiveDspPlan,
    gaming: &OutputGamingMode,
    sample_rate_hz: f32,
) -> Result<(), LiveDspPlanError> {
    if !gaming.enabled {
        return Ok(());
    }
    for (kind, frequency_hz, gain_db, q) in [
        (
            OutputFilterKind::LowShelf,
            gaming.impact_frequency_hz,
            gaming.impact_db,
            0.707_106_77,
        ),
        (
            OutputFilterKind::Peak,
            gaming.mud_frequency_hz,
            gaming.mud_cut_db,
            0.8,
        ),
        (
            OutputFilterKind::Peak,
            gaming.detail_frequency_hz,
            gaming.detail_db,
            0.9,
        ),
    ] {
        append_filter_sections(
            plan,
            &OutputFilter {
                enabled: true,
                kind,
                frequency_hz,
                gain_db,
                q,
                slope_db_per_octave: 12,
            },
            sample_rate_hz,
        )?;
    }
    Ok(())
}

fn append_parametric_eq(
    plan: &mut LiveDspPlan,
    band: &OutputParametricEqBand,
    sample_rate_hz: f32,
) -> Result<(), LiveDspPlanError> {
    if !band.enabled || band.frequency_hz >= sample_rate_hz * 0.49 {
        return Ok(());
    }
    let kind = match band.kind {
        ParametricEqBandKind::Peak => OutputFilterKind::Peak,
        ParametricEqBandKind::Notch => OutputFilterKind::Notch,
        ParametricEqBandKind::LowShelf => OutputFilterKind::LowShelf,
        ParametricEqBandKind::HighShelf => OutputFilterKind::HighShelf,
    };
    let filter = OutputFilter {
        enabled: true,
        kind,
        frequency_hz: band.frequency_hz,
        gain_db: band.gain_db,
        q: band.q,
        slope_db_per_octave: 12,
    };
    plan.push(biquad_coefficients(&filter, sample_rate_hz))
}

fn append_filter_sections(
    plan: &mut LiveDspPlan,
    filter: &OutputFilter,
    sample_rate_hz: f32,
) -> Result<(), LiveDspPlanError> {
    if matches!(filter.kind, OutputFilterKind::HighPass | OutputFilterKind::LowPass) {
        let mut remaining_slope = filter.slope_db_per_octave;
        if remaining_slope % 12 == 6 {
            plan.push(first_order_coefficients(
                filter.kind,
                filter.frequency_hz,
                sample_rate_hz,
            ))?;
            remaining_slope -= 6;
        }
        for _ in 0..remaining_slope / 12 {
            plan.push(biquad_coefficients(filter, sample_rate_hz))?;
        }
    } else {
        plan.push(biquad_coefficients(filter, sample_rate_hz))?;
    }
    Ok(())
}

fn first_order_coefficients(
    kind: OutputFilterKind,
    frequency_hz: f32,
    sample_rate_hz: f32,
) -> LiveBiquadCoefficients {
    let k = (std::f32::consts::PI * frequency_hz / sample_rate_hz).tan();
    let norm = 1.0 / (1.0 + k);
    match kind {
        OutputFilterKind::HighPass => LiveBiquadCoefficients {
            b0: norm,
            b1: -norm,
            b2: 0.0,
            a1: (k - 1.0) * norm,
            a2: 0.0,
        },
        OutputFilterKind::LowPass => LiveBiquadCoefficients {
            b0: k * norm,
            b1: k * norm,
            b2: 0.0,
            a1: (k - 1.0) * norm,
            a2: 0.0,
        },
        _ => unreachable!("first-order sections are only used by pass filters"),
    }
}

fn biquad_coefficients(filter: &OutputFilter, sample_rate_hz: f32) -> LiveBiquadCoefficients {
    let omega = std::f32::consts::TAU * filter.frequency_hz / sample_rate_hz;
    let sin_omega = omega.sin();
    let cos_omega = omega.cos();
    let alpha = sin_omega / (2.0 * filter.q);
    let a = 10.0_f32.powf(filter.gain_db / 40.0);
    let (b0, b1, b2, a0, a1, a2) = match filter.kind {
        OutputFilterKind::LowPass => (
            (1.0 - cos_omega) * 0.5,
            1.0 - cos_omega,
            (1.0 - cos_omega) * 0.5,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::HighPass => (
            (1.0 + cos_omega) * 0.5,
            -(1.0 + cos_omega),
            (1.0 + cos_omega) * 0.5,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::BandPass => (
            alpha,
            0.0,
            -alpha,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::Notch => (
            1.0,
            -2.0 * cos_omega,
            1.0,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::Peak => (
            1.0 + alpha * a,
            -2.0 * cos_omega,
            1.0 - alpha * a,
            1.0 + alpha / a,
            -2.0 * cos_omega,
            1.0 - alpha / a,
        ),
        OutputFilterKind::LowShelf | OutputFilterKind::HighShelf => {
            shelf_coefficients(filter, sin_omega, cos_omega, a)
        }
    };
    normalize(b0, b1, b2, a0, a1, a2)
}

fn shelf_coefficients(
    filter: &OutputFilter,
    sin_omega: f32,
    cos_omega: f32,
    a: f32,
) -> (f32, f32, f32, f32, f32, f32) {
    let slope = filter.q.clamp(0.1, 1.0);
    let alpha = sin_omega * 0.5 * (((a + 1.0 / a) * (1.0 / slope - 1.0) + 2.0).sqrt());
    let beta = 2.0 * a.sqrt() * alpha;
    match filter.kind {
        OutputFilterKind::LowShelf => (
            a * ((a + 1.0) - (a - 1.0) * cos_omega + beta),
            2.0 * a * ((a - 1.0) - (a + 1.0) * cos_omega),
            a * ((a + 1.0) - (a - 1.0) * cos_omega - beta),
            (a + 1.0) + (a - 1.0) * cos_omega + beta,
            -2.0 * ((a - 1.0) + (a + 1.0) * cos_omega),
            (a + 1.0) + (a - 1.0) * cos_omega - beta,
        ),
        OutputFilterKind::HighShelf => (
            a * ((a + 1.0) + (a - 1.0) * cos_omega + beta),
            -2.0 * a * ((a - 1.0) + (a + 1.0) * cos_omega),
            a * ((a + 1.0) + (a - 1.0) * cos_omega - beta),
            (a + 1.0) - (a - 1.0) * cos_omega + beta,
            2.0 * ((a - 1.0) - (a + 1.0) * cos_omega),
            (a + 1.0) - (a - 1.0) * cos_omega - beta,
        ),
        _ => unreachable!("shelf coefficients require a shelf filter"),
    }
}

fn normalize(
    b0: f32,
    b1: f32,
    b2: f32,
    a0: f32,
    a1: f32,
    a2: f32,
) -> LiveBiquadCoefficients {
    let inverse_a0 = 1.0 / a0;
    LiveBiquadCoefficients {
        b0: b0 * inverse_a0,
        b1: b1 * inverse_a0,
        b2: b2 * inverse_a0,
        a1: a1 * inverse_a0,
        a2: a2 * inverse_a0,
    }
}

#[inline]
fn db_to_linear(db: f32) -> f32 {
    10.0_f32.powf(db / 20.0)
}

#[inline]
fn soft_limit(input: f32, ceiling: f32) -> f32 {
    let magnitude = input.abs();
    if magnitude <= ceiling * 0.85 {
        return input;
    }
    let knee_start = ceiling * 0.85;
    let knee_width = ceiling - knee_start;
    let normalized = (magnitude - knee_start) / knee_width.max(f32::EPSILON);
    let limited = knee_start + knee_width * normalized.tanh();
    input.signum() * limited.min(ceiling)
}
