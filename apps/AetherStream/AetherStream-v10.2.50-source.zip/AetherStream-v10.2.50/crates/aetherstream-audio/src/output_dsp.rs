use aetherstream_core::{
    OutputDspProfile, OutputDspProfileError, OutputEnhancement, OutputFilter, OutputFilterKind,
    OutputGamingMode, OutputParametricEqBand, ParametricEqBandKind,
};
use thiserror::Error;

#[derive(Debug, Error, PartialEq)]
pub enum OutputDspProcessorError {
    #[error(transparent)]
    InvalidProfile(#[from] OutputDspProfileError),
    #[error("interleaved buffer length must be divisible by channel count")]
    InvalidBufferLength,
}

#[derive(Clone, Copy, Debug, Default)]
struct BiquadCoefficients {
    b0: f32,
    b1: f32,
    b2: f32,
    a1: f32,
    a2: f32,
}

#[derive(Clone, Copy, Debug, Default)]
struct BiquadState {
    z1: f32,
    z2: f32,
}

#[derive(Clone, Debug)]
struct BiquadSection {
    coefficients: BiquadCoefficients,
    state: Vec<BiquadState>,
}

impl BiquadSection {
    fn new(coefficients: BiquadCoefficients, channels: usize) -> Self {
        Self {
            coefficients,
            state: vec![BiquadState::default(); channels],
        }
    }

    #[inline]
    fn process(&mut self, channel: usize, input: f32) -> f32 {
        let state = &mut self.state[channel];
        let output = self.coefficients.b0.mul_add(input, state.z1);
        state.z1 = self
            .coefficients
            .b1
            .mul_add(input, state.z2 - self.coefficients.a1 * output);
        state.z2 = self.coefficients.b2 * input - self.coefficients.a2 * output;
        output
    }
}

#[derive(Clone, Debug)]
pub struct OutputDspProcessor {
    sample_rate_hz: f32,
    channels: usize,
    profile: OutputDspProfile,
    preamp_linear: f32,
    output_gain_linear: f32,
    limiter_ceiling_linear: f32,
    sections: Vec<BiquadSection>,
}

impl OutputDspProcessor {
    pub fn new(
        profile: OutputDspProfile,
        sample_rate_hz: f32,
        channels: usize,
    ) -> Result<Self, OutputDspProcessorError> {
        profile.validate(sample_rate_hz, channels)?;
        let mut processor = Self {
            sample_rate_hz,
            channels,
            profile,
            preamp_linear: 1.0,
            output_gain_linear: 1.0,
            limiter_ceiling_linear: 1.0,
            sections: Vec::new(),
        };
        processor.rebuild();
        Ok(processor)
    }

    pub fn reconfigure(
        &mut self,
        profile: OutputDspProfile,
    ) -> Result<(), OutputDspProcessorError> {
        profile.validate(self.sample_rate_hz, self.channels)?;
        self.profile = profile;
        self.rebuild();
        Ok(())
    }

    #[must_use]
    pub fn profile(&self) -> &OutputDspProfile {
        &self.profile
    }

    pub fn process_interleaved(
        &mut self,
        samples: &mut [f32],
    ) -> Result<(), OutputDspProcessorError> {
        if !samples.len().is_multiple_of(self.channels) {
            return Err(OutputDspProcessorError::InvalidBufferLength);
        }
        if self.profile.bypassed {
            return Ok(());
        }

        for (index, sample) in samples.iter_mut().enumerate() {
            let channel = index % self.channels;
            let mut value = *sample * self.preamp_linear;
            for section in &mut self.sections {
                value = section.process(channel, value);
            }
            value *= self.output_gain_linear;
            if self.profile.limiter.enabled {
                value = soft_limit(value, self.limiter_ceiling_linear);
            }
            *sample = if value.is_finite() { value } else { 0.0 };
        }
        Ok(())
    }

    fn rebuild(&mut self) {
        self.preamp_linear = db_to_linear(self.profile.preamp_db);
        self.output_gain_linear = db_to_linear(self.profile.output_gain_db);
        self.limiter_ceiling_linear = db_to_linear(self.profile.limiter.ceiling_dbfs);
        self.sections.clear();

        for filter in self.profile.filters.iter().filter(|filter| filter.enabled) {
            append_filter_sections(
                &mut self.sections,
                filter,
                self.sample_rate_hz,
                self.channels,
            );
        }
        for band in &self.profile.parametric_eq {
            append_parametric_eq(
                &mut self.sections,
                band,
                self.sample_rate_hz,
                self.channels,
            );
        }
        append_bass_or_clarity(
            &mut self.sections,
            &self.profile.bass,
            OutputFilterKind::LowShelf,
            self.sample_rate_hz,
            self.channels,
        );
        append_bass_or_clarity(
            &mut self.sections,
            &self.profile.clarity,
            OutputFilterKind::Peak,
            self.sample_rate_hz,
            self.channels,
        );
        if self.profile.gaming.enabled {
            append_gaming_mode(
                &mut self.sections,
                &self.profile.gaming,
                self.sample_rate_hz,
                self.channels,
            );
        }
    }
}

fn append_parametric_eq(
    sections: &mut Vec<BiquadSection>,
    band: &OutputParametricEqBand,
    sample_rate_hz: f32,
    channels: usize,
) {
    if !band.enabled || band.frequency_hz >= sample_rate_hz * 0.49 {
        return;
    }
    let kind = match band.kind {
        ParametricEqBandKind::Peak => OutputFilterKind::Peak,
        ParametricEqBandKind::Notch => OutputFilterKind::Notch,
        ParametricEqBandKind::LowShelf => OutputFilterKind::LowShelf,
        ParametricEqBandKind::HighShelf => OutputFilterKind::HighShelf,
    };
    let filter = OutputFilter {
        enabled: true,
        kind,
        frequency_hz: band.frequency_hz,
        gain_db: band.gain_db,
        q: band.q,
        slope_db_per_octave: 12,
    };
    append_filter_sections(sections, &filter, sample_rate_hz, channels);
}

fn append_gaming_mode(
    sections: &mut Vec<BiquadSection>,
    gaming: &OutputGamingMode,
    sample_rate_hz: f32,
    channels: usize,
) {
    if !gaming.enabled {
        return;
    }

    for (kind, frequency_hz, gain_db, q) in [
        (OutputFilterKind::LowShelf, gaming.impact_frequency_hz, gaming.impact_db, 0.707_106_77),
        (OutputFilterKind::Peak, gaming.mud_frequency_hz, gaming.mud_cut_db, 0.8),
        (OutputFilterKind::Peak, gaming.detail_frequency_hz, gaming.detail_db, 0.9),
    ] {
        let filter = OutputFilter {
            enabled: true,
            kind,
            frequency_hz,
            gain_db,
            q,
            slope_db_per_octave: 12,
        };
        append_filter_sections(sections, &filter, sample_rate_hz, channels);
    }
}

fn append_bass_or_clarity(
    sections: &mut Vec<BiquadSection>,
    enhancement: &OutputEnhancement,
    kind: OutputFilterKind,
    sample_rate_hz: f32,
    channels: usize,
) {
    if !enhancement.enabled || enhancement.amount_db.abs() <= f32::EPSILON {
        return;
    }
    let filter = OutputFilter {
        enabled: true,
        kind,
        frequency_hz: enhancement.frequency_hz,
        gain_db: enhancement.amount_db,
        q: enhancement.q,
        slope_db_per_octave: 12,
    };
    append_filter_sections(sections, &filter, sample_rate_hz, channels);
}

fn append_filter_sections(
    sections: &mut Vec<BiquadSection>,
    filter: &OutputFilter,
    sample_rate_hz: f32,
    channels: usize,
) {
    if matches!(filter.kind, OutputFilterKind::HighPass | OutputFilterKind::LowPass) {
        let mut remaining_slope = filter.slope_db_per_octave;
        if remaining_slope % 12 == 6 {
            sections.push(BiquadSection::new(
                first_order_coefficients(filter.kind, filter.frequency_hz, sample_rate_hz),
                channels,
            ));
            remaining_slope -= 6;
        }
        for _ in 0..remaining_slope / 12 {
            sections.push(BiquadSection::new(
                biquad_coefficients(filter, sample_rate_hz),
                channels,
            ));
        }
    } else {
        sections.push(BiquadSection::new(
            biquad_coefficients(filter, sample_rate_hz),
            channels,
        ));
    }
}

fn first_order_coefficients(
    kind: OutputFilterKind,
    frequency_hz: f32,
    sample_rate_hz: f32,
) -> BiquadCoefficients {
    let k = (std::f32::consts::PI * frequency_hz / sample_rate_hz).tan();
    let norm = 1.0 / (1.0 + k);
    match kind {
        OutputFilterKind::HighPass => BiquadCoefficients {
            b0: norm,
            b1: -norm,
            b2: 0.0,
            a1: (k - 1.0) * norm,
            a2: 0.0,
        },
        OutputFilterKind::LowPass => BiquadCoefficients {
            b0: k * norm,
            b1: k * norm,
            b2: 0.0,
            a1: (k - 1.0) * norm,
            a2: 0.0,
        },
        _ => unreachable!("first-order sections are only used by pass filters"),
    }
}

fn biquad_coefficients(filter: &OutputFilter, sample_rate_hz: f32) -> BiquadCoefficients {
    let omega = std::f32::consts::TAU * filter.frequency_hz / sample_rate_hz;
    let sin_omega = omega.sin();
    let cos_omega = omega.cos();
    let alpha = sin_omega / (2.0 * filter.q);
    let a = 10.0_f32.powf(filter.gain_db / 40.0);

    let (b0, b1, b2, a0, a1, a2) = match filter.kind {
        OutputFilterKind::LowPass => (
            (1.0 - cos_omega) * 0.5,
            1.0 - cos_omega,
            (1.0 - cos_omega) * 0.5,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::HighPass => (
            (1.0 + cos_omega) * 0.5,
            -(1.0 + cos_omega),
            (1.0 + cos_omega) * 0.5,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::BandPass => (
            alpha,
            0.0,
            -alpha,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::Notch => (
            1.0,
            -2.0 * cos_omega,
            1.0,
            1.0 + alpha,
            -2.0 * cos_omega,
            1.0 - alpha,
        ),
        OutputFilterKind::Peak => (
            1.0 + alpha * a,
            -2.0 * cos_omega,
            1.0 - alpha * a,
            1.0 + alpha / a,
            -2.0 * cos_omega,
            1.0 - alpha / a,
        ),
        OutputFilterKind::LowShelf | OutputFilterKind::HighShelf => {
            shelf_coefficients(filter, sin_omega, cos_omega, a)
        }
    };

    normalize(b0, b1, b2, a0, a1, a2)
}

fn shelf_coefficients(
    filter: &OutputFilter,
    sin_omega: f32,
    cos_omega: f32,
    a: f32,
) -> (f32, f32, f32, f32, f32, f32) {
    let slope = filter.q.clamp(0.1, 1.0);
    let alpha = sin_omega * 0.5 * (((a + 1.0 / a) * (1.0 / slope - 1.0) + 2.0).sqrt());
    let beta = 2.0 * a.sqrt() * alpha;
    match filter.kind {
        OutputFilterKind::LowShelf => (
            a * ((a + 1.0) - (a - 1.0) * cos_omega + beta),
            2.0 * a * ((a - 1.0) - (a + 1.0) * cos_omega),
            a * ((a + 1.0) - (a - 1.0) * cos_omega - beta),
            (a + 1.0) + (a - 1.0) * cos_omega + beta,
            -2.0 * ((a - 1.0) + (a + 1.0) * cos_omega),
            (a + 1.0) + (a - 1.0) * cos_omega - beta,
        ),
        OutputFilterKind::HighShelf => (
            a * ((a + 1.0) + (a - 1.0) * cos_omega + beta),
            -2.0 * a * ((a - 1.0) + (a + 1.0) * cos_omega),
            a * ((a + 1.0) + (a - 1.0) * cos_omega - beta),
            (a + 1.0) - (a - 1.0) * cos_omega + beta,
            2.0 * ((a - 1.0) - (a + 1.0) * cos_omega),
            (a + 1.0) - (a - 1.0) * cos_omega - beta,
        ),
        _ => unreachable!("shelf coefficients require a shelf filter"),
    }
}

fn normalize(
    b0: f32,
    b1: f32,
    b2: f32,
    a0: f32,
    a1: f32,
    a2: f32,
) -> BiquadCoefficients {
    let inverse_a0 = 1.0 / a0;
    BiquadCoefficients {
        b0: b0 * inverse_a0,
        b1: b1 * inverse_a0,
        b2: b2 * inverse_a0,
        a1: a1 * inverse_a0,
        a2: a2 * inverse_a0,
    }
}

#[inline]
fn db_to_linear(db: f32) -> f32 {
    10.0_f32.powf(db / 20.0)
}

#[inline]
fn soft_limit(input: f32, ceiling: f32) -> f32 {
    let magnitude = input.abs();
    if magnitude <= ceiling * 0.85 {
        return input;
    }
    let knee_start = ceiling * 0.85;
    let knee_width = ceiling - knee_start;
    let normalized = (magnitude - knee_start) / knee_width.max(f32::EPSILON);
    let limited = knee_start + knee_width * normalized.tanh();
    input.signum() * limited.min(ceiling)
}
