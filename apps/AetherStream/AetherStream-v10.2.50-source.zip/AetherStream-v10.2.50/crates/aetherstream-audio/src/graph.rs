use crate::DspNode;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use thiserror::Error;
use uuid::Uuid;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct DspLink {
    pub from: Uuid,
    pub to: Uuid,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DspGraph {
    pub schema_version: u16,
    pub nodes: Vec<DspNode>,
    pub links: Vec<DspLink>,
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum DspGraphError {
    #[error("dangling DSP link")]
    DanglingLink,
    #[error("self-link is not allowed")]
    SelfLink,
}

impl DspGraph {
    pub fn validate(&self) -> Result<(), DspGraphError> {
        let ids: HashSet<_> = self.nodes.iter().map(|node| node.id).collect();
        for link in &self.links {
            if link.from == link.to {
                return Err(DspGraphError::SelfLink);
            }
            if !ids.contains(&link.from) || !ids.contains(&link.to) {
                return Err(DspGraphError::DanglingLink);
            }
        }
        Ok(())
    }
}

pub trait PipeWireBackend: Send {
    fn apply_graph(&mut self, graph: &DspGraph) -> Result<(), String>;
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{BuiltinDsp, DspNode, DspNodeKind};

    #[test]
    fn dsp_graph_round_trip_and_dangling_links_reject() {
        let a = DspNode::new("gate", DspNodeKind::Builtin(BuiltinDsp::NoiseGate));
        let b = DspNode::new("eq", DspNodeKind::Builtin(BuiltinDsp::Equalizer));
        let graph = DspGraph {
            schema_version: 1,
            nodes: vec![a.clone(), b.clone()],
            links: vec![DspLink {
                from: a.id,
                to: b.id,
            }],
        };
        graph.validate().unwrap();
        let text = serde_json::to_string(&graph).unwrap();
        let decoded: DspGraph = serde_json::from_str(&text).unwrap();
        assert_eq!(decoded, graph);

        let bad = DspGraph {
            schema_version: 1,
            nodes: vec![a],
            links: vec![DspLink {
                from: b.id,
                to: Uuid::new_v4(),
            }],
        };
        assert_eq!(bad.validate(), Err(DspGraphError::DanglingLink));
    }
}
