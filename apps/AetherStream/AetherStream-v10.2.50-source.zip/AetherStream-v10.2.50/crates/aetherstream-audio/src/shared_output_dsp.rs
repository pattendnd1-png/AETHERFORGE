use crate::live_dsp::{LiveBiquadCoefficients, LiveDspPlan, MAX_LIVE_CHANNELS, MAX_LIVE_SECTIONS};
use std::fs::{File, OpenOptions};
use std::io;
use std::os::fd::AsRawFd;
use std::path::Path;
use std::ptr::NonNull;
use std::sync::atomic::{AtomicU32, Ordering};

pub const OUTPUT_DSP_SHARED_FILE: &str = "output-dsp-v1.shm";
pub const OUTPUT_DSP_SHARED_MAGIC: u32 = 0x4153_4450; // ASDP
pub const OUTPUT_DSP_SHARED_VERSION: u32 = 1;
const COEFFICIENT_WORDS: usize = MAX_LIVE_SECTIONS * 5;

#[repr(C, align(64))]
struct SharedOutputDspLayout {
    magic: AtomicU32,
    version: AtomicU32,
    generation: AtomicU32,
    bypassed: AtomicU32,
    channels: AtomicU32,
    preamp_linear: AtomicU32,
    output_gain_linear: AtomicU32,
    limiter_enabled: AtomicU32,
    limiter_ceiling_linear: AtomicU32,
    section_count: AtomicU32,
    coefficients: [AtomicU32; COEFFICIENT_WORDS],
}

pub struct SharedOutputDspWriter {
    _file: File,
    layout: NonNull<SharedOutputDspLayout>,
}

pub struct SharedOutputDspReader {
    _file: File,
    layout: NonNull<SharedOutputDspLayout>,
}

unsafe impl Send for SharedOutputDspWriter {}
unsafe impl Send for SharedOutputDspReader {}
unsafe impl Sync for SharedOutputDspReader {}

impl SharedOutputDspWriter {
    pub fn open_or_create(path: &Path) -> io::Result<Self> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let file = OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .open(path)?;
        file.set_len(std::mem::size_of::<SharedOutputDspLayout>() as u64)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))?;
        }
        let layout = map_layout(&file, true)?;
        let writer = Self {
            _file: file,
            layout,
        };
        let shared = writer.layout();
        shared.magic.store(OUTPUT_DSP_SHARED_MAGIC, Ordering::Release);
        shared.version.store(OUTPUT_DSP_SHARED_VERSION, Ordering::Release);
        if shared.generation.load(Ordering::Acquire) & 1 != 0 {
            shared.generation.store(0, Ordering::Release);
        }
        Ok(writer)
    }

    pub fn publish(&mut self, plan: &LiveDspPlan) -> u32 {
        let shared = self.layout();
        let current = shared.generation.load(Ordering::Acquire);
        let writing = if current & 1 == 0 {
            current.wrapping_add(1)
        } else {
            current.wrapping_add(2)
        };
        shared.generation.store(writing, Ordering::Release);
        shared.bypassed.store(if plan.bypassed { 1 } else { 0 }, Ordering::Relaxed);
        shared.channels.store(u32::from(plan.channels), Ordering::Relaxed);
        shared.preamp_linear.store(plan.preamp_linear.to_bits(), Ordering::Relaxed);
        shared.output_gain_linear.store(plan.output_gain_linear.to_bits(), Ordering::Relaxed);
        shared
            .limiter_enabled
            .store(if plan.limiter_enabled { 1 } else { 0 }, Ordering::Relaxed);
        shared
            .limiter_ceiling_linear
            .store(plan.limiter_ceiling_linear.to_bits(), Ordering::Relaxed);
        shared
            .section_count
            .store(u32::from(plan.section_count), Ordering::Relaxed);
        for (index, c) in plan.sections.iter().copied().enumerate() {
            let base = index * 5;
            for (slot, value) in [c.b0, c.b1, c.b2, c.a1, c.a2].into_iter().enumerate() {
                shared.coefficients[base + slot].store(value.to_bits(), Ordering::Relaxed);
            }
        }
        let complete = writing.wrapping_add(1);
        shared.generation.store(complete, Ordering::Release);
        complete
    }

    pub fn snapshot(&self) -> Option<(u32, LiveDspPlan)> {
        snapshot_layout(self.layout())
    }

    fn layout(&self) -> &SharedOutputDspLayout {
        unsafe { self.layout.as_ref() }
    }
}

impl SharedOutputDspReader {
    pub fn try_open(path: &Path) -> io::Result<Self> {
        let file = OpenOptions::new().read(true).open(path)?;
        if file.metadata()?.len() < std::mem::size_of::<SharedOutputDspLayout>() as u64 {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "DSP shared block is too small"));
        }
        let layout = map_layout(&file, false)?;
        let reader = Self {
            _file: file,
            layout,
        };
        let shared = reader.layout();
        if shared.magic.load(Ordering::Acquire) != OUTPUT_DSP_SHARED_MAGIC
            || shared.version.load(Ordering::Acquire) != OUTPUT_DSP_SHARED_VERSION
        {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "DSP shared block magic/version mismatch",
            ));
        }
        Ok(reader)
    }

    pub fn snapshot(&self) -> Option<(u32, LiveDspPlan)> {
        snapshot_layout(self.layout())
    }

    fn layout(&self) -> &SharedOutputDspLayout {
        unsafe { self.layout.as_ref() }
    }
}

impl Drop for SharedOutputDspWriter {
    fn drop(&mut self) {
        unmap_layout(self.layout);
    }
}

impl Drop for SharedOutputDspReader {
    fn drop(&mut self) {
        unmap_layout(self.layout);
    }
}

fn snapshot_layout(shared: &SharedOutputDspLayout) -> Option<(u32, LiveDspPlan)> {
    for _ in 0..4 {
        let before = shared.generation.load(Ordering::Acquire);
        if before == 0 || before & 1 != 0 {
            continue;
        }
        let channels = shared.channels.load(Ordering::Relaxed) as usize;
        let section_count = shared.section_count.load(Ordering::Relaxed) as usize;
        if channels == 0 || channels > MAX_LIVE_CHANNELS || section_count > MAX_LIVE_SECTIONS {
            return None;
        }
        let mut sections = [LiveBiquadCoefficients::default(); MAX_LIVE_SECTIONS];
        for (index, section) in sections.iter_mut().enumerate().take(section_count) {
            let base = index * 5;
            *section = LiveBiquadCoefficients {
                b0: f32::from_bits(shared.coefficients[base].load(Ordering::Relaxed)),
                b1: f32::from_bits(shared.coefficients[base + 1].load(Ordering::Relaxed)),
                b2: f32::from_bits(shared.coefficients[base + 2].load(Ordering::Relaxed)),
                a1: f32::from_bits(shared.coefficients[base + 3].load(Ordering::Relaxed)),
                a2: f32::from_bits(shared.coefficients[base + 4].load(Ordering::Relaxed)),
            };
        }
        let plan = LiveDspPlan {
            bypassed: shared.bypassed.load(Ordering::Relaxed) != 0,
            channels: channels as u8,
            preamp_linear: f32::from_bits(shared.preamp_linear.load(Ordering::Relaxed)),
            output_gain_linear: f32::from_bits(shared.output_gain_linear.load(Ordering::Relaxed)),
            limiter_enabled: shared.limiter_enabled.load(Ordering::Relaxed) != 0,
            limiter_ceiling_linear: f32::from_bits(
                shared.limiter_ceiling_linear.load(Ordering::Relaxed),
            ),
            section_count: section_count as u8,
            sections,
        };
        let after = shared.generation.load(Ordering::Acquire);
        if before == after && after & 1 == 0 {
            return Some((after, plan));
        }
    }
    None
}

fn map_layout(file: &File, writable: bool) -> io::Result<NonNull<SharedOutputDspLayout>> {
    let prot = if writable {
        libc::PROT_READ | libc::PROT_WRITE
    } else {
        libc::PROT_READ
    };
    let pointer = unsafe {
        libc::mmap(
            std::ptr::null_mut(),
            std::mem::size_of::<SharedOutputDspLayout>(),
            prot,
            libc::MAP_SHARED,
            file.as_raw_fd(),
            0,
        )
    };
    if pointer == libc::MAP_FAILED {
        return Err(io::Error::last_os_error());
    }
    NonNull::new(pointer.cast::<SharedOutputDspLayout>())
        .ok_or_else(|| io::Error::other("mmap returned null"))
}

fn unmap_layout(layout: NonNull<SharedOutputDspLayout>) {
    unsafe {
        libc::munmap(
            layout.as_ptr().cast::<libc::c_void>(),
            std::mem::size_of::<SharedOutputDspLayout>(),
        );
    }
}
