use serde::{Deserialize,Serialize};
#[derive(Clone,Debug,Eq,PartialEq,Hash,Serialize,Deserialize)] pub struct LogicalAudioDeviceId(pub String);
#[derive(Clone,Debug,Eq,PartialEq,Serialize,Deserialize)] pub struct LogicalDeviceDescriptor{pub id:LogicalAudioDeviceId,pub vendor:Option<String>,pub product:Option<String>,pub serial:Option<String>,pub profile:Option<String>}
impl LogicalDeviceDescriptor{pub fn stable(vendor:Option<&str>,product:Option<&str>,serial:Option<&str>,profile:Option<&str>)->Self{let key=format!("{}|{}|{}|{}",vendor.unwrap_or(""),product.unwrap_or(""),serial.unwrap_or(""),profile.unwrap_or(""));Self{id:LogicalAudioDeviceId(key),vendor:vendor.map(str::to_owned),product:product.map(str::to_owned),serial:serial.map(str::to_owned),profile:profile.map(str::to_owned)}}}
