use aetherstream_core::{AccountId, WindowId};
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct WindowPlacement {
    pub window_id: WindowId, pub monitor_name: Option<String>, pub x: f32, pub y: f32,
    pub width: f32, pub height: f32, pub maximized: bool, pub panel: String,
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct WorkspacePreset {
    pub name: String, pub account: Option<AccountId>, pub role: String,
    pub windows: Vec<WindowPlacement>, pub dock_json: String,
}
impl WorkspacePreset {
    pub fn fixture_three_monitors() -> Self {
        let windows = ["DP-1", "DP-2", "HDMI-A-1"].into_iter().enumerate().map(|(i, monitor)| WindowPlacement {
            window_id: WindowId::new(), monitor_name: Some(monitor.into()), x: (i as f32) * 100.0, y: 0.0,
            width: 800.0, height: 600.0, maximized: false, panel: format!("panel-{i}"),
        }).collect();
        Self { name: "Forge Master".into(), account: None, role: "streamer".into(), windows, dock_json: "{}".into() }
    }
}
