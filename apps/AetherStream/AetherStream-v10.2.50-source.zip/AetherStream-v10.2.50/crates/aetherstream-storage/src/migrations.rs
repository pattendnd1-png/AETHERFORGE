pub const SCHEMA_V1: &str = r#"
CREATE TABLE IF NOT EXISTS workspace_presets (
    name TEXT PRIMARY KEY NOT NULL,
    body_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_metadata (
    key TEXT PRIMARY KEY NOT NULL,
    value TEXT NOT NULL
);
"#;

pub const SCHEMA_V2: &str = r#"
CREATE TABLE IF NOT EXISTS broadcast_sessions (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    body_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_broadcast_sessions_name ON broadcast_sessions(name);
CREATE TABLE IF NOT EXISTS session_requirements (
    session_id TEXT NOT NULL,
    capability TEXT NOT NULL,
    level TEXT NOT NULL,
    PRIMARY KEY(session_id, capability)
);
CREATE TABLE IF NOT EXISTS session_summaries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    ended_at_ms INTEGER NOT NULL,
    duration_ms INTEGER NOT NULL,
    status TEXT NOT NULL,
    body_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS control_preferences (
    key TEXT PRIMARY KEY NOT NULL,
    value_json TEXT NOT NULL
);
"#;


pub const SCHEMA_V3: &str = r#"
CREATE TABLE IF NOT EXISTS account_metadata (
    account_key TEXT PRIMARY KEY NOT NULL,
    provider TEXT NOT NULL,
    body_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_account_metadata_provider ON account_metadata(provider);
"#;


pub const SCHEMA_V4: &str = r#"
CREATE TABLE IF NOT EXISTS output_dsp_profiles (
    device_id TEXT PRIMARY KEY NOT NULL,
    body_json TEXT NOT NULL
);
"#;
