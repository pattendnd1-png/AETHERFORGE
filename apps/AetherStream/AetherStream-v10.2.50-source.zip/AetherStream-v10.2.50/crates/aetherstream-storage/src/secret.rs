use secret_service::{blocking::SecretService, EncryptionType};
use std::{collections::HashMap, fmt, sync::Mutex};
use thiserror::Error;

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub struct SecretKey(pub String);

#[derive(Clone, Eq, PartialEq)]
pub struct SecretBytes(Vec<u8>);

impl SecretBytes {
    #[must_use]
    pub fn new(bytes: impl Into<Vec<u8>>) -> Self {
        Self(bytes.into())
    }

    #[must_use]
    pub fn as_slice(&self) -> &[u8] {
        &self.0
    }
}

impl fmt::Debug for SecretBytes {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "SecretBytes([REDACTED; {} bytes])", self.0.len())
    }
}

#[derive(Debug, Error)]
pub enum SecretError {
    #[error("secret store unavailable")]
    Unavailable,
}

pub trait SecretStore: Send + Sync {
    fn store(&self, key: SecretKey, value: SecretBytes) -> Result<(), SecretError>;
    fn load(&self, key: &SecretKey) -> Result<Option<SecretBytes>, SecretError>;
    fn remove(&self, key: &SecretKey) -> Result<(), SecretError>;
}

#[derive(Clone, Copy, Debug, Default)]
pub struct LinuxSecretStore;

impl LinuxSecretStore {
    fn service() -> Result<SecretService<'static>, SecretError> {
        SecretService::connect(EncryptionType::Dh).map_err(|_| SecretError::Unavailable)
    }

    fn attributes(key: &SecretKey) -> HashMap<&str, &str> {
        HashMap::from([("application", "aetherstream"), ("key", key.0.as_str())])
    }
}

impl SecretStore for LinuxSecretStore {
    fn store(&self, key: SecretKey, value: SecretBytes) -> Result<(), SecretError> {
        let service = Self::service()?;
        let collection = service
            .get_default_collection()
            .map_err(|_| SecretError::Unavailable)?;
        collection
            .ensure_unlocked()
            .map_err(|_| SecretError::Unavailable)?;
        collection
            .create_item(
                "AetherStream credential",
                Self::attributes(&key),
                value.as_slice(),
                true,
                "application/octet-stream",
            )
            .map_err(|_| SecretError::Unavailable)?;
        Ok(())
    }

    fn load(&self, key: &SecretKey) -> Result<Option<SecretBytes>, SecretError> {
        let service = Self::service()?;
        let mut items = service
            .search_items(Self::attributes(key))
            .map_err(|_| SecretError::Unavailable)?;
        if let Some(item) = items.unlocked.pop() {
            return item
                .get_secret()
                .map(SecretBytes::new)
                .map(Some)
                .map_err(|_| SecretError::Unavailable);
        }
        if let Some(item) = items.locked.pop() {
            item.unlock().map_err(|_| SecretError::Unavailable)?;
            return item
                .get_secret()
                .map(SecretBytes::new)
                .map(Some)
                .map_err(|_| SecretError::Unavailable);
        }
        Ok(None)
    }

    fn remove(&self, key: &SecretKey) -> Result<(), SecretError> {
        let service = Self::service()?;
        let items = service
            .search_items(Self::attributes(key))
            .map_err(|_| SecretError::Unavailable)?;
        for item in items.unlocked {
            item.delete().map_err(|_| SecretError::Unavailable)?;
        }
        for item in items.locked {
            item.unlock().map_err(|_| SecretError::Unavailable)?;
            item.delete().map_err(|_| SecretError::Unavailable)?;
        }
        Ok(())
    }
}

#[derive(Default)]
pub struct MemorySecretStore {
    values: Mutex<HashMap<SecretKey, SecretBytes>>,
}

impl SecretStore for MemorySecretStore {
    fn store(&self, key: SecretKey, value: SecretBytes) -> Result<(), SecretError> {
        self.values
            .lock()
            .map_err(|_| SecretError::Unavailable)?
            .insert(key, value);
        Ok(())
    }

    fn load(&self, key: &SecretKey) -> Result<Option<SecretBytes>, SecretError> {
        Ok(self
            .values
            .lock()
            .map_err(|_| SecretError::Unavailable)?
            .get(key)
            .cloned())
    }

    fn remove(&self, key: &SecretKey) -> Result<(), SecretError> {
        self.values
            .lock()
            .map_err(|_| SecretError::Unavailable)?
            .remove(key);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn debug_output_redacts_secret_bytes() {
        let value = SecretBytes::new(b"oauth:do-not-log".to_vec());
        let debug = format!("{value:?}");
        assert!(debug.contains("REDACTED"));
        assert!(!debug.contains("oauth:"));
    }
}
