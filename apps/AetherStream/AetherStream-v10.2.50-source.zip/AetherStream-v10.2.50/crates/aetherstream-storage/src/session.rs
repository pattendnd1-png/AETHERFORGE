use crate::{StateDb, StorageError};
use aetherstream_control::BroadcastSession;
use aetherstream_core::SessionId;
use rusqlite::params;
use serde::{Deserialize, Serialize};

pub struct SessionStore;

impl SessionStore {
    pub fn save(db: &StateDb, session: &BroadcastSession) -> Result<(), StorageError> {
        let body = serde_json::to_string(session)?;
        let transaction = db.conn.unchecked_transaction()?;
        transaction.execute(
            "INSERT INTO broadcast_sessions(id, name, body_json) VALUES(?1, ?2, ?3) ON CONFLICT(id) DO UPDATE SET name=excluded.name, body_json=excluded.body_json",
            params![session.id.to_string(), &session.name, body],
        )?;
        transaction.execute(
            "DELETE FROM session_requirements WHERE session_id=?1",
            [session.id.to_string()],
        )?;
        for requirement in &session.requirements {
            transaction.execute(
                "INSERT INTO session_requirements(session_id, capability, level) VALUES(?1, ?2, ?3)",
                params![
                    session.id.to_string(),
                    &requirement.capability,
                    format!("{:?}", requirement.level),
                ],
            )?;
        }
        transaction.commit()?;
        Ok(())
    }

    pub fn get(db: &StateDb, id: SessionId) -> Result<Option<BroadcastSession>, StorageError> {
        let mut stmt = db
            .conn
            .prepare("SELECT body_json FROM broadcast_sessions WHERE id=?1")?;
        let mut rows = stmt.query([id.to_string()])?;
        let Some(row) = rows.next()? else {
            return Ok(None);
        };
        let body: String = row.get(0)?;
        Ok(Some(serde_json::from_str(&body)?))
    }

    pub fn list(db: &StateDb) -> Result<Vec<BroadcastSession>, StorageError> {
        let mut stmt = db
            .conn
            .prepare("SELECT body_json FROM broadcast_sessions ORDER BY name, id")?;
        let rows = stmt.query_map([], |row| row.get::<_, String>(0))?;
        let mut sessions = Vec::new();
        for body in rows {
            sessions.push(serde_json::from_str(&body?)?);
        }
        Ok(sessions)
    }

    pub fn delete(db: &StateDb, id: SessionId) -> Result<(), StorageError> {
        let transaction = db.conn.unchecked_transaction()?;
        transaction.execute(
            "DELETE FROM session_requirements WHERE session_id=?1",
            [id.to_string()],
        )?;
        transaction.execute("DELETE FROM broadcast_sessions WHERE id=?1", [id.to_string()])?;
        transaction.commit()?;
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct SessionSummary {
    pub session_id: SessionId,
    pub ended_at_ms: i64,
    pub duration_ms: u64,
    pub status: String,
    pub media_project: Option<String>,
}

pub struct SessionSummaryStore;

impl SessionSummaryStore {
    pub fn save(db: &StateDb, summary: &SessionSummary) -> Result<(), StorageError> {
        let body = serde_json::to_string(summary)?;
        db.conn.execute(
            "INSERT INTO session_summaries(session_id, ended_at_ms, duration_ms, status, body_json) VALUES(?1, ?2, ?3, ?4, ?5)",
            params![
                summary.session_id.to_string(),
                summary.ended_at_ms,
                summary.duration_ms,
                &summary.status,
                body,
            ],
        )?;
        Ok(())
    }

    pub fn list(db: &StateDb, session_id: SessionId) -> Result<Vec<SessionSummary>, StorageError> {
        let mut stmt = db.conn.prepare(
            "SELECT body_json FROM session_summaries WHERE session_id=?1 ORDER BY ended_at_ms DESC, id DESC",
        )?;
        let rows = stmt.query_map([session_id.to_string()], |row| row.get::<_, String>(0))?;
        let mut summaries = Vec::new();
        for body in rows {
            summaries.push(serde_json::from_str(&body?)?);
        }
        Ok(summaries)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn broadcast_session_round_trip_uses_references_not_copied_secrets() {
        let db = StateDb::in_memory().unwrap();
        let session = BroadcastSession::fixture();
        SessionStore::save(&db, &session).unwrap();
        assert_eq!(SessionStore::get(&db, session.id).unwrap(), Some(session));
    }

    #[test]
    fn session_schema_has_no_secret_columns() {
        let db = StateDb::in_memory().unwrap();
        let schema = db.schema_sql().unwrap().to_ascii_lowercase();
        for forbidden in ["token", "password", "oauth", "secret"] {
            for line in schema.lines().filter(|line| line.contains("broadcast_sessions") || line.contains("session_requirements") || line.contains("session_summaries")) {
                assert!(!line.contains(forbidden), "forbidden session schema term {forbidden}: {line}");
            }
        }
    }
}
