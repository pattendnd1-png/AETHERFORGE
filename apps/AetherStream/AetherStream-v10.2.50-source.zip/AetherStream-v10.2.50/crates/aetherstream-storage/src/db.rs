use aetherstream_core::OutputDspProfile;
use crate::{migrations::{SCHEMA_V1, SCHEMA_V2, SCHEMA_V3, SCHEMA_V4}, WorkspacePreset};
use rusqlite::{params, Connection};
use std::collections::BTreeMap;
use std::path::Path;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum StorageError {
    #[error("sqlite: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
}

pub struct StateDb {
    pub(crate) conn: Connection,
}

impl StateDb {
    pub fn in_memory() -> Result<Self, StorageError> {
        let conn = Connection::open_in_memory()?;
        let db = Self { conn };
        db.migrate()?;
        Ok(db)
    }

    pub fn open(path: impl AsRef<Path>) -> Result<Self, StorageError> {
        let path = path.as_ref();
        if path.exists() {
            let backup = path.with_extension("pre-v10.2.13.bak");
            if !backup.exists() {
                std::fs::copy(path, backup)?;
            }
        }
        let conn = Connection::open(path)?;
        let db = Self { conn };
        db.migrate()?;
        Ok(db)
    }

    fn migrate(&self) -> Result<(), StorageError> {
        let transaction = self.conn.unchecked_transaction()?;
        transaction.execute_batch(SCHEMA_V1)?;
        transaction.execute_batch(SCHEMA_V2)?;
        transaction.execute_batch(SCHEMA_V3)?;
        transaction.execute_batch(SCHEMA_V4)?;
        transaction.commit()?;
        Ok(())
    }

    pub fn save_workspace(&self, preset: &WorkspacePreset) -> Result<(), StorageError> {
        let body = serde_json::to_string(preset)?;
        self.conn.execute(
            "INSERT INTO workspace_presets(name, body_json) VALUES(?1, ?2) ON CONFLICT(name) DO UPDATE SET body_json=excluded.body_json",
            params![&preset.name, body],
        )?;
        Ok(())
    }

    pub fn load_workspace(&self, name: &str) -> Result<Option<WorkspacePreset>, StorageError> {
        let mut stmt = self.conn.prepare("SELECT body_json FROM workspace_presets WHERE name=?1")?;
        let mut rows = stmt.query([name])?;
        let Some(row) = rows.next()? else {
            return Ok(None);
        };
        let body: String = row.get(0)?;
        Ok(Some(serde_json::from_str(&body)?))
    }


    pub fn save_output_dsp_profile(
        &self,
        device_id: &str,
        profile: &OutputDspProfile,
    ) -> Result<(), StorageError> {
        let body = serde_json::to_string(profile)?;
        self.conn.execute(
            "INSERT INTO output_dsp_profiles(device_id, body_json) VALUES(?1, ?2) ON CONFLICT(device_id) DO UPDATE SET body_json=excluded.body_json",
            params![device_id, body],
        )?;
        Ok(())
    }

    pub fn load_output_dsp_profiles(&self) -> Result<BTreeMap<String, OutputDspProfile>, StorageError> {
        let mut stmt = self
            .conn
            .prepare("SELECT device_id, body_json FROM output_dsp_profiles ORDER BY device_id")?;
        let rows = stmt.query_map([], |row| {
            Ok((row.get::<_, String>(0)?, row.get::<_, String>(1)?))
        })?;
        let mut profiles = BTreeMap::new();
        for row in rows {
            let (device_id, body) = row?;
            let mut profile: OutputDspProfile = serde_json::from_str(&body)?;
            profile.normalize_parametric_eq();
            profiles.insert(device_id, profile);
        }
        Ok(profiles)
    }

    pub fn schema_sql(&self) -> Result<String, StorageError> {
        let mut stmt = self.conn.prepare(
            "SELECT sql FROM sqlite_master WHERE type='table' AND sql IS NOT NULL ORDER BY name",
        )?;
        let rows = stmt.query_map([], |row| row.get::<_, String>(0))?;
        let mut out = String::new();
        for row in rows {
            out.push_str(&row?);
            out.push('\n');
        }
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn workspace_round_trip_preserves_multi_monitor_windows() {
        let db = StateDb::in_memory().unwrap();
        let preset = WorkspacePreset::fixture_three_monitors();
        db.save_workspace(&preset).unwrap();
        assert_eq!(db.load_workspace(&preset.name).unwrap(), Some(preset));
    }

    #[test]
    fn sqlite_schema_has_no_bearer_token_columns() {
        let db = StateDb::in_memory().unwrap();
        let schema = db.schema_sql().unwrap().to_ascii_lowercase();
        for forbidden in ["access_token", "refresh_token", "oauth_token"] {
            assert!(!schema.contains(forbidden));
        }
    }
}
