use crate::{StateDb, StorageError};
use aetherstream_core::{AccountId, AuthProvider};
use rusqlite::params;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct AccountMetadata {
    pub account: AccountId,
    pub provider: AuthProvider,
    pub display_name: Option<String>,
    pub is_default: bool,
    pub restore_enabled: bool,
    pub last_status: Option<String>,
}

pub struct AccountMetadataStore;

impl AccountMetadataStore {
    pub fn save(db: &StateDb, metadata: &AccountMetadata) -> Result<(), StorageError> {
        let body = serde_json::to_string(metadata)?;
        db.conn.execute(
            "INSERT INTO account_metadata(account_key, provider, body_json) VALUES(?1, ?2, ?3) ON CONFLICT(account_key) DO UPDATE SET provider=excluded.provider, body_json=excluded.body_json",
            params![metadata.account.to_string(), format!("{:?}", metadata.provider), body],
        )?;
        Ok(())
    }

    pub fn list(db: &StateDb) -> Result<Vec<AccountMetadata>, StorageError> {
        let mut stmt = db.conn.prepare("SELECT body_json FROM account_metadata ORDER BY provider, account_key")?;
        let rows = stmt.query_map([], |row| row.get::<_, String>(0))?;
        let mut values = Vec::new();
        for body in rows {
            values.push(serde_json::from_str(&body?)?);
        }
        Ok(values)
    }

    pub fn default_for(db: &StateDb, provider: AuthProvider) -> Result<Option<AccountMetadata>, StorageError> {
        Ok(Self::list(db)?
            .into_iter()
            .find(|metadata| metadata.provider == provider && metadata.is_default && metadata.restore_enabled))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn metadata_round_trip_keeps_only_safe_account_fields() {
        let db = StateDb::in_memory().unwrap();
        let metadata = AccountMetadata {
            account: AccountId::new(),
            provider: AuthProvider::Streamlabs,
            display_name: Some("Creator".into()),
            is_default: true,
            restore_enabled: true,
            last_status: Some("Connected".into()),
        };
        AccountMetadataStore::save(&db, &metadata).unwrap();
        assert_eq!(AccountMetadataStore::list(&db).unwrap(), vec![metadata]);
        let schema = db.schema_sql().unwrap().to_ascii_lowercase();
        for forbidden in ["access_token", "refresh_token", "client_secret", "password"] {
            assert!(!schema.contains(forbidden));
        }
    }
}
