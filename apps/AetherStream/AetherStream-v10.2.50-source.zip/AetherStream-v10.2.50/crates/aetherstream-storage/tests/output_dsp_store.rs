use aetherstream_core::{OutputDeviceClass, OutputDspProfile};
use aetherstream_storage::StateDb;

#[test]
fn output_dsp_profile_round_trip_is_keyed_by_physical_device_id() {
    let db = StateDb::in_memory().unwrap();
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Iem);
    profile.name = "My IEM".into();
    db.save_output_dsp_profile("alsa-card-1:analog-stereo", &profile)
        .unwrap();

    let loaded = db.load_output_dsp_profiles().unwrap();
    assert_eq!(loaded.get("alsa-card-1:analog-stereo"), Some(&profile));
}

#[test]
fn saving_same_device_replaces_profile_without_duplicate_rows() {
    let db = StateDb::in_memory().unwrap();
    let first = OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker);
    let second = OutputDspProfile::factory(OutputDeviceClass::StudioMonitor);
    db.save_output_dsp_profile("device-1", &first).unwrap();
    db.save_output_dsp_profile("device-1", &second).unwrap();
    let loaded = db.load_output_dsp_profiles().unwrap();
    assert_eq!(loaded.len(), 1);
    assert_eq!(loaded.get("device-1"), Some(&second));
}

#[test]
fn gaming_mode_round_trip_is_persisted_per_device() {
    let db = StateDb::in_memory().unwrap();
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::TvSpeaker);
    profile.gaming.enabled = true;
    profile.gaming.detail_db = 2.75;
    db.save_output_dsp_profile("hdmi-tv-living-room", &profile).unwrap();

    let loaded = db.load_output_dsp_profiles().unwrap();
    assert_eq!(loaded.get("hdmi-tv-living-room"), Some(&profile));
}
