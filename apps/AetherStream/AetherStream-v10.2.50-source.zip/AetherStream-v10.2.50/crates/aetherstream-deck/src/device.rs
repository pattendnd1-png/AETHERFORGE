use crate::{DeckInputEvent, DeckParseError};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DeckPlusModel { pub key_count:u8,pub dial_count:u8,pub touch_width:u16,pub touch_height:u16 }
impl DeckPlusModel { #[must_use] pub const fn canonical()->Self{Self{key_count:8,dial_count:4,touch_width:800,touch_height:100}} }

pub trait DeckTransport: Send {
    fn serial(&self)->&str;
    fn read_event(&mut self)->Result<DeckInputEvent,DeckParseError>;
    fn set_key_image(&mut self,key:u8,jpeg:&[u8])->Result<(),String>;
    fn set_touch_image(&mut self,x:u16,width:u16,jpeg:&[u8])->Result<(),String>;
}

#[cfg(test)] mod tests{use super::*;#[test]fn stream_deck_plus_geometry_is_eight_keys_four_dials_and_touch_strip(){let m=DeckPlusModel::canonical();assert_eq!(m.key_count,8);assert_eq!(m.dial_count,4);assert_eq!(m.touch_width,800);assert_eq!(m.touch_height,100);}}
