use crate::DeckBinding;
use aetherstream_control::AetherState;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ImageFrame {
    pub width: u16,
    pub height: u16,
    pub jpeg: Vec<u8>,
}

impl ImageFrame {
    pub fn validate(&self) -> Result<(), String> {
        if self.width == 0 || self.height == 0 {
            return Err("zero-sized frame".into());
        }
        if self.jpeg.is_empty() {
            return Err("empty image payload".into());
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct DeckFeedback {
    pub active: bool,
    pub label: Option<String>,
    pub value: Option<f32>,
}

impl DeckFeedback {
    #[must_use]
    pub fn from_binding(binding: &DeckBinding, state: &AetherState) -> Self {
        Self {
            active: binding.is_active(state),
            label: state.obs.active_scene.clone(),
            value: None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deck_feedback_reflects_shared_scene_state() {
        let binding = DeckBinding::scene("Gameplay");
        let mut state = AetherState::default();
        state.obs.active_scene = Some("Gameplay".into());
        let feedback = DeckFeedback::from_binding(&binding, &state);
        assert!(feedback.active);
        assert_eq!(feedback.label.as_deref(), Some("Gameplay"));
    }
}
