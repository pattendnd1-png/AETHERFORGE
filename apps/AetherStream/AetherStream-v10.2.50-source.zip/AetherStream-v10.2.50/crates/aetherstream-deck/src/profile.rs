use crate::{DeckControl, DeckGesture};
use aetherstream_control::AetherState;
use aetherstream_core::AetherStreamAction;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Binding {
    pub control: DeckControl,
    pub gesture: DeckGesture,
    pub actions: Vec<AetherStreamAction>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DeckProfile {
    pub schema_version: u16,
    pub name: String,
    pub theme: String,
    pub bindings: Vec<Binding>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum StateSelector {
    ObsScene(String),
    AudioBusMuted(String),
    StreamLive,
    RecordingActive,
    DeckProfile(String),
}

impl StateSelector {
    #[must_use]
    pub fn matches(&self, state: &AetherState) -> bool {
        match self {
            Self::ObsScene(scene) => state.obs.active_scene.as_deref() == Some(scene.as_str()),
            Self::AudioBusMuted(bus) => state.audio.buses.get(bus).is_some_and(|state| state.muted),
            Self::StreamLive => state.stream.live,
            Self::RecordingActive => state.recording.active,
            Self::DeckProfile(profile) => state.deck.profile.as_deref() == Some(profile.as_str()),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DeckBinding {
    pub action: AetherStreamAction,
    pub active_when: Option<StateSelector>,
}

impl DeckBinding {
    #[must_use]
    pub fn scene(scene: impl Into<String>) -> Self {
        let scene = scene.into();
        Self {
            action: AetherStreamAction::ObsScene(scene.clone()),
            active_when: Some(StateSelector::ObsScene(scene)),
        }
    }

    #[must_use]
    pub fn is_active(&self, state: &AetherState) -> bool {
        self.active_when
            .as_ref()
            .is_some_and(|selector| selector.matches(state))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gameplay_scene_binding_uses_shared_state() {
        let binding = DeckBinding::scene("Gameplay");
        let mut state = AetherState::default();
        state.obs.active_scene = Some("Gameplay".into());
        assert!(binding.is_active(&state));
        assert_eq!(binding.action, AetherStreamAction::ObsScene("Gameplay".into()));
    }
}
