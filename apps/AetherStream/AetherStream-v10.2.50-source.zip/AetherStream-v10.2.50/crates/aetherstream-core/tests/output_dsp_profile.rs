use aetherstream_core::{
    bluetooth_loadout_id, OutputDeviceClass, OutputDspProfile, OutputFilter, OutputFilterKind,
};

#[test]
fn every_output_device_class_has_a_valid_factory_profile() {
    for class in OutputDeviceClass::ALL {
        let profile = OutputDspProfile::factory(class);
        assert_eq!(profile.device_class, class);
        profile.validate(48_000.0, 2).unwrap();
    }
}

#[test]
fn factory_profiles_cover_requested_physical_output_families() {
    let names: Vec<_> = OutputDeviceClass::ALL.iter().map(|class| class.label()).collect();
    for required in [
        "Desktop speakers", "Bookshelf speakers", "Studio monitors",
        "Desktop monitor speakers", "TV speakers", "Soundbar", "2.1 speakers", "5.1 speakers", "7.1 speakers", "Open-back headphones",
        "Closed-back headphones", "Gaming headset", "IEM", "Wired earbuds",
        "Bluetooth earbuds", "Bluetooth headphones", "Bluetooth portable speaker",
        "Bluetooth 360° speaker", "Bluetooth stereo portable speaker",
        "Bluetooth desktop speaker", "Bluetooth bookshelf speakers",
        "Bluetooth 2.0 speakers", "Bluetooth 2.1 speakers", "Bluetooth soundbar",
        "Bluetooth soundbar + subwoofer", "Bluetooth TV speaker",
        "Bluetooth smart/home speaker", "Bluetooth party speaker",
        "Bluetooth outdoor speaker", "Bluetooth PA speaker",
        "Bluetooth multi-speaker / stereo pair",
        "Ultimate Ears WONDERBOOM 4 — 360° Bluetooth speaker",
        "Vehicle audio", "External audio", "Custom",
    ] {
        assert!(names.contains(&required), "missing {required}");
    }
}

#[test]
fn invalid_filter_frequency_q_and_gain_are_rejected() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.filters.push(OutputFilter {
        enabled: true,
        kind: OutputFilterKind::Peak,
        frequency_hz: 99_000.0,
        gain_db: 40.0,
        q: 0.0,
        slope_db_per_octave: 12,
    });
    assert!(profile.validate(48_000.0, 2).is_err());
}

#[test]
fn iem_and_earbud_factory_profiles_reserve_headroom() {
    for class in [
        OutputDeviceClass::Iem,
        OutputDeviceClass::WiredEarbud,
        OutputDeviceClass::BluetoothEarbud,
    ] {
        let profile = OutputDspProfile::factory(class);
        assert!(profile.preamp_db <= -2.0);
        assert!(profile.limiter.enabled);
        assert!(profile.limiter.ceiling_dbfs <= -1.0);
    }
}

#[test]
fn tv_speaker_factory_profile_is_small_driver_safe() {
    let profile = OutputDspProfile::factory(OutputDeviceClass::TvSpeaker);
    assert!(profile.preamp_db <= -5.0);
    let high_pass = profile.filters.iter().find(|filter| filter.kind == OutputFilterKind::HighPass).unwrap();
    assert!(high_pass.frequency_hz >= 80.0);
    assert!(high_pass.slope_db_per_octave >= 24);
    assert!(profile.limiter.enabled);
}

#[test]
fn desktop_monitor_speaker_factory_profile_is_small_driver_safe() {
    let profile = OutputDspProfile::factory(OutputDeviceClass::DesktopMonitorSpeaker);
    assert!(profile.preamp_db <= -4.5);
    let high_pass = profile.filters.iter().find(|filter| filter.kind == OutputFilterKind::HighPass).unwrap();
    assert!(high_pass.frequency_hz >= 90.0);
    assert!(high_pass.slope_db_per_octave >= 24);
    assert!(profile.limiter.enabled);
}

#[test]
fn display_speaker_classifier_distinguishes_tv_from_desktop_monitor() {
    assert_eq!(OutputDeviceClass::for_display_speakers(true), OutputDeviceClass::TvSpeaker);
    assert_eq!(
        OutputDeviceClass::for_display_speakers(false),
        OutputDeviceClass::DesktopMonitorSpeaker
    );
}

#[test]
fn gaming_mode_defaults_off() {
    for class in OutputDeviceClass::ALL {
        let profile = OutputDspProfile::factory(class);
        assert!(!profile.gaming.enabled);
        profile.validate(48_000.0, 2).unwrap();
    }
}

#[test]
fn factory_profile_starts_with_fifteen_band_parametric_eq() {
    let profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    assert_eq!(profile.parametric_eq.len(), 15);
    assert!(profile.parametric_eq.iter().all(|band| (5.0..=35_000.0).contains(&band.frequency_hz)));
}

#[test]
fn parametric_eq_can_expand_to_thirty_one_bands_and_not_beyond() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.set_parametric_eq_band_count(31);
    assert_eq!(profile.parametric_eq.len(), 31);
    profile.set_parametric_eq_band_count(99);
    assert_eq!(profile.parametric_eq.len(), 31);
    profile.set_parametric_eq_band_count(1);
    assert_eq!(profile.parametric_eq.len(), 15);
}

#[test]
fn parametric_eq_configuration_accepts_five_hz_through_thirty_five_khz() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.parametric_eq[0].frequency_hz = 5.0;
    profile.parametric_eq[1].frequency_hz = 35_000.0;
    profile.validate(48_000.0, 2).unwrap();
}

#[test]
fn legacy_parametric_filters_migrate_into_dedicated_bank() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.parametric_eq.clear();
    profile.filters.push(OutputFilter {
        enabled: true,
        kind: OutputFilterKind::Peak,
        frequency_hz: 777.0,
        gain_db: 3.0,
        q: 1.2,
        slope_db_per_octave: 12,
    });
    profile.normalize_parametric_eq();
    assert_eq!(profile.parametric_eq.len(), 15);
    assert!(profile.parametric_eq.iter().any(|band| band.frequency_hz == 777.0 && band.gain_db == 3.0));
    assert!(!profile.filters.iter().any(|filter| filter.kind == OutputFilterKind::Peak));
}


#[test]
fn wonderboom4_is_a_dedicated_360_degree_bluetooth_speaker_profile() {
    for alias in [
        "WONDERBOOM 4",
        "UE WONDERBOOM 4",
        "Ultimate Ears WONDERBOOM 4",
    ] {
        assert_eq!(
            OutputDeviceClass::for_bluetooth_speaker_name(alias),
            OutputDeviceClass::UltimateEarsWonderboom4
        );
    }
    let profile = OutputDspProfile::factory(OutputDeviceClass::UltimateEarsWonderboom4);
    assert!(profile.device_class.is_bluetooth_speaker());
    assert!(profile.preamp_db <= -5.0);
    assert!(profile.limiter.enabled);
    assert_eq!(profile.parametric_eq.len(), 15);
}

#[test]
fn bluetooth_loadout_identity_prefers_stable_bluez_address() {
    assert_eq!(
        bluetooth_loadout_id(Some("AA:BB:CC:DD:EE:FF"), "bluez_output.transient"),
        "bluetooth:aa_bb_cc_dd_ee_ff"
    );
    assert_eq!(
        bluetooth_loadout_id(None, "bluez_output.11_22_33"),
        "bluetooth:bluez_output_11_22_33"
    );
}

#[test]
fn generated_parametric_eq_sizes_pin_exact_frequency_boundaries() {
    for count in [15, 21, 25, 31] {
        let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
        profile.set_parametric_eq_band_count(count);
        assert_eq!(profile.parametric_eq.len(), count);
        assert_eq!(profile.parametric_eq.first().unwrap().frequency_hz, 5.0);
        assert_eq!(profile.parametric_eq.last().unwrap().frequency_hz, 35_000.0);
        assert!(profile
            .parametric_eq
            .iter()
            .all(|band| (5.0..=35_000.0).contains(&band.frequency_hz)));
        profile.validate(48_000.0, 2).unwrap();
    }
}

#[test]
fn legacy_peq_float_overshoot_normalizes_to_exact_upper_boundary() {
    let mut profile = OutputDspProfile::factory(OutputDeviceClass::Custom);
    profile.parametric_eq.last_mut().unwrap().frequency_hz = 35_000.01;
    profile.normalize_parametric_eq();
    assert_eq!(profile.parametric_eq.last().unwrap().frequency_hz, 35_000.0);
    profile.validate(48_000.0, 2).unwrap();
}
