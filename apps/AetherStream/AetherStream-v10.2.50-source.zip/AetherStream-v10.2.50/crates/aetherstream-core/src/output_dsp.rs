pub const HDMI3_LOADOUT_ID: &str = "hdmi3";
pub const PEQ_MIN_BANDS: usize = 15;
pub const PEQ_MAX_BANDS: usize = 31;
pub const PEQ_MIN_FREQUENCY_HZ: f32 = 5.0;
pub const PEQ_MAX_FREQUENCY_HZ: f32 = 35_000.0;

use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash, Serialize, Deserialize)]
pub enum OutputDeviceClass {
    DesktopSpeaker,
    BookshelfSpeaker,
    StudioMonitor,
    DesktopMonitorSpeaker,
    TvSpeaker,
    Soundbar,
    Speaker2_1,
    Speaker5_1,
    Speaker7_1,
    OpenBackHeadphone,
    ClosedBackHeadphone,
    GamingHeadset,
    Iem,
    WiredEarbud,
    BluetoothEarbud,
    BluetoothHeadphone,
    BluetoothPortableSpeaker,
    Bluetooth360Speaker,
    BluetoothStereoPortableSpeaker,
    BluetoothDesktopSpeaker,
    BluetoothBookshelfSpeaker,
    BluetoothSpeaker2_0,
    BluetoothSpeaker2_1,
    BluetoothSoundbar,
    BluetoothSoundbarSubwoofer,
    BluetoothTvSpeaker,
    BluetoothSmartSpeaker,
    BluetoothPartySpeaker,
    BluetoothOutdoorSpeaker,
    BluetoothPaSpeaker,
    BluetoothMultiSpeaker,
    UltimateEarsWonderboom4,
    VehicleAudio,
    ExternalAudio,
    Custom,
}

impl OutputDeviceClass {
    pub const ALL: [Self; 35] = [
        Self::DesktopSpeaker,
        Self::BookshelfSpeaker,
        Self::StudioMonitor,
        Self::DesktopMonitorSpeaker,
        Self::TvSpeaker,
        Self::Soundbar,
        Self::Speaker2_1,
        Self::Speaker5_1,
        Self::Speaker7_1,
        Self::OpenBackHeadphone,
        Self::ClosedBackHeadphone,
        Self::GamingHeadset,
        Self::Iem,
        Self::WiredEarbud,
        Self::BluetoothEarbud,
        Self::BluetoothHeadphone,
        Self::BluetoothPortableSpeaker,
        Self::Bluetooth360Speaker,
        Self::BluetoothStereoPortableSpeaker,
        Self::BluetoothDesktopSpeaker,
        Self::BluetoothBookshelfSpeaker,
        Self::BluetoothSpeaker2_0,
        Self::BluetoothSpeaker2_1,
        Self::BluetoothSoundbar,
        Self::BluetoothSoundbarSubwoofer,
        Self::BluetoothTvSpeaker,
        Self::BluetoothSmartSpeaker,
        Self::BluetoothPartySpeaker,
        Self::BluetoothOutdoorSpeaker,
        Self::BluetoothPaSpeaker,
        Self::BluetoothMultiSpeaker,
        Self::UltimateEarsWonderboom4,
        Self::VehicleAudio,
        Self::ExternalAudio,
        Self::Custom,
    ];

    #[must_use]
    pub const fn for_display_speakers(is_television: bool) -> Self {
        if is_television {
            Self::TvSpeaker
        } else {
            Self::DesktopMonitorSpeaker
        }
    }

    #[must_use]
    pub fn for_bluetooth_speaker_name(name: &str) -> Self {
        let normalized = name.trim().to_ascii_lowercase();
        if normalized.contains("ultimate ears wonderboom 4")
            || normalized.contains("ue wonderboom 4")
            || normalized.contains("wonderboom 4")
        {
            return Self::UltimateEarsWonderboom4;
        }
        if normalized.contains("soundbar") && normalized.contains("sub") {
            return Self::BluetoothSoundbarSubwoofer;
        }
        if normalized.contains("soundbar") {
            return Self::BluetoothSoundbar;
        }
        if normalized.contains("party") {
            return Self::BluetoothPartySpeaker;
        }
        if normalized.contains("outdoor") {
            return Self::BluetoothOutdoorSpeaker;
        }
        if normalized.contains("bookshelf") {
            return Self::BluetoothBookshelfSpeaker;
        }
        if normalized.contains("smart") || normalized.contains("home speaker") {
            return Self::BluetoothSmartSpeaker;
        }
        if normalized.contains("pa speaker") || normalized.contains("public address") {
            return Self::BluetoothPaSpeaker;
        }
        if normalized.contains("360") || normalized.contains("omnidirectional") {
            return Self::Bluetooth360Speaker;
        }
        Self::BluetoothPortableSpeaker
    }

    #[must_use]
    pub const fn is_bluetooth_speaker(self) -> bool {
        matches!(
            self,
            Self::BluetoothPortableSpeaker
                | Self::Bluetooth360Speaker
                | Self::BluetoothStereoPortableSpeaker
                | Self::BluetoothDesktopSpeaker
                | Self::BluetoothBookshelfSpeaker
                | Self::BluetoothSpeaker2_0
                | Self::BluetoothSpeaker2_1
                | Self::BluetoothSoundbar
                | Self::BluetoothSoundbarSubwoofer
                | Self::BluetoothTvSpeaker
                | Self::BluetoothSmartSpeaker
                | Self::BluetoothPartySpeaker
                | Self::BluetoothOutdoorSpeaker
                | Self::BluetoothPaSpeaker
                | Self::BluetoothMultiSpeaker
                | Self::UltimateEarsWonderboom4
        )
    }

    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::DesktopSpeaker => "Desktop speakers",
            Self::BookshelfSpeaker => "Bookshelf speakers",
            Self::StudioMonitor => "Studio monitors",
            Self::DesktopMonitorSpeaker => "Desktop monitor speakers",
            Self::TvSpeaker => "TV speakers",
            Self::Soundbar => "Soundbar",
            Self::Speaker2_1 => "2.1 speakers",
            Self::Speaker5_1 => "5.1 speakers",
            Self::Speaker7_1 => "7.1 speakers",
            Self::OpenBackHeadphone => "Open-back headphones",
            Self::ClosedBackHeadphone => "Closed-back headphones",
            Self::GamingHeadset => "Gaming headset",
            Self::Iem => "IEM",
            Self::WiredEarbud => "Wired earbuds",
            Self::BluetoothEarbud => "Bluetooth earbuds",
            Self::BluetoothHeadphone => "Bluetooth headphones",
            Self::BluetoothPortableSpeaker => "Bluetooth portable speaker",
            Self::Bluetooth360Speaker => "Bluetooth 360° speaker",
            Self::BluetoothStereoPortableSpeaker => "Bluetooth stereo portable speaker",
            Self::BluetoothDesktopSpeaker => "Bluetooth desktop speaker",
            Self::BluetoothBookshelfSpeaker => "Bluetooth bookshelf speakers",
            Self::BluetoothSpeaker2_0 => "Bluetooth 2.0 speakers",
            Self::BluetoothSpeaker2_1 => "Bluetooth 2.1 speakers",
            Self::BluetoothSoundbar => "Bluetooth soundbar",
            Self::BluetoothSoundbarSubwoofer => "Bluetooth soundbar + subwoofer",
            Self::BluetoothTvSpeaker => "Bluetooth TV speaker",
            Self::BluetoothSmartSpeaker => "Bluetooth smart/home speaker",
            Self::BluetoothPartySpeaker => "Bluetooth party speaker",
            Self::BluetoothOutdoorSpeaker => "Bluetooth outdoor speaker",
            Self::BluetoothPaSpeaker => "Bluetooth PA speaker",
            Self::BluetoothMultiSpeaker => "Bluetooth multi-speaker / stereo pair",
            Self::UltimateEarsWonderboom4 => "Ultimate Ears WONDERBOOM 4 — 360° Bluetooth speaker",
            Self::VehicleAudio => "Vehicle audio",
            Self::ExternalAudio => "External audio",
            Self::Custom => "Custom",
        }
    }
}

#[must_use]
pub fn bluetooth_loadout_id(address: Option<&str>, node_name: &str) -> String {
    let source = address
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| node_name.trim());
    let stable: String = source
        .chars()
        .map(|character| {
            if character.is_ascii_alphanumeric() {
                character.to_ascii_lowercase()
            } else {
                '_'
            }
        })
        .collect();
    format!("bluetooth:{stable}")
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum OutputFilterKind {
    HighPass,
    LowPass,
    BandPass,
    Peak,
    Notch,
    LowShelf,
    HighShelf,
}

impl OutputFilterKind {
    pub const ALL: [Self; 7] = [
        Self::HighPass,
        Self::BandPass,
        Self::LowPass,
        Self::Peak,
        Self::Notch,
        Self::LowShelf,
        Self::HighShelf,
    ];

    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::HighPass => "High-pass",
            Self::LowPass => "Low-pass",
            Self::BandPass => "Mid / band-pass",
            Self::Peak => "Parametric peak",
            Self::Notch => "Notch",
            Self::LowShelf => "Low shelf",
            Self::HighShelf => "High shelf",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum ParametricEqBandKind {
    Peak,
    Notch,
    LowShelf,
    HighShelf,
}

impl ParametricEqBandKind {
    pub const ALL: [Self; 4] = [Self::Peak, Self::Notch, Self::LowShelf, Self::HighShelf];

    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::Peak => "Peak",
            Self::Notch => "Notch",
            Self::LowShelf => "Low shelf",
            Self::HighShelf => "High shelf",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct OutputParametricEqBand {
    pub enabled: bool,
    pub kind: ParametricEqBandKind,
    pub frequency_hz: f32,
    pub gain_db: f32,
    pub q: f32,
}

impl OutputParametricEqBand {
    #[must_use]
    pub const fn neutral(frequency_hz: f32) -> Self {
        Self {
            enabled: true,
            kind: ParametricEqBandKind::Peak,
            frequency_hz,
            gain_db: 0.0,
            q: 1.0,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct OutputFilter {
    pub enabled: bool,
    pub kind: OutputFilterKind,
    pub frequency_hz: f32,
    pub gain_db: f32,
    pub q: f32,
    pub slope_db_per_octave: u8,
}

impl OutputFilter {
    #[must_use]
    pub fn new(kind: OutputFilterKind, frequency_hz: f32) -> Self {
        Self {
            enabled: true,
            kind,
            frequency_hz,
            gain_db: 0.0,
            q: 0.707_106_77,
            slope_db_per_octave: 12,
        }
    }

    #[must_use]
    pub fn high_pass(frequency_hz: f32, slope_db_per_octave: u8) -> Self {
        let mut filter = Self::new(OutputFilterKind::HighPass, frequency_hz);
        filter.slope_db_per_octave = slope_db_per_octave;
        filter
    }

    #[must_use]
    pub fn low_pass(frequency_hz: f32, slope_db_per_octave: u8) -> Self {
        let mut filter = Self::new(OutputFilterKind::LowPass, frequency_hz);
        filter.slope_db_per_octave = slope_db_per_octave;
        filter
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct OutputEnhancement {
    pub enabled: bool,
    pub amount_db: f32,
    pub frequency_hz: f32,
    pub q: f32,
}

impl OutputEnhancement {
    #[must_use]
    pub const fn disabled(frequency_hz: f32, q: f32) -> Self {
        Self {
            enabled: false,
            amount_db: 0.0,
            frequency_hz,
            q,
        }
    }

    #[must_use]
    pub const fn enabled(amount_db: f32, frequency_hz: f32, q: f32) -> Self {
        Self {
            enabled: true,
            amount_db,
            frequency_hz,
            q,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct OutputLimiter {
    pub enabled: bool,
    pub ceiling_dbfs: f32,
}

impl Default for OutputLimiter {
    fn default() -> Self {
        Self {
            enabled: true,
            ceiling_dbfs: -1.0,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct OutputGamingMode {
    pub enabled: bool,
    pub impact_db: f32,
    pub impact_frequency_hz: f32,
    pub mud_cut_db: f32,
    pub mud_frequency_hz: f32,
    pub detail_db: f32,
    pub detail_frequency_hz: f32,
}

impl Default for OutputGamingMode {
    fn default() -> Self {
        Self {
            enabled: false,
            impact_db: 1.5,
            impact_frequency_hz: 110.0,
            mud_cut_db: -1.5,
            mud_frequency_hz: 300.0,
            detail_db: 2.0,
            detail_frequency_hz: 2_800.0,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct OutputDspProfile {
    pub schema_version: u16,
    pub name: String,
    pub device_class: OutputDeviceClass,
    pub bypassed: bool,
    pub preamp_db: f32,
    pub filters: Vec<OutputFilter>,
    #[serde(default)]
    pub parametric_eq: Vec<OutputParametricEqBand>,
    pub bass: OutputEnhancement,
    pub clarity: OutputEnhancement,
    #[serde(default)]
    pub gaming: OutputGamingMode,
    pub output_gain_db: f32,
    pub limiter: OutputLimiter,
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum OutputDspProfileError {
    #[error("sample rate must be finite and between 8 kHz and 384 kHz")]
    InvalidSampleRate,
    #[error("channel count must be between 1 and 32")]
    InvalidChannelCount,
    #[error("gain values must be finite and between -24 dB and +24 dB")]
    InvalidGain,
    #[error("parametric EQ must contain between 15 and 31 bands")]
    InvalidParametricEqBandCount,
    #[error("filter or enhancement frequency is outside the usable audio band")]
    InvalidFrequency,
    #[error("Q must be finite and between 0.1 and 18")]
    InvalidQ,
    #[error("filter slope must be 6, 12, 18, 24, 36, or 48 dB/octave")]
    InvalidSlope,
    #[error("limiter ceiling must be finite and between -12 dBFS and 0 dBFS")]
    InvalidLimiterCeiling,
}

impl OutputDspProfile {
    #[must_use]
    pub fn factory(device_class: OutputDeviceClass) -> Self {
        let (preamp_db, high_pass_hz, high_pass_slope, bass_db, bass_hz, clarity_db, clarity_hz) =
            match device_class {
                OutputDeviceClass::DesktopSpeaker => (-4.0, 60.0, 24, 2.5, 95.0, 1.5, 3_000.0),
                OutputDeviceClass::BookshelfSpeaker => (-3.0, 45.0, 24, 2.0, 85.0, 1.0, 3_200.0),
                OutputDeviceClass::StudioMonitor => (-1.5, 28.0, 12, 0.0, 80.0, 0.0, 3_000.0),
                OutputDeviceClass::DesktopMonitorSpeaker => (-5.0, 100.0, 24, 1.0, 125.0, 2.0, 3_000.0),
                OutputDeviceClass::TvSpeaker => (-5.5, 85.0, 24, 1.5, 110.0, 2.5, 2_700.0),
                OutputDeviceClass::Soundbar => (-4.0, 70.0, 24, 2.0, 105.0, 2.0, 2_700.0),
                OutputDeviceClass::Speaker2_1 => (-4.0, 28.0, 24, 2.5, 75.0, 1.0, 3_000.0),
                OutputDeviceClass::Speaker5_1 => (-3.0, 28.0, 24, 1.5, 80.0, 1.0, 3_000.0),
                OutputDeviceClass::Speaker7_1 => (-3.0, 28.0, 24, 1.5, 80.0, 1.0, 3_000.0),
                OutputDeviceClass::OpenBackHeadphone => (-3.0, 20.0, 12, 2.0, 75.0, 1.0, 3_200.0),
                OutputDeviceClass::ClosedBackHeadphone => (-3.0, 22.0, 12, 1.5, 80.0, 1.5, 3_000.0),
                OutputDeviceClass::GamingHeadset => (-5.0, 30.0, 18, 2.5, 90.0, 2.5, 2_800.0),
                OutputDeviceClass::Iem => (-3.5, 25.0, 12, 1.5, 85.0, 1.0, 3_200.0),
                OutputDeviceClass::WiredEarbud => (-4.0, 35.0, 18, 2.5, 95.0, 1.5, 3_000.0),
                OutputDeviceClass::BluetoothEarbud => (-4.5, 45.0, 18, 2.5, 100.0, 1.5, 2_900.0),
                OutputDeviceClass::BluetoothHeadphone => (-4.0, 30.0, 18, 2.0, 90.0, 1.0, 3_000.0),
                OutputDeviceClass::BluetoothPortableSpeaker => (-5.0, 65.0, 24, 2.0, 100.0, 1.5, 2_900.0),
                OutputDeviceClass::Bluetooth360Speaker => (-5.0, 65.0, 24, 1.5, 100.0, 1.0, 2_800.0),
                OutputDeviceClass::BluetoothStereoPortableSpeaker => (-4.5, 55.0, 24, 2.0, 90.0, 1.2, 3_000.0),
                OutputDeviceClass::BluetoothDesktopSpeaker => (-4.0, 55.0, 24, 1.5, 90.0, 1.2, 3_000.0),
                OutputDeviceClass::BluetoothBookshelfSpeaker => (-3.5, 45.0, 24, 1.5, 85.0, 1.0, 3_100.0),
                OutputDeviceClass::BluetoothSpeaker2_0 => (-3.5, 45.0, 24, 1.5, 85.0, 1.0, 3_000.0),
                OutputDeviceClass::BluetoothSpeaker2_1 => (-4.0, 30.0, 24, 2.0, 75.0, 1.0, 3_000.0),
                OutputDeviceClass::BluetoothSoundbar => (-4.5, 70.0, 24, 1.5, 105.0, 2.0, 2_700.0),
                OutputDeviceClass::BluetoothSoundbarSubwoofer => (-4.5, 32.0, 24, 2.0, 75.0, 1.5, 2_700.0),
                OutputDeviceClass::BluetoothTvSpeaker => (-5.0, 80.0, 24, 1.0, 110.0, 2.2, 2_700.0),
                OutputDeviceClass::BluetoothSmartSpeaker => (-4.5, 60.0, 24, 1.5, 95.0, 1.8, 2_800.0),
                OutputDeviceClass::BluetoothPartySpeaker => (-6.0, 40.0, 24, 2.5, 75.0, 1.0, 2_800.0),
                OutputDeviceClass::BluetoothOutdoorSpeaker => (-5.5, 55.0, 24, 1.5, 95.0, 1.5, 2_900.0),
                OutputDeviceClass::BluetoothPaSpeaker => (-5.0, 45.0, 24, 1.0, 85.0, 2.0, 2_500.0),
                OutputDeviceClass::BluetoothMultiSpeaker => (-5.0, 45.0, 24, 1.5, 85.0, 1.2, 3_000.0),
                OutputDeviceClass::UltimateEarsWonderboom4 => (-5.5, 70.0, 24, 1.5, 100.0, 1.5, 2_800.0),
                OutputDeviceClass::VehicleAudio => (-5.0, 28.0, 24, 3.0, 80.0, 1.0, 2_800.0),
                OutputDeviceClass::ExternalAudio => (-2.0, 20.0, 12, 0.0, 80.0, 0.0, 3_000.0),
                OutputDeviceClass::Custom => (0.0, 20.0, 12, 0.0, 80.0, 0.0, 3_000.0),
            };

        let mut filters = Vec::new();
        if device_class != OutputDeviceClass::Custom {
            filters.push(OutputFilter::high_pass(high_pass_hz, high_pass_slope));
        }

        Self {
            schema_version: 3,
            name: format!("{} — Aether Reference", device_class.label()),
            device_class,
            bypassed: false,
            preamp_db,
            filters,
            parametric_eq: default_parametric_eq_bands(),
            bass: if bass_db > 0.0 {
                OutputEnhancement::enabled(bass_db, bass_hz, 0.707_106_77)
            } else {
                OutputEnhancement::disabled(bass_hz, 0.707_106_77)
            },
            clarity: if clarity_db > 0.0 {
                OutputEnhancement::enabled(clarity_db, clarity_hz, 0.9)
            } else {
                OutputEnhancement::disabled(clarity_hz, 0.9)
            },
            gaming: OutputGamingMode::default(),
            output_gain_db: 0.0,
            limiter: OutputLimiter::default(),
        }
    }

    pub fn set_parametric_eq_band_count(&mut self, count: usize) {
        let target = count.clamp(PEQ_MIN_BANDS, PEQ_MAX_BANDS);
        self.parametric_eq.truncate(target);
        while self.parametric_eq.len() < target {
            let index = self.parametric_eq.len();
            self.parametric_eq
                .push(OutputParametricEqBand::neutral(peq_log_frequency(index, target)));
        }
    }

    pub fn normalize_parametric_eq(&mut self) {
        let mut migrated = Vec::new();
        self.filters.retain(|filter| {
            let kind = match filter.kind {
                OutputFilterKind::Peak => Some(ParametricEqBandKind::Peak),
                OutputFilterKind::Notch => Some(ParametricEqBandKind::Notch),
                OutputFilterKind::LowShelf => Some(ParametricEqBandKind::LowShelf),
                OutputFilterKind::HighShelf => Some(ParametricEqBandKind::HighShelf),
                _ => None,
            };
            if let Some(kind) = kind {
                migrated.push(OutputParametricEqBand {
                    enabled: filter.enabled,
                    kind,
                    frequency_hz: filter.frequency_hz.clamp(PEQ_MIN_FREQUENCY_HZ, PEQ_MAX_FREQUENCY_HZ),
                    gain_db: filter.gain_db.clamp(-24.0, 24.0),
                    q: filter.q.clamp(0.1, 18.0),
                });
                false
            } else {
                true
            }
        });
        if !migrated.is_empty() {
            self.parametric_eq.splice(0..0, migrated);
        }
        self.parametric_eq.truncate(PEQ_MAX_BANDS);
        let defaults = default_parametric_eq_bands();
        while self.parametric_eq.len() < PEQ_MIN_BANDS {
            self.parametric_eq.push(defaults[self.parametric_eq.len()].clone());
        }
        for band in &mut self.parametric_eq {
            band.frequency_hz = band.frequency_hz.clamp(PEQ_MIN_FREQUENCY_HZ, PEQ_MAX_FREQUENCY_HZ);
            band.gain_db = band.gain_db.clamp(-24.0, 24.0);
            band.q = band.q.clamp(0.1, 18.0);
        }
        self.schema_version = 3;
    }

    pub fn validate(
        &self,
        sample_rate_hz: f32,
        channels: usize,
    ) -> Result<(), OutputDspProfileError> {
        if !sample_rate_hz.is_finite() || !(8_000.0..=384_000.0).contains(&sample_rate_hz) {
            return Err(OutputDspProfileError::InvalidSampleRate);
        }
        if !(1..=32).contains(&channels) {
            return Err(OutputDspProfileError::InvalidChannelCount);
        }

        for gain in [self.preamp_db, self.output_gain_db] {
            validate_gain(gain)?;
        }
        for filter in &self.filters {
            validate_frequency(filter.frequency_hz, sample_rate_hz)?;
            validate_q(filter.q)?;
            validate_gain(filter.gain_db)?;
            if !matches!(filter.slope_db_per_octave, 6 | 12 | 18 | 24 | 36 | 48) {
                return Err(OutputDspProfileError::InvalidSlope);
            }
        }
        if !(PEQ_MIN_BANDS..=PEQ_MAX_BANDS).contains(&self.parametric_eq.len()) {
            return Err(OutputDspProfileError::InvalidParametricEqBandCount);
        }
        for band in &self.parametric_eq {
            validate_peq_frequency(band.frequency_hz)?;
            validate_q(band.q)?;
            validate_gain(band.gain_db)?;
        }
        for enhancement in [&self.bass, &self.clarity] {
            validate_frequency(enhancement.frequency_hz, sample_rate_hz)?;
            validate_q(enhancement.q)?;
            validate_gain(enhancement.amount_db)?;
        }
        for gain in [self.gaming.impact_db, self.gaming.mud_cut_db, self.gaming.detail_db] {
            validate_gain(gain)?;
        }
        for frequency in [
            self.gaming.impact_frequency_hz,
            self.gaming.mud_frequency_hz,
            self.gaming.detail_frequency_hz,
        ] {
            validate_frequency(frequency, sample_rate_hz)?;
        }
        if !self.limiter.ceiling_dbfs.is_finite()
            || !(-12.0..=0.0).contains(&self.limiter.ceiling_dbfs)
        {
            return Err(OutputDspProfileError::InvalidLimiterCeiling);
        }
        Ok(())
    }
}

fn peq_log_frequency(index: usize, band_count: usize) -> f32 {
    let count = band_count.clamp(PEQ_MIN_BANDS, PEQ_MAX_BANDS);
    if index == 0 {
        return PEQ_MIN_FREQUENCY_HZ;
    }
    if index + 1 >= count {
        return PEQ_MAX_FREQUENCY_HZ;
    }
    let position = index as f32 / (count - 1) as f32;
    (PEQ_MIN_FREQUENCY_HZ
        * (PEQ_MAX_FREQUENCY_HZ / PEQ_MIN_FREQUENCY_HZ).powf(position))
    .clamp(PEQ_MIN_FREQUENCY_HZ, PEQ_MAX_FREQUENCY_HZ)
}

fn default_parametric_eq_bands() -> Vec<OutputParametricEqBand> {
    (0..PEQ_MIN_BANDS)
        .map(|index| OutputParametricEqBand::neutral(peq_log_frequency(index, PEQ_MIN_BANDS)))
        .collect()
}

fn validate_peq_frequency(value: f32) -> Result<(), OutputDspProfileError> {
    if value.is_finite() && (PEQ_MIN_FREQUENCY_HZ..=PEQ_MAX_FREQUENCY_HZ).contains(&value) {
        Ok(())
    } else {
        Err(OutputDspProfileError::InvalidFrequency)
    }
}

fn validate_gain(value: f32) -> Result<(), OutputDspProfileError> {
    if value.is_finite() && (-24.0..=24.0).contains(&value) {
        Ok(())
    } else {
        Err(OutputDspProfileError::InvalidGain)
    }
}

fn validate_q(value: f32) -> Result<(), OutputDspProfileError> {
    if value.is_finite() && (0.1..=18.0).contains(&value) {
        Ok(())
    } else {
        Err(OutputDspProfileError::InvalidQ)
    }
}

fn validate_frequency(value: f32, sample_rate_hz: f32) -> Result<(), OutputDspProfileError> {
    let upper = sample_rate_hz * 0.49;
    if value.is_finite() && (PEQ_MIN_FREQUENCY_HZ..=upper).contains(&value) {
        Ok(())
    } else {
        Err(OutputDspProfileError::InvalidFrequency)
    }
}
