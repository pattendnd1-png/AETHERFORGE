pub const FORGEHX_BRIDGE_MAGIC: [u8; 8] = *b"AFXHXM01";
pub const FORGEHX_BRIDGE_VERSION: u16 = 1;
pub const FORGEHX_BRIDGE_RATE: u32 = 48_000;
pub const FORGEHX_BRIDGE_CHANNELS: u16 = 1;
pub const FORGEHX_BRIDGE_FRAME_SAMPLES: usize = 480;
pub const FORGEHX_BRIDGE_HEADER_BYTES: usize = 32;
pub const FORGEHX_BRIDGE_PACKET_BYTES: usize =
    FORGEHX_BRIDGE_HEADER_BYTES + FORGEHX_BRIDGE_FRAME_SAMPLES * std::mem::size_of::<f32>();
pub const SYSTEM_MICROPHONE_NODE_NAME: &str = "aetherstream.system.microphone";

#[derive(Clone, Debug, PartialEq)]
pub struct ForgeHxMicPacket {
    pub sequence: u64,
    pub samples: [f32; FORGEHX_BRIDGE_FRAME_SAMPLES],
}

pub fn decode_forgehx_mic_packet(bytes: &[u8]) -> Option<ForgeHxMicPacket> {
    if bytes.len() != FORGEHX_BRIDGE_PACKET_BYTES || bytes[..8] != FORGEHX_BRIDGE_MAGIC {
        return None;
    }
    let version = u16::from_le_bytes([bytes[8], bytes[9]]);
    let rate = u32::from_le_bytes([bytes[12], bytes[13], bytes[14], bytes[15]]);
    let channels = u16::from_le_bytes([bytes[16], bytes[17]]);
    let frame_samples = u16::from_le_bytes([bytes[18], bytes[19]]) as usize;
    if version != FORGEHX_BRIDGE_VERSION
        || rate != FORGEHX_BRIDGE_RATE
        || channels != FORGEHX_BRIDGE_CHANNELS
        || frame_samples != FORGEHX_BRIDGE_FRAME_SAMPLES
    {
        return None;
    }
    let sequence = u64::from_le_bytes(bytes[20..28].try_into().ok()?);
    let mut samples = [0.0_f32; FORGEHX_BRIDGE_FRAME_SAMPLES];
    for (index, sample) in samples.iter_mut().enumerate() {
        let start = FORGEHX_BRIDGE_HEADER_BYTES + index * 4;
        *sample = f32::from_le_bytes(bytes[start..start + 4].try_into().ok()?);
    }
    Some(ForgeHxMicPacket { sequence, samples })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_wrong_bridge_magic() {
        let mut packet = [0_u8; FORGEHX_BRIDGE_PACKET_BYTES];
        packet[..8].copy_from_slice(b"NOTHX001");
        assert!(decode_forgehx_mic_packet(&packet).is_none());
    }

    #[test]
    fn decodes_fixed_forgehx_frame_contract() {
        let mut packet = [0_u8; FORGEHX_BRIDGE_PACKET_BYTES];
        packet[..8].copy_from_slice(&FORGEHX_BRIDGE_MAGIC);
        packet[8..10].copy_from_slice(&FORGEHX_BRIDGE_VERSION.to_le_bytes());
        packet[12..16].copy_from_slice(&FORGEHX_BRIDGE_RATE.to_le_bytes());
        packet[16..18].copy_from_slice(&FORGEHX_BRIDGE_CHANNELS.to_le_bytes());
        packet[18..20].copy_from_slice(&(FORGEHX_BRIDGE_FRAME_SAMPLES as u16).to_le_bytes());
        packet[20..28].copy_from_slice(&42_u64.to_le_bytes());
        packet[FORGEHX_BRIDGE_HEADER_BYTES..FORGEHX_BRIDGE_HEADER_BYTES + 4]
            .copy_from_slice(&0.5_f32.to_le_bytes());
        let decoded = decode_forgehx_mic_packet(&packet).unwrap();
        assert_eq!(decoded.sequence, 42);
        assert_eq!(decoded.samples[0], 0.5);
    }
}
