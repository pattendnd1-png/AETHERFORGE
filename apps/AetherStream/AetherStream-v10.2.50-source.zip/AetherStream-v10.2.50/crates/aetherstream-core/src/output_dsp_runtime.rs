use crate::OutputDspProfile;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum OutputDspRuntimeRequest {
    Apply {
        device_id: String,
        profile: OutputDspProfile,
    },
    Status,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum OutputDspRuntimeResponse {
    Applied {
        device_id: String,
        generation: u64,
    },
    Status {
        live: bool,
        active_device_id: Option<String>,
        generation: u64,
    },
    Rejected {
        reason: String,
    },
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::OutputDeviceClass;

    #[test]
    fn live_runtime_apply_round_trips_without_losing_profile() {
        let request = OutputDspRuntimeRequest::Apply {
            device_id: "@DEFAULT_AUDIO_SINK@".into(),
            profile: OutputDspProfile::factory(OutputDeviceClass::TvSpeaker),
        };
        let encoded = postcard::to_stdvec(&request).unwrap();
        let decoded: OutputDspRuntimeRequest = postcard::from_bytes(&encoded).unwrap();
        assert_eq!(decoded, request);
    }
}
