use crate::AccountId;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
pub enum Provider { Twitch, Obs, StreamElements, Streamlabs, AetherForge }

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum UnifiedEventKind {
    Follow,
    Subscription,
    GiftSubscription,
    Raid,
    Cheer,
    Tip,
    Donation,
    ChannelPointRedemption,
    ChatMessage,
    ModerationAction,
    Alert,
    StreamOnline,
    StreamOffline,
    ObsSceneChanged,
    RecordingStarted,
    RecordingStopped,
    Custom(String),
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct UnifiedEvent {
    pub event_id: Uuid,
    pub provider: Provider,
    pub account: Option<AccountId>,
    pub channel: Option<String>,
    pub timestamp_ms: i64,
    pub kind: UnifiedEventKind,
    pub provider_payload: serde_json::Value,
}

impl UnifiedEvent {
    #[must_use]
    pub fn new(provider: Provider, kind: UnifiedEventKind) -> Self {
        Self {
            event_id: Uuid::new_v4(), provider, account: None, channel: None,
            timestamp_ms: 0, kind, provider_payload: serde_json::Value::Null,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn unified_event_preserves_provider() {
        let event = UnifiedEvent::new(Provider::StreamElements, UnifiedEventKind::Tip);
        let json = serde_json::to_string(&event).unwrap();
        let decoded: UnifiedEvent = serde_json::from_str(&json).unwrap();
        assert_eq!(decoded.provider, Provider::StreamElements);
    }
}
