use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
pub enum Capability {
    ChatRead,
    ChatWrite,
    Viewer,
    Creator,
    Moderator,
    ObsControl,
    StreamElements,
    Streamlabs,
    StreamDeck,
    AudioDsp,
    AvStudio,
    Custom(String),
}

impl Capability {
    #[must_use]
    pub fn twitch_scope(&self) -> Option<&'static str> {
        match self {
            Self::ChatRead => Some("user:read:chat"),
            Self::ChatWrite => Some("user:write:chat"),
            Self::Creator => Some("channel:manage:broadcast"),
            Self::Moderator => Some("moderator:manage:banned_users"),
            _ => None,
        }
    }
}
