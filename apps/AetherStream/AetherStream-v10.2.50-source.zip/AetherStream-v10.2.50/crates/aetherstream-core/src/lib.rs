pub mod action;
pub mod capability;
pub mod event;
pub mod health;
pub mod forgehx_bridge;
pub mod identity;
pub mod output_dsp;
pub mod output_dsp_runtime;

pub use action::{
    AccountConnection, AetherAuthAction, AetherStreamAction, AuthConnectionState, AuthProvider, LinkedOutputConfig,
    StreamElementsOverlayAction, StreamlabsAlertAction,
    StreamlabsMediaShareAction, TwitchModerationAction, TwitchPollSpec, TwitchPredictionSpec,
};
pub use capability::Capability;
pub use event::{Provider, UnifiedEvent, UnifiedEventKind};
pub use health::ServiceHealth;
pub use identity::{AccountId, ClientInstanceId, SessionId, WindowId};

pub use output_dsp::{
    bluetooth_loadout_id, OutputDeviceClass, OutputDspProfile, OutputDspProfileError, OutputEnhancement, OutputFilter,
    OutputFilterKind, OutputGamingMode, OutputLimiter, OutputParametricEqBand, ParametricEqBandKind,
    HDMI3_LOADOUT_ID, PEQ_MAX_BANDS, PEQ_MAX_FREQUENCY_HZ, PEQ_MIN_BANDS, PEQ_MIN_FREQUENCY_HZ,
};

pub use output_dsp_runtime::{OutputDspRuntimeRequest, OutputDspRuntimeResponse};

pub use forgehx_bridge::{decode_forgehx_mic_packet, ForgeHxMicPacket, FORGEHX_BRIDGE_CHANNELS, FORGEHX_BRIDGE_FRAME_SAMPLES, FORGEHX_BRIDGE_MAGIC, FORGEHX_BRIDGE_PACKET_BYTES, FORGEHX_BRIDGE_RATE, FORGEHX_BRIDGE_VERSION, SYSTEM_MICROPHONE_NODE_NAME};
