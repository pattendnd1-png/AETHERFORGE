use crate::output_dsp::OutputDspProfile;
use crate::{AccountId, SessionId};
use serde::{Deserialize, Serialize};


#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Serialize, Deserialize)]
pub enum AuthProvider {
    Twitch,
    Streamlabs,
    StreamElements,
    BroadcastEngine,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum AuthConnectionState {
    Disconnected,
    Connecting,
    AwaitingUser,
    Connected,
    NeedsAttention,
    AuthenticationRequired,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct AccountConnection {
    pub provider: AuthProvider,
    pub account: Option<AccountId>,
    pub display_name: Option<String>,
    pub state: AuthConnectionState,
    pub is_default: bool,
    pub scopes: Vec<String>,
    pub status_detail: Option<String>,
    pub user_code: Option<String>,
    pub verification_uri: Option<String>,
    pub manual_code_available: bool,
    pub expires_at_unix: Option<u64>,
}

impl AccountConnection {
    #[must_use]
    pub fn disconnected(provider: AuthProvider) -> Self {
        Self {
            provider,
            account: None,
            display_name: None,
            state: AuthConnectionState::Disconnected,
            is_default: false,
            scopes: Vec::new(),
            status_detail: None,
            user_code: None,
            verification_uri: None,
            manual_code_available: false,
            expires_at_unix: None,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum AetherAuthAction {
    BeginLogin(AuthProvider),
    SubmitManualCode { provider: AuthProvider, code: String },
    Disconnect(AuthProvider),
    SetDefault { provider: AuthProvider, account: AccountId },
    SmartRestore,
    ConnectBroadcastEngine,
    DisconnectBroadcastEngine,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct TwitchPollSpec {
    pub title: String,
    pub choices: Vec<String>,
    pub duration_secs: u32,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct TwitchPredictionSpec {
    pub title: String,
    pub outcomes: Vec<String>,
    pub window_secs: u32,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum TwitchModerationAction {
    Ban {
        user: String,
        reason: Option<String>,
    },
    Timeout {
        user: String,
        duration_secs: u32,
        reason: Option<String>,
    },
    Unban {
        user: String,
    },
    DeleteMessage {
        message_id: String,
    },
    ApproveAutomod {
        message_id: String,
    },
    DenyAutomod {
        message_id: String,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum StreamElementsOverlayAction {
    Pause,
    Resume,
    Mute,
    Unmute,
    Skip,
    PlayNext,
    Reload,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum StreamlabsAlertAction {
    Skip,
    Pause,
    Resume,
    Mute,
    Unmute,
    Test(String),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum StreamlabsMediaShareAction {
    Play,
    Pause,
    Skip,
    VolumeUp,
    VolumeDown,
    Moderation(bool),
}


#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct LinkedOutputConfig {
    pub enabled: bool,
    pub hdmi_node_name: Option<String>,
    pub bluetooth_node_name: Option<String>,
    pub master_normalized_10k: u16,
    pub hdmi_trim_db_x100: i16,
    pub bluetooth_trim_db_x100: i16,
}

impl Default for LinkedOutputConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            hdmi_node_name: None,
            bluetooth_node_name: None,
            master_normalized_10k: 7_000,
            hdmi_trim_db_x100: 0,
            bluetooth_trim_db_x100: 0,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum AetherStreamAction {
    Auth(AetherAuthAction),
    ObsScene(String),
    ObsMute { input: String, muted: bool },
    ObsTransition(String),
    ObsSourceVisibility { source: String, visible: bool },
    ObsReplayBufferSave,
    TwitchCreateClip,
    TwitchMarker(Option<String>),
    TwitchRaid(String),
    TwitchShieldMode(bool),
    TwitchCreatePoll(TwitchPollSpec),
    TwitchCreatePrediction(TwitchPredictionSpec),
    TwitchModeration(TwitchModerationAction),
    StreamElementsTestAlert(String),
    StreamElementsOverlay(StreamElementsOverlayAction),
    StreamlabsSkipAlert,
    StreamlabsAlert(StreamlabsAlertAction),
    StreamlabsMediaShare(StreamlabsMediaShareAction),
    Workspace(String),
    MultiviewLayout(String),
    DspPreset(String),
    OutputDspApply { device_id: String, profile: OutputDspProfile },
    OutputDspBypass { device_id: String, bypassed: bool },
    RecordingToggle,
    AudioGain { bus: String, gain_db: f32 },
    AudioMute { bus: String, muted: bool },
    AudioSolo { bus: String, soloed: bool },
    AudioMonitor { bus: String, enabled: bool },
    SystemOutputVolume { normalized_10k: u16 },
    LinkedOutputConfigure(LinkedOutputConfig),
    DeckProfile(String),
    DeckPage(String),
    MediaOpenProject(String),
    RecordingFinalize,
    SessionLoad(SessionId),
    SessionSave(SessionId),
    SessionGoLive,
    SessionEnd,
    Macro(Vec<AetherStreamAction>),
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn account_connection_serialization_contains_no_secret_fields() {
        let mut connection = AccountConnection::disconnected(AuthProvider::Twitch);
        connection.user_code = Some("ABCD1234".into());
        connection.verification_uri = Some("https://www.twitch.tv/activate".into());
        let json = serde_json::to_string(&connection).unwrap();
        for forbidden in ["access_token", "refresh_token", "client_secret", "password"] {
            assert!(!json.contains(forbidden));
        }
    }

    #[test]
    fn auth_action_round_trip_keeps_provider_and_no_tokens() {
        let action = AetherStreamAction::Auth(AetherAuthAction::BeginLogin(AuthProvider::Streamlabs));
        let json = serde_json::to_string(&action).unwrap();
        assert!(json.contains("Streamlabs"));
        assert!(!json.contains("access_token"));
    }
}
