use serde::{Deserialize, Serialize};
use std::fmt;
use uuid::Uuid;

macro_rules! uuid_id {
    ($name:ident) => {
        #[derive(Clone, Copy, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
        pub struct $name(Uuid);

        impl $name {
            #[must_use]
            pub fn new() -> Self { Self(Uuid::new_v4()) }
            #[must_use]
            pub fn as_uuid(self) -> Uuid { self.0 }
        }

        impl Default for $name { fn default() -> Self { Self::new() } }
        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "{}", self.0) }
        }
    };
}

uuid_id!(ClientInstanceId);
uuid_id!(WindowId);
uuid_id!(AccountId);
uuid_id!(SessionId);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn client_instance_ids_are_unique_and_round_trip() {
        let a = ClientInstanceId::new();
        let b = ClientInstanceId::new();
        assert_ne!(a, b);
        let encoded = serde_json::to_string(&a).unwrap();
        assert_eq!(serde_json::from_str::<ClientInstanceId>(&encoded).unwrap(), a);
    }

    #[test]
    fn session_ids_are_unique_and_round_trip() {
        let a = SessionId::new();
        let b = SessionId::new();
        assert_ne!(a, b);
        let encoded = serde_json::to_string(&a).unwrap();
        assert_eq!(serde_json::from_str::<SessionId>(&encoded).unwrap(), a);
    }
}
