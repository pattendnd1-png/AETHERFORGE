use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
pub enum ServiceHealth { Connected, Reconnecting, Degraded, Offline, AuthRequired, RateLimited }

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn service_health_has_six_states() {
        let all = [ServiceHealth::Connected, ServiceHealth::Reconnecting, ServiceHealth::Degraded,
            ServiceHealth::Offline, ServiceHealth::AuthRequired, ServiceHealth::RateLimited];
        assert_eq!(all.len(), 6);
    }
}
