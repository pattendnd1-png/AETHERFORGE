use aetherstream_audio::{
    LiveDspPlan, LiveDspProcessor, SharedOutputDspReader, OUTPUT_DSP_SHARED_FILE,
};
use aetherstream_core::{OutputDeviceClass, OutputDspProfile};
use std::ffi::{c_char, c_int, c_ulong, c_void};
use std::path::PathBuf;
use std::ptr;
use std::sync::atomic::{AtomicBool, AtomicPtr, Ordering};
use std::sync::{Arc, Once};
use std::thread::{self, JoinHandle};
use std::time::Duration;

const LADSPA_PORT_INPUT: c_int = 0x1;
const LADSPA_PORT_OUTPUT: c_int = 0x2;
const LADSPA_PORT_AUDIO: c_int = 0x8;
const PORT_INPUT_L: usize = 0;
const PORT_INPUT_R: usize = 1;
const PORT_OUTPUT_L: usize = 2;
const PORT_OUTPUT_R: usize = 3;
const PORT_COUNT: usize = 4;
const PLUGIN_UNIQUE_ID: c_ulong = 0x00A3_6001;
const SMOOTHING_MS: usize = 12;

#[repr(C)]
struct LadspaPortRangeHint {
    hint_descriptor: c_int,
    lower_bound: f32,
    upper_bound: f32,
}

type LadspaHandle = *mut c_void;
type LadspaPortDescriptor = c_int;

#[repr(C)]
pub struct LadspaDescriptor {
    unique_id: c_ulong,
    label: *const c_char,
    properties: c_int,
    name: *const c_char,
    maker: *const c_char,
    copyright: *const c_char,
    port_count: c_ulong,
    port_descriptors: *const LadspaPortDescriptor,
    port_names: *const *const c_char,
    port_range_hints: *const LadspaPortRangeHint,
    implementation_data: *mut c_void,
    instantiate: Option<unsafe extern "C" fn(*const LadspaDescriptor, c_ulong) -> LadspaHandle>,
    connect_port: Option<unsafe extern "C" fn(LadspaHandle, c_ulong, *mut f32)>,
    activate: Option<unsafe extern "C" fn(LadspaHandle)>,
    run: Option<unsafe extern "C" fn(LadspaHandle, c_ulong)>,
    run_adding: Option<unsafe extern "C" fn(LadspaHandle, c_ulong)>,
    set_run_adding_gain: Option<unsafe extern "C" fn(LadspaHandle, f32)>,
    deactivate: Option<unsafe extern "C" fn(LadspaHandle)>,
    cleanup: Option<unsafe extern "C" fn(LadspaHandle)>,
}

struct Instance {
    ports: [*mut f32; PORT_COUNT],
    processor: LiveDspProcessor,
    last_generation: u32,
    reader: Arc<AtomicPtr<SharedOutputDspReader>>,
    stop: Arc<AtomicBool>,
    worker: Option<JoinHandle<()>>,
}

fn runtime_dir() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
        PathBuf::from(dir).join("aetherstream")
    } else {
        PathBuf::from(format!(
            "/tmp/aetherstream-{}",
            std::env::var("UID").unwrap_or_else(|_| "user".into())
        ))
    }
}

fn shared_path() -> PathBuf {
    runtime_dir().join(OUTPUT_DSP_SHARED_FILE)
}

fn active_marker_path() -> PathBuf {
    runtime_dir().join("physical-output-internal-dsp.active")
}

fn start_reader_worker(
    reader_slot: Arc<AtomicPtr<SharedOutputDspReader>>,
    stop: Arc<AtomicBool>,
) -> std::io::Result<JoinHandle<()>> {
    thread::Builder::new()
        .name("aetherstream-physical-output-dsp-state".into())
        .spawn(move || {
            while !stop.load(Ordering::Acquire) {
                if reader_slot.load(Ordering::Acquire).is_null()
                    && let Ok(reader) = SharedOutputDspReader::try_open(&shared_path())
                {
                    let raw = Box::into_raw(Box::new(reader));
                    if reader_slot
                        .compare_exchange(
                            ptr::null_mut(),
                            raw,
                            Ordering::AcqRel,
                            Ordering::Acquire,
                        )
                        .is_err()
                    {
                        unsafe {
                            drop(Box::from_raw(raw));
                        }
                    }
                }
                thread::sleep(Duration::from_millis(100));
            }
        })
}

unsafe extern "C" fn instantiate(
    _descriptor: *const LadspaDescriptor,
    sample_rate: c_ulong,
) -> LadspaHandle {
    let flat = OutputDspProfile::factory(OutputDeviceClass::Custom);
    let plan = match LiveDspPlan::compile(&flat, sample_rate as f32, 2) {
        Ok(plan) => plan,
        Err(_) => return ptr::null_mut(),
    };
    let smoothing_samples = ((sample_rate as usize * SMOOTHING_MS * 2) / 1_000).max(2);
    let processor = match LiveDspProcessor::new(plan, 2, smoothing_samples) {
        Ok(processor) => processor,
        Err(_) => return ptr::null_mut(),
    };
    let reader = Arc::new(AtomicPtr::new(ptr::null_mut()));
    let stop = Arc::new(AtomicBool::new(false));
    let worker = match start_reader_worker(Arc::clone(&reader), Arc::clone(&stop)) {
        Ok(worker) => worker,
        Err(_) => return ptr::null_mut(),
    };
    let marker = active_marker_path();
    if let Some(parent) = marker.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let _ = std::fs::write(marker, format!("pid={}\n", std::process::id()));
    Box::into_raw(Box::new(Instance {
        ports: [ptr::null_mut(); PORT_COUNT],
        processor,
        last_generation: 0,
        reader,
        stop,
        worker: Some(worker),
    }))
    .cast::<c_void>()
}

unsafe extern "C" fn connect_port(handle: LadspaHandle, port: c_ulong, data: *mut f32) {
    if handle.is_null() || port as usize >= PORT_COUNT {
        return;
    }
    let instance = unsafe { &mut *handle.cast::<Instance>() };
    instance.ports[port as usize] = data;
}

unsafe extern "C" fn activate(_handle: LadspaHandle) {
    let path = active_marker_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let _ = std::fs::write(path, format!("pid={}\n", std::process::id()));
}

unsafe extern "C" fn run(handle: LadspaHandle, sample_count: c_ulong) {
    if handle.is_null() {
        return;
    }
    let instance = unsafe { &mut *handle.cast::<Instance>() };
    let reader_ptr = instance.reader.load(Ordering::Acquire);
    if !reader_ptr.is_null()
        && let Some((generation, plan)) = unsafe { &*reader_ptr }.snapshot()
        && generation != instance.last_generation
        && plan.channels == 2
    {
        instance.processor.begin_transition(plan);
        instance.last_generation = generation;
    }

    let [input_l, input_r, output_l, output_r] = instance.ports;
    if input_l.is_null() || input_r.is_null() || output_l.is_null() || output_r.is_null() {
        return;
    }
    for index in 0..sample_count as usize {
        let left = unsafe { *input_l.add(index) };
        let right = unsafe { *input_r.add(index) };
        let processed_left = instance.processor.process_sample(0, left);
        let processed_right = instance.processor.process_sample(1, right);
        unsafe {
            *output_l.add(index) = processed_left;
            *output_r.add(index) = processed_right;
        }
    }
}

unsafe extern "C" fn deactivate(_handle: LadspaHandle) {
    let _ = std::fs::remove_file(active_marker_path());
}

unsafe extern "C" fn cleanup(handle: LadspaHandle) {
    if handle.is_null() {
        return;
    }
    let mut instance = unsafe { Box::from_raw(handle.cast::<Instance>()) };
    instance.stop.store(true, Ordering::Release);
    if let Some(worker) = instance.worker.take() {
        let _ = worker.join();
    }
    let reader_ptr = instance.reader.swap(ptr::null_mut(), Ordering::AcqRel);
    if !reader_ptr.is_null() {
        unsafe {
            drop(Box::from_raw(reader_ptr));
        }
    }
    let _ = std::fs::remove_file(active_marker_path());
}

fn descriptor_ptr() -> *const LadspaDescriptor {
    static INIT: Once = Once::new();
    static DESCRIPTOR: AtomicPtr<LadspaDescriptor> = AtomicPtr::new(ptr::null_mut());
    INIT.call_once(|| {
        let port_descriptors = Box::new([
            LADSPA_PORT_INPUT | LADSPA_PORT_AUDIO,
            LADSPA_PORT_INPUT | LADSPA_PORT_AUDIO,
            LADSPA_PORT_OUTPUT | LADSPA_PORT_AUDIO,
            LADSPA_PORT_OUTPUT | LADSPA_PORT_AUDIO,
        ]);
        let port_names = Box::new([
            c"Input_L".as_ptr(),
            c"Input_R".as_ptr(),
            c"Output_L".as_ptr(),
            c"Output_R".as_ptr(),
        ]);
        let port_hints = Box::new([
            LadspaPortRangeHint {
                hint_descriptor: 0,
                lower_bound: 0.0,
                upper_bound: 0.0,
            },
            LadspaPortRangeHint {
                hint_descriptor: 0,
                lower_bound: 0.0,
                upper_bound: 0.0,
            },
            LadspaPortRangeHint {
                hint_descriptor: 0,
                lower_bound: 0.0,
                upper_bound: 0.0,
            },
            LadspaPortRangeHint {
                hint_descriptor: 0,
                lower_bound: 0.0,
                upper_bound: 0.0,
            },
        ]);
        let descriptor = Box::new(LadspaDescriptor {
            unique_id: PLUGIN_UNIQUE_ID,
            label: c"aetherstream_hdmi3_dsp_stereo".as_ptr(),
            properties: 0,
            name: c"AetherStream Physical Output Internal DSP".as_ptr(),
            maker: c"AetherForge".as_ptr(),
            copyright: c"GPL-3.0-or-later".as_ptr(),
            port_count: PORT_COUNT as c_ulong,
            port_descriptors: Box::into_raw(port_descriptors).cast::<LadspaPortDescriptor>(),
            port_names: Box::into_raw(port_names).cast::<*const c_char>(),
            port_range_hints: Box::into_raw(port_hints).cast::<LadspaPortRangeHint>(),
            implementation_data: ptr::null_mut(),
            instantiate: Some(instantiate),
            connect_port: Some(connect_port),
            activate: Some(activate),
            run: Some(run),
            run_adding: None,
            set_run_adding_gain: None,
            deactivate: Some(deactivate),
            cleanup: Some(cleanup),
        });
        DESCRIPTOR.store(Box::into_raw(descriptor), Ordering::Release);
    });
    DESCRIPTOR.load(Ordering::Acquire)
}

/// Returns the LADSPA descriptor for the AetherStream physical-output DSP plugin.
///
/// # Safety
///
/// This is a C ABI entry point. The returned pointer is process-lifetime static and must be
/// treated as read-only by the host.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ladspa_descriptor(index: c_ulong) -> *const LadspaDescriptor {
    if index == 0 {
        descriptor_ptr()
    } else {
        ptr::null()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use aetherstream_audio::SharedOutputDspWriter;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_path() -> PathBuf {
        std::env::temp_dir().join(format!(
            "aetherstream-ladspa-plan-{}-{}.shm",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ))
    }

    #[test]
    fn descriptor_exposes_only_stereo_audio_ports() {
        let descriptor = descriptor_ptr();
        assert!(!descriptor.is_null());
        let descriptor = unsafe { &*descriptor };
        assert_eq!(descriptor.port_count, 4);
        assert_eq!(
            unsafe { *descriptor.port_descriptors.add(0) },
            LADSPA_PORT_INPUT | LADSPA_PORT_AUDIO
        );
        assert_eq!(
            unsafe { *descriptor.port_descriptors.add(1) },
            LADSPA_PORT_INPUT | LADSPA_PORT_AUDIO
        );
        assert_eq!(
            unsafe { *descriptor.port_descriptors.add(2) },
            LADSPA_PORT_OUTPUT | LADSPA_PORT_AUDIO
        );
        assert_eq!(
            unsafe { *descriptor.port_descriptors.add(3) },
            LADSPA_PORT_OUTPUT | LADSPA_PORT_AUDIO
        );
    }

    #[test]
    fn run_consumes_published_shared_plan_without_an_output_stream() {
        let path = temp_path();
        let mut writer = SharedOutputDspWriter::open_or_create(&path).unwrap();
        let flat = OutputDspProfile::factory(OutputDeviceClass::Custom);
        let initial = LiveDspPlan::compile(&flat, 48_000.0, 2).unwrap();
        writer.publish(&initial);

        let reader = SharedOutputDspReader::try_open(&path).unwrap();
        let reader_ptr = Box::into_raw(Box::new(reader));
        let reader_slot = Arc::new(AtomicPtr::new(reader_ptr));
        let stop = Arc::new(AtomicBool::new(false));
        let processor = LiveDspProcessor::new(initial, 2, 1).unwrap();
        let instance = Instance {
            ports: [ptr::null_mut(); PORT_COUNT],
            processor,
            last_generation: 0,
            reader: reader_slot,
            stop,
            worker: None,
        };
        let handle = Box::into_raw(Box::new(instance)).cast::<c_void>();

        let mut left = [1.0_f32; 4];
        let mut right = [1.0_f32; 4];
        let mut out_left = [0.0_f32; 4];
        let mut out_right = [0.0_f32; 4];
        unsafe {
            connect_port(handle, PORT_INPUT_L as c_ulong, left.as_mut_ptr());
            connect_port(handle, PORT_INPUT_R as c_ulong, right.as_mut_ptr());
            connect_port(handle, PORT_OUTPUT_L as c_ulong, out_left.as_mut_ptr());
            connect_port(handle, PORT_OUTPUT_R as c_ulong, out_right.as_mut_ptr());
        }

        let mut attenuated = flat;
        attenuated.output_gain_db = -6.0;
        attenuated.limiter.enabled = false;
        let changed = LiveDspPlan::compile(&attenuated, 48_000.0, 2).unwrap();
        writer.publish(&changed);
        unsafe { run(handle, left.len() as c_ulong) };

        assert!(out_left.iter().all(|sample| *sample < 0.6 && *sample > 0.45));
        assert!(out_right.iter().all(|sample| *sample < 0.6 && *sample > 0.45));

        let instance = unsafe { Box::from_raw(handle.cast::<Instance>()) };
        let reader_ptr = instance.reader.swap(ptr::null_mut(), Ordering::AcqRel);
        if !reader_ptr.is_null() {
            unsafe {
                drop(Box::from_raw(reader_ptr));
            }
        }
        drop(instance);
        let _ = std::fs::remove_file(path);
    }
}
