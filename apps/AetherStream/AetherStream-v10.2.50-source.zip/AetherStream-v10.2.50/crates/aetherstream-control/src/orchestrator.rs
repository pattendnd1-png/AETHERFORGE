use crate::{AetherState, BroadcastSession, RequirementLevel};
use aetherstream_core::ServiceHealth;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityIssue {
    pub capability: String,
    pub reason: String,
    pub required: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum WorkflowState {
    Ready,
    Running,
    Degraded(Vec<CapabilityIssue>),
    Blocked(Vec<CapabilityIssue>),
    Failed(String),
    Completed,
}

impl WorkflowState {
    #[must_use]
    pub fn may_continue(&self) -> bool {
        matches!(self, Self::Ready | Self::Running | Self::Degraded(_))
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ServiceCommand {
    ResolveSession,
    RestoreWorkspace(String),
    RestoreInputDsp(String),
    RestoreOutputDsp(String),
    SelectDeckProfile(String),
    SelectStreamElementsPackage(String),
    SelectStreamlabsProfile(String),
    PrepareRecording(String),
    StartRecording,
    SwitchObsScene(String),
    StartObsStream,
    WaitForStreamOnline,
    BeginRaid,
    StopObsStream,
    WaitForStreamOffline,
    StopAndFinalizeRecording,
    CreateOrUpdateMediaProject,
    PersistSessionSummary,
    SwitchOfflinePresentation,
}

#[derive(Default)]
pub struct SessionOrchestrator;

impl SessionOrchestrator {
    #[must_use]
    pub fn preflight(&self, session: &BroadcastSession, state: &AetherState) -> WorkflowState {
        let mut required = Vec::new();
        let mut optional = Vec::new();
        for requirement in &session.requirements {
            let service_key = match requirement.capability.as_str() {
                "obs" => "obsd",
                "streamlabs" => "labsd",
                "streamelements" => "elementsd",
                "deck" => "deckd",
                "audio" => "audiod",
                "av" => "avd",
                other => other,
            };
            let health = state
                .services
                .get(&requirement.capability)
                .or_else(|| state.services.get(service_key))
                .copied()
                .unwrap_or(ServiceHealth::Offline);
            if health != ServiceHealth::Connected {
                let issue = CapabilityIssue {
                    capability: requirement.capability.clone(),
                    reason: format!("service health is {health:?}"),
                    required: requirement.level == RequirementLevel::Required,
                };
                if issue.required {
                    required.push(issue);
                } else {
                    optional.push(issue);
                }
            }
        }
        if !required.is_empty() {
            WorkflowState::Blocked(required)
        } else if !optional.is_empty() {
            WorkflowState::Degraded(optional)
        } else {
            WorkflowState::Ready
        }
    }

    #[must_use]
    pub fn load_commands(&self, session: &BroadcastSession) -> Vec<ServiceCommand> {
        let mut commands = vec![ServiceCommand::ResolveSession];
        if let Some(value) = &session.workspace_preset {
            commands.push(ServiceCommand::RestoreWorkspace(value.clone()));
        }
        if let Some(value) = &session.input_dsp_preset {
            commands.push(ServiceCommand::RestoreInputDsp(value.clone()));
        }
        if let Some(value) = &session.output_dsp_preset {
            commands.push(ServiceCommand::RestoreOutputDsp(value.clone()));
        }
        if let Some(value) = &session.deck_profile {
            commands.push(ServiceCommand::SelectDeckProfile(value.clone()));
        }
        if let Some(value) = &session.streamelements_package {
            commands.push(ServiceCommand::SelectStreamElementsPackage(value.clone()));
        }
        if let Some(value) = &session.streamlabs_profile {
            commands.push(ServiceCommand::SelectStreamlabsProfile(value.clone()));
        }
        commands
    }

    #[must_use]
    pub fn go_live_commands(&self, session: &BroadcastSession) -> Vec<ServiceCommand> {
        let mut commands = self.load_commands(session);
        if let Some(profile) = &session.recording_profile {
            commands.push(ServiceCommand::PrepareRecording(profile.clone()));
            commands.push(ServiceCommand::StartRecording);
        }
        commands.push(ServiceCommand::SwitchObsScene("Starting Soon".into()));
        commands.push(ServiceCommand::StartObsStream);
        commands.push(ServiceCommand::WaitForStreamOnline);
        commands
    }

    #[must_use]
    pub fn end_commands(&self, raid: bool) -> Vec<ServiceCommand> {
        let mut commands = Vec::new();
        if raid {
            commands.push(ServiceCommand::BeginRaid);
        }
        commands.extend([
            ServiceCommand::SwitchObsScene("Ending".into()),
            ServiceCommand::StopObsStream,
            ServiceCommand::WaitForStreamOffline,
            ServiceCommand::StopAndFinalizeRecording,
            ServiceCommand::CreateOrUpdateMediaProject,
            ServiceCommand::PersistSessionSummary,
            ServiceCommand::SwitchOfflinePresentation,
        ]);
        commands
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{RequirementLevel, SessionRequirement};

    fn ready_state() -> AetherState {
        let mut state = AetherState::default();
        for name in ["obs", "streamlabs", "streamelements"] {
            state.services.insert(name.into(), ServiceHealth::Connected);
        }
        state
    }

    #[test]
    fn optional_streamlabs_failure_degrades_but_does_not_block_go_live() {
        let mut session = BroadcastSession::fixture();
        session.requirements = vec![SessionRequirement::provider(
            "streamlabs",
            RequirementLevel::Optional,
        )];
        let mut state = ready_state();
        state.services.insert("streamlabs".into(), ServiceHealth::Offline);
        let result = SessionOrchestrator.preflight(&session, &state);
        assert!(matches!(result, WorkflowState::Degraded(_)));
        assert!(result.may_continue());
    }

    #[test]
    fn required_obs_failure_blocks_go_live() {
        let mut session = BroadcastSession::fixture();
        session.requirements = vec![SessionRequirement::provider("obs", RequirementLevel::Required)];
        let mut state = ready_state();
        state.services.insert("obs".into(), ServiceHealth::Offline);
        assert!(matches!(
            SessionOrchestrator.preflight(&session, &state),
            WorkflowState::Blocked(_)
        ));
    }

    #[test]
    fn go_live_command_order_is_deterministic() {
        let session = BroadcastSession::fixture();
        let commands = SessionOrchestrator.go_live_commands(&session);
        assert!(matches!(commands.last(), Some(ServiceCommand::WaitForStreamOnline)));
        let start = commands.iter().position(|c| matches!(c, ServiceCommand::StartObsStream)).unwrap();
        let wait = commands.iter().position(|c| matches!(c, ServiceCommand::WaitForStreamOnline)).unwrap();
        assert!(start < wait);
    }
}
