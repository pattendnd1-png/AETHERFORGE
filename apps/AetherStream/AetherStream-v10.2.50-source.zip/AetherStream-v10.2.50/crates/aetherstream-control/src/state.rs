use aetherstream_core::{AccountConnection, AuthProvider, OutputDspProfile, Provider, ServiceHealth, SessionId};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct StreamState {
    pub live: bool,
    pub channel: Option<String>,
    pub title: Option<String>,
    pub category: Option<String>,
    pub viewer_count: Option<u64>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct CreatorOpsState {
    pub active_poll: Option<String>,
    pub active_prediction: Option<String>,
    pub raid_target: Option<String>,
    pub shield_mode: bool,
    pub last_moderation: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct ObsState {
    pub active_scene: Option<String>,
    pub transition: Option<String>,
    pub sources: BTreeMap<String, bool>,
    pub replay_saves: u64,
    pub streaming: bool,
    pub recording: bool,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct AudioBusState {
    pub gain_db: f32,
    pub muted: bool,
    pub soloed: bool,
    pub monitor: bool,
    pub meter_dbfs: Option<f32>,
    pub dsp_preset: Option<String>,
    pub destinations: Vec<String>,
    pub recording_armed: bool,
}

impl Default for AudioBusState {
    fn default() -> Self {
        Self {
            gain_db: 0.0,
            muted: false,
            soloed: false,
            monitor: false,
            meter_dbfs: None,
            dsp_preset: None,
            destinations: Vec::new(),
            recording_armed: false,
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct OutputDspState {
    pub active_device_id: Option<String>,
    pub profiles: BTreeMap<String, OutputDspProfile>,
}


#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct LinkedOutputState {
    pub enabled: bool,
    pub hdmi_node_name: Option<String>,
    pub bluetooth_node_name: Option<String>,
    pub master_normalized_10k: u16,
    pub hdmi_trim_db_x100: i16,
    pub bluetooth_trim_db_x100: i16,
    pub latency_compensated: bool,
    pub topology_exact: bool,
    pub linked_sink_count: u16,
    pub member_count: u16,
    pub hdmi_route_count: u16,
    pub bluetooth_route_count: u16,
    pub extraneous_virtual_sinks: u16,
    pub extraneous_virtual_sources: u16,
    pub duplicate_output_routes: u16,
    pub orphan_links: u16,
    pub status_detail: Option<String>,
}

impl Default for LinkedOutputState {
    fn default() -> Self {
        Self {
            enabled: false,
            hdmi_node_name: None,
            bluetooth_node_name: None,
            master_normalized_10k: 7_000,
            hdmi_trim_db_x100: 0,
            bluetooth_trim_db_x100: 0,
            latency_compensated: false,
            topology_exact: false,
            linked_sink_count: 0,
            member_count: 0,
            hdmi_route_count: 0,
            bluetooth_route_count: 0,
            extraneous_virtual_sinks: 0,
            extraneous_virtual_sources: 0,
            duplicate_output_routes: 0,
            orphan_links: 0,
            status_detail: None,
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct AudioState {
    pub buses: BTreeMap<String, AudioBusState>,
    #[serde(default)]
    pub output_dsp: OutputDspState,
    #[serde(default)]
    pub linked_output: LinkedOutputState,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct RecordingState {
    pub active: bool,
    pub profile: Option<String>,
    pub manifest_ref: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct OverlayState {
    pub streamelements_package: Option<String>,
    pub streamlabs_profile: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct StreamElementsOpsState {
    pub queue_paused: bool,
    pub muted: bool,
    pub last_action: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct StreamlabsOpsState {
    pub alert_queue_paused: bool,
    pub alert_muted: bool,
    pub media_share_paused: bool,
    pub media_share_moderation: bool,
    pub last_action: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct AlertState {
    pub last_provider: Option<Provider>,
    pub last_kind: Option<String>,
    pub pending_count: u64,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct DeckState {
    pub profile: Option<String>,
    pub page: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct MediaState {
    pub project: Option<String>,
    pub last_recording_manifest: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct AuthState {
    pub connections: BTreeMap<AuthProvider, AccountConnection>,
    pub smart_restore_enabled: bool,
    pub last_restore_status: Option<String>,
}

impl Default for AuthState {
    fn default() -> Self {
        let connections = [
            AuthProvider::Twitch,
            AuthProvider::Streamlabs,
            AuthProvider::StreamElements,
            AuthProvider::BroadcastEngine,
        ]
        .into_iter()
        .map(|provider| (provider, AccountConnection::disconnected(provider)))
        .collect();
        Self { connections, smart_restore_enabled: true, last_restore_status: None }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct AetherState {
    pub revision: u64,
    pub auth: AuthState,
    pub active_session: Option<SessionId>,
    pub stream: StreamState,
    pub creator: CreatorOpsState,
    pub obs: ObsState,
    pub audio: AudioState,
    pub recording: RecordingState,
    pub overlays: OverlayState,
    pub streamelements_ops: StreamElementsOpsState,
    pub streamlabs_ops: StreamlabsOpsState,
    pub alerts: AlertState,
    pub deck: DeckState,
    pub media: MediaState,
    pub services: BTreeMap<String, ServiceHealth>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum StateChange {
    Auth(AuthState),
    ActiveSession(Option<SessionId>),
    Stream(StreamState),
    Creator(CreatorOpsState),
    Obs(ObsState),
    Audio(AudioState),
    Recording(RecordingState),
    Overlays(OverlayState),
    StreamElementsOps(StreamElementsOpsState),
    StreamlabsOps(StreamlabsOpsState),
    Alerts(AlertState),
    Deck(DeckState),
    Media(MediaState),
    Services(BTreeMap<String, ServiceHealth>),
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct StateDelta {
    pub from_revision: u64,
    pub to_revision: u64,
    pub changes: Vec<StateChange>,
}

impl StateDelta {
    #[must_use]
    pub fn is_contiguous(&self) -> bool {
        self.to_revision == self.from_revision.saturating_add(1)
    }

    #[must_use]
    pub fn between(previous: &AetherState, next: &AetherState) -> Self {
        let mut changes = Vec::new();
        if previous.auth != next.auth {
            changes.push(StateChange::Auth(next.auth.clone()));
        }
        if previous.active_session != next.active_session {
            changes.push(StateChange::ActiveSession(next.active_session));
        }
        if previous.stream != next.stream {
            changes.push(StateChange::Stream(next.stream.clone()));
        }
        if previous.creator != next.creator {
            changes.push(StateChange::Creator(next.creator.clone()));
        }
        if previous.obs != next.obs {
            changes.push(StateChange::Obs(next.obs.clone()));
        }
        if previous.audio != next.audio {
            changes.push(StateChange::Audio(next.audio.clone()));
        }
        if previous.recording != next.recording {
            changes.push(StateChange::Recording(next.recording.clone()));
        }
        if previous.overlays != next.overlays {
            changes.push(StateChange::Overlays(next.overlays.clone()));
        }
        if previous.streamelements_ops != next.streamelements_ops {
            changes.push(StateChange::StreamElementsOps(
                next.streamelements_ops.clone(),
            ));
        }
        if previous.streamlabs_ops != next.streamlabs_ops {
            changes.push(StateChange::StreamlabsOps(next.streamlabs_ops.clone()));
        }
        if previous.alerts != next.alerts {
            changes.push(StateChange::Alerts(next.alerts.clone()));
        }
        if previous.deck != next.deck {
            changes.push(StateChange::Deck(next.deck.clone()));
        }
        if previous.media != next.media {
            changes.push(StateChange::Media(next.media.clone()));
        }
        if previous.services != next.services {
            changes.push(StateChange::Services(next.services.clone()));
        }
        Self {
            from_revision: previous.revision,
            to_revision: next.revision,
            changes,
        }
    }

    pub fn apply_to(&self, state: &mut AetherState) -> Result<(), String> {
        if state.revision != self.from_revision || !self.is_contiguous() {
            return Err("non-contiguous state delta".into());
        }
        for change in &self.changes {
            match change {
                StateChange::Auth(value) => state.auth = value.clone(),
                StateChange::ActiveSession(value) => state.active_session = *value,
                StateChange::Stream(value) => state.stream = value.clone(),
                StateChange::Creator(value) => state.creator = value.clone(),
                StateChange::Obs(value) => state.obs = value.clone(),
                StateChange::Audio(value) => state.audio = value.clone(),
                StateChange::Recording(value) => state.recording = value.clone(),
                StateChange::Overlays(value) => state.overlays = value.clone(),
                StateChange::StreamElementsOps(value) => state.streamelements_ops = value.clone(),
                StateChange::StreamlabsOps(value) => state.streamlabs_ops = value.clone(),
                StateChange::Alerts(value) => state.alerts = value.clone(),
                StateChange::Deck(value) => state.deck = value.clone(),
                StateChange::Media(value) => state.media = value.clone(),
                StateChange::Services(value) => state.services = value.clone(),
            }
        }
        state.revision = self.to_revision;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_state_starts_at_revision_zero() {
        let state = AetherState::default();
        assert_eq!(state.revision, 0);
        assert!(state.active_session.is_none());
    }

    #[test]
    fn state_delta_requires_next_revision() {
        let delta = StateDelta {
            from_revision: 7,
            to_revision: 8,
            changes: vec![],
        };
        assert!(delta.is_contiguous());
    }

    #[test]
    fn auth_state_round_trips_in_revision_delta_without_secret_fields() {
        let previous = AetherState::default();
        let mut next = previous.clone();
        next.revision = 1;
        let twitch = next.auth.connections.get_mut(&AuthProvider::Twitch).unwrap();
        twitch.state = aetherstream_core::AuthConnectionState::AwaitingUser;
        twitch.user_code = Some("ABCD1234".into());
        let delta = StateDelta::between(&previous, &next);
        let mut applied = previous;
        delta.apply_to(&mut applied).unwrap();
        assert_eq!(applied, next);
        let json = serde_json::to_string(&applied.auth).unwrap();
        for forbidden in ["access_token", "refresh_token", "client_secret", "password"] {
            assert!(!json.contains(forbidden));
        }
    }

    #[test]
    fn provider_operation_projections_round_trip_in_delta() {
        let previous = AetherState::default();
        let mut next = previous.clone();
        next.revision = 1;
        next.creator.active_poll = Some("Next game?".into());
        next.obs.transition = Some("Fade".into());
        next.streamelements_ops.queue_paused = true;
        next.streamlabs_ops.media_share_paused = true;
        let delta = StateDelta::between(&previous, &next);
        let mut applied = previous;
        delta.apply_to(&mut applied).unwrap();
        assert_eq!(applied, next);
    }
}
