use crate::{AetherState, StateDelta};
use std::collections::VecDeque;

#[derive(Clone, Debug, PartialEq)]
pub enum SubscriptionUpdate {
    Snapshot(Box<AetherState>),
    Delta(StateDelta),
}

pub struct SubscriptionHub {
    retained: usize,
    deltas: VecDeque<StateDelta>,
}

impl SubscriptionHub {
    #[must_use]
    pub fn new(retained: usize) -> Self {
        Self {
            retained: retained.max(1),
            deltas: VecDeque::new(),
        }
    }

    pub fn publish(&mut self, previous: &AetherState, next: &AetherState) {
        if next.revision == previous.revision {
            return;
        }
        if next.revision != previous.revision.saturating_add(1) {
            self.deltas.clear();
            return;
        }
        self.deltas.push_back(StateDelta::between(previous, next));
        while self.deltas.len() > self.retained {
            self.deltas.pop_front();
        }
    }

    #[must_use]
    pub fn update_since(&self, since_revision: u64, current: &AetherState) -> SubscriptionUpdate {
        if since_revision == current.revision {
            return SubscriptionUpdate::Snapshot(Box::new(current.clone()));
        }
        let Some(delta) = self
            .deltas
            .iter()
            .find(|delta| delta.from_revision == since_revision && delta.to_revision == current.revision)
        else {
            return SubscriptionUpdate::Snapshot(Box::new(current.clone()));
        };
        SubscriptionUpdate::Delta(delta.clone())
    }
}

impl Default for SubscriptionHub {
    fn default() -> Self {
        Self::new(64)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn snapshot_variant_keeps_large_state_out_of_line() {
        assert!(std::mem::size_of::<SubscriptionUpdate>() < std::mem::size_of::<AetherState>());
    }

    #[test]
    fn old_revision_falls_back_to_snapshot() {
        let mut hub = SubscriptionHub::new(1);
        let a = AetherState::default();
        let mut b = a.clone();
        b.revision = 1;
        hub.publish(&a, &b);
        let mut c = b.clone();
        c.revision = 2;
        hub.publish(&b, &c);
        assert!(matches!(hub.update_since(0, &c), SubscriptionUpdate::Snapshot(_)));
    }
}
