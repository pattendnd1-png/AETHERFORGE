use crate::AetherState;
use aetherstream_core::{UnifiedEvent, UnifiedEventKind};
use thiserror::Error;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ReduceOutcome {
    pub changed: bool,
    pub revision: u64,
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum ReduceError {
    #[error("missing or invalid event field: {0}")]
    InvalidPayload(&'static str),
}

pub fn reduce(state: &mut AetherState, event: &UnifiedEvent) -> Result<ReduceOutcome, ReduceError> {
    let changed = match &event.kind {
        UnifiedEventKind::ObsSceneChanged => {
            let scene = event
                .provider_payload
                .get("scene")
                .and_then(serde_json::Value::as_str)
                .ok_or(ReduceError::InvalidPayload("scene"))?;
            if state.obs.active_scene.as_deref() == Some(scene) {
                false
            } else {
                state.obs.active_scene = Some(scene.to_owned());
                true
            }
        }
        UnifiedEventKind::StreamOnline => {
            let mut changed = !state.stream.live;
            if state.stream.channel != event.channel {
                state.stream.channel.clone_from(&event.channel);
                changed = true;
            }
            state.stream.live = true;
            changed
        }
        UnifiedEventKind::StreamOffline => {
            if state.stream.live {
                state.stream.live = false;
                true
            } else {
                false
            }
        }
        UnifiedEventKind::RecordingStarted => {
            let mut changed = !state.recording.active || !state.obs.recording;
            state.recording.active = true;
            state.obs.recording = true;
            if let Some(profile) = event
                .provider_payload
                .get("profile")
                .and_then(serde_json::Value::as_str)
                && state.recording.profile.as_deref() != Some(profile)
            {
                state.recording.profile = Some(profile.to_owned());
                changed = true;
            }
            changed
        }
        UnifiedEventKind::RecordingStopped => {
            if state.recording.active || state.obs.recording {
                state.recording.active = false;
                state.obs.recording = false;
                true
            } else {
                false
            }
        }
        UnifiedEventKind::Alert
        | UnifiedEventKind::Follow
        | UnifiedEventKind::Subscription
        | UnifiedEventKind::GiftSubscription
        | UnifiedEventKind::Raid
        | UnifiedEventKind::Cheer
        | UnifiedEventKind::Tip
        | UnifiedEventKind::Donation
        | UnifiedEventKind::ChannelPointRedemption => {
            state.alerts.last_provider = Some(event.provider);
            state.alerts.last_kind = Some(format!("{:?}", event.kind));
            state.alerts.pending_count = state.alerts.pending_count.saturating_add(1);
            true
        }
        UnifiedEventKind::Custom(name) if name == "service.health" => {
            let service = event
                .provider_payload
                .get("service")
                .and_then(serde_json::Value::as_str)
                .ok_or(ReduceError::InvalidPayload("service"))?;
            let health = event
                .provider_payload
                .get("health")
                .and_then(serde_json::Value::as_str)
                .ok_or(ReduceError::InvalidPayload("health"))?;
            let parsed = match health {
                "connected" => aetherstream_core::ServiceHealth::Connected,
                "reconnecting" => aetherstream_core::ServiceHealth::Reconnecting,
                "degraded" => aetherstream_core::ServiceHealth::Degraded,
                "offline" => aetherstream_core::ServiceHealth::Offline,
                "auth_required" => aetherstream_core::ServiceHealth::AuthRequired,
                "rate_limited" => aetherstream_core::ServiceHealth::RateLimited,
                _ => return Err(ReduceError::InvalidPayload("health")),
            };
            if state.services.get(service).copied() == Some(parsed) {
                false
            } else {
                state.services.insert(service.to_owned(), parsed);
                true
            }
        }
        UnifiedEventKind::Custom(_) | UnifiedEventKind::ChatMessage | UnifiedEventKind::ModerationAction => false,
    };

    if changed {
        state.revision = state.revision.saturating_add(1);
    }
    Ok(ReduceOutcome {
        changed,
        revision: state.revision,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use aetherstream_core::{Provider, UnifiedEvent, UnifiedEventKind};

    #[test]
    fn obs_scene_event_updates_scene_and_revision_once() {
        let mut state = AetherState::default();
        let mut event = UnifiedEvent::new(Provider::Obs, UnifiedEventKind::ObsSceneChanged);
        event.provider_payload = serde_json::json!({"scene":"Gameplay"});
        let out = reduce(&mut state, &event).unwrap();
        assert!(out.changed);
        assert_eq!(state.obs.active_scene.as_deref(), Some("Gameplay"));
        assert_eq!(state.revision, 1);
    }

    #[test]
    fn duplicate_equivalent_state_does_not_increment_revision() {
        let mut state = AetherState::default();
        state.obs.active_scene = Some("Gameplay".into());
        let mut event = UnifiedEvent::new(Provider::Obs, UnifiedEventKind::ObsSceneChanged);
        event.provider_payload = serde_json::json!({"scene":"Gameplay"});
        let out = reduce(&mut state, &event).unwrap();
        assert!(!out.changed);
        assert_eq!(state.revision, 0);
    }

    #[test]
    fn provider_alert_event_updates_shared_alert_projection() {
        let mut state = AetherState::default();
        let event = UnifiedEvent::new(Provider::StreamElements, UnifiedEventKind::Tip);
        reduce(&mut state, &event).unwrap();
        assert_eq!(state.alerts.last_provider, Some(Provider::StreamElements));
        assert_eq!(state.alerts.pending_count, 1);
    }
}
