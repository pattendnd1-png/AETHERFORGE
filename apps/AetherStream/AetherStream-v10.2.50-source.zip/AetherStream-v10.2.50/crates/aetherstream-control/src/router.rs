use aetherstream_core::AetherStreamAction;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ActionTarget {
    Twitch,
    Obs,
    StreamElements,
    Streamlabs,
    Audio,
    Deck,
    Workspace,
    Media,
    Session,
    Control,
    Auth,
    Unknown,
}

pub struct ActionRouter;

impl ActionRouter {
    #[must_use]
    pub fn target(action: &AetherStreamAction) -> ActionTarget {
        match action {
            AetherStreamAction::Auth(_) => ActionTarget::Auth,
            AetherStreamAction::ObsScene(_)
            | AetherStreamAction::ObsMute { .. }
            | AetherStreamAction::ObsTransition(_)
            | AetherStreamAction::ObsSourceVisibility { .. }
            | AetherStreamAction::ObsReplayBufferSave => ActionTarget::Obs,
            AetherStreamAction::TwitchCreateClip
            | AetherStreamAction::TwitchMarker(_)
            | AetherStreamAction::TwitchRaid(_)
            | AetherStreamAction::TwitchShieldMode(_)
            | AetherStreamAction::TwitchCreatePoll(_)
            | AetherStreamAction::TwitchCreatePrediction(_)
            | AetherStreamAction::TwitchModeration(_) => ActionTarget::Twitch,
            AetherStreamAction::StreamElementsTestAlert(_)
            | AetherStreamAction::StreamElementsOverlay(_) => ActionTarget::StreamElements,
            AetherStreamAction::StreamlabsSkipAlert
            | AetherStreamAction::StreamlabsAlert(_)
            | AetherStreamAction::StreamlabsMediaShare(_) => ActionTarget::Streamlabs,
            AetherStreamAction::Workspace(_) | AetherStreamAction::MultiviewLayout(_) => {
                ActionTarget::Workspace
            }
            AetherStreamAction::DspPreset(_)
            | AetherStreamAction::OutputDspApply { .. }
            | AetherStreamAction::OutputDspBypass { .. }
            | AetherStreamAction::AudioGain { .. }
            | AetherStreamAction::AudioMute { .. }
            | AetherStreamAction::AudioSolo { .. }
            | AetherStreamAction::AudioMonitor { .. }
            | AetherStreamAction::SystemOutputVolume { .. }
            | AetherStreamAction::LinkedOutputConfigure(_) => ActionTarget::Audio,
            AetherStreamAction::RecordingToggle
            | AetherStreamAction::RecordingFinalize
            | AetherStreamAction::MediaOpenProject(_) => ActionTarget::Media,
            AetherStreamAction::DeckProfile(_) | AetherStreamAction::DeckPage(_) => {
                ActionTarget::Deck
            }
            AetherStreamAction::SessionLoad(_)
            | AetherStreamAction::SessionSave(_)
            | AetherStreamAction::SessionGoLive
            | AetherStreamAction::SessionEnd => ActionTarget::Session,
            AetherStreamAction::Macro(_) => ActionTarget::Control,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use aetherstream_core::{
        SessionId, StreamElementsOverlayAction, StreamlabsMediaShareAction, TwitchPollSpec,
    };

    fn representative_actions() -> Vec<AetherStreamAction> {
        vec![
            AetherStreamAction::Auth(aetherstream_core::AetherAuthAction::SmartRestore),
            AetherStreamAction::ObsScene("Gameplay".into()),
            AetherStreamAction::ObsTransition("Fade".into()),
            AetherStreamAction::TwitchCreateClip,
            AetherStreamAction::TwitchCreatePoll(TwitchPollSpec {
                title: "Next game?".into(),
                choices: vec!["One".into(), "Two".into()],
                duration_secs: 60,
            }),
            AetherStreamAction::StreamElementsOverlay(StreamElementsOverlayAction::Skip),
            AetherStreamAction::StreamlabsMediaShare(StreamlabsMediaShareAction::Pause),
            AetherStreamAction::Workspace("Forge Master".into()),
            AetherStreamAction::AudioGain {
                bus: "Mic".into(),
                gain_db: -4.0,
            },
            AetherStreamAction::SystemOutputVolume { normalized_10k: 7_300 },
            AetherStreamAction::DeckProfile("Forge Master".into()),
            AetherStreamAction::MediaOpenProject("session-1".into()),
            AetherStreamAction::SessionLoad(SessionId::new()),
            AetherStreamAction::Macro(vec![]),
        ]
    }

    #[test]
    fn every_action_has_exactly_one_owner() {
        for action in representative_actions() {
            assert_ne!(ActionRouter::target(&action), ActionTarget::Unknown);
        }
    }

    #[test]
    fn auth_actions_route_only_to_auth_owner() {
        assert_eq!(
            ActionRouter::target(&AetherStreamAction::Auth(
                aetherstream_core::AetherAuthAction::BeginLogin(aetherstream_core::AuthProvider::Twitch)
            )),
            ActionTarget::Auth
        );
    }

    #[test]
    fn creator_and_provider_operations_keep_single_owner() {
        assert_eq!(
            ActionRouter::target(&AetherStreamAction::TwitchCreatePoll(TwitchPollSpec {
                title: "Next game?".into(),
                choices: vec!["One".into(), "Two".into()],
                duration_secs: 60,
            })),
            ActionTarget::Twitch
        );
        assert_eq!(
            ActionRouter::target(&AetherStreamAction::ObsTransition("Fade".into())),
            ActionTarget::Obs
        );
        assert_eq!(
            ActionRouter::target(&AetherStreamAction::StreamElementsOverlay(
                StreamElementsOverlayAction::Skip
            )),
            ActionTarget::StreamElements
        );
        assert_eq!(
            ActionRouter::target(&AetherStreamAction::StreamlabsMediaShare(
                StreamlabsMediaShareAction::Pause
            )),
            ActionTarget::Streamlabs
        );
    }

    #[test]
    fn mic_gain_routes_only_to_audio() {
        let action = AetherStreamAction::AudioGain {
            bus: "Mic".into(),
            gain_db: -4.0,
        };
        assert_eq!(ActionRouter::target(&action), ActionTarget::Audio);
    }
}
