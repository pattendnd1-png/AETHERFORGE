use aetherstream_core::{AccountId, SessionId};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum SessionRole {
    Viewer,
    Streamer,
    Moderator,
    ForgeMaster,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum RequirementLevel {
    Optional,
    Required,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct SessionRequirement {
    pub capability: String,
    pub level: RequirementLevel,
}

impl SessionRequirement {
    #[must_use]
    pub fn provider(capability: impl Into<String>, level: RequirementLevel) -> Self {
        Self {
            capability: capability.into(),
            level,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct BroadcastSession {
    pub id: SessionId,
    pub name: String,
    pub twitch_account: Option<AccountId>,
    pub twitch_channel: Option<String>,
    pub role: SessionRole,
    pub stream_title: Option<String>,
    pub stream_category: Option<String>,
    pub obs_scene_collection: Option<String>,
    pub streamelements_package: Option<String>,
    pub streamlabs_profile: Option<String>,
    pub deck_profile: Option<String>,
    pub input_dsp_preset: Option<String>,
    pub output_dsp_preset: Option<String>,
    pub recording_profile: Option<String>,
    pub multiview_layout: Option<String>,
    pub workspace_preset: Option<String>,
    pub media_project: Option<String>,
    #[serde(default)]
    pub requirements: Vec<SessionRequirement>,
}

impl BroadcastSession {
    #[must_use]
    pub fn fixture() -> Self {
        Self {
            id: SessionId::new(),
            name: "Forge Master".into(),
            twitch_account: None,
            twitch_channel: Some("channel-a".into()),
            role: SessionRole::ForgeMaster,
            stream_title: Some("AetherForge".into()),
            stream_category: Some("Software and Game Development".into()),
            obs_scene_collection: Some("Forge".into()),
            streamelements_package: Some("DragonGlass".into()),
            streamlabs_profile: Some("DragonGlass".into()),
            deck_profile: Some("Forge Master".into()),
            input_dsp_preset: Some("Broadcast Voice".into()),
            output_dsp_preset: Some("Gaming Output".into()),
            recording_profile: Some("1440p ISO".into()),
            multiview_layout: Some("2x2".into()),
            workspace_preset: Some("Forge Master".into()),
            media_project: None,
            requirements: vec![SessionRequirement::provider(
                "obs",
                RequirementLevel::Required,
            )],
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn session_round_trip_preserves_cross_service_references() {
        let session = BroadcastSession::fixture();
        let bytes = serde_json::to_vec(&session).unwrap();
        assert_eq!(serde_json::from_slice::<BroadcastSession>(&bytes).unwrap(), session);
    }

    #[test]
    fn session_document_contains_references_not_secrets() {
        let text = serde_json::to_string(&BroadcastSession::fixture()).unwrap();
        for forbidden in ["access_token", "refresh_token", "oauth_secret", "password"] {
            assert!(!text.contains(forbidden));
        }
    }
}
