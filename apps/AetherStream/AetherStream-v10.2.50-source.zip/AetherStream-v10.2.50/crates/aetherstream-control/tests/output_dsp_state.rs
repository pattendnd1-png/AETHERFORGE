use aetherstream_control::{ActionRouter, ActionTarget, AetherState};
use aetherstream_core::{AetherStreamAction, OutputDeviceClass, OutputDspProfile};

#[test]
fn output_dsp_actions_route_to_audio_owner() {
    let profile = OutputDspProfile::factory(OutputDeviceClass::ClosedBackHeadphone);
    assert_eq!(
        ActionRouter::target(&AetherStreamAction::OutputDspApply {
            device_id: "alsa-output-headphones".into(),
            profile,
        }),
        ActionTarget::Audio
    );
    assert_eq!(
        ActionRouter::target(&AetherStreamAction::OutputDspBypass {
            device_id: "alsa-output-headphones".into(),
            bypassed: true,
        }),
        ActionTarget::Audio
    );
}

#[test]
fn output_dsp_state_defaults_empty_and_unselected() {
    let state = AetherState::default();
    assert!(state.audio.output_dsp.profiles.is_empty());
    assert!(state.audio.output_dsp.active_device_id.is_none());
}
