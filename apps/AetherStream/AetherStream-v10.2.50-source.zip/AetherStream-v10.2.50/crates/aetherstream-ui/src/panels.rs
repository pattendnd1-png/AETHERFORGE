pub const PRIMARY_TABS: &[&str] = &[
    "Home",
    "Live",
    "Streamlabs",
    "StreamElements",
    "A/V Studio",
    "Settings",
];

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ForgeMasterModel {
    panels: Vec<String>,
}

impl Default for ForgeMasterModel {
    fn default() -> Self {
        Self {
            panels: PRIMARY_TABS.iter().map(|panel| (*panel).to_owned()).collect(),
        }
    }
}

impl ForgeMasterModel {
    #[must_use]
    pub fn has_panel(&self, panel: &str) -> bool {
        self.panels.iter().any(|candidate| candidate == panel)
    }

    pub fn panels(&self) -> impl Iterator<Item = &str> {
        self.panels.iter().map(String::as_str)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn forge_master_uses_six_consolidated_primary_tabs() {
        let model = ForgeMasterModel::default();
        let panels: Vec<_> = model.panels().collect();
        assert_eq!(panels, PRIMARY_TABS);
        assert_eq!(panels.len(), 6);
        assert!(!model.has_panel("OBS"));
    }

    #[test]
    fn provider_features_are_not_reintroduced_as_primary_tabs() {
        let model = ForgeMasterModel::default();
        for redundant in [
            "OBS",
            "Player",
            "Chat",
            "Moderation",
            "Mixer",
            "DSP",
            "Alerts",
            "Activity",
            "Recording",
            "Replay",
            "Deck",
            "Health",
        ] {
            assert!(!model.has_panel(redundant));
        }
    }
}
