use aetherstream_control::AetherState;
use aetherstream_core::WindowId;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DetachedViewport {
    pub window_id: WindowId,
    pub panel: String,
    pub monitor_name: Option<String>,
    pub x: f32,
    pub y: f32,
    pub width: f32,
    pub height: f32,
}

impl DetachedViewport {
    pub fn show(&self, ctx: &egui::Context, state: &AetherState) {
        let id = egui::ViewportId::from_hash_of(self.window_id.to_string());
        let builder = egui::ViewportBuilder::default()
            .with_title(format!("AetherStream — {}", self.panel))
            .with_inner_size([self.width, self.height])
            .with_position([self.x, self.y]);
        let panel = self.panel.clone();
        let revision = state.revision;
        let live = state.stream.live;
        let scene = state.obs.active_scene.clone();
        let services = state.services.len();
        ctx.show_viewport_deferred(id, builder, move |ui, _class| {
            ui.heading(&panel);
            ui.label(if live { "● LIVE" } else { "○ OFFLINE" });
            ui.label(format!("Shared state revision {revision}"));
            ui.label(format!("Broadcast scene: {}", scene.as_deref().unwrap_or("—")));
            ui.label(format!("{services} service health entries"));
        });
    }
}
