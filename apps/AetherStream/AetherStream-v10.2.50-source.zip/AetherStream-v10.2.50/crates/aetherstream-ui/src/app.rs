use crate::{panels::ForgeMasterModel, theme, UiControlBridge, WorkspaceController};
use aetherstream_control::{AetherState, AudioBusState};
use aetherstream_core::{
    AccountConnection, AetherAuthAction, AetherStreamAction, AuthProvider, ClientInstanceId,
    OutputDeviceClass, OutputDspProfile, OutputFilter, OutputFilterKind, OutputParametricEqBand,
    ParametricEqBandKind, ServiceHealth, HDMI3_LOADOUT_ID, PEQ_MAX_BANDS,
    PEQ_MAX_FREQUENCY_HZ, PEQ_MIN_BANDS, PEQ_MIN_FREQUENCY_HZ,
    StreamElementsOverlayAction, StreamlabsAlertAction, StreamlabsMediaShareAction,
    TwitchModerationAction, TwitchPollSpec, TwitchPredictionSpec,
};
use aetherstream_ipc::ServiceSnapshot;
use egui_dock::{DockArea, DockState, TabViewer};
use std::collections::BTreeMap;
use std::time::Duration;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UiInstanceState {
    pub client_id: ClientInstanceId,
    pub services: BTreeMap<String, ServiceHealth>,
}

impl UiInstanceState {
    #[must_use]
    pub fn from_snapshot(client_id: ClientInstanceId, snapshot: ServiceSnapshot) -> Self {
        Self {
            client_id,
            services: snapshot.services,
        }
    }
}


#[derive(Clone, Debug)]
struct CreatorDrafts {
    poll_title: String,
    poll_choices: Vec<String>,
    poll_duration_secs: u32,
    prediction_title: String,
    prediction_outcomes: Vec<String>,
    prediction_window_secs: u32,
    raid_target: String,
    moderation_target: String,
    moderation_reason: String,
    moderation_timeout_secs: u32,
    moderation_message_id: String,
    manual_auth_codes: BTreeMap<AuthProvider, String>,
}

impl Default for CreatorDrafts {
    fn default() -> Self {
        Self {
            poll_title: String::new(),
            poll_choices: vec![String::new(), String::new()],
            poll_duration_secs: 60,
            prediction_title: String::new(),
            prediction_outcomes: vec![String::new(), String::new()],
            prediction_window_secs: 120,
            raid_target: String::new(),
            moderation_target: String::new(),
            moderation_reason: String::new(),
            moderation_timeout_secs: 600,
            moderation_message_id: String::new(),
            manual_auth_codes: BTreeMap::new(),
        }
    }
}

#[derive(Clone, Debug)]
struct OutputDspEditor {
    device_id: String,
    profile: OutputDspProfile,
    loaded_device_id: Option<String>,
}

impl Default for OutputDspEditor {
    fn default() -> Self {
        Self {
            device_id: HDMI3_LOADOUT_ID.into(),
            profile: OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker),
            loaded_device_id: None,
        }
    }
}

fn auto_apply_output_dsp_action(
    device_id: &str,
    before: &OutputDspProfile,
    after: &OutputDspProfile,
) -> Option<AetherStreamAction> {
    let device_id = device_id.trim();
    if device_id.is_empty() || before == after || after.validate(48_000.0, 2).is_err() {
        return None;
    }
    Some(AetherStreamAction::OutputDspApply {
        device_id: device_id.to_owned(),
        profile: after.clone(),
    })
}

impl OutputDspEditor {
    fn select_class(&mut self, class: OutputDeviceClass) {
        if self.profile.device_class != class {
            self.profile = OutputDspProfile::factory(class);
        }
    }

    fn sync_from_state(&mut self, state: &AetherState) {
        let Some(device_id) = state.audio.output_dsp.active_device_id.as_ref() else {
            return;
        };
        if self.loaded_device_id.as_ref() == Some(device_id) {
            return;
        }
        let Some(profile) = state.audio.output_dsp.profiles.get(device_id) else {
            return;
        };
        self.device_id.clone_from(device_id);
        self.profile.clone_from(profile);
        self.profile.normalize_parametric_eq();
        self.loaded_device_id = Some(device_id.clone());
    }
}

fn peq_visual_gain_db(bands: &[OutputParametricEqBand], frequency_hz: f32) -> f32 {
    bands
        .iter()
        .filter(|band| band.enabled)
        .map(|band| {
            let octaves = (frequency_hz / band.frequency_hz.max(PEQ_MIN_FREQUENCY_HZ)).log2();
            match band.kind {
                ParametricEqBandKind::Peak => {
                    let width = (1.0 / band.q.max(0.1)).max(0.03);
                    band.gain_db * (-0.5 * (octaves / width).powi(2)).exp()
                }
                ParametricEqBandKind::Notch => {
                    let width = (1.0 / band.q.max(0.1)).max(0.03);
                    -band.gain_db.abs().max(6.0) * (-0.5 * (octaves / width).powi(2)).exp()
                }
                ParametricEqBandKind::LowShelf => {
                    band.gain_db / (1.0 + (octaves * band.q.max(0.1) * 3.0).exp())
                }
                ParametricEqBandKind::HighShelf => {
                    band.gain_db / (1.0 + (-octaves * band.q.max(0.1) * 3.0).exp())
                }
            }
        })
        .sum::<f32>()
        .clamp(-24.0, 24.0)
}

fn render_peq_response_graph(ui: &mut egui::Ui, bands: &[OutputParametricEqBand]) {
    let width = ui.available_width().max(320.0);
    let (rect, _) = ui.allocate_exact_size(egui::vec2(width, 170.0), egui::Sense::hover());
    let painter = ui.painter_at(rect);
    let zero_y = rect.center().y;
    painter.line_segment(
        [egui::pos2(rect.left(), zero_y), egui::pos2(rect.right(), zero_y)],
        egui::Stroke::new(1.0, theme::color(theme::DRAGONGLASS_MUTED)),
    );
    for db in [-24.0_f32, -12.0, 12.0, 24.0] {
        let y = rect.center().y - (db / 48.0) * rect.height();
        painter.line_segment(
            [egui::pos2(rect.left(), y), egui::pos2(rect.right(), y)],
            egui::Stroke::new(0.5, theme::color(theme::DRAGONGLASS_MUTED)),
        );
    }
    let log_min = PEQ_MIN_FREQUENCY_HZ.ln();
    let log_max = PEQ_MAX_FREQUENCY_HZ.ln();
    let points = (0..=192)
        .map(|index| {
            let t = index as f32 / 192.0;
            let frequency = (log_min + (log_max - log_min) * t).exp();
            let gain = peq_visual_gain_db(bands, frequency);
            let x = rect.left() + rect.width() * t;
            let y = rect.center().y - (gain / 48.0) * rect.height();
            egui::pos2(x, y)
        })
        .collect::<Vec<_>>();
    painter.add(egui::Shape::line(
        points,
        egui::Stroke::new(2.0, theme::color(theme::DRAGONGLASS_ACCENT)),
    ));
    painter.text(
        rect.left_top() + egui::vec2(4.0, 4.0),
        egui::Align2::LEFT_TOP,
        "5 Hz",
        egui::FontId::monospace(10.0),
        theme::color(theme::DRAGONGLASS_MUTED),
    );
    painter.text(
        rect.right_top() + egui::vec2(-4.0, 4.0),
        egui::Align2::RIGHT_TOP,
        "35 kHz",
        egui::FontId::monospace(10.0),
        theme::color(theme::DRAGONGLASS_MUTED),
    );
}

struct PanelViewer<'a> {
    state: &'a AetherState,
    pending_actions: &'a mut Vec<AetherStreamAction>,
    detach_requests: &'a mut Vec<String>,
    drafts: &'a mut CreatorDrafts,
    dsp_editor: &'a mut OutputDspEditor,
}

impl PanelViewer<'_> {
    fn action(&mut self, action: AetherStreamAction) {
        self.pending_actions.push(action);
    }

    fn header(&mut self, ui: &mut egui::Ui, tab: &str, subtitle: &str) {
        ui.horizontal(|ui| {
            ui.vertical(|ui| {
                ui.heading(tab);
                ui.weak(subtitle);
            });
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.small_button("Detach").clicked() {
                    self.detach_requests.push(tab.to_owned());
                }
            });
        });
        ui.separator();
    }

    fn provider_connection(&self, provider: AuthProvider) -> AccountConnection {
        self.state
            .auth
            .connections
            .get(&provider)
            .cloned()
            .unwrap_or_else(|| AccountConnection::disconnected(provider))
    }

    fn render_provider_connection(
        &mut self,
        ui: &mut egui::Ui,
        provider: AuthProvider,
        title: &str,
        connect_label: &str,
    ) {
        let connection = self.provider_connection(provider);
        let mut pending_action = None;
        theme::glass_card(ui, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.strong(title);
                ui.separator();
                theme::connection_chip(ui, &connection.state);
                if let Some(name) = connection.display_name.as_deref() {
                    ui.separator();
                    ui.label(name);
                }
            });
            if let Some(detail) = connection.status_detail.as_deref() {
                ui.weak(detail);
            }
            if let Some(expires_at) = connection.expires_at_unix {
                ui.weak(format!("Credential expiry: unix {expires_at}"));
            }
            match provider {
                AuthProvider::Twitch => {
                    ui.label("Twitch Device Code");
                    if let Some(code) = connection.user_code.as_deref() {
                        ui.monospace(format!("Code: {code}"));
                    }
                    if let Some(uri) = connection.verification_uri.as_deref() {
                        ui.hyperlink_to("Open Twitch activation", uri);
                    }
                }
                AuthProvider::Streamlabs => {
                    ui.weak("Automatic browser callback with manual-code fallback for the Streamlabs account.");
                }
                AuthProvider::StreamElements => {
                    ui.weak("Automatic browser callback with manual-code fallback for the StreamElements account.");
                }
                AuthProvider::BroadcastEngine => {
                    ui.weak("Broadcast Engine challenge authentication stays behind Streamlabs Studio.");
                }
            }
            ui.horizontal_wrapped(|ui| {
                if connection.state == aetherstream_core::AuthConnectionState::Connected {
                    if ui.button("Disconnect").clicked() {
                        pending_action = Some(match provider {
                            AuthProvider::BroadcastEngine => {
                                AetherStreamAction::Auth(AetherAuthAction::DisconnectBroadcastEngine)
                            }
                            _ => AetherStreamAction::Auth(AetherAuthAction::Disconnect(provider)),
                        });
                    }
                } else if ui.button(connect_label).clicked() {
                    pending_action = Some(match provider {
                        AuthProvider::BroadcastEngine => {
                            AetherStreamAction::Auth(AetherAuthAction::ConnectBroadcastEngine)
                        }
                        _ => AetherStreamAction::Auth(AetherAuthAction::BeginLogin(provider)),
                    });
                }
            });
            if connection.manual_code_available {
                ui.horizontal(|ui| {
                    let code = self.drafts.manual_auth_codes.entry(provider).or_default();
                    ui.text_edit_singleline(code);
                    if ui.button("Submit manual code").clicked() {
                        let submitted = code.trim().to_owned();
                        if !submitted.is_empty() {
                            pending_action = Some(AetherStreamAction::Auth(
                                AetherAuthAction::SubmitManualCode { provider, code: submitted },
                            ));
                            code.clear();
                        }
                    }
                });
            }
        });
        if let Some(action) = pending_action {
            self.action(action);
        }
    }

    fn render_home(&mut self, ui: &mut egui::Ui) {
        self.header(ui, "Home", "Session overview • health • quick actions");

        ui.horizontal_wrapped(|ui| {
            ui.label(if self.state.stream.live { "● LIVE" } else { "○ OFFLINE" });
            ui.separator();
            ui.label(format!("revision {}", self.state.revision));
            ui.separator();
            ui.label(format!(
                "Scene: {}",
                self.state.obs.active_scene.as_deref().unwrap_or("—")
            ));
            ui.separator();
            ui.label(format!(
                "Deck: {}",
                self.state.deck.profile.as_deref().unwrap_or("—")
            ));
            ui.separator();
            ui.label(format!("Alerts: {}", self.state.alerts.pending_count));
        });

        ui.add_space(8.0);
        ui.horizontal_wrapped(|ui| {
            if ui.button("Go Live").clicked() {
                self.action(AetherStreamAction::SessionGoLive);
            }
            if ui.button("End Stream").clicked() {
                self.action(AetherStreamAction::SessionEnd);
            }
            if ui.button("Create Clip").clicked() {
                self.action(AetherStreamAction::TwitchCreateClip);
            }
            if ui.button("Add Marker").clicked() {
                self.action(AetherStreamAction::TwitchMarker(None));
            }
        });

        ui.add_space(8.0);
        ui.collapsing("Service health", |ui| self.render_health(ui));
        ui.collapsing("Current session", |ui| {
            ui.label(format!(
                "Channel: {}",
                self.state.stream.channel.as_deref().unwrap_or("—")
            ));
            ui.label(format!(
                "Title: {}",
                self.state.stream.title.as_deref().unwrap_or("—")
            ));
            ui.label(format!(
                "Category: {}",
                self.state.stream.category.as_deref().unwrap_or("—")
            ));
            ui.label(format!(
                "Media project: {}",
                self.state.media.project.as_deref().unwrap_or("—")
            ));
        });
    }

    fn render_live(&mut self, ui: &mut egui::Ui) {
        self.header(
            ui,
            "Live",
            "Twitch player • multiview • chat • moderation • creator controls",
        );

        self.render_provider_connection(ui, AuthProvider::Twitch, "Twitch account", "Connect Twitch");
        ui.add_space(8.0);

        ui.group(|ui| {
            ui.heading(if self.state.stream.live {
                "● LIVE PROGRAM"
            } else {
                "○ OFFLINE PROGRAM"
            });
            ui.label(self.state.stream.title.as_deref().unwrap_or("No stream title"));
            ui.label(format!(
                "Category: {}   Viewers: {}",
                self.state.stream.category.as_deref().unwrap_or("—"),
                self.state
                    .stream
                    .viewer_count
                    .map_or_else(|| "—".to_owned(), |count| count.to_string())
            ));
            ui.weak("Twitch-approved player surface mounts here when authenticated.");
        });

        ui.collapsing("Multiview", |ui| {
            ui.horizontal_wrapped(|ui| {
                for layout in ["1-up", "2-up", "3-up", "4-grid"] {
                    if ui.button(layout).clicked() {
                        self.action(AetherStreamAction::MultiviewLayout(layout.to_owned()));
                    }
                }
            });
        });

        ui.collapsing("Creator tools", |ui| {
            ui.horizontal_wrapped(|ui| {
                if ui.button("Create Clip").clicked() {
                    self.action(AetherStreamAction::TwitchCreateClip);
                }
                if ui.button("Add Marker").clicked() {
                    self.action(AetherStreamAction::TwitchMarker(None));
                }
                if ui.button("Shield ON").clicked() {
                    self.action(AetherStreamAction::TwitchShieldMode(true));
                }
                if ui.button("Shield OFF").clicked() {
                    self.action(AetherStreamAction::TwitchShieldMode(false));
                }
            });
            ui.label(format!(
                "Shield Mode: {}",
                on_off(self.state.creator.shield_mode)
            ));

            ui.separator();
            ui.strong("Poll");
            ui.text_edit_singleline(&mut self.drafts.poll_title);
            for choice in &mut self.drafts.poll_choices {
                ui.text_edit_singleline(choice);
            }
            ui.horizontal(|ui| {
                if self.drafts.poll_choices.len() < 5 && ui.small_button("+ choice").clicked() {
                    self.drafts.poll_choices.push(String::new());
                }
                if self.drafts.poll_choices.len() > 2 && ui.small_button("− choice").clicked() {
                    self.drafts.poll_choices.pop();
                }
                ui.add(
                    egui::Slider::new(&mut self.drafts.poll_duration_secs, 15..=1800)
                        .text("seconds"),
                );
                if ui.button("Create Poll").clicked() {
                    self.action(AetherStreamAction::TwitchCreatePoll(TwitchPollSpec {
                        title: self.drafts.poll_title.trim().to_owned(),
                        choices: self
                            .drafts
                            .poll_choices
                            .iter()
                            .map(|choice| choice.trim().to_owned())
                            .filter(|choice| !choice.is_empty())
                            .collect(),
                        duration_secs: self.drafts.poll_duration_secs,
                    }));
                }
            });
            ui.weak(format!(
                "Projected poll: {}",
                self.state.creator.active_poll.as_deref().unwrap_or("—")
            ));

            ui.separator();
            ui.strong("Prediction");
            ui.text_edit_singleline(&mut self.drafts.prediction_title);
            for outcome in &mut self.drafts.prediction_outcomes {
                ui.text_edit_singleline(outcome);
            }
            ui.horizontal(|ui| {
                if self.drafts.prediction_outcomes.len() < 10
                    && ui.small_button("+ outcome").clicked()
                {
                    self.drafts.prediction_outcomes.push(String::new());
                }
                if self.drafts.prediction_outcomes.len() > 2
                    && ui.small_button("− outcome").clicked()
                {
                    self.drafts.prediction_outcomes.pop();
                }
                ui.add(
                    egui::Slider::new(&mut self.drafts.prediction_window_secs, 30..=1800)
                        .text("seconds"),
                );
                if ui.button("Create Prediction").clicked() {
                    self.action(AetherStreamAction::TwitchCreatePrediction(
                        TwitchPredictionSpec {
                            title: self.drafts.prediction_title.trim().to_owned(),
                            outcomes: self
                                .drafts
                                .prediction_outcomes
                                .iter()
                                .map(|outcome| outcome.trim().to_owned())
                                .filter(|outcome| !outcome.is_empty())
                                .collect(),
                            window_secs: self.drafts.prediction_window_secs,
                        },
                    ));
                }
            });
            ui.weak(format!(
                "Projected prediction: {}",
                self.state.creator.active_prediction.as_deref().unwrap_or("—")
            ));

            ui.separator();
            ui.strong("Raid");
            ui.horizontal(|ui| {
                ui.text_edit_singleline(&mut self.drafts.raid_target);
                if ui.button("Start Raid").clicked() {
                    self.action(AetherStreamAction::TwitchRaid(
                        self.drafts.raid_target.trim().to_owned(),
                    ));
                }
            });
            ui.weak(format!(
                "Projected raid target: {}",
                self.state.creator.raid_target.as_deref().unwrap_or("—")
            ));
        });

        ui.collapsing("Chat & moderation", |ui| {
            ui.weak("EventSub chat and moderation remain service-owned across every window.");
            ui.horizontal(|ui| {
                ui.label("User");
                ui.text_edit_singleline(&mut self.drafts.moderation_target);
            });
            ui.horizontal(|ui| {
                ui.label("Reason");
                ui.text_edit_singleline(&mut self.drafts.moderation_reason);
            });
            ui.horizontal_wrapped(|ui| {
                if ui.button("Ban").clicked() {
                    self.action(AetherStreamAction::TwitchModeration(
                        TwitchModerationAction::Ban {
                            user: self.drafts.moderation_target.trim().to_owned(),
                            reason: non_empty_owned(&self.drafts.moderation_reason),
                        },
                    ));
                }
                ui.add(
                    egui::Slider::new(&mut self.drafts.moderation_timeout_secs, 1..=86_400)
                        .text("timeout s"),
                );
                if ui.button("Timeout").clicked() {
                    self.action(AetherStreamAction::TwitchModeration(
                        TwitchModerationAction::Timeout {
                            user: self.drafts.moderation_target.trim().to_owned(),
                            duration_secs: self.drafts.moderation_timeout_secs,
                            reason: non_empty_owned(&self.drafts.moderation_reason),
                        },
                    ));
                }
                if ui.button("Unban").clicked() {
                    self.action(AetherStreamAction::TwitchModeration(
                        TwitchModerationAction::Unban {
                            user: self.drafts.moderation_target.trim().to_owned(),
                        },
                    ));
                }
            });
            ui.horizontal(|ui| {
                ui.label("Message ID");
                ui.text_edit_singleline(&mut self.drafts.moderation_message_id);
            });
            ui.horizontal_wrapped(|ui| {
                if ui.button("Delete message").clicked() {
                    self.action(AetherStreamAction::TwitchModeration(
                        TwitchModerationAction::DeleteMessage {
                            message_id: self.drafts.moderation_message_id.trim().to_owned(),
                        },
                    ));
                }
                if ui.button("Approve AutoMod").clicked() {
                    self.action(AetherStreamAction::TwitchModeration(
                        TwitchModerationAction::ApproveAutomod {
                            message_id: self.drafts.moderation_message_id.trim().to_owned(),
                        },
                    ));
                }
                if ui.button("Deny AutoMod").clicked() {
                    self.action(AetherStreamAction::TwitchModeration(
                        TwitchModerationAction::DenyAutomod {
                            message_id: self.drafts.moderation_message_id.trim().to_owned(),
                        },
                    ));
                }
            });
            ui.weak(format!(
                "Last moderation: {}",
                self.state.creator.last_moderation.as_deref().unwrap_or("—")
            ));
        });
    }

    fn render_streamelements_workspace(&mut self, ui: &mut egui::Ui) {
        self.header(
            ui,
            "StreamElements",
            "StreamElements • Overlays / Alerts / Goals / Activity",
        );

        self.render_provider_connection(
            ui,
            AuthProvider::StreamElements,
            "StreamElements account",
            "Connect StreamElements",
        );
        ui.add_space(8.0);

        ui.collapsing("Overlay package", |ui| {
            ui.label(format!(
                "Active package: {}",
                self.state
                    .overlays
                    .streamelements_package
                    .as_deref()
                    .unwrap_or("—")
            ));
            ui.label("Overlay Studio, widget configuration and browser-source deployment live here.");
        });
        ui.collapsing("Alert & overlay queue", |ui| {
            ui.horizontal_wrapped(|ui| {
                if ui.button("Test follow").clicked() {
                    self.action(AetherStreamAction::StreamElementsTestAlert("follow".into()));
                }
                for (label, action) in [
                    ("Pause", StreamElementsOverlayAction::Pause),
                    ("Resume", StreamElementsOverlayAction::Resume),
                    ("Mute", StreamElementsOverlayAction::Mute),
                    ("Unmute", StreamElementsOverlayAction::Unmute),
                    ("Skip", StreamElementsOverlayAction::Skip),
                    ("Play next", StreamElementsOverlayAction::PlayNext),
                    ("Reload", StreamElementsOverlayAction::Reload),
                ] {
                    if ui.button(label).clicked() {
                        self.action(AetherStreamAction::StreamElementsOverlay(action));
                    }
                }
            });
            ui.label(format!(
                "Queue: {}   Audio: {}   Last: {}",
                if self.state.streamelements_ops.queue_paused { "PAUSED" } else { "RUNNING" },
                if self.state.streamelements_ops.muted { "MUTED" } else { "AUDIBLE" },
                self.state.streamelements_ops.last_action.as_deref().unwrap_or("—")
            ));
            ui.label(format!("Unified pending events: {}", self.state.alerts.pending_count));
        });
        ui.collapsing("Goals, chatbot & activity", |ui| {
            ui.label("Goals, tips, chatbot state and StreamElements activity share this workspace rather than separate tabs.");
            ui.label(format!(
                "Last provider event: {}",
                self.state.alerts.last_kind.as_deref().unwrap_or("—")
            ));
        });
        ui.collapsing("Stream Deck actions", |ui| {
            if ui.button("Deck → StreamElements").clicked() {
                self.action(AetherStreamAction::DeckPage("StreamElements".into()));
            }
        });
    }

    fn render_streamlabs_workspace(&mut self, ui: &mut egui::Ui) {
        self.header(
            ui,
            "Streamlabs",
            "Streamlabs Studio • complete broadcast workspace • alerts • Media Share",
        );

        ui.horizontal_wrapped(|ui| {
            theme::streaming_chip(ui, self.state.stream.live || self.state.obs.streaming);
            ui.separator();
            theme::recording_chip(ui, self.state.recording.active || self.state.obs.recording);
            ui.separator();
            theme::connection_chip(
                ui,
                &self.provider_connection(AuthProvider::Streamlabs).state,
            );
            ui.separator();
            ui.weak(format!("revision {}", self.state.revision));
        });
        ui.add_space(6.0);

        self.render_provider_connection(
            ui,
            AuthProvider::Streamlabs,
            "Streamlabs account",
            "Connect Streamlabs",
        );
        ui.add_space(4.0);
        self.render_provider_connection(
            ui,
            AuthProvider::BroadcastEngine,
            "Broadcast Engine",
            "Connect Engine",
        );
        ui.add_space(8.0);

        ui.horizontal(|ui| {
            theme::status_card(
                ui,
                "STREAM",
                if self.state.stream.live || self.state.obs.streaming { "LIVE" } else { "OFFLINE" },
                self.state.stream.live || self.state.obs.streaming,
            );
            theme::status_card(
                ui,
                "RECORD",
                if self.state.recording.active || self.state.obs.recording { "ACTIVE" } else { "READY" },
                self.state.recording.active || self.state.obs.recording,
            );
            theme::status_card(
                ui,
                "ALERT QUEUE",
                if self.state.streamlabs_ops.alert_queue_paused { "PAUSED" } else { "RUNNING" },
                !self.state.streamlabs_ops.alert_queue_paused,
            );
        });
        ui.add_space(8.0);

        ui.horizontal(|ui| {
            theme::studio_panel(ui, "Preview", |ui| {
                ui.label("Preview bus");
                ui.strong(self.state.obs.active_scene.as_deref().unwrap_or("No scene selected"));
                ui.weak("Scene and source changes are prepared here before program output.");
            });
            theme::studio_panel(ui, "Program", |ui| {
                ui.label("Program output");
                ui.strong(self.state.obs.active_scene.as_deref().unwrap_or("No scene selected"));
                ui.weak(format!(
                    "{} • {}",
                    if self.state.stream.live { "LIVE" } else { "OFFLINE" },
                    self.state.obs.transition.as_deref().unwrap_or("Cut")
                ));
            });
        });
        ui.add_space(8.0);

        theme::studio_panel(ui, "Scene rail", |ui| {
            ui.horizontal_wrapped(|ui| {
                for scene in ["Starting Soon", "Gameplay", "BRB", "Ending"] {
                    let active = self.state.obs.active_scene.as_deref() == Some(scene);
                    if ui.selectable_label(active, scene).clicked() {
                        self.action(AetherStreamAction::ObsScene(scene.to_owned()));
                    }
                }
            });
        });
        ui.add_space(6.0);

        theme::studio_panel(ui, "Source stack", |ui| {
            for source in ["Game Capture", "Camera", "Chat", "Alerts"] {
                let visible = self.state.obs.sources.get(source).copied().unwrap_or(true);
                ui.horizontal(|ui| {
                    if ui
                        .selectable_label(visible, if visible { "●" } else { "○" })
                        .clicked()
                    {
                        self.action(AetherStreamAction::ObsSourceVisibility {
                            source: source.to_owned(),
                            visible: !visible,
                        });
                    }
                    ui.label(source);
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        ui.weak(if visible { "Visible" } else { "Hidden" });
                    });
                });
            }
        });
        ui.add_space(6.0);

        theme::studio_panel(ui, "Transition & broadcast controls", |ui| {
            ui.horizontal_wrapped(|ui| {
                for transition in ["Cut", "Fade", "Swipe", "Stinger"] {
                    let active = self.state.obs.transition.as_deref() == Some(transition);
                    if ui.selectable_label(active, transition).clicked() {
                        self.action(AetherStreamAction::ObsTransition(transition.to_owned()));
                    }
                }
            });
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                if ui.button("Go Live").clicked() {
                    self.action(AetherStreamAction::SessionGoLive);
                }
                if ui.button("End Stream").clicked() {
                    self.action(AetherStreamAction::SessionEnd);
                }
                if ui.button(if self.state.recording.active { "Stop Record" } else { "Record" }).clicked() {
                    self.action(AetherStreamAction::RecordingToggle);
                }
                if ui.button("Save Replay").clicked() {
                    self.action(AetherStreamAction::ObsReplayBufferSave);
                }
                ui.weak(format!("Replay saves: {}", self.state.obs.replay_saves));
            });
        });
        ui.add_space(6.0);

        theme::studio_panel(ui, "Mixer & DSP", |ui| self.render_mixer(ui));
        ui.add_space(6.0);

        theme::studio_panel(ui, "Alert queue", |ui| {
            ui.label(format!(
                "Profile: {}",
                self.state.overlays.streamlabs_profile.as_deref().unwrap_or("—")
            ));
            ui.horizontal_wrapped(|ui| {
                for (label, action) in [
                    ("Skip", StreamlabsAlertAction::Skip),
                    ("Pause", StreamlabsAlertAction::Pause),
                    ("Resume", StreamlabsAlertAction::Resume),
                    ("Mute", StreamlabsAlertAction::Mute),
                    ("Unmute", StreamlabsAlertAction::Unmute),
                    ("Test follow", StreamlabsAlertAction::Test("follow".into())),
                ] {
                    if ui.button(label).clicked() {
                        self.action(AetherStreamAction::StreamlabsAlert(action));
                    }
                }
            });
            ui.label(format!(
                "Queue: {}   Audio: {}",
                if self.state.streamlabs_ops.alert_queue_paused { "PAUSED" } else { "RUNNING" },
                if self.state.streamlabs_ops.alert_muted { "MUTED" } else { "AUDIBLE" }
            ));
        });
        ui.add_space(6.0);

        theme::studio_panel(ui, "Donations & activity", |ui| {
            ui.label("Streamlabs donations and realtime activity are normalized into the shared AetherStream event bus.");
            ui.label(format!("Unified pending events: {}", self.state.alerts.pending_count));
            ui.label(format!(
                "Last activity: {}",
                self.state.alerts.last_kind.as_deref().unwrap_or("—")
            ));
        });
        ui.add_space(6.0);

        theme::studio_panel(ui, "Media Share", |ui| {
            ui.horizontal_wrapped(|ui| {
                for (label, action) in [
                    ("Play", StreamlabsMediaShareAction::Play),
                    ("Pause", StreamlabsMediaShareAction::Pause),
                    ("Skip", StreamlabsMediaShareAction::Skip),
                    ("Vol +", StreamlabsMediaShareAction::VolumeUp),
                    ("Vol −", StreamlabsMediaShareAction::VolumeDown),
                    ("Moderation ON", StreamlabsMediaShareAction::Moderation(true)),
                    ("Moderation OFF", StreamlabsMediaShareAction::Moderation(false)),
                ] {
                    if ui.button(label).clicked() {
                        self.action(AetherStreamAction::StreamlabsMediaShare(action));
                    }
                }
            });
            ui.label(format!(
                "Playback: {}   Moderation: {}   Last: {}",
                if self.state.streamlabs_ops.media_share_paused { "PAUSED" } else { "PLAYING" },
                on_off(self.state.streamlabs_ops.media_share_moderation),
                self.state.streamlabs_ops.last_action.as_deref().unwrap_or("—")
            ));
        });
        ui.add_space(6.0);

        theme::studio_panel(ui, "Stream Deck & broadcast health", |ui| {
            if ui.button("Deck → Streamlabs").clicked() {
                self.action(AetherStreamAction::DeckPage("Streamlabs".into()));
            }
            self.render_health_matching(ui, &["obs", "audio", "record", "labs"]);
        });
    }

    fn render_av_studio(&mut self, ui: &mut egui::Ui) {
        self.header(ui, "A/V Studio", "Capture • ISO recording • timeline • clips/VODs • export");
        self.render_recording(ui);
        ui.separator();
        ui.label(format!(
            "Project: {}",
            self.state.media.project.as_deref().unwrap_or("—")
        ));
        ui.label(format!(
            "Last recording manifest: {}",
            self.state
                .media
                .last_recording_manifest
                .as_deref()
                .unwrap_or("—")
        ));
        ui.collapsing("Editing workspace", |ui| {
            ui.label("Timeline, ISO tracks, audio stems, captions, scopes, color, overlays and export remain under one A/V Studio surface.");
        });
    }

    fn render_settings(&mut self, ui: &mut egui::Ui) {
        self.header(ui, "Settings", "Accounts • devices • DSP presets • Stream Deck editor • appearance");
        ui.collapsing("Settings → Accounts", |ui| {
            ui.label("Master account manager for Twitch, Streamlabs and StreamElements identities, defaults, scopes and reconnect actions.");
            ui.weak("OAuth app setup, when required: run aetherstream-configure-auth. Client secrets go straight to Linux Secret Service.");
            self.render_provider_connection(ui, AuthProvider::Twitch, "Twitch account", "Connect Twitch");
            ui.add_space(4.0);
            self.render_provider_connection(ui, AuthProvider::Streamlabs, "Streamlabs account", "Connect Streamlabs");
            ui.add_space(4.0);
            self.render_provider_connection(ui, AuthProvider::StreamElements, "StreamElements account", "Connect StreamElements");
            ui.separator();
            ui.horizontal_wrapped(|ui| {
                ui.label(format!("Smart restore: {}", on_off(self.state.auth.smart_restore_enabled)));
                if ui.button("Run Smart restore").clicked() {
                    self.action(AetherStreamAction::Auth(AetherAuthAction::SmartRestore));
                }
            });
            if let Some(status) = self.state.auth.last_restore_status.as_deref() {
                ui.weak(status);
            }
        });
        ui.collapsing("Broadcast Engine", |ui| {
            ui.label("Advanced Broadcast Engine connection/authentication diagnostics. Stream controls remain in Streamlabs Studio.");
            self.render_provider_connection(ui, AuthProvider::BroadcastEngine, "Broadcast Engine", "Connect Engine");
        });
        ui.collapsing("Audio devices & full-range DSP", |ui| {
            self.render_output_dsp_editor(ui);
            ui.separator();
            if self.state.audio.buses.is_empty() {
                ui.label("No active broadcast buses.");
            } else {
                for (name, bus) in &self.state.audio.buses {
                    ui.label(format!(
                        "{name}: {}",
                        bus.dsp_preset.as_deref().unwrap_or("No bus DSP preset")
                    ));
                }
            }
        });
        ui.collapsing("Stream Deck+ editor", |ui| self.render_deck(ui));
        ui.collapsing("Appearance", |ui| {
            ui.label("DragonGlass is active. Theme, density and per-workspace presentation settings live here.");
        });
        ui.collapsing("Service diagnostics", |ui| self.render_health(ui));
    }

    fn render_output_dsp_editor(&mut self, ui: &mut egui::Ui) {
        if let Some(active_device) = self.state.audio.output_dsp.active_device_id.as_deref() {
            let label = self
                .state
                .audio
                .output_dsp
                .profiles
                .get(active_device)
                .map(|profile| profile.name.as_str())
                .unwrap_or("Profile unavailable");
            theme::state_badge(
                ui,
                &format!("● OUTPUT DSP PROFILE — {active_device} — {label}"),
                theme::DRAGONGLASS_CONNECTED,
            );
        } else {
            theme::state_badge(
                ui,
                "○ OUTPUT DSP READY — no physical output profile applied yet",
                theme::DRAGONGLASS_MUTED,
            );
        }
        theme::state_badge(
            ui,
            "● LIVE • AUTO-APPLY — valid changes are sent while controls move",
            theme::DRAGONGLASS_CONNECTED,
        );

        let before_profile = self.dsp_editor.profile.clone();
        {
            let editor = &mut *self.dsp_editor;
            theme::dsp_card(ui, "Physical output", theme::DRAGONGLASS_ACCENT, |ui| {
                theme::state_badge(
                    ui,
                    "● PHYSICAL OUTPUT • NO OUTPUT SWITCHING",
                    theme::DRAGONGLASS_CONNECTED,
                );
                ui.horizontal_wrapped(|ui| {
                    ui.label("Loadout target");
                    ui.monospace(&editor.device_id);
                });
                ui.weak("Your selected physical output stays the real system output. HDMI3 and Bluetooth speakers use the same in-place DSP with no virtual or alternate output stream.");

                let before = editor.profile.device_class;
                let mut selected = before;
                egui::ComboBox::from_label("Output type")
                    .selected_text(selected.label())
                    .show_ui(ui, |ui| {
                        for class in OutputDeviceClass::ALL {
                            ui.selectable_value(&mut selected, class, class.label());
                        }
                    });
                if selected != before {
                    editor.select_class(selected);
                }
                ui.text_edit_singleline(&mut editor.profile.name);
                ui.checkbox(&mut editor.profile.bypassed, "Bypass entire DSP chain");
            });

            theme::dsp_card(ui, "Headroom & output", theme::DRAGONGLASS_ACCENT_DEEP, |ui| {
                ui.add(
                    egui::Slider::new(&mut editor.profile.preamp_db, -24.0..=12.0)
                        .suffix(" dB")
                        .text("Preamp / headroom"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.output_gain_db, -24.0..=12.0)
                        .suffix(" dB")
                        .text("Output gain"),
                );
                ui.checkbox(&mut editor.profile.limiter.enabled, "Output limiter");
                if editor.profile.limiter.enabled {
                    ui.add(
                        egui::Slider::new(&mut editor.profile.limiter.ceiling_dbfs, -12.0..=0.0)
                            .suffix(" dBFS")
                            .text("Limiter ceiling"),
                    );
                }
            });

            theme::dsp_card(ui, "Bass boost", theme::DRAGONGLASS_BASS, |ui| {
                ui.checkbox(&mut editor.profile.bass.enabled, "Enabled");
                ui.add(
                    egui::Slider::new(&mut editor.profile.bass.amount_db, 0.0..=12.0)
                        .suffix(" dB")
                        .text("Bass boost"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.bass.frequency_hz, 35.0..=220.0)
                        .logarithmic(true)
                        .suffix(" Hz")
                        .text("Bass center"),
                );
                ui.add(egui::Slider::new(&mut editor.profile.bass.q, 0.3..=2.0).text("Bass Q"));
            });

            theme::dsp_card(ui, "Clarity boost", theme::DRAGONGLASS_CLARITY, |ui| {
                ui.checkbox(&mut editor.profile.clarity.enabled, "Enabled");
                ui.add(
                    egui::Slider::new(&mut editor.profile.clarity.amount_db, 0.0..=12.0)
                        .suffix(" dB")
                        .text("Clarity boost"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.clarity.frequency_hz, 1_000.0..=8_000.0)
                        .logarithmic(true)
                        .suffix(" Hz")
                        .text("Clarity center"),
                );
                ui.add(egui::Slider::new(&mut editor.profile.clarity.q, 0.3..=4.0).text("Clarity Q"));
            });

            theme::dsp_card(ui, "Gaming mode", theme::DRAGONGLASS_GAMING, |ui| {
                ui.checkbox(&mut editor.profile.gaming.enabled, "Gaming mode");
                ui.weak("Zero-lookahead IIR overlay for impact, reduced low-mid masking, and positional/detail emphasis.");
                ui.add(
                    egui::Slider::new(&mut editor.profile.gaming.impact_db, 0.0..=6.0)
                        .suffix(" dB")
                        .text("Impact"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.gaming.impact_frequency_hz, 60.0..=180.0)
                        .logarithmic(true)
                        .suffix(" Hz")
                        .text("Impact center"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.gaming.mud_cut_db, -6.0..=0.0)
                        .suffix(" dB")
                        .text("Low-mid cleanup"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.gaming.detail_db, 0.0..=6.0)
                        .suffix(" dB")
                        .text("Positional detail"),
                );
                ui.add(
                    egui::Slider::new(&mut editor.profile.gaming.detail_frequency_hz, 1_800.0..=5_000.0)
                        .logarithmic(true)
                        .suffix(" Hz")
                        .text("Detail center"),
                );
            });

            theme::dsp_card(ui, "Crossover & protection filters", theme::DRAGONGLASS_ACCENT, |ui| {
                let mut remove = None;
                for (index, filter) in editor.profile.filters.iter_mut().enumerate() {
                    ui.push_id(("protection-filter", index), |ui| {
                        ui.horizontal_wrapped(|ui| {
                            ui.checkbox(&mut filter.enabled, "");
                            egui::ComboBox::from_id_salt("filter-kind")
                                .selected_text(filter.kind.label())
                                .show_ui(ui, |ui| {
                                    for kind in [
                                        OutputFilterKind::HighPass,
                                        OutputFilterKind::BandPass,
                                        OutputFilterKind::LowPass,
                                    ] {
                                        ui.selectable_value(&mut filter.kind, kind, kind.label());
                                    }
                                });
                            if ui.small_button("Remove").clicked() {
                                remove = Some(index);
                            }
                        });
                        ui.add(
                            egui::Slider::new(&mut filter.frequency_hz, 5.0..=35_000.0)
                                .logarithmic(true)
                                .suffix(" Hz")
                                .text("Frequency"),
                        );
                        ui.add(egui::Slider::new(&mut filter.q, 0.1..=18.0).text("Q"));
                        if matches!(filter.kind, OutputFilterKind::HighPass | OutputFilterKind::LowPass) {
                            egui::ComboBox::from_label("Slope")
                                .selected_text(format!("{} dB/oct", filter.slope_db_per_octave))
                                .show_ui(ui, |ui| {
                                    for slope in [6, 12, 18, 24, 36, 48] {
                                        ui.selectable_value(
                                            &mut filter.slope_db_per_octave,
                                            slope,
                                            format!("{slope} dB/oct"),
                                        );
                                    }
                                });
                        }
                        ui.separator();
                    });
                }
                if let Some(index) = remove {
                    editor.profile.filters.remove(index);
                }
                ui.horizontal_wrapped(|ui| {
                    if ui.button("+ High-pass").clicked() {
                        editor.profile.filters.push(OutputFilter::high_pass(30.0, 12));
                    }
                    if ui.button("+ Mid-pass").clicked() {
                        editor.profile.filters.push(OutputFilter::new(OutputFilterKind::BandPass, 1_000.0));
                    }
                    if ui.button("+ Low-pass").clicked() {
                        editor.profile.filters.push(OutputFilter::low_pass(18_000.0, 12));
                    }
                });
            });

            theme::dsp_card(ui, "Parametric EQ — 15–31 bands", theme::DRAGONGLASS_ACCENT_DEEP, |ui| {
                ui.weak("Fully parametric • 5 Hz–35 kHz • ±24 dB • Q 0.1–18 • live auto-apply");
                render_peq_response_graph(ui, &editor.profile.parametric_eq);
                ui.horizontal_wrapped(|ui| {
                    ui.label(format!("{} bands", editor.profile.parametric_eq.len()));
                    for (count, label) in [(15, "15-band"), (21, "21-band"), (25, "25-band"), (31, "31-band")] {
                        if ui.small_button(label).clicked() {
                            editor.profile.set_parametric_eq_band_count(count);
                        }
                    }
                    if ui.small_button("+ Band").clicked() && editor.profile.parametric_eq.len() < PEQ_MAX_BANDS {
                        let next = editor.profile.parametric_eq.len() + 1;
                        editor.profile.set_parametric_eq_band_count(next);
                    }
                    if ui.small_button("- Band").clicked() && editor.profile.parametric_eq.len() > PEQ_MIN_BANDS {
                        let next = editor.profile.parametric_eq.len() - 1;
                        editor.profile.set_parametric_eq_band_count(next);
                    }
                });
                ui.separator();
                for (index, band) in editor.profile.parametric_eq.iter_mut().enumerate() {
                    ui.push_id(("peq-band", index), |ui| {
                        ui.horizontal_wrapped(|ui| {
                            ui.checkbox(&mut band.enabled, format!("Band {:02}", index + 1));
                            egui::ComboBox::from_id_salt("peq-kind")
                                .selected_text(band.kind.label())
                                .show_ui(ui, |ui| {
                                    for kind in ParametricEqBandKind::ALL {
                                        ui.selectable_value(&mut band.kind, kind, kind.label());
                                    }
                                });
                        });
                        ui.add(
                            egui::Slider::new(&mut band.frequency_hz, 5.0..=35_000.0)
                                .logarithmic(true)
                                .suffix(" Hz")
                                .text("Frequency"),
                        );
                        if !matches!(band.kind, ParametricEqBandKind::Notch) {
                            ui.add(
                                egui::Slider::new(&mut band.gain_db, -24.0..=24.0)
                                    .suffix(" dB")
                                    .text("Gain"),
                            );
                        }
                        ui.add(egui::Slider::new(&mut band.q, 0.1..=18.0).text("Q"));
                        if band.frequency_hz >= 48_000.0 * 0.49 {
                            ui.weak("Stored at full range; activates when HDMI3 sample rate supports this center frequency.");
                        }
                        ui.separator();
                    });
                }
            });

            if let Err(error) = editor.profile.validate(48_000.0, 2) {
                theme::state_badge(
                    ui,
                    &format!("▲ PROFILE CHECK — {error}"),
                    theme::DRAGONGLASS_ERROR,
                );
            }

            ui.horizontal_wrapped(|ui| {
                let bypass_label = if editor.profile.bypassed {
                    "Enable DSP"
                } else {
                    "Bypass DSP"
                };
                if ui.button(bypass_label).clicked() {
                    editor.profile.bypassed = !editor.profile.bypassed;
                }
                if ui.button("Reset selected type").clicked() {
                    let class = editor.profile.device_class;
                    editor.profile = OutputDspProfile::factory(class);
                }
                ui.weak("Auto-save + auto-apply active");
            });
        }

        if let Some(action) = auto_apply_output_dsp_action(
            &self.dsp_editor.device_id,
            &before_profile,
            &self.dsp_editor.profile,
        ) {
            self.action(action);
        }
    }

    fn render_mixer(&mut self, ui: &mut egui::Ui) {
        if self.state.audio.buses.is_empty() {
            ui.label("No broadcast buses yet.");
            if ui.button("Create broadcast mix").clicked() {
                let actions = ["Mic", "Game", "Discord", "Music", "Alerts", "Stream Master"]
                    .into_iter()
                    .map(|bus| AetherStreamAction::AudioGain {
                        bus: bus.to_owned(),
                        gain_db: 0.0,
                    })
                    .collect();
                self.action(AetherStreamAction::Macro(actions));
            }
            return;
        }

        let buses: Vec<(String, AudioBusState)> = self
            .state
            .audio
            .buses
            .iter()
            .map(|(name, bus)| (name.clone(), bus.clone()))
            .collect();
        for (name, bus) in buses {
            ui.horizontal(|ui| {
                ui.label(format!("{name:>13}"));
                let mut gain = bus.gain_db;
                if ui
                    .add(egui::Slider::new(&mut gain, -60.0..=12.0).suffix(" dB"))
                    .changed()
                {
                    self.action(AetherStreamAction::AudioGain {
                        bus: name.clone(),
                        gain_db: gain,
                    });
                }
                if ui.selectable_label(bus.muted, "M").clicked() {
                    self.action(AetherStreamAction::AudioMute {
                        bus: name.clone(),
                        muted: !bus.muted,
                    });
                }
                if ui.selectable_label(bus.soloed, "S").clicked() {
                    self.action(AetherStreamAction::AudioSolo {
                        bus: name.clone(),
                        soloed: !bus.soloed,
                    });
                }
                if ui.selectable_label(bus.monitor, "MON").clicked() {
                    self.action(AetherStreamAction::AudioMonitor {
                        bus: name.clone(),
                        enabled: !bus.monitor,
                    });
                }
                ui.label(bus.dsp_preset.as_deref().unwrap_or("DSP —"));
            });
        }
    }

    fn render_recording(&mut self, ui: &mut egui::Ui) {
        ui.label(if self.state.recording.active {
            "Recording is active"
        } else {
            "Recording is stopped"
        });
        if ui
            .button(if self.state.recording.active {
                "Stop recording"
            } else {
                "Start recording"
            })
            .clicked()
        {
            self.action(AetherStreamAction::RecordingToggle);
        }
        ui.label(format!(
            "Profile: {}",
            self.state.recording.profile.as_deref().unwrap_or("—")
        ));
    }

    fn render_deck(&mut self, ui: &mut egui::Ui) {
        ui.label(format!(
            "Profile: {}   Page: {}",
            self.state.deck.profile.as_deref().unwrap_or("—"),
            self.state.deck.page.as_deref().unwrap_or("—")
        ));
        ui.horizontal_wrapped(|ui| {
            for profile in ["Forge Master", "Streamer", "Moderator"] {
                if ui.button(profile).clicked() {
                    self.action(AetherStreamAction::DeckProfile(profile.to_owned()));
                }
            }
        });
        ui.horizontal_wrapped(|ui| {
            for page in ["Home", "Live", "Streamlabs", "StreamElements", "A/V Studio"] {
                if ui.small_button(page).clicked() {
                    self.action(AetherStreamAction::DeckPage(page.to_owned()));
                }
            }
        });
        ui.weak("Theme, key-state, dial, touch-strip and profile editing stay here while provider actions remain in their owning tabs.");
    }

    fn render_health(&self, ui: &mut egui::Ui) {
        if self.state.services.is_empty() {
            ui.label("No service health reports yet.");
            return;
        }
        for (service, health) in &self.state.services {
            ui.horizontal(|ui| {
                ui.label(health_dot(*health));
                ui.label(service);
                ui.label(format!("{health:?}"));
            });
        }
    }

    fn render_health_matching(&self, ui: &mut egui::Ui, needles: &[&str]) {
        let mut shown = 0usize;
        for (service, health) in &self.state.services {
            let lower = service.to_ascii_lowercase();
            if needles.iter().any(|needle| lower.contains(needle)) {
                shown += 1;
                ui.horizontal(|ui| {
                    ui.label(health_dot(*health));
                    ui.label(service);
                    ui.label(format!("{health:?}"));
                });
            }
        }
        if shown == 0 {
            ui.label("No matching service health reports yet.");
        }
    }
}

impl TabViewer for PanelViewer<'_> {
    type Tab = String;

    fn title(&mut self, tab: &mut Self::Tab) -> egui::WidgetText {
        tab.as_str().into()
    }

    fn id(&mut self, tab: &mut Self::Tab) -> egui::Id {
        egui::Id::new(tab.as_str())
    }

    fn ui(&mut self, ui: &mut egui::Ui, tab: &mut Self::Tab) {
        match tab.as_str() {
            "Home" => self.render_home(ui),
            "Live" => self.render_live(ui),
            "Streamlabs" => self.render_streamlabs_workspace(ui),
            "StreamElements" => self.render_streamelements_workspace(ui),
            "A/V Studio" => self.render_av_studio(ui),
            "Settings" => self.render_settings(ui),
            _ => {
                ui.label("AetherStream shared workstation");
            }
        };
    }
}

pub struct AetherStreamApp {
    pub instance: UiInstanceState,
    pub control_state: AetherState,
    pub workspace: WorkspaceController,
    dock: DockState<String>,
    bridge: UiControlBridge,
    theme_applied: bool,
    active_workspace: String,
    last_action_feedback: Option<String>,
    creator_drafts: CreatorDrafts,
    output_dsp_editor: OutputDspEditor,
}

impl AetherStreamApp {
    #[must_use]
    pub fn new(
        client_id: ClientInstanceId,
        snapshot: ServiceSnapshot,
        control_state: AetherState,
    ) -> Self {
        Self::with_bridge(client_id, snapshot, control_state, UiControlBridge::default())
    }

    #[must_use]
    pub fn with_bridge(
        client_id: ClientInstanceId,
        snapshot: ServiceSnapshot,
        control_state: AetherState,
        bridge: UiControlBridge,
    ) -> Self {
        let model = ForgeMasterModel::default();
        Self {
            instance: UiInstanceState::from_snapshot(client_id, snapshot),
            control_state,
            workspace: WorkspaceController::default(),
            dock: DockState::new(model.panels().map(str::to_owned).collect()),
            bridge,
            theme_applied: false,
            active_workspace: "Forge Master".into(),
            last_action_feedback: None,
            creator_drafts: CreatorDrafts::default(),
            output_dsp_editor: OutputDspEditor::default(),
        }
    }

    pub fn apply_state(&mut self, state: AetherState) {
        self.instance.services.clone_from(&state.services);
        self.output_dsp_editor.sync_from_state(&state);
        self.control_state = state;
    }

    fn dispatch_action(&mut self, action: AetherStreamAction) {
        self.last_action_feedback = Some(if self.bridge.dispatch(action) {
            "Action queued".into()
        } else {
            "Control service unavailable".into()
        });
    }
}

impl eframe::App for AetherStreamApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        if !self.theme_applied {
            theme::apply_dragonglass(&ctx);
            self.theme_applied = true;
        }
        if let Some(state) = self.bridge.drain_latest() {
            self.apply_state(state);
        }
        ctx.request_repaint_after(Duration::from_millis(250));

        egui::Panel::top("top").show(ui, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.heading("AetherStream");
                ui.separator();
                ui.label(format!("v{}", env!("CARGO_PKG_VERSION")));
                ui.separator();
                ui.label(if self.control_state.stream.live { "● LIVE" } else { "○ OFFLINE" });
                ui.separator();
                ui.label(format!("rev {}", self.control_state.revision));
                ui.separator();
                if ui.button("Go Live").clicked() {
                    self.dispatch_action(AetherStreamAction::SessionGoLive);
                }
                if ui.button("End Stream").clicked() {
                    self.dispatch_action(AetherStreamAction::SessionEnd);
                }
                if ui
                    .button(if self.control_state.recording.active { "Stop REC" } else { "Start REC" })
                    .clicked()
                {
                    self.dispatch_action(AetherStreamAction::RecordingToggle);
                }
                if let Some(feedback) = &self.last_action_feedback {
                    ui.separator();
                    ui.weak(feedback);
                }
            });
        });

        egui::Panel::left("workspace_rail")
            .resizable(false)
            .default_size(132.0)
            .show(ui, |ui| {
                ui.strong("WORKSPACE");
                for workspace in ["Forge Master", "Viewer", "Creator", "Moderator"] {
                    if ui
                        .selectable_label(self.active_workspace == workspace, workspace)
                        .clicked()
                    {
                        self.active_workspace = workspace.to_owned();
                        self.dispatch_action(AetherStreamAction::Workspace(workspace.to_owned()));
                    }
                }
                ui.separator();
                ui.small(format!("client {}", self.instance.client_id));
            });

        let mut pending_actions = Vec::new();
        let mut detach_requests = Vec::new();
        egui::CentralPanel::default().show(ui, |ui| {
            let mut viewer = PanelViewer {
                state: &self.control_state,
                pending_actions: &mut pending_actions,
                detach_requests: &mut detach_requests,
                drafts: &mut self.creator_drafts,
                dsp_editor: &mut self.output_dsp_editor,
            };
            DockArea::new(&mut self.dock).show_inside(ui, &mut viewer);
        });

        for action in pending_actions {
            self.dispatch_action(action);
        }
        for panel in detach_requests {
            let _ = self.workspace.detach(panel, "Current monitor");
        }
        for viewport in self.workspace.iter() {
            viewport.show(&ctx, &self.control_state);
        }
    }
}

fn non_empty_owned(value: &str) -> Option<String> {
    let value = value.trim();
    if value.is_empty() { None } else { Some(value.to_owned()) }
}

fn on_off(value: bool) -> &'static str {
    if value { "ON" } else { "OFF" }
}

fn health_dot(health: ServiceHealth) -> &'static str {
    match health {
        ServiceHealth::Connected => "●",
        ServiceHealth::Reconnecting | ServiceHealth::RateLimited => "◐",
        ServiceHealth::Degraded | ServiceHealth::AuthRequired => "▲",
        ServiceHealth::Offline => "○",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn output_dsp_editor_defaults_to_hdmi3_physical_loadout() {
        let editor = OutputDspEditor::default();
        assert_eq!(editor.device_id, HDMI3_LOADOUT_ID);
        assert_eq!(editor.profile.device_class, OutputDeviceClass::DesktopSpeaker);
        assert!(editor.profile.limiter.enabled);
    }

    #[test]
    fn output_dsp_editor_can_select_every_factory_device_class() {
        let mut editor = OutputDspEditor::default();
        for class in OutputDeviceClass::ALL {
            editor.select_class(class);
            assert_eq!(editor.profile.device_class, class);
        }
    }

    #[test]
    fn output_dsp_editor_keeps_gaming_mode_per_selected_profile() {
        let mut editor = OutputDspEditor::default();
        editor.select_class(OutputDeviceClass::TvSpeaker);
        editor.profile.gaming.enabled = true;
        assert_eq!(editor.profile.device_class, OutputDeviceClass::TvSpeaker);
        assert!(editor.profile.gaming.enabled);
    }

    #[test]
    fn output_dsp_editor_restores_active_persisted_profile_once() {
        let mut editor = OutputDspEditor::default();
        let mut state = AetherState::default();
        let mut saved = OutputDspProfile::factory(OutputDeviceClass::Iem);
        saved.name = "Stage IEM".into();
        state.audio.output_dsp.active_device_id = Some("alsa_output.stage".into());
        state
            .audio
            .output_dsp
            .profiles
            .insert("alsa_output.stage".into(), saved);

        editor.sync_from_state(&state);
        assert_eq!(editor.device_id, "alsa_output.stage");
        assert_eq!(editor.profile.name, "Stage IEM");

        editor.profile.name = "Unsaved edit".into();
        editor.sync_from_state(&state);
        assert_eq!(editor.profile.name, "Unsaved edit");
    }

    #[test]
    fn bass_edit_dispatches_output_dsp_apply_without_manual_button() {
        let before = OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker);
        let mut after = before.clone();
        after.bass.amount_db += 1.0;
        let action = auto_apply_output_dsp_action(HDMI3_LOADOUT_ID, &before, &after);
        assert_eq!(
            action,
            Some(AetherStreamAction::OutputDspApply {
                device_id: HDMI3_LOADOUT_ID.into(),
                profile: after,
            })
        );
    }

    #[test]
    fn clarity_edit_dispatches_output_dsp_apply_without_manual_button() {
        let before = OutputDspProfile::factory(OutputDeviceClass::TvSpeaker);
        let mut after = before.clone();
        after.clarity.frequency_hz = 3_200.0;
        assert!(matches!(
            auto_apply_output_dsp_action("tv-hdmi", &before, &after),
            Some(AetherStreamAction::OutputDspApply { .. })
        ));
    }

    #[test]
    fn invalid_profile_is_not_auto_dispatched() {
        let before = OutputDspProfile::factory(OutputDeviceClass::Custom);
        let mut after = before.clone();
        after.bass.frequency_hz = 99_000.0;
        assert!(auto_apply_output_dsp_action("sink", &before, &after).is_none());
    }

    #[test]
    fn second_ui_instance_reuses_backend_snapshot() {
        let mut snapshot = ServiceSnapshot::default();
        snapshot.services.insert("obsd".into(), ServiceHealth::Connected);
        let a = UiInstanceState::from_snapshot(ClientInstanceId::new(), snapshot.clone());
        let b = UiInstanceState::from_snapshot(ClientInstanceId::new(), snapshot);
        assert_ne!(a.client_id, b.client_id);
        assert_eq!(a.services, b.services);
    }

    #[test]
    fn shared_state_revision_is_visible_to_ui_model() {
        let mut state = AetherState {
            revision: 9,
            ..Default::default()
        };
        state.obs.active_scene = Some("Gameplay".into());
        let app = AetherStreamApp::new(ClientInstanceId::new(), ServiceSnapshot::default(), state);
        assert_eq!(app.control_state.revision, 9);
        assert_eq!(app.control_state.obs.active_scene.as_deref(), Some("Gameplay"));
    }

    #[test]
    fn forge_master_exposes_six_consolidated_primary_tabs() {
        let model = ForgeMasterModel::default();
        for panel in ["Home", "Live", "Streamlabs", "StreamElements", "A/V Studio", "Settings"] {
            assert!(model.has_panel(panel));
        }
        assert_eq!(model.panels().count(), 6);
        assert!(!model.has_panel("OBS"));
    }
}

#[cfg(test)]
mod peq_v10_2_39_regression {
    use super::*;

    #[test]
    fn peq_edit_dispatches_output_dsp_apply_without_manual_button() {
        let before = OutputDspProfile::factory(OutputDeviceClass::DesktopSpeaker);
        let mut after = before.clone();
        after.parametric_eq[0].gain_db = 3.0;
        assert!(matches!(
            auto_apply_output_dsp_action(HDMI3_LOADOUT_ID, &before, &after),
            Some(AetherStreamAction::OutputDspApply { .. })
        ));
    }
}
