use crate::DetachedViewport;
use aetherstream_core::WindowId;
use aetherstream_storage::{WindowPlacement, WorkspacePreset};
use std::collections::HashMap;

#[derive(Default)]
pub struct WorkspaceController {
    windows: HashMap<WindowId, DetachedViewport>,
}

impl WorkspaceController {
    #[must_use]
    pub fn fixture() -> Self {
        Self::default()
    }

    #[must_use]
    pub fn from_preset(preset: &WorkspacePreset) -> Self {
        let windows = preset
            .windows
            .iter()
            .map(|placement| {
                (
                    placement.window_id,
                    DetachedViewport {
                        window_id: placement.window_id,
                        panel: placement.panel.clone(),
                        monitor_name: placement.monitor_name.clone(),
                        x: placement.x,
                        y: placement.y,
                        width: placement.width,
                        height: placement.height,
                    },
                )
            })
            .collect();
        Self { windows }
    }

    pub fn detach(
        &mut self,
        panel: impl Into<String>,
        monitor: impl Into<String>,
    ) -> Result<WindowId, String> {
        let id = WindowId::new();
        let viewport = DetachedViewport {
            window_id: id,
            panel: panel.into(),
            monitor_name: Some(monitor.into()),
            x: 120.0,
            y: 120.0,
            width: 640.0,
            height: 520.0,
        };
        self.windows.insert(id, viewport);
        Ok(id)
    }

    #[must_use]
    pub fn window(&self, id: WindowId) -> Option<&DetachedViewport> {
        self.windows.get(&id)
    }

    pub fn iter(&self) -> impl Iterator<Item = &DetachedViewport> {
        self.windows.values()
    }

    #[must_use]
    pub fn to_preset(&self, name: impl Into<String>) -> WorkspacePreset {
        WorkspacePreset {
            name: name.into(),
            account: None,
            role: "streamer".into(),
            windows: self
                .windows
                .values()
                .map(|window| WindowPlacement {
                    window_id: window.window_id,
                    monitor_name: window.monitor_name.clone(),
                    x: window.x,
                    y: window.y,
                    width: window.width,
                    height: window.height,
                    maximized: false,
                    panel: window.panel.clone(),
                })
                .collect(),
            dock_json: "{}".into(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detaching_panel_creates_stable_window_id() {
        let mut workspace = WorkspaceController::fixture();
        let id = workspace.detach("chat:channel-a", "DP-2").unwrap();
        assert_eq!(workspace.window(id).unwrap().panel, "chat:channel-a");
        assert_eq!(workspace.window(id).unwrap().monitor_name.as_deref(), Some("DP-2"));
    }

    #[test]
    fn workspace_restore_keeps_three_monitor_placements() {
        let preset = WorkspacePreset::fixture_three_monitors();
        let restored = WorkspaceController::from_preset(&preset);
        assert_eq!(restored.iter().count(), 3);
    }
}
