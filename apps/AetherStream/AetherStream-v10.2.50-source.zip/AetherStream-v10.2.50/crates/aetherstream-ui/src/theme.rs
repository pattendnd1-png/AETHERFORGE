use aetherstream_core::AuthConnectionState;

pub const DRAGONGLASS_SURFACE: (u8, u8, u8, u8) = (12, 9, 28, 232);
pub const DRAGONGLASS_CARD: (u8, u8, u8, u8) = (22, 16, 48, 224);
pub const DRAGONGLASS_ACCENT: (u8, u8, u8, u8) = (105, 78, 235, 255);
pub const DRAGONGLASS_ACCENT_DEEP: (u8, u8, u8, u8) = (61, 55, 174, 255);
pub const DRAGONGLASS_TEXT: (u8, u8, u8, u8) = (239, 236, 255, 255);
pub const DRAGONGLASS_BASS: (u8, u8, u8, u8) = (92, 86, 224, 255);
pub const DRAGONGLASS_CLARITY: (u8, u8, u8, u8) = (124, 111, 255, 255);
pub const DRAGONGLASS_GAMING: (u8, u8, u8, u8) = (88, 118, 255, 255);
pub const DRAGONGLASS_CONNECTED: (u8, u8, u8, u8) = (112, 230, 178, 255);
pub const DRAGONGLASS_ATTENTION: (u8, u8, u8, u8) = (246, 190, 92, 255);
pub const DRAGONGLASS_MUTED: (u8, u8, u8, u8) = (164, 154, 196, 255);
pub const DRAGONGLASS_ERROR: (u8, u8, u8, u8) = (244, 112, 132, 255);
pub const DRAGONGLASS_RECORDING: (u8, u8, u8, u8) = (255, 87, 116, 255);
pub const DRAGONGLASS_STREAMING: (u8, u8, u8, u8) = (91, 226, 170, 255);
pub const DRAGONGLASS_LOADING: (u8, u8, u8, u8) = (138, 118, 255, 255);

pub(crate) fn color(token: (u8, u8, u8, u8)) -> egui::Color32 {
    egui::Color32::from_rgba_premultiplied(token.0, token.1, token.2, token.3)
}

pub fn apply_dragonglass(ctx: &egui::Context) {
    let mut visuals = egui::Visuals::dark();
    visuals.panel_fill = color(DRAGONGLASS_SURFACE);
    visuals.window_fill = color(DRAGONGLASS_CARD);
    visuals.extreme_bg_color = egui::Color32::from_rgb(8, 6, 20);
    visuals.faint_bg_color = egui::Color32::from_rgba_premultiplied(32, 24, 68, 156);
    visuals.selection.bg_fill = color(DRAGONGLASS_ACCENT);
    visuals.override_text_color = Some(color(DRAGONGLASS_TEXT));
    visuals.weak_text_color = Some(color(DRAGONGLASS_MUTED));
    visuals.hyperlink_color = color(DRAGONGLASS_CLARITY);
    visuals.window_corner_radius = egui::CornerRadius::same(12);
    visuals.menu_corner_radius = egui::CornerRadius::same(10);
    visuals.widgets.active.bg_fill = egui::Color32::from_rgb(91, 67, 204);
    visuals.widgets.hovered.bg_fill = egui::Color32::from_rgb(62, 47, 132);
    visuals.widgets.inactive.bg_fill = egui::Color32::from_rgba_premultiplied(32, 24, 68, 210);
    visuals.widgets.noninteractive.bg_fill = egui::Color32::from_rgba_premultiplied(18, 14, 40, 198);
    visuals.widgets.active.fg_stroke = egui::Stroke::new(1.5, color(DRAGONGLASS_TEXT));
    visuals.widgets.hovered.fg_stroke = egui::Stroke::new(1.5, color(DRAGONGLASS_TEXT));
    visuals.widgets.inactive.fg_stroke = egui::Stroke::new(1.0, color(DRAGONGLASS_TEXT));
    visuals.widgets.noninteractive.fg_stroke = egui::Stroke::new(1.0, color(DRAGONGLASS_MUTED));
    visuals.widgets.active.corner_radius = egui::CornerRadius::same(8);
    visuals.widgets.hovered.corner_radius = egui::CornerRadius::same(8);
    visuals.widgets.inactive.corner_radius = egui::CornerRadius::same(8);
    visuals.widgets.noninteractive.corner_radius = egui::CornerRadius::same(8);
    visuals.widgets.open.corner_radius = egui::CornerRadius::same(8);
    ctx.set_visuals(visuals);
}

pub fn glass_card<R>(
    ui: &mut egui::Ui,
    add_contents: impl FnOnce(&mut egui::Ui) -> R,
) -> egui::InnerResponse<R> {
    egui::Frame::group(ui.style())
        .fill(color(DRAGONGLASS_CARD))
        .show(ui, add_contents)
}

pub fn studio_panel<R>(
    ui: &mut egui::Ui,
    title: &str,
    add_contents: impl FnOnce(&mut egui::Ui) -> R,
) -> egui::InnerResponse<R> {
    glass_card(ui, |ui| {
        ui.strong(title);
        ui.separator();
        add_contents(ui)
    })
}


pub fn dsp_card<R>(
    ui: &mut egui::Ui,
    title: &str,
    accent: (u8, u8, u8, u8),
    add_contents: impl FnOnce(&mut egui::Ui) -> R,
) -> egui::InnerResponse<R> {
    egui::Frame::new()
        .fill(color(DRAGONGLASS_CARD))
        .stroke(egui::Stroke::new(1.0, color(accent)))
        .corner_radius(egui::CornerRadius::same(10))
        .inner_margin(10)
        .show(ui, |ui| {
            ui.label(egui::RichText::new(title).strong().color(color(accent)));
            ui.separator();
            add_contents(ui)
        })
}

pub fn status_card(ui: &mut egui::Ui, title: &str, value: &str, active: bool) {
    let token = if active { DRAGONGLASS_STREAMING } else { DRAGONGLASS_MUTED };
    glass_card(ui, |ui| {
        ui.weak(title);
        ui.label(egui::RichText::new(value).strong().color(color(token)));
    });
}

pub fn state_badge(ui: &mut egui::Ui, label: &str, token: (u8, u8, u8, u8)) {
    ui.label(egui::RichText::new(label).strong().color(color(token)));
}

pub fn connection_chip(ui: &mut egui::Ui, state: &AuthConnectionState) {
    let (label, token) = match state {
        AuthConnectionState::Connected => ("● Connected", DRAGONGLASS_CONNECTED),
        AuthConnectionState::Connecting => ("◐ Connecting", DRAGONGLASS_LOADING),
        AuthConnectionState::AwaitingUser => ("◐ Awaiting user", DRAGONGLASS_ATTENTION),
        AuthConnectionState::NeedsAttention => ("▲ Needs attention", DRAGONGLASS_ERROR),
        AuthConnectionState::AuthenticationRequired => ("▲ Authentication required", DRAGONGLASS_ERROR),
        AuthConnectionState::Disconnected => ("○ Offline", DRAGONGLASS_MUTED),
    };
    state_badge(ui, label, token);
}

pub fn recording_chip(ui: &mut egui::Ui, recording: bool) {
    if recording {
        state_badge(ui, "● RECORDING", DRAGONGLASS_RECORDING);
    } else {
        state_badge(ui, "○ RECORD", DRAGONGLASS_MUTED);
    }
}

pub fn streaming_chip(ui: &mut egui::Ui, streaming: bool) {
    if streaming {
        state_badge(ui, "● LIVE", DRAGONGLASS_STREAMING);
    } else {
        state_badge(ui, "○ OFFLINE", DRAGONGLASS_MUTED);
    }
}
