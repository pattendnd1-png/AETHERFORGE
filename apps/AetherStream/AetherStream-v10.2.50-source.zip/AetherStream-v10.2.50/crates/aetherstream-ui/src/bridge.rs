use aetherstream_control::AetherState;
use aetherstream_core::AetherStreamAction;
use std::sync::mpsc::{self, Receiver, Sender};

#[derive(Default)]
pub struct UiControlBridge {
    action_tx: Option<Sender<AetherStreamAction>>,
    state_rx: Option<Receiver<AetherState>>,
}

impl UiControlBridge {
    #[must_use]
    pub fn channel_pair() -> (Self, Receiver<AetherStreamAction>, Sender<AetherState>) {
        let (action_tx, action_rx) = mpsc::channel();
        let (state_tx, state_rx) = mpsc::channel();
        (
            Self {
                action_tx: Some(action_tx),
                state_rx: Some(state_rx),
            },
            action_rx,
            state_tx,
        )
    }

    #[must_use]
    pub fn dispatch(&self, action: AetherStreamAction) -> bool {
        self.action_tx
            .as_ref()
            .is_some_and(|sender| sender.send(action).is_ok())
    }

    pub fn drain_latest(&self) -> Option<AetherState> {
        let receiver = self.state_rx.as_ref()?;
        let mut latest = None;
        while let Ok(state) = receiver.try_recv() {
            latest = Some(state);
        }
        latest
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bridge_dispatches_action_and_drains_latest_state() {
        let (bridge, action_rx, state_tx) = UiControlBridge::channel_pair();
        let action = AetherStreamAction::ObsScene("Gameplay".into());
        assert!(bridge.dispatch(action.clone()));
        assert_eq!(action_rx.try_recv().unwrap(), action);

        state_tx
            .send(AetherState {
                revision: 7,
                ..Default::default()
            })
            .unwrap();
        state_tx
            .send(AetherState {
                revision: 8,
                ..Default::default()
            })
            .unwrap();
        assert_eq!(bridge.drain_latest().unwrap().revision, 8);
    }
}
