use crate::EventSubMessage;
use aetherstream_core::{AccountId, Provider, UnifiedEvent, UnifiedEventKind};
use serde_json::Value;
use thiserror::Error;

#[derive(Debug, Error)] pub enum NormalizeError { #[error("event notification missing subscription type")] MissingSubscription }
pub fn normalize_twitch_event(account: AccountId, message: EventSubMessage) -> Result<Option<UnifiedEvent>, NormalizeError> {
    if message.message_type() != Some("notification") { return Ok(None); }
    let kind = match message.subscription_type().ok_or(NormalizeError::MissingSubscription)? {
        "channel.chat.message" => UnifiedEventKind::ChatMessage,
        "stream.online" => UnifiedEventKind::StreamOnline,
        "stream.offline" => UnifiedEventKind::StreamOffline,
        "channel.follow" => UnifiedEventKind::Follow,
        "channel.subscribe" => UnifiedEventKind::Subscription,
        "channel.subscription.gift" => UnifiedEventKind::GiftSubscription,
        "channel.raid" => UnifiedEventKind::Raid,
        "channel.cheer" => UnifiedEventKind::Cheer,
        "channel.channel_points_custom_reward_redemption.add" => UnifiedEventKind::ChannelPointRedemption,
        other => UnifiedEventKind::Custom(other.to_owned()),
    };
    let channel = message.payload.get("event").and_then(|v| v.get("broadcaster_user_login")).and_then(Value::as_str).map(str::to_owned);
    let mut event=UnifiedEvent::new(Provider::Twitch, kind); event.account=Some(account); event.channel=channel; event.provider_payload=message.payload; Ok(Some(event))
}

#[cfg(test)] mod tests { use super::*; use crate::EventSubMessage;
    #[test] fn chat_fixture_normalizes_to_twitch_chat_event(){ let fixture=include_str!("../tests/fixtures/chat_message.json"); let msg=EventSubMessage::parse(fixture).unwrap(); let event=normalize_twitch_event(AccountId::new(),msg).unwrap().unwrap(); assert_eq!(event.provider,Provider::Twitch); assert_eq!(event.kind,UnifiedEventKind::ChatMessage); }
}
