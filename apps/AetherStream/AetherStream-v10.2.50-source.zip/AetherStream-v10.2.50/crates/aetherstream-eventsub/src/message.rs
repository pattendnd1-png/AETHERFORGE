use serde_json::Value;
use thiserror::Error;

#[derive(Clone, Debug)]
pub struct EventSubMessage { pub metadata: Value, pub payload: Value }
#[derive(Debug, Error)] pub enum EventSubParseError { #[error("invalid JSON: {0}")] Json(#[from] serde_json::Error), #[error("missing metadata or payload")] MissingFields }
impl EventSubMessage {
    pub fn parse(raw: &str) -> Result<Self, EventSubParseError> { let root:Value=serde_json::from_str(raw)?; let metadata=root.get("metadata").cloned().ok_or(EventSubParseError::MissingFields)?; let payload=root.get("payload").cloned().ok_or(EventSubParseError::MissingFields)?; Ok(Self{metadata,payload}) }
    pub fn message_type(&self)->Option<&str>{ self.metadata.get("message_type").and_then(Value::as_str) }
    pub fn subscription_type(&self)->Option<&str>{ self.payload.get("subscription").and_then(|v|v.get("type")).and_then(Value::as_str) }
    pub fn message_id(&self)->Option<&str>{ self.metadata.get("message_id").and_then(Value::as_str) }
}
