#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReconnectState { Disconnected, Connecting, Welcomed { session_id: String }, Reconnecting { url: String }, ResubscribeRequired }
impl ReconnectState {
    pub fn network_lost(self) -> Self { Self::ResubscribeRequired }
    pub fn twitch_reconnect(url: impl Into<String>) -> Self { Self::Reconnecting { url: url.into() } }
}
