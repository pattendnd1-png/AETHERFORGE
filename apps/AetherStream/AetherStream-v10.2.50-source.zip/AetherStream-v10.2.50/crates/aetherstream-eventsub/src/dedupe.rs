use std::collections::{HashSet, VecDeque};
pub struct MessageDeduper { cap: usize, set: HashSet<String>, order: VecDeque<String> }
impl MessageDeduper {
    pub fn new(cap: usize) -> Self { Self { cap: cap.max(1), set: HashSet::new(), order: VecDeque::new() } }
    pub fn should_process(&mut self, id: &str) -> bool {
        if self.set.contains(id) { return false; }
        let owned=id.to_owned(); self.set.insert(owned.clone()); self.order.push_back(owned);
        while self.order.len() > self.cap { if let Some(old)=self.order.pop_front() { self.set.remove(&old); } }
        true
    }
}
#[cfg(test)] mod tests { use super::*; #[test] fn duplicate_message_id_is_delivered_once(){ let mut d=MessageDeduper::new(1024); assert!(d.should_process("msg-123")); assert!(!d.should_process("msg-123")); } }
