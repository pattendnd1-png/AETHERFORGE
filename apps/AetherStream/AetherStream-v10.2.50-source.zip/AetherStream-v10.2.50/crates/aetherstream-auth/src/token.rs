use aetherstream_core::{AccountId, Capability};
use aetherstream_storage::SecretBytes;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug)]
pub struct TokenPair { pub access: SecretBytes, pub refresh: SecretBytes, pub expires_in_secs: u64 }

#[derive(Clone, Debug)]
pub enum TokenPoll { Pending, SlowDown, Denied, Expired, Authorized(TokenPair) }

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct AuthorizationHandle { pub account: AccountId, pub capability: Capability, pub generation: u64 }
impl AuthorizationHandle { pub fn new(account: AccountId, capability: Capability, generation: u64) -> Self { Self { account, capability, generation } } }
