use crate::{AuthError, DeviceAuthorization, HttpAuthTransport, ProviderTokenSet, TokenPoll};
use aetherstream_core::{AccountConnection, AccountId, AuthConnectionState, AuthProvider};
use aetherstream_storage::{
    AccountMetadata, AccountMetadataStore, SecretKey, SecretStore, StateDb,
};
use reqwest::Url;
use std::{path::PathBuf, process::Command, time::{Duration, SystemTime, UNIX_EPOCH}};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::TcpListener,
    time::{sleep, timeout},
};
use uuid::Uuid;

#[derive(Clone, Debug)]
pub struct RuntimeConfig {
    pub twitch_client_id: Option<String>,
    pub twitch_scopes: Vec<String>,
    pub streamlabs_client_id: Option<String>,
    pub streamlabs_scopes: Vec<String>,
    pub streamelements_client_id: Option<String>,
    pub streamelements_authorize_url: Option<String>,
    pub streamelements_token_url: Option<String>,
    pub streamelements_scopes: Vec<String>,
    pub redirect_uri: String,
}

impl RuntimeConfig {
    #[must_use]
    pub fn from_env() -> Self {
        Self {
            twitch_client_id: std::env::var("AETHERSTREAM_TWITCH_CLIENT_ID").ok(),
            twitch_scopes: env_scopes(
                "AETHERSTREAM_TWITCH_SCOPES",
                "user:read:chat user:write:chat channel:manage:broadcast moderator:manage:banned_users",
            ),
            streamlabs_client_id: std::env::var("AETHERSTREAM_STREAMLABS_CLIENT_ID").ok(),
            streamlabs_scopes: env_scopes(
                "AETHERSTREAM_STREAMLABS_SCOPES",
                "donations.read alerts.create alerts.write socket.token profiles.write mediashare.control",
            ),
            streamelements_client_id: std::env::var("AETHERSTREAM_STREAMELEMENTS_CLIENT_ID").ok(),
            streamelements_authorize_url: std::env::var("AETHERSTREAM_STREAMELEMENTS_AUTHORIZE_URL").ok(),
            streamelements_token_url: std::env::var("AETHERSTREAM_STREAMELEMENTS_TOKEN_URL").ok(),
            streamelements_scopes: env_scopes("AETHERSTREAM_STREAMELEMENTS_SCOPES", "*"),
            redirect_uri: std::env::var("AETHERSTREAM_OAUTH_REDIRECT_URI")
                .unwrap_or_else(|_| "http://127.0.0.1:43127/oauth/callback".into()),
        }
    }
}

fn env_scopes(name: &str, fallback: &str) -> Vec<String> {
    std::env::var(name)
        .unwrap_or_else(|_| fallback.into())
        .split_whitespace()
        .map(str::to_owned)
        .collect()
}

#[derive(Debug)]
pub struct TwitchDeviceSession {
    pub authorization: DeviceAuthorization,
    pub scopes: Vec<String>,
}

pub struct StreamlabsOAuthSession {
    listener: TcpListener,
    state: String,
}

pub struct StreamElementsAuthSession {
    listener: TcpListener,
    state: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct SmartRestoreOutcome {
    pub connections: Vec<AccountConnection>,
    pub restored: usize,
    pub needs_attention: usize,
}

pub struct AuthRuntime<S: SecretStore> {
    config: RuntimeConfig,
    http: HttpAuthTransport,
    secrets: S,
    state_db_path: PathBuf,
}

impl<S: SecretStore> AuthRuntime<S> {
    #[must_use]
    pub fn new(config: RuntimeConfig, secrets: S, state_db_path: PathBuf) -> Self {
        Self { config, http: HttpAuthTransport::new(), secrets, state_db_path }
    }

    pub async fn begin_twitch(&self) -> Result<(TwitchDeviceSession, AccountConnection), AuthError> {
        let client_id = self
            .config
            .twitch_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("AETHERSTREAM_TWITCH_CLIENT_ID is not configured".into()))?;
        let authorization = self.http.twitch_device_code(client_id, &self.config.twitch_scopes).await?;
        let _ = open_system_browser(&authorization.verification_uri);
        let mut connection = AccountConnection::disconnected(AuthProvider::Twitch);
        connection.state = AuthConnectionState::AwaitingUser;
        connection.status_detail = Some("Authorize AetherStream in the Twitch browser window".into());
        connection.user_code = Some(authorization.user_code.clone());
        connection.verification_uri = Some(authorization.verification_uri.clone());
        connection.scopes = self.config.twitch_scopes.clone();
        Ok((TwitchDeviceSession { authorization, scopes: self.config.twitch_scopes.clone() }, connection))
    }

    pub async fn complete_twitch(&self, session: TwitchDeviceSession) -> Result<AccountConnection, AuthError> {
        let client_id = self
            .config
            .twitch_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("AETHERSTREAM_TWITCH_CLIENT_ID is not configured".into()))?;
        let mut interval = session.authorization.interval_secs.max(1);
        let deadline = tokio::time::Instant::now() + Duration::from_secs(session.authorization.expires_in_secs);
        loop {
            if tokio::time::Instant::now() >= deadline {
                return Err(AuthError::Expired);
            }
            sleep(Duration::from_secs(interval)).await;
            match self
                .http
                .twitch_poll_device(client_id, &session.scopes, &session.authorization.device_code)
                .await?
            {
                TokenPoll::Pending => {}
                TokenPoll::SlowDown => interval = interval.saturating_add(5),
                TokenPoll::Denied => return Err(AuthError::Denied),
                TokenPoll::Expired => return Err(AuthError::Expired),
                TokenPoll::Authorized(pair) => {
                    let validation = self.http.twitch_validate(&pair.access).await?;
                    let tokens = ProviderTokenSet {
                        access: pair.access,
                        refresh: Some(pair.refresh),
                        expires_in_secs: Some(validation.expires_in_secs),
                        scopes: validation.scopes.clone(),
                    };
                    return self.finish_login(
                        AuthProvider::Twitch,
                        Some(validation.login),
                        tokens,
                    );
                }
            }
        }
    }

    pub async fn begin_streamlabs(&self) -> Result<(StreamlabsOAuthSession, AccountConnection), AuthError> {
        let client_id = self
            .config
            .streamlabs_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("AETHERSTREAM_STREAMLABS_CLIENT_ID is not configured".into()))?;
        let listener = self.bind_callback_listener().await?;
        let state = Uuid::new_v4().to_string();
        let authorize_url = self.http.streamlabs_authorize_url(
            client_id,
            &self.config.redirect_uri,
            &self.config.streamlabs_scopes,
            &state,
        )?;
        open_system_browser(&authorize_url)?;
        let mut connection = AccountConnection::disconnected(AuthProvider::Streamlabs);
        connection.state = AuthConnectionState::AwaitingUser;
        connection.status_detail = Some("Complete Streamlabs authorization in your browser".into());
        connection.scopes = self.config.streamlabs_scopes.clone();
        connection.manual_code_available = true;
        Ok((StreamlabsOAuthSession { listener, state }, connection))
    }

    pub async fn complete_streamlabs(&self, session: StreamlabsOAuthSession) -> Result<AccountConnection, AuthError> {
        let code = wait_for_callback(session.listener, &session.state).await?;
        self.exchange_streamlabs_code(&code).await
    }

    pub async fn exchange_streamlabs_code(&self, code: &str) -> Result<AccountConnection, AuthError> {
        let client_id = self
            .config
            .streamlabs_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("AETHERSTREAM_STREAMLABS_CLIENT_ID is not configured".into()))?;
        let secret_key = self.client_secret_key(AuthProvider::Streamlabs);
        let tokens = self
            .http
            .streamlabs_exchange_code(
                client_id,
                &self.config.redirect_uri,
                code,
                &self.secrets,
                &secret_key,
            )
            .await?;
        let display_name = self.http.streamlabs_display_name(&tokens.access).await.ok().flatten();
        self.finish_login(AuthProvider::Streamlabs, display_name, tokens)
    }

    pub async fn begin_streamelements(&self) -> Result<(StreamElementsAuthSession, AccountConnection), AuthError> {
        let client_id = self
            .config
            .streamelements_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("StreamElements OAuth client id is not configured".into()))?;
        let authorize_url = self
            .config
            .streamelements_authorize_url
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("StreamElements OAuth authorize URL is not configured for this registered integration".into()))?;
        let listener = self.bind_callback_listener().await?;
        let state = Uuid::new_v4().to_string();
        let authorize_url = self.http.authorization_url(
            authorize_url,
            client_id,
            &self.config.redirect_uri,
            &self.config.streamelements_scopes,
            &state,
        )?;
        open_system_browser(&authorize_url)?;
        let mut connection = AccountConnection::disconnected(AuthProvider::StreamElements);
        connection.state = AuthConnectionState::AwaitingUser;
        connection.status_detail = Some("Complete StreamElements authorization in your browser".into());
        connection.scopes = self.config.streamelements_scopes.clone();
        connection.manual_code_available = true;
        Ok((StreamElementsAuthSession { listener, state }, connection))
    }

    pub async fn complete_streamelements(&self, session: StreamElementsAuthSession) -> Result<AccountConnection, AuthError> {
        let code = wait_for_callback(session.listener, &session.state).await?;
        self.exchange_streamelements_code(&code).await
    }

    pub async fn exchange_streamelements_code(&self, code: &str) -> Result<AccountConnection, AuthError> {
        let client_id = self
            .config
            .streamelements_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("StreamElements OAuth client id is not configured".into()))?;
        let token_url = self
            .config
            .streamelements_token_url
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("StreamElements OAuth token URL is not configured for this registered integration".into()))?;
        let client_secret = self
            .secrets
            .load(&self.client_secret_key(AuthProvider::StreamElements))
            .map_err(|_| AuthError::SecretStore)?;
        let secret_text = client_secret
            .as_ref()
            .map(|secret| std::str::from_utf8(secret.as_slice()).map_err(|_| AuthError::InvalidResponse))
            .transpose()?;
        let tokens = self
            .http
            .exchange_authorization_code(
                token_url,
                client_id,
                secret_text,
                &self.config.redirect_uri,
                code,
            )
            .await?;
        self.finish_login(AuthProvider::StreamElements, None, tokens)
    }

    pub fn disconnect(&self, provider: AuthProvider) -> Result<(), AuthError> {
        if let Some(mut metadata) = self.default_metadata(provider)? {
            for kind in ["access", "refresh"] {
                self.secrets
                    .remove(&self.token_key(provider, metadata.account, kind))
                    .map_err(|_| AuthError::SecretStore)?;
            }
            metadata.restore_enabled = false;
            metadata.last_status = Some("Disconnected".into());
            self.save_metadata(&metadata)?;
        }
        Ok(())
    }

    pub fn set_default(&self, provider: AuthProvider, account: AccountId) -> Result<(), AuthError> {
        let db = self.open_db()?;
        let mut all = AccountMetadataStore::list(&db)
            .map_err(|error| AuthError::Configuration(error.to_string()))?;
        let mut found = false;
        for metadata in all.iter_mut().filter(|metadata| metadata.provider == provider) {
            metadata.is_default = metadata.account == account;
            if metadata.is_default {
                metadata.restore_enabled = true;
                found = true;
            }
            AccountMetadataStore::save(&db, metadata)
                .map_err(|error| AuthError::Configuration(error.to_string()))?;
        }
        if found {
            Ok(())
        } else {
            Err(AuthError::Configuration("requested account is not known to AetherStream".into()))
        }
    }

    pub async fn run_smart_restore(&self) -> SmartRestoreOutcome {
        let mut outcome = SmartRestoreOutcome::default();
        for provider in [AuthProvider::Twitch, AuthProvider::Streamlabs, AuthProvider::StreamElements] {
            let Some(metadata) = self.default_metadata(provider).ok().flatten() else {
                continue;
            };
            if !metadata.restore_enabled {
                continue;
            }
            match self.restore_account(&metadata).await {
                Ok(connection) => {
                    outcome.restored += 1;
                    outcome.connections.push(connection);
                }
                Err(error) => {
                    outcome.needs_attention += 1;
                    let mut connection = AccountConnection::disconnected(provider);
                    connection.account = Some(metadata.account);
                    connection.display_name = metadata.display_name;
                    connection.is_default = metadata.is_default;
                    connection.state = AuthConnectionState::NeedsAttention;
                    connection.status_detail = Some(error.to_string());
                    outcome.connections.push(connection);
                }
            }
        }
        outcome
    }

    async fn restore_account(&self, metadata: &AccountMetadata) -> Result<AccountConnection, AuthError> {
        let access_key = self.token_key(metadata.provider, metadata.account, "access");
        let access = self
            .secrets
            .load(&access_key)
            .map_err(|_| AuthError::SecretStore)?
            .ok_or_else(|| AuthError::Configuration("stored access credential is missing".into()))?;
        match metadata.provider {
            AuthProvider::Twitch => {
                match self.http.twitch_validate(&access).await {
                    Ok(validation) => Ok(self.connection_from_metadata(
                        metadata,
                        validation.scopes,
                        Some(validation.expires_in_secs),
                    )),
                    Err(_) => self.restore_twitch_with_refresh(metadata).await,
                }
            }
            AuthProvider::Streamlabs => {
                match self.http.streamlabs_display_name(&access).await {
                    Ok(display_name) => {
                        let mut connection = self.connection_from_metadata(metadata, Vec::new(), None);
                        if display_name.is_some() {
                            connection.display_name = display_name;
                        }
                        Ok(connection)
                    }
                    Err(_) => self.restore_streamlabs_with_refresh(metadata).await,
                }
            }
            AuthProvider::StreamElements => Ok(self.connection_from_metadata(metadata, Vec::new(), None)),
            AuthProvider::BroadcastEngine => Err(AuthError::Configuration("broadcast engine restore is owned by the engine service".into())),
        }
    }

    async fn restore_streamlabs_with_refresh(&self, metadata: &AccountMetadata) -> Result<AccountConnection, AuthError> {
        let client_id = self
            .config
            .streamlabs_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("AETHERSTREAM_STREAMLABS_CLIENT_ID is not configured".into()))?;
        let refresh_key = self.token_key(AuthProvider::Streamlabs, metadata.account, "refresh");
        let refresh = self
            .secrets
            .load(&refresh_key)
            .map_err(|_| AuthError::SecretStore)?
            .ok_or_else(|| AuthError::Configuration("stored Streamlabs refresh credential is missing".into()))?;
        let secret_key = self.client_secret_key(AuthProvider::Streamlabs);
        let tokens = self
            .http
            .streamlabs_refresh(
                client_id,
                &self.config.redirect_uri,
                &refresh,
                &self.secrets,
                &secret_key,
            )
            .await?;
        self.store_tokens(AuthProvider::Streamlabs, metadata.account, &tokens)?;
        let display_name = self.http.streamlabs_display_name(&tokens.access).await.ok().flatten();
        let mut connection = self.connection_from_metadata(metadata, tokens.scopes, tokens.expires_in_secs);
        if display_name.is_some() {
            connection.display_name = display_name;
        }
        Ok(connection)
    }

    async fn restore_twitch_with_refresh(&self, metadata: &AccountMetadata) -> Result<AccountConnection, AuthError> {
        let client_id = self
            .config
            .twitch_client_id
            .as_deref()
            .ok_or_else(|| AuthError::Configuration("AETHERSTREAM_TWITCH_CLIENT_ID is not configured".into()))?;
        let refresh_key = self.token_key(AuthProvider::Twitch, metadata.account, "refresh");
        let refresh = self
            .secrets
            .load(&refresh_key)
            .map_err(|_| AuthError::SecretStore)?
            .ok_or_else(|| AuthError::Configuration("stored Twitch refresh credential is missing".into()))?;
        let tokens = self.http.twitch_refresh(client_id, &refresh).await?;
        self.store_tokens(AuthProvider::Twitch, metadata.account, &tokens)?;
        let validation = self.http.twitch_validate(&tokens.access).await?;
        Ok(self.connection_from_metadata(
            metadata,
            validation.scopes,
            Some(validation.expires_in_secs),
        ))
    }

    fn finish_login(
        &self,
        provider: AuthProvider,
        display_name: Option<String>,
        tokens: ProviderTokenSet,
    ) -> Result<AccountConnection, AuthError> {
        let account = AccountId::new();
        self.store_tokens(provider, account, &tokens)?;
        let metadata = AccountMetadata {
            account,
            provider,
            display_name: display_name.clone(),
            is_default: true,
            restore_enabled: true,
            last_status: Some("Connected".into()),
        };
        self.clear_previous_default(provider)?;
        self.save_metadata(&metadata)?;
        let mut connection = AccountConnection::disconnected(provider);
        connection.account = Some(account);
        connection.display_name = display_name;
        connection.state = AuthConnectionState::Connected;
        connection.is_default = true;
        connection.scopes = tokens.scopes;
        connection.status_detail = Some("Authenticated and stored in Linux Secret Service".into());
        connection.expires_at_unix = tokens.expires_in_secs.map(|seconds| now_unix().saturating_add(seconds));
        Ok(connection)
    }

    fn connection_from_metadata(
        &self,
        metadata: &AccountMetadata,
        scopes: Vec<String>,
        expires_in_secs: Option<u64>,
    ) -> AccountConnection {
        let mut connection = AccountConnection::disconnected(metadata.provider);
        connection.account = Some(metadata.account);
        connection.display_name = metadata.display_name.clone();
        connection.state = AuthConnectionState::Connected;
        connection.is_default = metadata.is_default;
        connection.scopes = scopes;
        connection.status_detail = Some("Smart restore connected".into());
        connection.expires_at_unix = expires_in_secs.map(|seconds| now_unix().saturating_add(seconds));
        connection
    }

    fn store_tokens(
        &self,
        provider: AuthProvider,
        account: AccountId,
        tokens: &ProviderTokenSet,
    ) -> Result<(), AuthError> {
        self.secrets
            .store(self.token_key(provider, account, "access"), tokens.access.clone())
            .map_err(|_| AuthError::SecretStore)?;
        if let Some(refresh) = &tokens.refresh {
            self.secrets
                .store(self.token_key(provider, account, "refresh"), refresh.clone())
                .map_err(|_| AuthError::SecretStore)?;
        }
        Ok(())
    }

    fn token_key(&self, provider: AuthProvider, account: AccountId, kind: &str) -> SecretKey {
        SecretKey(format!("aetherstream:{provider:?}:{account}:{kind}"))
    }

    fn client_secret_key(&self, provider: AuthProvider) -> SecretKey {
        SecretKey(format!("aetherstream:{provider:?}:default:client-secret"))
    }

    fn default_metadata(&self, provider: AuthProvider) -> Result<Option<AccountMetadata>, AuthError> {
        let db = self.open_db()?;
        AccountMetadataStore::default_for(&db, provider).map_err(|error| AuthError::Configuration(error.to_string()))
    }

    fn save_metadata(&self, metadata: &AccountMetadata) -> Result<(), AuthError> {
        let db = self.open_db()?;
        AccountMetadataStore::save(&db, metadata).map_err(|error| AuthError::Configuration(error.to_string()))
    }

    fn clear_previous_default(&self, provider: AuthProvider) -> Result<(), AuthError> {
        let db = self.open_db()?;
        let mut all = AccountMetadataStore::list(&db).map_err(|error| AuthError::Configuration(error.to_string()))?;
        for metadata in all.iter_mut().filter(|metadata| metadata.provider == provider && metadata.is_default) {
            metadata.is_default = false;
            AccountMetadataStore::save(&db, metadata).map_err(|error| AuthError::Configuration(error.to_string()))?;
        }
        Ok(())
    }

    fn open_db(&self) -> Result<StateDb, AuthError> {
        if let Some(parent) = self.state_db_path.parent() {
            std::fs::create_dir_all(parent).map_err(|error| AuthError::Configuration(error.to_string()))?;
        }
        StateDb::open(&self.state_db_path).map_err(|error| AuthError::Configuration(error.to_string()))
    }

    async fn bind_callback_listener(&self) -> Result<TcpListener, AuthError> {
        let url = Url::parse(&self.config.redirect_uri).map_err(|error| AuthError::Configuration(error.to_string()))?;
        let host = url.host_str().ok_or_else(|| AuthError::Configuration("redirect URI has no host".into()))?;
        if host != "127.0.0.1" && host != "localhost" {
            return Err(AuthError::Configuration("OAuth redirect URI must use loopback localhost".into()));
        }
        let port = url.port_or_known_default().ok_or_else(|| AuthError::Configuration("redirect URI has no port".into()))?;
        TcpListener::bind((host, port)).await.map_err(|error| AuthError::Callback(error.to_string()))
    }
}

fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |value| value.as_secs())
}

fn open_system_browser(url: &str) -> Result<(), AuthError> {
    Command::new("xdg-open")
        .arg(url)
        .spawn()
        .map(|_| ())
        .map_err(|error| AuthError::Callback(format!("failed to open system browser: {error}")))
}

async fn wait_for_callback(listener: TcpListener, expected_state: &str) -> Result<String, AuthError> {
    let accepted = timeout(Duration::from_secs(300), listener.accept())
        .await
        .map_err(|_| AuthError::Callback("OAuth callback timed out".into()))?
        .map_err(|error| AuthError::Callback(error.to_string()))?;
    let (mut stream, _) = accepted;
    let mut buffer = vec![0_u8; 8192];
    let read = stream.read(&mut buffer).await.map_err(|error| AuthError::Callback(error.to_string()))?;
    let request = String::from_utf8_lossy(&buffer[..read]);
    let target = request
        .lines()
        .next()
        .and_then(|line| line.split_whitespace().nth(1))
        .ok_or_else(|| AuthError::Callback("invalid OAuth callback request".into()))?;
    let url = Url::parse(&format!("http://127.0.0.1{target}"))
        .map_err(|error| AuthError::Callback(error.to_string()))?;
    let state = url.query_pairs().find(|(key, _)| key == "state").map(|(_, value)| value.into_owned());
    let code = url.query_pairs().find(|(key, _)| key == "code").map(|(_, value)| value.into_owned());
    let error = url.query_pairs().find(|(key, _)| key == "error").map(|(_, value)| value.into_owned());
    let success = error.is_none() && state.as_deref() == Some(expected_state) && code.is_some();
    let body = if success {
        "AetherStream authorization received. You can close this tab."
    } else {
        "AetherStream authorization failed. Return to AetherStream for details."
    };
    let response = format!(
        "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
        body.len(), body
    );
    let _ = stream.write_all(response.as_bytes()).await;
    if let Some(error) = error {
        return Err(AuthError::Callback(format!("provider returned {error}")));
    }
    if state.as_deref() != Some(expected_state) {
        return Err(AuthError::StateMismatch);
    }
    code.ok_or(AuthError::InvalidResponse)
}

#[cfg(test)]
mod tests {
    use super::*;
    use aetherstream_storage::MemorySecretStore;

    #[test]
    fn runtime_config_never_contains_client_secret_fields() {
        let config = RuntimeConfig {
            twitch_client_id: Some("client".into()),
            twitch_scopes: vec![],
            streamlabs_client_id: Some("client".into()),
            streamlabs_scopes: vec![],
            streamelements_client_id: None,
            streamelements_authorize_url: None,
            streamelements_token_url: None,
            streamelements_scopes: vec![],
            redirect_uri: "http://127.0.0.1:43127/oauth/callback".into(),
        };
        let debug = format!("{config:?}").to_ascii_lowercase();
        assert!(!debug.contains("client_secret"));
        let _runtime = AuthRuntime::new(config, MemorySecretStore::default(), PathBuf::from(":memory:"));
    }

    #[tokio::test]
    async fn smart_restore_with_no_accounts_is_empty_and_offline_safe() {
        let path = std::env::temp_dir().join(format!(
            "aetherstream-auth-runtime-{}.db",
            Uuid::new_v4()
        ));
        let runtime = AuthRuntime::new(
            RuntimeConfig {
                twitch_client_id: None,
                twitch_scopes: vec![],
                streamlabs_client_id: None,
                streamlabs_scopes: vec![],
                streamelements_client_id: None,
                streamelements_authorize_url: None,
                streamelements_token_url: None,
                streamelements_scopes: vec![],
                redirect_uri: "http://127.0.0.1:43127/oauth/callback".into(),
            },
            MemorySecretStore::default(),
            path.clone(),
        );
        let outcome = runtime.run_smart_restore().await;
        assert_eq!(outcome, SmartRestoreOutcome::default());
        let _ = std::fs::remove_file(path);
    }
}
