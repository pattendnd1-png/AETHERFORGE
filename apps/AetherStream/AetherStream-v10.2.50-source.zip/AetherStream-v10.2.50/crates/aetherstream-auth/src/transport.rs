use crate::{AuthError, DeviceAuthorization, TokenPair, TokenPoll};
use aetherstream_storage::SecretBytes;
use async_trait::async_trait;

#[async_trait]
pub trait AuthTransport: Send + Sync {
    async fn request_device_code(&self, scopes: &[String]) -> Result<DeviceAuthorization, AuthError>;
    async fn poll_device_code(&self, device_code: &str) -> Result<TokenPoll, AuthError>;
    async fn refresh(&self, refresh_token: &SecretBytes) -> Result<TokenPair, AuthError>;
}
