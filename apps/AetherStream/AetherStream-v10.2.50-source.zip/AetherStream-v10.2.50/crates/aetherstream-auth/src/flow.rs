use aetherstream_core::{AccountConnection, AuthProvider};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OAuthLoginMode {
    DeviceCode,
    BrowserCallback,
    ManualCodeFallback,
    EngineChallenge,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BrowserCallback {
    pub provider: AuthProvider,
    pub redirect_uri: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ManualCodeFallback {
    pub provider: AuthProvider,
    pub prompt: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderLoginPlan {
    pub provider: AuthProvider,
    pub primary: OAuthLoginMode,
    pub fallback: Option<OAuthLoginMode>,
    pub callback: Option<BrowserCallback>,
    pub manual: Option<ManualCodeFallback>,
}

impl ProviderLoginPlan {
    #[must_use]
    pub fn for_provider(provider: AuthProvider) -> Self {
        match provider {
            AuthProvider::Twitch => Self {
                provider,
                primary: OAuthLoginMode::DeviceCode,
                fallback: None,
                callback: None,
                manual: None,
            },
            AuthProvider::Streamlabs | AuthProvider::StreamElements => Self {
                provider,
                primary: OAuthLoginMode::BrowserCallback,
                fallback: Some(OAuthLoginMode::ManualCodeFallback),
                callback: Some(BrowserCallback {
                    provider,
                    redirect_uri: "http://127.0.0.1:43127/oauth/callback".into(),
                }),
                manual: Some(ManualCodeFallback {
                    provider,
                    prompt: "Paste the one-time authorization code".into(),
                }),
            },
            AuthProvider::BroadcastEngine => Self {
                provider,
                primary: OAuthLoginMode::EngineChallenge,
                fallback: None,
                callback: None,
                manual: None,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SmartRestorePlan {
    pub providers: Vec<AuthProvider>,
}

impl SmartRestorePlan {
    #[must_use]
    pub fn from_connections<'a>(connections: impl IntoIterator<Item = &'a AccountConnection>) -> Self {
        let mut providers: Vec<AuthProvider> = connections
            .into_iter()
            .filter(|connection| connection.is_default)
            .map(|connection| connection.provider)
            .collect();
        providers.sort();
        providers.dedup();
        if !providers.contains(&AuthProvider::BroadcastEngine) {
            providers.push(AuthProvider::BroadcastEngine);
        }
        Self { providers }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use aetherstream_core::{AccountConnection, AuthConnectionState};

    #[test]
    fn twitch_uses_device_code_without_manual_fallback() {
        let plan = ProviderLoginPlan::for_provider(AuthProvider::Twitch);
        assert_eq!(plan.primary, OAuthLoginMode::DeviceCode);
        assert!(plan.fallback.is_none());
    }

    #[test]
    fn hosted_providers_use_callback_with_manual_fallback() {
        for provider in [AuthProvider::Streamlabs, AuthProvider::StreamElements] {
            let plan = ProviderLoginPlan::for_provider(provider);
            assert_eq!(plan.primary, OAuthLoginMode::BrowserCallback);
            assert_eq!(plan.fallback, Some(OAuthLoginMode::ManualCodeFallback));
            assert!(plan.callback.is_some());
            assert!(plan.manual.is_some());
        }
    }

    #[test]
    fn smart_restore_uses_default_accounts_plus_broadcast_engine() {
        let mut twitch = AccountConnection::disconnected(AuthProvider::Twitch);
        twitch.is_default = true;
        twitch.state = AuthConnectionState::Connected;
        let plan = SmartRestorePlan::from_connections([&twitch]);
        assert!(plan.providers.contains(&AuthProvider::Twitch));
        assert!(plan.providers.contains(&AuthProvider::BroadcastEngine));
    }
}
