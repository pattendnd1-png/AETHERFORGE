use aetherstream_core::{AccountConnection, AccountId, AuthProvider, Capability};
use crate::{AuthorizationHandle, ProviderLoginPlan, SmartRestorePlan};
use std::collections::HashMap;

#[derive(Default)]
pub struct PermissionBroker { generations: HashMap<AccountId, u64> }
impl PermissionBroker {
    pub fn publish_generation(&mut self, account: AccountId, generation: u64) { self.generations.insert(account, generation); }
    pub fn validate(&self, handle: &AuthorizationHandle, required: &Capability) -> bool {
        &handle.capability == required && self.generations.get(&handle.account) == Some(&handle.generation)
    }
}


#[derive(Default)]
pub struct LoginBroker;

impl LoginBroker {
    #[must_use]
    pub fn login_plan(provider: AuthProvider) -> ProviderLoginPlan {
        ProviderLoginPlan::for_provider(provider)
    }

    #[must_use]
    pub fn smart_restore<'a>(connections: impl IntoIterator<Item = &'a AccountConnection>) -> SmartRestorePlan {
        SmartRestorePlan::from_connections(connections)
    }

    #[must_use]
    pub fn secret_reference(provider: AuthProvider, account: Option<AccountId>, kind: &str) -> String {
        let account = account.map_or_else(|| "default".into(), |id| id.to_string());
        format!("aetherstream:{provider:?}:{account}:{kind}")
    }
}

#[cfg(test)]
mod login_tests {
    use super::*;
    use crate::OAuthLoginMode;

    #[test]
    fn twitch_login_plan_is_device_code() {
        assert_eq!(
            LoginBroker::login_plan(AuthProvider::Twitch).primary,
            OAuthLoginMode::DeviceCode
        );
    }

    #[test]
    fn secret_reference_contains_identity_not_secret_value() {
        let reference = LoginBroker::secret_reference(AuthProvider::Streamlabs, None, "client-secret");
        assert!(reference.contains("Streamlabs"));
        assert!(!reference.contains("oauth:"));
    }
}
