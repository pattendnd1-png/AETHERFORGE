use crate::{AuthTransport, AuthorizationHandle, TokenPoll};
use aetherstream_core::{AccountId, Capability};
use aetherstream_storage::{SecretKey, SecretStore};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use thiserror::Error;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct DeviceAuthorization {
    pub device_code: String,
    pub user_code: String,
    pub verification_uri: String,
    #[serde(rename = "expires_in")]
    pub expires_in_secs: u64,
    #[serde(rename = "interval")]
    pub interval_secs: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TokenState { Pending, SlowDown, Denied, Expired, Authorized { handles: Vec<AuthorizationHandle> } }

#[derive(Debug, Error)]
pub enum AuthError {
    #[error("transport: {0}")] Transport(String),
    #[error("unknown pending device authorization")]
    UnknownDeviceCode,
    #[error("secret store failure")]
    SecretStore,
    #[error("authentication configuration: {0}")]
    Configuration(String),
    #[error("authentication http transport: {0}")]
    Http(String),
    #[error("authentication callback: {0}")]
    Callback(String),
    #[error("authorization denied")]
    Denied,
    #[error("authorization expired")]
    Expired,
    #[error("authorization state mismatch")]
    StateMismatch,
    #[error("invalid provider response")]
    InvalidResponse,
}

struct PendingAuth { account: AccountId, capabilities: Vec<Capability>, generation: u64 }
pub struct AuthService<T, S> { transport: T, secrets: S, pending: HashMap<String, PendingAuth> }
impl<T, S> AuthService<T, S> where T: AuthTransport, S: SecretStore {
    pub fn new(transport: T, secrets: S) -> Self { Self { transport, secrets, pending: HashMap::new() } }
    pub async fn begin_device_code(&mut self, capabilities: Vec<Capability>) -> Result<DeviceAuthorization, AuthError> {
        let scopes: Vec<String> = capabilities.iter().filter_map(Capability::twitch_scope).map(str::to_owned).collect();
        let auth = self.transport.request_device_code(&scopes).await?;
        self.pending.insert(auth.device_code.clone(), PendingAuth { account: AccountId::new(), capabilities, generation: 1 });
        Ok(auth)
    }
    pub async fn poll(&mut self, auth: &DeviceAuthorization) -> Result<TokenState, AuthError> {
        let pending = self.pending.get(&auth.device_code).ok_or(AuthError::UnknownDeviceCode)?;
        match self.transport.poll_device_code(&auth.device_code).await? {
            TokenPoll::Pending => Ok(TokenState::Pending),
            TokenPoll::SlowDown => Ok(TokenState::SlowDown),
            TokenPoll::Denied => Ok(TokenState::Denied),
            TokenPoll::Expired => Ok(TokenState::Expired),
            TokenPoll::Authorized(pair) => {
                let account = pending.account; let generation = pending.generation; let capabilities = pending.capabilities.clone();
                self.secrets.store(SecretKey(format!("twitch:{account}:access")), pair.access).map_err(|_| AuthError::SecretStore)?;
                self.secrets.store(SecretKey(format!("twitch:{account}:refresh")), pair.refresh).map_err(|_| AuthError::SecretStore)?;
                let handles = capabilities.into_iter().map(|capability| AuthorizationHandle::new(account, capability, generation)).collect();
                self.pending.remove(&auth.device_code);
                Ok(TokenState::Authorized { handles })
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::TokenPair;
    use aetherstream_storage::{MemorySecretStore, SecretBytes};
    use async_trait::async_trait;
    use std::sync::atomic::{AtomicUsize, Ordering};

    struct FixtureAuthTransport { polls: AtomicUsize, authorize_after: usize }
    impl FixtureAuthTransport { fn authorized_after(n: usize) -> Self { Self { polls: AtomicUsize::new(0), authorize_after: n } } }
    #[async_trait]
    impl AuthTransport for FixtureAuthTransport {
        async fn request_device_code(&self, _scopes: &[String]) -> Result<DeviceAuthorization, AuthError> {
            Ok(DeviceAuthorization { device_code: "dev".into(), user_code: "ABCD".into(), verification_uri: "https://www.twitch.tv/activate".into(), expires_in_secs: 600, interval_secs: 5 })
        }
        async fn poll_device_code(&self, _device_code: &str) -> Result<TokenPoll, AuthError> {
            let n = self.polls.fetch_add(1, Ordering::SeqCst) + 1;
            if n < self.authorize_after { Ok(TokenPoll::Pending) } else { Ok(TokenPoll::Authorized(TokenPair { access: SecretBytes::new(b"oauth:access".to_vec()), refresh: SecretBytes::new(b"refresh".to_vec()), expires_in_secs: 14400 })) }
        }
        async fn refresh(&self, _refresh_token: &SecretBytes) -> Result<TokenPair, AuthError> { Err(AuthError::Transport("unused".into())) }
    }

    #[tokio::test]
    async fn device_code_transitions_pending_to_authorized() {
        let transport = FixtureAuthTransport::authorized_after(2); let secrets = MemorySecretStore::default();
        let mut auth = AuthService::new(transport, secrets);
        let pending = auth.begin_device_code(vec![Capability::ChatRead]).await.unwrap();
        assert!(matches!(auth.poll(&pending).await.unwrap(), TokenState::Pending));
        assert!(matches!(auth.poll(&pending).await.unwrap(), TokenState::Authorized { .. }));
    }
    #[test]
    fn authorization_handle_contains_no_raw_token() {
        let handle = AuthorizationHandle::new(AccountId::new(), Capability::ChatRead, 7);
        let json = serde_json::to_string(&handle).unwrap();
        assert!(!json.contains("oauth:")); assert!(!json.contains("access_token"));
    }
}
