use crate::{AuthError, DeviceAuthorization, TokenPair, TokenPoll};
use aetherstream_storage::{SecretBytes, SecretKey, SecretStore};
use reqwest::{Client, StatusCode, Url};
use serde::{Deserialize, Deserializer};

const TWITCH_DEVICE_URL: &str = "https://id.twitch.tv/oauth2/device";
const TWITCH_TOKEN_URL: &str = "https://id.twitch.tv/oauth2/token";
const TWITCH_VALIDATE_URL: &str = "https://id.twitch.tv/oauth2/validate";
const STREAMLABS_AUTHORIZE_URL: &str = "https://streamlabs.com/api/v2.0/authorize";
const STREAMLABS_TOKEN_URL: &str = "https://streamlabs.com/api/v2.0/token";
const STREAMLABS_USER_URL: &str = "https://streamlabs.com/api/v2.0/user";

#[derive(Clone)]
pub struct HttpAuthTransport {
    client: Client,
}

#[derive(Deserialize)]
struct OAuthTokenBody {
    access_token: String,
    #[serde(default)]
    refresh_token: Option<String>,
    #[serde(default)]
    expires_in: Option<u64>,
    #[serde(default, deserialize_with = "deserialize_scopes")]
    scope: Vec<String>,
}


fn deserialize_scopes<'de, D>(deserializer: D) -> Result<Vec<String>, D::Error>
where
    D: Deserializer<'de>,
{
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum ScopeValue {
        List(Vec<String>),
        Text(String),
    }

    let value = Option::<ScopeValue>::deserialize(deserializer)?;
    Ok(match value {
        Some(ScopeValue::List(values)) => values,
        Some(ScopeValue::Text(value)) => value.split_whitespace().map(str::to_owned).collect(),
        None => Vec::new(),
    })
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderTokenSet {
    pub access: SecretBytes,
    pub refresh: Option<SecretBytes>,
    pub expires_in_secs: Option<u64>,
    pub scopes: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TwitchValidation {
    pub user_id: String,
    pub login: String,
    pub scopes: Vec<String>,
    pub expires_in_secs: u64,
}

#[derive(Deserialize)]
struct TwitchValidationBody {
    #[serde(default)]
    user_id: Option<String>,
    #[serde(default)]
    login: Option<String>,
    #[serde(default)]
    scopes: Vec<String>,
    expires_in: u64,
}

impl Default for HttpAuthTransport {
    fn default() -> Self {
        Self::new()
    }
}

impl HttpAuthTransport {
    #[must_use]
    pub fn new() -> Self {
        Self { client: Client::new() }
    }

    pub async fn twitch_device_code(
        &self,
        client_id: &str,
        scopes: &[String],
    ) -> Result<DeviceAuthorization, AuthError> {
        let scope_string = scopes.join(" ");
        self.client
            .post(TWITCH_DEVICE_URL)
            .form(&[("client_id", client_id), ("scopes", scope_string.as_str())])
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?
            .error_for_status()
            .map_err(|error| AuthError::Http(error.to_string()))?
            .json::<DeviceAuthorization>()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))
    }

    pub async fn twitch_poll_device(
        &self,
        client_id: &str,
        scopes: &[String],
        device_code: &str,
    ) -> Result<TokenPoll, AuthError> {
        let scope_string = scopes.join(" ");
        let response = self
            .client
            .post(TWITCH_TOKEN_URL)
            .form(&[
                ("client_id", client_id),
                ("scopes", scope_string.as_str()),
                ("device_code", device_code),
                ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
            ])
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        if response.status().is_success() {
            let body = response
                .json::<OAuthTokenBody>()
                .await
                .map_err(|error| AuthError::Http(error.to_string()))?;
            let refresh = body.refresh_token.unwrap_or_default();
            return Ok(TokenPoll::Authorized(TokenPair {
                access: SecretBytes::new(body.access_token.into_bytes()),
                refresh: SecretBytes::new(refresh.into_bytes()),
                expires_in_secs: body.expires_in.unwrap_or_default(),
            }));
        }
        let status = response.status();
        let body = response
            .json::<serde_json::Value>()
            .await
            .unwrap_or_else(|_| serde_json::json!({}));
        let message = body
            .get("message")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        match message {
            "authorization_pending" => Ok(TokenPoll::Pending),
            "slow_down" => Ok(TokenPoll::SlowDown),
            "access_denied" => Ok(TokenPoll::Denied),
            "expired_token" | "invalid device code" => Ok(TokenPoll::Expired),
            _ if status == StatusCode::UNAUTHORIZED => Ok(TokenPoll::Denied),
            _ => Err(AuthError::Http(format!("Twitch token endpoint returned {status}"))),
        }
    }

    pub async fn twitch_validate(&self, access: &SecretBytes) -> Result<TwitchValidation, AuthError> {
        let token = std::str::from_utf8(access.as_slice()).map_err(|_| AuthError::InvalidResponse)?;
        let response = self
            .client
            .get(TWITCH_VALIDATE_URL)
            .header(reqwest::header::AUTHORIZATION, format!("OAuth {token}"))
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        if response.status() == StatusCode::UNAUTHORIZED {
            return Err(AuthError::Denied);
        }
        let body = response
            .error_for_status()
            .map_err(|error| AuthError::Http(error.to_string()))?
            .json::<TwitchValidationBody>()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        Ok(TwitchValidation {
            user_id: body.user_id.ok_or(AuthError::InvalidResponse)?,
            login: body.login.ok_or(AuthError::InvalidResponse)?,
            scopes: body.scopes,
            expires_in_secs: body.expires_in,
        })
    }

    pub async fn twitch_refresh(
        &self,
        client_id: &str,
        refresh: &SecretBytes,
    ) -> Result<ProviderTokenSet, AuthError> {
        let refresh_token = std::str::from_utf8(refresh.as_slice()).map_err(|_| AuthError::InvalidResponse)?;
        let body = self
            .client
            .post(TWITCH_TOKEN_URL)
            .form(&[
                ("grant_type", "refresh_token"),
                ("refresh_token", refresh_token),
                ("client_id", client_id),
            ])
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?
            .error_for_status()
            .map_err(|error| AuthError::Http(error.to_string()))?
            .json::<OAuthTokenBody>()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        Ok(Self::provider_tokens(body))
    }

    pub fn streamlabs_authorize_url(
        &self,
        client_id: &str,
        redirect_uri: &str,
        scopes: &[String],
        state: &str,
    ) -> Result<String, AuthError> {
        self.authorization_url(STREAMLABS_AUTHORIZE_URL, client_id, redirect_uri, scopes, state)
    }

    pub fn authorization_url(
        &self,
        authorize_url: &str,
        client_id: &str,
        redirect_uri: &str,
        scopes: &[String],
        state: &str,
    ) -> Result<String, AuthError> {
        let mut url = Url::parse(authorize_url).map_err(|error| AuthError::Configuration(error.to_string()))?;
        url.query_pairs_mut()
            .append_pair("response_type", "code")
            .append_pair("client_id", client_id)
            .append_pair("redirect_uri", redirect_uri)
            .append_pair("scope", &scopes.join(" "))
            .append_pair("state", state);
        Ok(url.to_string())
    }

    pub async fn streamlabs_exchange_code<S: SecretStore>(
        &self,
        client_id: &str,
        redirect_uri: &str,
        code: &str,
        secrets: &S,
        client_secret_key: &SecretKey,
    ) -> Result<ProviderTokenSet, AuthError> {
        let client_secret = secrets
            .load(client_secret_key)
            .map_err(|_| AuthError::SecretStore)?
            .ok_or_else(|| AuthError::Configuration("Streamlabs client secret is not configured in Secret Service".into()))?;
        let client_secret = std::str::from_utf8(client_secret.as_slice()).map_err(|_| AuthError::InvalidResponse)?;
        self.exchange_authorization_code(
            STREAMLABS_TOKEN_URL,
            client_id,
            Some(client_secret),
            redirect_uri,
            code,
        )
        .await
    }

    pub async fn streamlabs_refresh<S: SecretStore>(
        &self,
        client_id: &str,
        redirect_uri: &str,
        refresh: &SecretBytes,
        secrets: &S,
        client_secret_key: &SecretKey,
    ) -> Result<ProviderTokenSet, AuthError> {
        let client_secret = secrets
            .load(client_secret_key)
            .map_err(|_| AuthError::SecretStore)?
            .ok_or_else(|| AuthError::Configuration("Streamlabs client secret is not configured in Secret Service".into()))?;
        let client_secret = std::str::from_utf8(client_secret.as_slice()).map_err(|_| AuthError::InvalidResponse)?;
        let refresh_token = std::str::from_utf8(refresh.as_slice()).map_err(|_| AuthError::InvalidResponse)?;
        let body = self
            .client
            .post(STREAMLABS_TOKEN_URL)
            .form(&[
                ("grant_type", "refresh_token"),
                ("client_id", client_id),
                ("client_secret", client_secret),
                ("redirect_uri", redirect_uri),
                ("refresh_token", refresh_token),
            ])
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?
            .error_for_status()
            .map_err(|error| AuthError::Http(error.to_string()))?
            .json::<OAuthTokenBody>()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        Ok(Self::provider_tokens(body))
    }

    pub async fn streamlabs_display_name(&self, access: &SecretBytes) -> Result<Option<String>, AuthError> {
        let token = std::str::from_utf8(access.as_slice()).map_err(|_| AuthError::InvalidResponse)?;
        let value = self
            .client
            .get(STREAMLABS_USER_URL)
            .bearer_auth(token)
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?
            .error_for_status()
            .map_err(|error| AuthError::Http(error.to_string()))?
            .json::<serde_json::Value>()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        Ok(find_display_name(&value))
    }

    pub async fn exchange_authorization_code(
        &self,
        token_url: &str,
        client_id: &str,
        client_secret: Option<&str>,
        redirect_uri: &str,
        code: &str,
    ) -> Result<ProviderTokenSet, AuthError> {
        let mut form = vec![
            ("grant_type", "authorization_code"),
            ("client_id", client_id),
            ("redirect_uri", redirect_uri),
            ("code", code),
        ];
        if let Some(secret) = client_secret {
            form.push(("client_secret", secret));
        }
        let body = self
            .client
            .post(token_url)
            .form(&form)
            .send()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?
            .error_for_status()
            .map_err(|error| AuthError::Http(error.to_string()))?
            .json::<OAuthTokenBody>()
            .await
            .map_err(|error| AuthError::Http(error.to_string()))?;
        Ok(Self::provider_tokens(body))
    }

    fn provider_tokens(body: OAuthTokenBody) -> ProviderTokenSet {
        ProviderTokenSet {
            access: SecretBytes::new(body.access_token.into_bytes()),
            refresh: body.refresh_token.map(|value| SecretBytes::new(value.into_bytes())),
            expires_in_secs: body.expires_in,
            scopes: body.scope,
        }
    }
}

fn find_display_name(value: &serde_json::Value) -> Option<String> {
    for key in ["display_name", "displayName", "username", "name"] {
        if let Some(name) = value.get(key).and_then(serde_json::Value::as_str)
            && !name.is_empty()
        {
            return Some(name.to_owned());
        }
    }
    value.as_object().and_then(|object| {
        object.values().find_map(|child| {
            if child.is_object() {
                find_display_name(child)
            } else {
                None
            }
        })
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn twitch_device_response_uses_provider_field_names() {
        let value = serde_json::json!({
            "device_code": "device",
            "user_code": "ABCDEFGH",
            "verification_uri": "https://www.twitch.tv/activate",
            "expires_in": 1800,
            "interval": 5
        });
        let auth: DeviceAuthorization = serde_json::from_value(value).unwrap();
        assert_eq!(auth.expires_in_secs, 1800);
        assert_eq!(auth.interval_secs, 5);
    }

    #[test]
    fn oauth_scope_accepts_array_or_space_delimited_text() {
        let list: OAuthTokenBody = serde_json::from_value(serde_json::json!({
            "access_token": "x", "scope": ["a", "b"]
        })).unwrap();
        let text: OAuthTokenBody = serde_json::from_value(serde_json::json!({
            "access_token": "x", "scope": "a b"
        })).unwrap();
        assert_eq!(list.scope, vec!["a", "b"]);
        assert_eq!(text.scope, vec!["a", "b"]);
    }

    #[test]
    fn streamlabs_authorize_url_contains_csrf_state() {
        let transport = HttpAuthTransport::new();
        let url = transport
            .streamlabs_authorize_url(
                "client",
                "http://127.0.0.1:43127/oauth/callback",
                &["donations.read".into()],
                "csrf-state",
            )
            .unwrap();
        assert!(url.contains("state=csrf-state"));
        assert!(url.contains("response_type=code"));
    }
}
