use crate::{IntegrationError, ProviderOperation, ProviderOperationError, ProviderTransport};
use aetherstream_core::{
    AetherStreamAction, Provider, StreamlabsAlertAction, StreamlabsMediaShareAction, UnifiedEvent,
    UnifiedEventKind,
};

pub struct StreamlabsClient<T> {
    _transport: T,
    connected: bool,
}

impl<T: ProviderTransport> StreamlabsClient<T> {
    pub fn new(transport: T) -> Self {
        Self {
            _transport: transport,
            connected: false,
        }
    }

    pub fn is_connected(&self) -> bool {
        self.connected
    }
}

pub fn translate_streamlabs_action(
    action: &AetherStreamAction,
) -> Result<Option<ProviderOperation>, ProviderOperationError> {
    let operation = match action {
        AetherStreamAction::StreamlabsSkipAlert => ProviderOperation::new(
            Provider::Streamlabs,
            "POST",
            "/api/v2.0/alerts/skip",
            serde_json::json!({}),
            &["alerts.write"],
        ),
        AetherStreamAction::StreamlabsAlert(alert_action) => {
            let (method, path, body, scope) = match alert_action {
                StreamlabsAlertAction::Skip => ("POST", "/api/v2.0/alerts/skip", serde_json::json!({}), "alerts.write"),
                StreamlabsAlertAction::Pause => ("POST", "/api/v2.0/alerts/pause_queue", serde_json::json!({}), "alerts.write"),
                StreamlabsAlertAction::Resume => ("POST", "/api/v2.0/alerts/unpause_queue", serde_json::json!({}), "alerts.write"),
                StreamlabsAlertAction::Mute => ("POST", "/api/v2.0/alerts/mute_volume", serde_json::json!({}), "alerts.write"),
                StreamlabsAlertAction::Unmute => ("POST", "/api/v2.0/alerts/unmute_volume", serde_json::json!({}), "alerts.write"),
                StreamlabsAlertAction::Test(kind) => ("POST", "/api/v2.0/alerts/send_test_alert", serde_json::json!({"type": kind}), "alerts.write"),
            };
            ProviderOperation::new(Provider::Streamlabs, method, path, body, &[scope])
        }
        AetherStreamAction::StreamlabsMediaShare(media_action) => {
            let path = match media_action {
                StreamlabsMediaShareAction::Play => "/api/v2.0/media-share/play-media",
                StreamlabsMediaShareAction::Pause => "/api/v2.0/media-share/pause-media",
                StreamlabsMediaShareAction::Skip => "/api/v2.0/media-share/skip-video",
                StreamlabsMediaShareAction::VolumeUp => "/api/v2.0/media-share/volume-up",
                StreamlabsMediaShareAction::VolumeDown => "/api/v2.0/media-share/volume-down",
                StreamlabsMediaShareAction::Moderation(true) => "/api/v2.0/media-share/enable-moderation",
                StreamlabsMediaShareAction::Moderation(false) => "/api/v2.0/media-share/disable-moderation",
            };
            ProviderOperation::new(
                Provider::Streamlabs,
                "PUT",
                path,
                serde_json::json!({}),
                &["mediashare.control"],
            )
        }
        _ => return Ok(None),
    };
    Ok(Some(operation))
}

pub fn normalize_streamlabs(raw: &str) -> Result<UnifiedEvent, IntegrationError> {
    let value: serde_json::Value =
        serde_json::from_str(raw).map_err(|error| IntegrationError::Payload(error.to_string()))?;
    let kind = match value.get("type").and_then(serde_json::Value::as_str) {
        Some("donation") => UnifiedEventKind::Donation,
        Some(name) => UnifiedEventKind::Custom(name.into()),
        None => UnifiedEventKind::Custom("unknown".into()),
    };
    let mut event = UnifiedEvent::new(Provider::Streamlabs, kind);
    event.provider_payload = value;
    Ok(event)
}
