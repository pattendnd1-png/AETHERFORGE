use crate::{IntegrationError, ProviderOperation, ProviderOperationError, ProviderRequest, ProviderTransport};
use aetherstream_core::{AetherStreamAction, Provider, UnifiedEvent, UnifiedEventKind};

pub struct ObsClient<T> {
    transport: T,
    connected: bool,
}

impl<T: ProviderTransport> ObsClient<T> {
    pub fn new(transport: T) -> Self {
        Self {
            transport,
            connected: false,
        }
    }

    pub fn is_connected(&self) -> bool {
        self.connected
    }

    pub async fn handshake(&mut self) -> Result<(), IntegrationError> {
        let response = self
            .transport
            .send(ProviderRequest {
                method: "OBS_IDENTIFY".into(),
                path: "/".into(),
                body: serde_json::json!({"rpcVersion": 1}),
            })
            .await?;
        self.connected = (200..300).contains(&response.status);
        if self.connected {
            Ok(())
        } else {
            Err(IntegrationError::Transport(format!(
                "OBS handshake status {}",
                response.status
            )))
        }
    }
}

pub fn translate_obs_action(
    action: &AetherStreamAction,
) -> Result<Option<ProviderOperation>, ProviderOperationError> {
    let (request_type, body) = match action {
        AetherStreamAction::ObsScene(scene) => (
            "SetCurrentProgramScene",
            serde_json::json!({"sceneName": scene}),
        ),
        AetherStreamAction::ObsMute { input, muted } => (
            "SetInputMute",
            serde_json::json!({"inputName": input, "inputMuted": muted}),
        ),
        AetherStreamAction::ObsTransition(transition) => (
            "SetCurrentSceneTransition",
            serde_json::json!({"transitionName": transition}),
        ),
        AetherStreamAction::ObsSourceVisibility { source, visible } => (
            "SetSceneItemEnabled",
            serde_json::json!({"sourceName": source, "sceneItemEnabled": visible}),
        ),
        AetherStreamAction::ObsReplayBufferSave => ("SaveReplayBuffer", serde_json::json!({})),
        _ => return Ok(None),
    };
    Ok(Some(ProviderOperation::new(
        Provider::Obs,
        "OBS_REQUEST",
        request_type,
        body,
        &[],
    )))
}

pub fn normalize_obs(raw: &str) -> Result<UnifiedEvent, IntegrationError> {
    let value: serde_json::Value =
        serde_json::from_str(raw).map_err(|error| IntegrationError::Payload(error.to_string()))?;
    let mut event = UnifiedEvent::new(Provider::Obs, UnifiedEventKind::ObsSceneChanged);
    event.provider_payload = value;
    Ok(event)
}
