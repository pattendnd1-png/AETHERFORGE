use crate::{IntegrationError, ProviderOperation, ProviderOperationError, ProviderTransport};
use aetherstream_core::{
    AetherStreamAction, Provider, StreamElementsOverlayAction, UnifiedEvent, UnifiedEventKind,
};

pub struct StreamElementsClient<T> {
    _transport: T,
    connected: bool,
}

impl<T: ProviderTransport> StreamElementsClient<T> {
    pub fn new(transport: T) -> Self {
        Self {
            _transport: transport,
            connected: false,
        }
    }

    pub fn is_connected(&self) -> bool {
        self.connected
    }
}

pub fn translate_streamelements_action(
    action: &AetherStreamAction,
) -> Result<Option<ProviderOperation>, ProviderOperationError> {
    let operation = match action {
        AetherStreamAction::StreamElementsTestAlert(kind) => ProviderOperation::new(
            Provider::StreamElements,
            "OVERLAY_TEST",
            "channel.overlay.broadcast",
            serde_json::json!({"event": "aetherstream-test-alert", "data": {"kind": kind}}),
            &["overlays:broadcast"],
        ),
        AetherStreamAction::StreamElementsOverlay(action) => {
            let action_name = match action {
                StreamElementsOverlayAction::Pause => "pause",
                StreamElementsOverlayAction::Resume => "unpause",
                StreamElementsOverlayAction::Mute => "mute",
                StreamElementsOverlayAction::Unmute => "unmute",
                StreamElementsOverlayAction::Skip => "skip",
                StreamElementsOverlayAction::PlayNext => "playNext",
                StreamElementsOverlayAction::Reload => "reload",
            };
            ProviderOperation::new(
                Provider::StreamElements,
                "OVERLAY_CONTROL",
                "channel.overlay.action",
                serde_json::json!({"action": action_name}),
                &[],
            )
        }
        _ => return Ok(None),
    };
    Ok(Some(operation))
}

pub fn normalize_streamelements(raw: &str) -> Result<UnifiedEvent, IntegrationError> {
    let value: serde_json::Value =
        serde_json::from_str(raw).map_err(|error| IntegrationError::Payload(error.to_string()))?;
    let kind = match value.get("type").and_then(serde_json::Value::as_str) {
        Some("tip") => UnifiedEventKind::Tip,
        Some(name) => UnifiedEventKind::Custom(name.into()),
        None => UnifiedEventKind::Custom("unknown".into()),
    };
    let mut event = UnifiedEvent::new(Provider::StreamElements, kind);
    event.provider_payload = value;
    Ok(event)
}
