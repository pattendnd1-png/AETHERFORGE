use crate::{ProviderOperation, ProviderOperationError};
use aetherstream_core::{
    AetherStreamAction, Provider, TwitchModerationAction, TwitchPollSpec, TwitchPredictionSpec,
};

fn non_empty(value: &str, field: &'static str) -> Result<(), ProviderOperationError> {
    if value.trim().is_empty() {
        Err(ProviderOperationError::Invalid(field))
    } else {
        Ok(())
    }
}

fn validate_poll(spec: &TwitchPollSpec) -> Result<(), ProviderOperationError> {
    non_empty(&spec.title, "poll title")?;
    if spec.title.chars().count() > 60 {
        return Err(ProviderOperationError::Invalid("poll title length"));
    }
    if !(2..=5).contains(&spec.choices.len()) {
        return Err(ProviderOperationError::Invalid("poll choice count"));
    }
    if !(15..=1800).contains(&spec.duration_secs) {
        return Err(ProviderOperationError::Invalid("poll duration"));
    }
    for choice in &spec.choices {
        non_empty(choice, "poll choice")?;
        if choice.chars().count() > 25 {
            return Err(ProviderOperationError::Invalid("poll choice length"));
        }
    }
    Ok(())
}

fn validate_prediction(spec: &TwitchPredictionSpec) -> Result<(), ProviderOperationError> {
    non_empty(&spec.title, "prediction title")?;
    if spec.title.chars().count() > 45 {
        return Err(ProviderOperationError::Invalid("prediction title length"));
    }
    if !(2..=10).contains(&spec.outcomes.len()) {
        return Err(ProviderOperationError::Invalid("prediction outcome count"));
    }
    if !(30..=1800).contains(&spec.window_secs) {
        return Err(ProviderOperationError::Invalid("prediction window"));
    }
    for outcome in &spec.outcomes {
        non_empty(outcome, "prediction outcome")?;
        if outcome.chars().count() > 25 {
            return Err(ProviderOperationError::Invalid("prediction outcome length"));
        }
    }
    Ok(())
}

pub fn translate_twitch_action(
    action: &AetherStreamAction,
) -> Result<Option<ProviderOperation>, ProviderOperationError> {
    let operation = match action {
        AetherStreamAction::TwitchCreateClip => ProviderOperation::new(
            Provider::Twitch,
            "POST",
            "/helix/clips",
            serde_json::json!({}),
            &["clips:edit"],
        ),
        AetherStreamAction::TwitchMarker(description) => ProviderOperation::new(
            Provider::Twitch,
            "POST",
            "/helix/streams/markers",
            serde_json::json!({"description": description}),
            &["channel:manage:broadcast"],
        ),
        AetherStreamAction::TwitchRaid(target) => {
            non_empty(target, "raid target")?;
            ProviderOperation::new(
                Provider::Twitch,
                "POST_RESOLVE_TARGET",
                "/helix/raids",
                serde_json::json!({"target_login": target.trim()}),
                &["channel:manage:raids"],
            )
        }
        AetherStreamAction::TwitchShieldMode(active) => ProviderOperation::new(
            Provider::Twitch,
            "PUT",
            "/helix/moderation/shield_mode",
            serde_json::json!({"is_active": active}),
            &["moderator:manage:shield_mode"],
        ),
        AetherStreamAction::TwitchCreatePoll(spec) => {
            validate_poll(spec)?;
            ProviderOperation::new(
                Provider::Twitch,
                "POST",
                "/helix/polls",
                serde_json::json!({
                    "title": spec.title,
                    "choices": spec.choices.iter().map(|title| serde_json::json!({"title": title})).collect::<Vec<_>>(),
                    "duration": spec.duration_secs,
                }),
                &["channel:manage:polls"],
            )
        }
        AetherStreamAction::TwitchCreatePrediction(spec) => {
            validate_prediction(spec)?;
            ProviderOperation::new(
                Provider::Twitch,
                "POST",
                "/helix/predictions",
                serde_json::json!({
                    "title": spec.title,
                    "outcomes": spec.outcomes.iter().map(|title| serde_json::json!({"title": title})).collect::<Vec<_>>(),
                    "prediction_window": spec.window_secs,
                }),
                &["channel:manage:predictions"],
            )
        }
        AetherStreamAction::TwitchModeration(moderation) => match moderation {
            TwitchModerationAction::Ban { user, reason } => {
                non_empty(user, "moderation user")?;
                ProviderOperation::new(
                    Provider::Twitch,
                    "POST_RESOLVE_TARGET",
                    "/helix/moderation/bans",
                    serde_json::json!({"target_login": user.trim(), "reason": reason}),
                    &["moderator:manage:banned_users"],
                )
            }
            TwitchModerationAction::Timeout {
                user,
                duration_secs,
                reason,
            } => {
                non_empty(user, "moderation user")?;
                if *duration_secs == 0 || *duration_secs > 1_209_600 {
                    return Err(ProviderOperationError::Invalid("timeout duration"));
                }
                ProviderOperation::new(
                    Provider::Twitch,
                    "POST_RESOLVE_TARGET",
                    "/helix/moderation/bans",
                    serde_json::json!({
                        "target_login": user.trim(),
                        "duration": duration_secs,
                        "reason": reason,
                    }),
                    &["moderator:manage:banned_users"],
                )
            }
            TwitchModerationAction::Unban { user } => {
                non_empty(user, "moderation user")?;
                ProviderOperation::new(
                    Provider::Twitch,
                    "DELETE_RESOLVE_TARGET",
                    "/helix/moderation/bans",
                    serde_json::json!({"target_login": user.trim()}),
                    &["moderator:manage:banned_users"],
                )
            }
            TwitchModerationAction::DeleteMessage { message_id } => {
                non_empty(message_id, "message id")?;
                ProviderOperation::new(
                    Provider::Twitch,
                    "DELETE",
                    "/helix/moderation/chat",
                    serde_json::json!({"message_id": message_id.trim()}),
                    &["moderator:manage:chat_messages"],
                )
            }
            TwitchModerationAction::ApproveAutomod { message_id } => {
                non_empty(message_id, "message id")?;
                ProviderOperation::new(
                    Provider::Twitch,
                    "PUT",
                    "/helix/moderation/automod/message",
                    serde_json::json!({"msg_id": message_id.trim(), "action": "ALLOWED"}),
                    &["moderator:manage:automod"],
                )
            }
            TwitchModerationAction::DenyAutomod { message_id } => {
                non_empty(message_id, "message id")?;
                ProviderOperation::new(
                    Provider::Twitch,
                    "PUT",
                    "/helix/moderation/automod/message",
                    serde_json::json!({"msg_id": message_id.trim(), "action": "DENIED"}),
                    &["moderator:manage:automod"],
                )
            }
        },
        _ => return Ok(None),
    };
    Ok(Some(operation))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn poll_validation_matches_twitch_limits() {
        let action = AetherStreamAction::TwitchCreatePoll(TwitchPollSpec {
            title: "Next game?".into(),
            choices: vec!["A".into(), "B".into()],
            duration_secs: 60,
        });
        let operation = translate_twitch_action(&action).unwrap().unwrap();
        assert_eq!(operation.path, "/helix/polls");
        assert!(operation.required_scopes.contains(&"channel:manage:polls".into()));
    }

    #[test]
    fn poll_rejects_too_few_choices() {
        let action = AetherStreamAction::TwitchCreatePoll(TwitchPollSpec {
            title: "Next game?".into(),
            choices: vec!["A".into()],
            duration_secs: 60,
        });
        assert_eq!(
            translate_twitch_action(&action),
            Err(ProviderOperationError::Invalid("poll choice count"))
        );
    }

    #[test]
    fn prediction_rejects_short_window() {
        let action = AetherStreamAction::TwitchCreatePrediction(TwitchPredictionSpec {
            title: "Win?".into(),
            outcomes: vec!["Yes".into(), "No".into()],
            window_secs: 29,
        });
        assert_eq!(
            translate_twitch_action(&action),
            Err(ProviderOperationError::Invalid("prediction window"))
        );
    }
}
