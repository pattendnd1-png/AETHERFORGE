use async_trait::async_trait; use serde::{Deserialize,Serialize}; use thiserror::Error;
#[derive(Clone,Debug,PartialEq,Serialize,Deserialize)] pub struct ProviderRequest{pub method:String,pub path:String,pub body:serde_json::Value}
#[derive(Clone,Debug,PartialEq,Serialize,Deserialize)] pub struct ProviderResponse{pub status:u16,pub body:serde_json::Value}
#[derive(Debug,Error)] pub enum IntegrationError{#[error("transport: {0}")]Transport(String),#[error("payload: {0}")]Payload(String)}
#[async_trait] pub trait ProviderTransport:Send+Sync{async fn send(&self,request:ProviderRequest)->Result<ProviderResponse,IntegrationError>;}
