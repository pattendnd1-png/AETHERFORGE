use aetherstream_core::{AetherStreamAction, Provider};
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct ProviderOperation {
    pub provider: Provider,
    pub method: String,
    pub path: String,
    pub body: serde_json::Value,
    pub required_scopes: Vec<String>,
}

impl ProviderOperation {
    #[must_use]
    pub fn new(
        provider: Provider,
        method: impl Into<String>,
        path: impl Into<String>,
        body: serde_json::Value,
        required_scopes: &[&str],
    ) -> Self {
        Self {
            provider,
            method: method.into(),
            path: path.into(),
            body,
            required_scopes: required_scopes.iter().map(|scope| (*scope).to_owned()).collect(),
        }
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum ProviderOperationError {
    #[error("invalid provider operation: {0}")]
    Invalid(&'static str),
}

pub fn translate_action(
    action: &AetherStreamAction,
) -> Result<Option<ProviderOperation>, ProviderOperationError> {
    if let Some(operation) = crate::twitch::translate_twitch_action(action)? {
        return Ok(Some(operation));
    }
    if let Some(operation) = crate::obs::translate_obs_action(action)? {
        return Ok(Some(operation));
    }
    if let Some(operation) = crate::streamelements::translate_streamelements_action(action)? {
        return Ok(Some(operation));
    }
    if let Some(operation) = crate::streamlabs::translate_streamlabs_action(action)? {
        return Ok(Some(operation));
    }
    Ok(None)
}
