pub mod client;
pub mod codec;
pub mod envelope;
pub mod protocol;

pub use client::{read_envelope, write_envelope};
pub use codec::{CodecError, FrameCodec};
pub use envelope::{IpcEnvelope, IPC_PROTOCOL_VERSION};
pub use protocol::{
    ClientHello, ClientSnapshot, ClientSnapshotRequest, ControlRequest, ControlResponse, ServiceSnapshot,
};
