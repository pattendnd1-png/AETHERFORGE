use aetherstream_control::{AetherState, StateDelta};
use aetherstream_core::{AetherStreamAction, ClientInstanceId, ServiceHealth};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use uuid::Uuid;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClientHello {
    pub client: ClientInstanceId,
    pub pid: u32,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClientSnapshotRequest {
    pub client: ClientInstanceId,
}

#[derive(Clone, Debug, Eq, PartialEq, Default, Serialize, Deserialize)]
pub struct ServiceSnapshot {
    pub services: BTreeMap<String, ServiceHealth>,
    pub connected_clients: usize,
}

pub type ClientSnapshot = ServiceSnapshot;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum ControlRequest {
    GetState,
    SubscribeState { since_revision: u64 },
    DispatchAction(AetherStreamAction),
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum ControlResponse {
    StateSnapshot(Box<AetherState>),
    StateDelta(StateDelta),
    ActionAccepted { id: Uuid },
    ActionRejected { id: Uuid, reason: String },
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn control_response_keeps_full_state_out_of_line() {
        assert!(std::mem::size_of::<ControlResponse>() < std::mem::size_of::<AetherState>());
    }

    #[test]
    fn control_protocol_round_trip_keeps_revision_and_action() {
        let request = ControlRequest::DispatchAction(AetherStreamAction::ObsScene("Gameplay".into()));
        let bytes = postcard::to_stdvec(&request).unwrap();
        assert_eq!(postcard::from_bytes::<ControlRequest>(&bytes).unwrap(), request);

        let state = AetherState {
            revision: 42,
            ..AetherState::default()
        };
        let response = ControlResponse::StateSnapshot(Box::new(state));
        let bytes = postcard::to_stdvec(&response).unwrap();
        assert_eq!(postcard::from_bytes::<ControlResponse>(&bytes).unwrap(), response);
    }
}
