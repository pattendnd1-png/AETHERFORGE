use crate::{CodecError, FrameCodec};
use serde::{de::DeserializeOwned, Serialize};
use std::io;
use thiserror::Error;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::UnixStream;

#[derive(Debug, Error)]
pub enum IpcIoError {
    #[error("io: {0}")]
    Io(#[from] io::Error),
    #[error("codec: {0}")]
    Codec(#[from] CodecError),
}

pub async fn write_envelope<T: Serialize>(stream: &mut UnixStream, value: &T) -> Result<(), IpcIoError> {
    let frame = FrameCodec::encode(value)?;
    stream.write_all(&frame).await?;
    Ok(())
}

pub async fn read_envelope<T: DeserializeOwned>(stream: &mut UnixStream) -> Result<T, IpcIoError> {
    let mut prefix = [0u8; 4];
    stream.read_exact(&mut prefix).await?;
    let len = u32::from_be_bytes(prefix) as usize;
    if len > FrameCodec::MAX_FRAME { return Err(IpcIoError::Codec(CodecError::TooLarge)); }
    let mut payload = vec![0u8; len];
    stream.read_exact(&mut payload).await?;
    let mut frame = Vec::with_capacity(len + 4);
    frame.extend_from_slice(&prefix);
    frame.extend_from_slice(&payload);
    Ok(FrameCodec::decode(&frame)?)
}
