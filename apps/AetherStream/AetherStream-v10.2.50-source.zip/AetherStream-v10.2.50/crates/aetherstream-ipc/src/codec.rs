use serde::{de::DeserializeOwned, Serialize};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum CodecError {
    #[error("frame is shorter than four-byte prefix")]
    ShortFrame,
    #[error("frame length prefix does not match payload")]
    LengthMismatch,
    #[error("frame is too large")]
    TooLarge,
    #[error("serialization failed: {0}")]
    Serialize(#[from] postcard::Error),
}

pub struct FrameCodec;
impl FrameCodec {
    pub const MAX_FRAME: usize = 8 * 1024 * 1024;

    pub fn encode<T: Serialize>(value: &T) -> Result<Vec<u8>, CodecError> {
        let payload = postcard::to_stdvec(value)?;
        if payload.len() > Self::MAX_FRAME { return Err(CodecError::TooLarge); }
        let len = u32::try_from(payload.len()).map_err(|_| CodecError::TooLarge)?;
        let mut out = Vec::with_capacity(payload.len() + 4);
        out.extend_from_slice(&len.to_be_bytes());
        out.extend_from_slice(&payload);
        Ok(out)
    }

    pub fn decode<T: DeserializeOwned>(frame: &[u8]) -> Result<T, CodecError> {
        if frame.len() < 4 { return Err(CodecError::ShortFrame); }
        let expected = u32::from_be_bytes(frame[..4].try_into().expect("slice is four bytes")) as usize;
        if expected > Self::MAX_FRAME { return Err(CodecError::TooLarge); }
        if frame.len() - 4 != expected { return Err(CodecError::LengthMismatch); }
        Ok(postcard::from_bytes(&frame[4..])?)
    }
}
