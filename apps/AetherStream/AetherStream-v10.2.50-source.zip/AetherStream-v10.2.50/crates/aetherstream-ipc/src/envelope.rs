use serde::{Deserialize, Serialize};
use uuid::Uuid;

pub const IPC_PROTOCOL_VERSION: u16 = 1;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct IpcEnvelope<T> {
    pub protocol_version: u16,
    pub message_id: Uuid,
    pub payload: T,
}

impl<T> IpcEnvelope<T> {
    pub fn new(payload: T) -> Self {
        Self { protocol_version: IPC_PROTOCOL_VERSION, message_id: Uuid::new_v4(), payload }
    }
}
