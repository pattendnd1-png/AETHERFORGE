use aetherstream_core::ClientInstanceId;
use aetherstream_ipc::{read_envelope, write_envelope, ClientHello, IpcEnvelope, ServiceSnapshot};
use tokio::net::{UnixListener, UnixStream};

#[tokio::test]
async fn two_clients_receive_same_snapshot() {
    let dir = std::env::temp_dir().join(format!("aetherstream-ipc-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let sock = dir.join("test.sock");
    let _ = std::fs::remove_file(&sock);
    let listener = UnixListener::bind(&sock).unwrap();
    let server = tokio::spawn(async move {
        for n in 0..2 {
            let (mut stream, _) = listener.accept().await.unwrap();
            let hello: IpcEnvelope<ClientHello> = read_envelope(&mut stream).await.unwrap();
            assert_eq!(hello.protocol_version, aetherstream_ipc::IPC_PROTOCOL_VERSION);
            let snapshot = ServiceSnapshot { connected_clients: 2, ..Default::default() };
            write_envelope(&mut stream, &IpcEnvelope::new(snapshot)).await.unwrap();
            assert!(n < 2);
        }
    });
    for _ in 0..2 {
        let mut stream = UnixStream::connect(&sock).await.unwrap();
        let hello = ClientHello { client: ClientInstanceId::new(), pid: std::process::id() };
        write_envelope(&mut stream, &IpcEnvelope::new(hello)).await.unwrap();
        let reply: IpcEnvelope<ServiceSnapshot> = read_envelope(&mut stream).await.unwrap();
        assert_eq!(reply.payload.connected_clients, 2);
    }
    server.await.unwrap();
    let _ = std::fs::remove_dir_all(dir);
}
