use crate::{Marker, MediaSource, MediaSourceId};
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct IsoTrack {
    pub name: String,
    pub source: MediaSourceId,
    pub kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RecordingPlan {
    pub schema_version: u16,
    pub program: MediaSourceId,
    pub iso_tracks: Vec<IsoTrack>,
    pub audio_stems: Vec<IsoTrack>,
    pub crash_tolerant_container: String,
    pub delivery_container: String,
    pub replay_buffer_seconds: u32,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum RecordedAssetKind {
    Program,
    VideoIso,
    AudioStem,
    Replay,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RecordedAsset {
    pub name: String,
    pub source: MediaSource,
    pub kind: RecordedAssetKind,
    pub synchronized_start_ms: u64,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RecordingManifest {
    pub schema_version: u16,
    pub session_name: String,
    pub assets: Vec<RecordedAsset>,
    pub markers: Vec<Marker>,
}

impl RecordingManifest {
    #[must_use]
    pub fn fixture_two_iso_one_stem() -> Self {
        let assets = [
            ("Camera", "file:///recordings/camera.mkv", RecordedAssetKind::VideoIso),
            ("Gameplay", "file:///recordings/gameplay.mkv", RecordedAssetKind::VideoIso),
            ("Mic", "file:///recordings/mic.flac", RecordedAssetKind::AudioStem),
        ]
        .into_iter()
        .map(|(name, uri, kind)| RecordedAsset {
            name: name.into(),
            source: MediaSource {
                id: MediaSourceId::new(),
                uri: uri.into(),
                checksum: None,
                duration_ms: Some(60_000),
            },
            kind,
            synchronized_start_ms: 0,
        })
        .collect();
        Self {
            schema_version: 1,
            session_name: "Forge Master".into(),
            assets,
            markers: vec![Marker {
                at_ms: 10_000,
                label: "Highlight".into(),
            }],
        }
    }
}
