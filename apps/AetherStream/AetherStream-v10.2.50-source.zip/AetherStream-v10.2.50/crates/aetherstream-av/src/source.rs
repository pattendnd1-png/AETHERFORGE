use serde::{Deserialize,Serialize};use uuid::Uuid;
#[derive(Clone,Copy,Debug,Eq,PartialEq,Hash,Serialize,Deserialize)]pub struct MediaSourceId(pub Uuid);impl MediaSourceId{pub fn new()->Self{Self(Uuid::new_v4())}}impl Default for MediaSourceId{fn default()->Self{Self::new()}}
#[derive(Clone,Debug,Eq,PartialEq,Serialize,Deserialize)]pub struct MediaSource{pub id:MediaSourceId,pub uri:String,pub checksum:Option<String>,pub duration_ms:Option<u64>}
