use crate::{
    Clip, MediaSource, RecordedAssetKind, RecordingManifest, Timeline, Track, TrackKind,
};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct AvProject {
    pub schema_version: u16,
    pub name: String,
    pub sources: Vec<MediaSource>,
    pub timeline: Timeline,
}

pub type Project = AvProject;

impl AvProject {
    #[must_use]
    pub fn from_recording_manifest(manifest: &RecordingManifest) -> Self {
        let sources = manifest.assets.iter().map(|asset| asset.source.clone()).collect();
        let tracks = manifest
            .assets
            .iter()
            .map(|asset| {
                let kind = match asset.kind {
                    RecordedAssetKind::AudioStem => TrackKind::Audio,
                    RecordedAssetKind::Program | RecordedAssetKind::VideoIso | RecordedAssetKind::Replay => TrackKind::Video,
                };
                let source_out_ms = asset.source.duration_ms.unwrap_or_default();
                Track {
                    id: Uuid::new_v4(),
                    name: asset.name.clone(),
                    kind,
                    clips: vec![Clip {
                        id: Uuid::new_v4(),
                        source: asset.source.id,
                        source_in_ms: 0,
                        source_out_ms,
                        timeline_start_ms: asset.synchronized_start_ms,
                        dsp_preset: None,
                        destructive: false,
                    }],
                }
            })
            .collect();
        Self {
            schema_version: 1,
            name: manifest.session_name.clone(),
            sources,
            timeline: Timeline {
                tracks,
                markers: manifest.markers.clone(),
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Clip, MediaSourceId, Track, TrackKind};

    #[test]
    fn project_round_trip_is_non_destructive_and_deterministic() {
        let source = MediaSource {
            id: MediaSourceId::new(),
            uri: "file:///media/source.mkv".into(),
            checksum: None,
            duration_ms: Some(10_000),
        };
        let mut track = Track {
            id: Uuid::new_v4(),
            name: "V1".into(),
            kind: TrackKind::Video,
            clips: vec![
                Clip {
                    id: Uuid::new_v4(),
                    source: source.id,
                    source_in_ms: 0,
                    source_out_ms: 3_000,
                    timeline_start_ms: 1_000,
                    dsp_preset: None,
                    destructive: false,
                },
                Clip {
                    id: Uuid::new_v4(),
                    source: source.id,
                    source_in_ms: 3_000,
                    source_out_ms: 6_000,
                    timeline_start_ms: 1_000,
                    dsp_preset: None,
                    destructive: false,
                },
            ],
        };
        track.sort_deterministically();
        let project = AvProject {
            schema_version: 1,
            name: "test".into(),
            sources: vec![source],
            timeline: Timeline {
                tracks: vec![track],
                markers: vec![],
            },
        };
        let json = serde_json::to_string(&project).unwrap();
        assert!(!json.contains("source_media_bytes"));
        assert_eq!(serde_json::from_str::<AvProject>(&json).unwrap(), project);
    }

    #[test]
    fn finalized_recording_manifest_populates_project_without_destructive_edits() {
        let manifest = RecordingManifest::fixture_two_iso_one_stem();
        let project = Project::from_recording_manifest(&manifest);
        assert_eq!(project.sources.len(), 3);
        assert!(project
            .timeline
            .tracks
            .iter()
            .flat_map(|track| &track.clips)
            .all(|clip| !clip.destructive));
    }
}
