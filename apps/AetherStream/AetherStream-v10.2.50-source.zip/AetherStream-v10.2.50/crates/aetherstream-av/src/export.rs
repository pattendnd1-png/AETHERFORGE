use serde::{Deserialize, Serialize};
use thiserror::Error;
use uuid::Uuid;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum HardwareAcceleration {
    Software,
    Vaapi,
    Vulkan,
    Other(String),
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ExportPreset {
    pub name: String,
    pub container: String,
    pub video_codec: Option<String>,
    pub audio_codec: Option<String>,
    pub acceleration: HardwareAcceleration,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RenderJob {
    pub id: Uuid,
    pub preset: ExportPreset,
    pub output_uri: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BackendRole {
    PipeWireLiveIo,
    GStreamerRealtime,
    FFmpegOffline,
    ObsBroadcast,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BackendAssignment {
    pub live_io: BackendRole,
    pub realtime_media: BackendRole,
    pub offline_render: BackendRole,
    pub broadcast: BackendRole,
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum BackendError {
    #[error("backend ownership overlaps or violates canonical roles")]
    InvalidRole,
}

impl BackendAssignment {
    pub fn canonical() -> Self {
        Self {
            live_io: BackendRole::PipeWireLiveIo,
            realtime_media: BackendRole::GStreamerRealtime,
            offline_render: BackendRole::FFmpegOffline,
            broadcast: BackendRole::ObsBroadcast,
        }
    }

    pub fn validate(&self) -> Result<(), BackendError> {
        if *self == Self::canonical() {
            Ok(())
        } else {
            Err(BackendError::InvalidRole)
        }
    }
}

pub trait GStreamerRealtimeBackend: Send {
    fn start_recording(&mut self, plan_name: &str) -> Result<(), String>;
    fn stop_recording(&mut self) -> Result<(), String>;
}

pub trait FfmpegOfflineBackend: Send {
    fn enqueue_render(&mut self, job: &RenderJob) -> Result<(), String>;
    fn discovered_acceleration(&self) -> Vec<HardwareAcceleration>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_ffmpeg_as_live_broadcast_compositor() {
        let mut assignment = BackendAssignment::canonical();
        assignment.broadcast = BackendRole::FFmpegOffline;
        assert_eq!(assignment.validate(), Err(BackendError::InvalidRole));
    }
}
