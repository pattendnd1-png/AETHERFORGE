use aetherstream_core::{AccountId, ClientInstanceId};
use std::collections::{hash_map::Entry, HashMap};
use thiserror::Error;

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub enum LeaseKey {
    OAuthRefresh(AccountId), EventSub(AccountId), Obs(String), StreamElements(AccountId),
    Streamlabs(AccountId), StreamDeck(String),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ServiceOwner { Authd, Eventsubd, Obsd, Elementsd, Labsd, Deckd, Supervisord, Ui(ClientInstanceId) }

#[derive(Debug, Error, Eq, PartialEq)]
pub enum LeaseError {
    #[error("UI processes cannot own singleton external resources")]
    UiOwnershipForbidden,
    #[error("lease already owned")]
    AlreadyOwned,
    #[error("service is not the canonical owner for this lease")]
    WrongService,
}

#[derive(Default)]
pub struct LeaseRegistry { leases: HashMap<LeaseKey, ServiceOwner> }

impl LeaseRegistry {
    pub fn acquire(&mut self, key: LeaseKey, owner: ServiceOwner) -> Result<(), LeaseError> {
        if matches!(owner, ServiceOwner::Ui(_)) { return Err(LeaseError::UiOwnershipForbidden); }
        let canonical = matches!((&key, &owner),
            (LeaseKey::OAuthRefresh(_), ServiceOwner::Authd) |
            (LeaseKey::EventSub(_), ServiceOwner::Eventsubd) |
            (LeaseKey::Obs(_), ServiceOwner::Obsd) |
            (LeaseKey::StreamElements(_), ServiceOwner::Elementsd) |
            (LeaseKey::Streamlabs(_), ServiceOwner::Labsd) |
            (LeaseKey::StreamDeck(_), ServiceOwner::Deckd));
        if !canonical { return Err(LeaseError::WrongService); }
        match self.leases.entry(key) {
            Entry::Vacant(slot) => { slot.insert(owner); Ok(()) }
            Entry::Occupied(_) => Err(LeaseError::AlreadyOwned),
        }
    }
    pub fn owner(&self, key: &LeaseKey) -> Option<&ServiceOwner> { self.leases.get(key) }
    pub fn release(&mut self, key: &LeaseKey, owner: &ServiceOwner) -> bool {
        if self.leases.get(key) == Some(owner) { self.leases.remove(key); true } else { false }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn second_owner_cannot_take_stream_deck_lease() {
        let mut leases = LeaseRegistry::default();
        let key = LeaseKey::StreamDeck("serial-1".into());
        leases.acquire(key.clone(), ServiceOwner::Deckd).unwrap();
        assert!(leases.acquire(key, ServiceOwner::Deckd).is_err());
    }
    #[test]
    fn ui_cannot_own_stream_deck_lease() {
        let mut leases = LeaseRegistry::default();
        let result = leases.acquire(LeaseKey::StreamDeck("serial-1".into()), ServiceOwner::Ui(ClientInstanceId::new()));
        assert_eq!(result, Err(LeaseError::UiOwnershipForbidden));
    }
}
