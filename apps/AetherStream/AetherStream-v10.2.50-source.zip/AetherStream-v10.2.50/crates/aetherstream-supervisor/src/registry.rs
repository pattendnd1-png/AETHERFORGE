use aetherstream_core::{ClientInstanceId, ServiceHealth};
use aetherstream_ipc::ServiceSnapshot;
use std::collections::{BTreeMap, HashMap};

#[derive(Default)]
pub struct ClientRegistry {
    clients: HashMap<ClientInstanceId, u32>,
    subscriptions: HashMap<ClientInstanceId, u64>,
    services: BTreeMap<String, ServiceHealth>,
}

impl ClientRegistry {
    pub fn register(&mut self, id: ClientInstanceId, pid: u32) {
        self.clients.insert(id, pid);
    }

    pub fn unregister(&mut self, id: ClientInstanceId) {
        self.clients.remove(&id);
        self.subscriptions.remove(&id);
    }

    #[must_use]
    pub fn contains(&self, id: ClientInstanceId) -> bool {
        self.clients.contains_key(&id)
    }

    pub fn subscribe(&mut self, id: ClientInstanceId, since_revision: u64) {
        if self.clients.contains_key(&id) {
            self.subscriptions.insert(id, since_revision);
        }
    }

    pub fn acknowledge_revision(&mut self, id: ClientInstanceId, revision: u64) {
        if let Some(value) = self.subscriptions.get_mut(&id) {
            *value = revision;
        }
    }

    #[must_use]
    pub fn subscribed_revision(&self, id: ClientInstanceId) -> Option<u64> {
        self.subscriptions.get(&id).copied()
    }

    pub fn set_service_health(&mut self, name: impl Into<String>, health: ServiceHealth) {
        self.services.insert(name.into(), health);
    }

    #[must_use]
    pub fn service_health(&self, name: &str) -> Option<ServiceHealth> {
        self.services.get(name).copied()
    }

    #[must_use]
    pub fn snapshot(&self) -> ServiceSnapshot {
        ServiceSnapshot {
            services: self.services.clone(),
            connected_clients: self.clients.len(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unregistering_one_ui_does_not_drop_service_health() {
        let mut registry = ClientRegistry::default();
        let a = ClientInstanceId::new();
        let b = ClientInstanceId::new();
        registry.register(a, 1001);
        registry.register(b, 1002);
        registry.set_service_health("obsd", ServiceHealth::Connected);
        registry.unregister(a);
        assert_eq!(registry.service_health("obsd"), Some(ServiceHealth::Connected));
        assert!(registry.contains(b));
    }

    #[test]
    fn state_subscription_is_per_client_not_per_service_owner() {
        let mut registry = ClientRegistry::default();
        let a = ClientInstanceId::new();
        let b = ClientInstanceId::new();
        registry.register(a, 1001);
        registry.register(b, 1002);
        registry.subscribe(a, 3);
        registry.subscribe(b, 3);
        registry.acknowledge_revision(a, 4);
        assert_eq!(registry.subscribed_revision(a), Some(4));
        assert_eq!(registry.subscribed_revision(b), Some(3));
    }
}
