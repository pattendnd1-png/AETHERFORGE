#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
VERSION="10.2.50"
AETHERSTREAM_CACHE_ROOT="${XDG_CACHE_HOME:-$HOME/.cache}/aetherstream"
CARGO_TARGET_DIR="${AETHERSTREAM_CARGO_TARGET_DIR:-$AETHERSTREAM_CACHE_ROOT/cargo-target-v${VERSION}}"
AETHERSTREAM_BUILD_TMP_DIR="${AETHERSTREAM_BUILD_TMP_DIR:-$AETHERSTREAM_CACHE_ROOT/compiler-tmp-v${VERSION}}"
TMPDIR="$AETHERSTREAM_BUILD_TMP_DIR"
TMP="$AETHERSTREAM_BUILD_TMP_DIR"
TEMP="$AETHERSTREAM_BUILD_TMP_DIR"
CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR CARGO_INCREMENTAL AETHERSTREAM_BUILD_TMP_DIR
export TMPDIR TMP TEMP
mkdir -p "$CARGO_TARGET_DIR" "$AETHERSTREAM_BUILD_TMP_DIR"

check_build_space() {
  local min_kib="${AETHERSTREAM_MIN_BUILD_FREE_KIB:-4194304}"
  local available_kib
  available_kib="$(df -Pk "$AETHERSTREAM_BUILD_TMP_DIR" | awk 'NR==2 {print $4}')"
  [[ "$available_kib" =~ ^[0-9]+$ ]] || {
    echo "AETHERSTREAM_BUILD_SPACE=FAIL:unable-to-read-free-space:$AETHERSTREAM_BUILD_TMP_DIR" >&2
    return 1
  }
  if (( available_kib < min_kib )); then
    echo "AETHERSTREAM_BUILD_SPACE=FAIL:need-${min_kib}KiB-have-${available_kib}KiB:$AETHERSTREAM_BUILD_TMP_DIR" >&2
    return 1
  fi
  echo "AETHERSTREAM_BUILD_TMPDIR=$AETHERSTREAM_BUILD_TMP_DIR"
  echo "AETHERSTREAM_BUILD_SPACE=PASS:${available_kib}KiB"
}

dedupe_colon_path() {
  local required="$1" current="${2:-}" part
  local out="$required"
  local -a parts=()
  current="${current//:/,}"
  IFS=',' read -r -a parts <<< "$current"
  for part in "${parts[@]}"; do
    [[ -z "$part" || "$part" == "$required" ]] && continue
    out+="${out:+,}$part"
  done
  printf '%s\n' "$out"
}
OUT_DIR="${AETHERSTREAM_DOWNLOADS_DIR:-$HOME/Downloads}"
VERIFY="$OUT_DIR/AetherStream-v${VERSION}-VERIFY.txt"
BUILD_LOG="$OUT_DIR/AetherStream-v${VERSION}-BUILD.log"
INSTALL_LOG="$OUT_DIR/AetherStream-v${VERSION}-INSTALL.log"
HOST_VERIFY_SNAPSHOT=""
VERIFY_FINALIZED=0
LINKED_TOPOLOGY_SNAPSHOT=""
AETHERSTREAM_INSTALLER_STAGE="startup"
AETHERSTREAM_INSTALLER_STAGE_STARTED=""
WAS_AUDIOD_ACTIVE=0
WAS_SUPERVISORD_ACTIVE=0

mkdir -p "$OUT_DIR"
: > "$INSTALL_LOG"
exec > >(tee -a "$INSTALL_LOG") 2>&1

write_running_verify() {
  local tmp
  tmp="$(mktemp "${VERIFY}.tmp.XXXXXX")"
  {
    echo "AETHERSTREAM_VERSION=$VERSION"
    echo "AETHERSTREAM_INSTALLER_STAGE=$AETHERSTREAM_INSTALLER_STAGE"
    echo "AETHERSTREAM_INSTALLER_STAGE_STARTED=$AETHERSTREAM_INSTALLER_STAGE_STARTED"
    echo "AETHERSTREAM_INSTALL_LOG=$INSTALL_LOG"
    echo "AETHERSTREAM_BUILD_LOG=$BUILD_LOG"
    echo "AETHERSTREAM_VERIFY=RUNNING"
  } > "$tmp"
  mv -f "$tmp" "$VERIFY"
}

set_stage() {
  AETHERSTREAM_INSTALLER_STAGE="$1"
  AETHERSTREAM_INSTALLER_STAGE_STARTED="$(date --iso-8601=seconds 2>/dev/null || date '+%Y-%m-%dT%H:%M:%S%z')"
  write_running_verify
}

write_early_failure_verify() {
  local rc="$1"
  local tmp
  tmp="$(mktemp "${VERIFY}.tmp.XXXXXX")"
  {
    echo "AETHERSTREAM_VERSION=$VERSION"
    echo "AETHERSTREAM_INSTALLER_STAGE=$AETHERSTREAM_INSTALLER_STAGE"
    echo "AETHERSTREAM_INSTALLER_STAGE_STARTED=$AETHERSTREAM_INSTALLER_STAGE_STARTED"
    echo "AETHERSTREAM_INSTALLER_EXIT=$rc"
    echo "AETHERSTREAM_INSTALL_LOG=$INSTALL_LOG"
    echo "AETHERSTREAM_BUILD_LOG=$BUILD_LOG"
    echo "AETHERSTREAM_EARLY_VERIFY_HANDOFF=PASS"
    echo "AETHERSTREAM_VERIFY=FAIL"
  } > "$tmp"
  mv -f "$tmp" "$VERIFY"
}

write_build_failure_verify() {
  local rc="$1"
  local log="$2"
  local tmp
  tmp="$(mktemp "${VERIFY}.tmp.XXXXXX")"
  {
    echo "AETHERSTREAM_VERSION=$VERSION"
    echo "AETHERSTREAM_INSTALLER_STAGE=$AETHERSTREAM_INSTALLER_STAGE"
    echo "AETHERSTREAM_INSTALLER_STAGE_STARTED=$AETHERSTREAM_INSTALLER_STAGE_STARTED"
    echo "AETHERSTREAM_INSTALLER_EXIT=$rc"
    echo "AETHERSTREAM_EARLY_VERIFY_HANDOFF=PASS"
    echo "AETHERSTREAM_INSTALL_LOG=$INSTALL_LOG"
    echo "AETHERSTREAM_BUILD_LOG=$log"
    echo "AETHERSTREAM_COMPILER_DETAIL_BEGIN"
    tail -n 200 "$log" 2>/dev/null || true
    echo "AETHERSTREAM_COMPILER_DETAIL_END"
    echo "AETHERSTREAM_VERIFY=FAIL"
  } > "$tmp"
  mv -f "$tmp" "$VERIFY"
}

write_final_success_verify() {
  local tmp
  [[ -n "$HOST_VERIFY_SNAPSHOT" && -f "$HOST_VERIFY_SNAPSHOT" ]] || return 1
  tmp="$(mktemp "${VERIFY}.tmp.XXXXXX")"
  {
    echo "AETHERSTREAM_VERSION=$VERSION"
    echo "AETHERSTREAM_INSTALLER_STAGE=complete"
    echo "AETHERSTREAM_INSTALLER_STAGE_STARTED=$AETHERSTREAM_INSTALLER_STAGE_STARTED"
    echo "AETHERSTREAM_INSTALL_LOG=$INSTALL_LOG"
    echo "AETHERSTREAM_BUILD_LOG=$BUILD_LOG"
    grep -v -E '^AETHERSTREAM_(VERSION|INSTALLER_STAGE|INSTALLER_STAGE_STARTED|INSTALL_LOG|BUILD_LOG)=' "$HOST_VERIFY_SNAPSHOT" || true
    echo "AETHERSTREAM_LINKED_OUTPUT_INSTALLER_QUIESCE=PASS:SUPERVISOR_STOPPED_BEFORE_PHYSICAL_RESOLUTION"
    if [[ -n "$LINKED_TOPOLOGY_SNAPSHOT" && -f "$LINKED_TOPOLOGY_SNAPSHOT" ]]; then
      cat "$LINKED_TOPOLOGY_SNAPSHOT"
    fi
  } > "$tmp"
  mv -f "$tmp" "$VERIFY"
}

capture_linked_topology_runtime() {
  local probe="$HOME/.local/bin/aetherstream-audiod"
  local raw="" status="" enabled="" attempt
  local sink_count member_count hdmi_routes bluetooth_routes extra_sinks extra_sources duplicate_routes orphan_links
  [[ -x "$probe" ]] || {
    echo "AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY_RUNTIME=FAIL:aetherstream-audiod-missing" >&2
    return 1
  }
  for attempt in $(seq 1 40); do
    raw="$($probe --verify-linked-output-topology 2>&1)" || true
    status="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY=//p' | tail -n1)"
    enabled="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_CONFIG_ENABLED=//p' | tail -n1)"
    if [[ "$status" == "PASS:EXACT_ONE_SINK_TWO_MEMBERS" ]]; then
      break
    fi
    # When the persisted policy is enabled, give the supervisor time to rebuild the exact graph.
    # A completely clean namespace is still acceptable after the wait if Bluetooth is unavailable.
    if [[ "$enabled" == "true" && "$status" == "PASS:CLEAN_NOT_ACTIVE" && $attempt -lt 40 ]]; then
      sleep 0.25
      continue
    fi
    if [[ "$status" == "PASS:CLEAN_NOT_ACTIVE" ]]; then
      break
    fi
    sleep 0.25
  done
  status="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY=//p' | tail -n1)"
  [[ "$status" == "PASS:EXACT_ONE_SINK_TWO_MEMBERS" || "$status" == "PASS:CLEAN_NOT_ACTIVE" ]] || {
    echo "AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY_RUNTIME=FAIL" >&2
    printf '%s\n' "$raw" >&2
    return 1
  }
  sink_count="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT=//p' | tail -n1)"
  member_count="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT=//p' | tail -n1)"
  hdmi_routes="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES=//p' | tail -n1)"
  bluetooth_routes="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES=//p' | tail -n1)"
  extra_sinks="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_EXTRANEOUS_VIRTUAL_SINKS=//p' | tail -n1)"
  extra_sources="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_EXTRANEOUS_VIRTUAL_SOURCES=//p' | tail -n1)"
  duplicate_routes="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_DUPLICATE_OUTPUT_ROUTES=//p' | tail -n1)"
  orphan_links="$(printf '%s\n' "$raw" | sed -n 's/^AETHERSTREAM_ORPHAN_LINKS=//p' | tail -n1)"
  LINKED_TOPOLOGY_SNAPSHOT="$(mktemp "$OUT_DIR/.AetherStream-v${VERSION}-LINKED-TOPOLOGY.XXXXXX")"
  {
    echo "AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY_RUNTIME=$status"
    if [[ "$status" == "PASS:EXACT_ONE_SINK_TWO_MEMBERS" ]]; then
      echo "AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT=PASS:${sink_count}"
      echo "AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT=PASS:${member_count}"
      echo "AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES=PASS:${hdmi_routes}"
      echo "AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES=PASS:${bluetooth_routes}"
    else
      echo "AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT=PASS:${sink_count}:CLEAN_NOT_ACTIVE"
      echo "AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT=PASS:${member_count}:CLEAN_NOT_ACTIVE"
      echo "AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES=PASS:${hdmi_routes}:CLEAN_NOT_ACTIVE"
      echo "AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES=PASS:${bluetooth_routes}:CLEAN_NOT_ACTIVE"
    fi
    echo "AETHERSTREAM_EXTRANEOUS_VIRTUAL_SINKS=PASS:${extra_sinks}"
    echo "AETHERSTREAM_EXTRANEOUS_VIRTUAL_SOURCES=PASS:${extra_sources}"
    echo "AETHERSTREAM_DUPLICATE_OUTPUT_ROUTES=PASS:${duplicate_routes}"
    echo "AETHERSTREAM_ORPHAN_LINKS=PASS:${orphan_links}"
  } > "$LINKED_TOPOLOGY_SNAPSHOT"
}

restore_and_finalize() {
  local rc=$?
  if [[ $rc -ne 0 && $VERIFY_FINALIZED -eq 0 ]]; then
    write_early_failure_verify "$rc" || true
  fi
  if [[ $rc -ne 0 && $WAS_AUDIOD_ACTIVE -eq 1 ]]; then
    systemctl --user start aetherstream-audiod.service >/dev/null 2>&1 || true
  fi
  if [[ $rc -ne 0 && $WAS_SUPERVISORD_ACTIVE -eq 1 ]]; then
    systemctl --user start aetherstream-supervisord.service >/dev/null 2>&1 || true
  fi
  trap - EXIT
  exit "$rc"
}
trap restore_and_finalize EXIT
set_stage "startup"

if [[ "${1:-}" == "--self-test-early-verify" ]]; then
  set_stage "self-test-forced-failure"
  false
fi

if [[ "${1:-}" == "--self-test-stage-sequence" ]]; then
  set_stage "dependency-check"
  set_stage "dependency-install"
  set_stage "release-build"
  trap - EXIT
  exit 0
fi

set_stage "dependency-check"
if command -v pacman >/dev/null 2>&1; then
  candidates=(
    base-devel rust cargo rustfmt clippy pkgconf
    pipewire pipewire-audio wireplumber
    gstreamer gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly gst-libav
    ffmpeg libsecret hidapi lv2 lilv libebur128 libsamplerate libsndfile libsoxr
    libmysofa rnnoise rubberband fftw speexdsp libbs2b
  )
  missing=()
  for package in "${candidates[@]}"; do
    if pacman -Q "$package" >/dev/null 2>&1; then
      continue
    fi
    pacman -Si "$package" >/dev/null 2>&1 && missing+=("$package") || true
  done
  set_stage "dependency-install"
  if ((${#missing[@]})); then
    sudo pacman -S --needed "${missing[@]}"
  fi
else
  set_stage "dependency-install"
fi

if ! command -v pactl >/dev/null 2>&1; then
  echo "AETHERSTREAM_DEPENDENCY=FAIL:pactl-missing" >&2
  exit 1
fi

set_stage "build-space-preflight"
check_build_space

if systemctl --user is-active --quiet aetherstream-supervisord.service 2>/dev/null; then
  WAS_SUPERVISORD_ACTIVE=1
  set_stage "stop-previous-supervisord"
  systemctl --user stop aetherstream-supervisord.service
fi
if systemctl --user is-active --quiet aetherstream-audiod.service 2>/dev/null; then
  WAS_AUDIOD_ACTIVE=1
  set_stage "stop-previous-audiod"
  systemctl --user stop aetherstream-audiod.service
fi

# Build first so the selected physical output can be resolved by this exact runtime and
# the Rust LADSPA cdylib can be installed before host runtime verification.
set_stage "release-build"
set +e
cargo build --workspace --release 2>&1 | tee "$BUILD_LOG"
BUILD_RC=${PIPESTATUS[0]}
set -e
if [[ $BUILD_RC -ne 0 ]]; then
  write_build_failure_verify "$BUILD_RC" "$BUILD_LOG"
  VERIFY_FINALIZED=1
  exit "$BUILD_RC"
fi

node_name() {
  wpctl inspect "$1" 2>/dev/null | awk -F= '/node.name/{v=$2; gsub(/^[[:space:]"]+|[[:space:]"]+$/, "", v); print v; exit}'
}

set_stage "linked-output-quiesce"
while read -r module_id module_name rest; do
  [[ "$module_name" == "module-combine-sink" && "$rest" == *"aetherstream_linked_hdmi_bluetooth"* ]] || continue
  pactl unload-module "$module_id" || true
done < <(pactl list modules short 2>/dev/null || true)
set_stage "linked-output-quiesce-wait"
for _ in $(seq 1 50); do
  DEFAULT_QUIESCE="$(node_name @DEFAULT_AUDIO_SINK@ || true)"
  [[ "$DEFAULT_QUIESCE" != "aetherstream_linked_hdmi_bluetooth" ]] && break
  sleep 0.1
done
DEFAULT_QUIESCE="$(node_name @DEFAULT_AUDIO_SINK@ || true)"
[[ "$DEFAULT_QUIESCE" != "aetherstream_linked_hdmi_bluetooth" ]] || {
  echo "AETHERSTREAM_LINKED_OUTPUT_QUIESCE=FAIL:linked-sink-remained-default" >&2
  exit 1
}

set_stage "physical-output-resolution"
PHYSICAL_NODE_NAME="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-node-name)"
PHYSICAL_CHANNELS="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-channels)"
PHYSICAL_LOADOUT_ID="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-loadout-id)"
PHYSICAL_CLASS="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-class)"
DEFAULT_BEFORE="$(node_name @DEFAULT_AUDIO_SINK@)"
[[ -n "$PHYSICAL_NODE_NAME" && -n "$PHYSICAL_LOADOUT_ID" && -n "$DEFAULT_BEFORE" ]] || {
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_DSP_INSTALL=FAIL:node-resolution" >&2
  exit 1
}
[[ "$PHYSICAL_NODE_NAME" == "$DEFAULT_BEFORE" ]] || {
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_DSP_INSTALL=FAIL:selected-output-mismatch-and-AetherStream-will-not-switch-outputs" >&2
  exit 1
}
[[ "$PHYSICAL_CHANNELS" == "2" ]] || {
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_DSP_INSTALL=FAIL:stereo-required-found-${PHYSICAL_CHANNELS}" >&2
  exit 1
}

LADSPA_DIR="$HOME/.local/lib/aetherstream/ladspa"
LADSPA_SO="$LADSPA_DIR/libaetherstream_hdmi3_dsp.so"
WP_DIR="$HOME/.config/wireplumber/wireplumber.conf.d"
WP_CONF="$WP_DIR/90-aetherstream-physical-output-internal-dsp.conf"
set_stage "dsp-plugin-install"
install -Dm755 "$CARGO_TARGET_DIR/release/libaetherstream_hdmi3_dsp.so" "$LADSPA_SO"
set_stage "wireplumber-config"
mkdir -p "$WP_DIR"
rm -f "$WP_DIR/90-aetherstream-hdmi3-internal-dsp.conf"
# Make the per-user LADSPA directory discoverable to future user-session PipeWire/WirePlumber restarts.
# The rendered graph also uses the exact absolute plugin path, so the current session does not rely on
# a daemon restart solely to learn a search path.
SESSION_LADSPA_PATH="$(systemctl --user show-environment 2>/dev/null | sed -n 's/^LADSPA_PATH=//p' | head -n1)"
MERGED_LADSPA_PATH="$(dedupe_colon_path "$LADSPA_DIR" "${LADSPA_PATH:-${SESSION_LADSPA_PATH:-}}")"
export LADSPA_PATH="$MERGED_LADSPA_PATH"
systemctl --user set-environment "LADSPA_PATH=$MERGED_LADSPA_PATH"
AETHERSTREAM_PRIMARY_NODE_NAME="$PHYSICAL_NODE_NAME" \
python3 - <<'PY'
import os
from pathlib import Path
src = Path("packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in").read_text()
def spa_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')
src = src.replace("__AETHERSTREAM_PRIMARY_NODE_NAME__", spa_escape(os.environ["AETHERSTREAM_PRIMARY_NODE_NAME"]))
path = Path.home() / ".config/wireplumber/wireplumber.conf.d/90-aetherstream-physical-output-internal-dsp.conf"
path.write_text(src)
PY

# WirePlumber static filter-graph rules are read only at startup. Restart once
# during installation, then prove the user-selected physical output node did not change.
set_stage "wireplumber-restart"
systemctl --user restart wireplumber.service
for _ in $(seq 1 100); do
  DEFAULT_AFTER="$(node_name @DEFAULT_AUDIO_SINK@ || true)"
  [[ "$DEFAULT_AFTER" == "$DEFAULT_BEFORE" ]] && break
  sleep 0.1
done
DEFAULT_AFTER="$(node_name @DEFAULT_AUDIO_SINK@ || true)"
[[ "$DEFAULT_AFTER" == "$DEFAULT_BEFORE" ]] || {
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_DSP_INSTALL=FAIL:default-output-changed" >&2
  exit 1
}

# Full host verification now runs with the internal HDMI3 graph actually active.
set_stage "host-verification"
set +e
bash scripts/verify-release.sh
VERIFY_RC=$?
set -e
if [[ $VERIFY_RC -ne 0 ]]; then
  VERIFY_FINALIZED=1
  exit "$VERIFY_RC"
fi
HOST_VERIFY_SNAPSHOT="$(mktemp "$OUT_DIR/.AetherStream-v${VERSION}-HOST-VERIFY.XXXXXX")"
cp -f "$VERIFY" "$HOST_VERIFY_SNAPSHOT"

set_stage "runtime-install"
install -Dm755 "$CARGO_TARGET_DIR/release/aetherstream" "$HOME/.local/bin/aetherstream"
install -Dm755 "$CARGO_TARGET_DIR/release/aetherstream"-supervisord "$HOME/.local/bin/aetherstream-supervisord"
install -Dm755 "$CARGO_TARGET_DIR/release/aetherstream-audiod" "$HOME/.local/bin/aetherstream-audiod"
install -Dm755 "$CARGO_TARGET_DIR/release/libaetherstream_hdmi3_dsp.so" "$LADSPA_SO"
install -Dm755 CONFIGURE-AUTH.sh "$HOME/.local/bin/aetherstream-configure-auth"
install -Dm644 packaging/systemd/aetherstream-supervisord.service "$HOME/.config/systemd/user/aetherstream-supervisord.service"
install -Dm644 packaging/systemd/aetherstream-audiod.service "$HOME/.config/systemd/user/aetherstream-audiod.service"
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/aetherstream.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=AetherStream
Comment=Unified Rust system audio, broadcast, DSP and A/V workstation for AetherForge
Exec=$HOME/.local/bin/aetherstream
Terminal=false
Categories=AudioVideo;Network;
StartupNotify=true
DESKTOP
set_stage "service-enable"
systemctl --user daemon-reload
systemctl --user enable --now aetherstream-audiod.service
systemctl --user enable --now aetherstream-supervisord.service
set_stage "linked-output-topology-runtime"
capture_linked_topology_runtime
update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
set_stage "complete"
write_final_success_verify
VERIFY_FINALIZED=1
rm -f "$HOST_VERIFY_SNAPSHOT" "$LINKED_TOPOLOGY_SNAPSHOT"
trap - EXIT
printf 'AETHERSTREAM_INSTALL=PASS\nAETHERSTREAM_VERSION=%s\nAETHERSTREAM_PHYSICAL_OUTPUT_NODE=%s\nAETHERSTREAM_PHYSICAL_OUTPUT_LOADOUT=%s\nAETHERSTREAM_PHYSICAL_OUTPUT_CLASS=%s\nAETHERSTREAM_EXTRA_OUTPUT_STREAMS=0\nVERIFY=%s\n' "$VERSION" "$PHYSICAL_NODE_NAME" "$PHYSICAL_LOADOUT_ID" "$PHYSICAL_CLASS" "$VERIFY"
nohup "$HOME/.local/bin/aetherstream" >/dev/null 2>&1 &
