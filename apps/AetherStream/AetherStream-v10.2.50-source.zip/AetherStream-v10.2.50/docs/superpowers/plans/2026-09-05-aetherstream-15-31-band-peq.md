# AetherStream 15–31 Band PEQ Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a persistent, live-auto-applied 15–31 band fully parametric EQ spanning 5 Hz–35 kHz to the existing one-node HDMI3 internal DSP path.

**Architecture:** Keep crossover/protection filters in `OutputDspProfile.filters` and add a dedicated `parametric_eq` bank with typed PEQ bands. Factory profiles start with 15 neutral bands; old profiles migrate legacy Peak/Notch/Shelf filters into the PEQ bank and are padded to 15. The existing `LiveDspPlan` compiles active PEQ bands into the same 64-section Rust DSP plan; bands above the current stream Nyquist are preserved but skipped until the device sample rate can represent them.

**Tech Stack:** Rust 2024 / Rust 1.98+, serde, egui 0.36, native `f32` RBJ biquads, existing shared-memory LADSPA/WirePlumber HDMI3 internal DSP.

**Spec:** Approved chat design: 15–31 fully parametric bands, 5 Hz–35 kHz, ±24 dB, Q 0.1–18, Peak/Notch/Low Shelf/High Shelf, live auto-apply, one HDMI3 output node, no virtual/extra output streams.

## Global Constraints

- Canonical version is `10.2.39`; do not overwrite v10.2.38.
- PEQ band count minimum 15, maximum 31.
- Configurable PEQ frequency range is 5 Hz through 35,000 Hz.
- PEQ gain range is -24 dB through +24 dB; Q range is 0.1 through 18.0.
- HDMI3 remains the sole physical output node; output default switching remains OFF.
- No virtual output, smart-filter pair, loopback output, or additional output stream may be introduced.
- Existing live auto-save/auto-apply behavior remains authoritative.

---

### Task 1: PEQ schema, migration, and validation

**Files:**
- Modify: `crates/aetherstream-core/src/output_dsp.rs`
- Modify: `crates/aetherstream-core/src/lib.rs`
- Modify: `crates/aetherstream-storage/src/db.rs`
- Test: `crates/aetherstream-core/tests/output_dsp_profile.rs`
- Test: `crates/aetherstream-storage/tests/output_dsp_store.rs`

**Interfaces:**
- Produces: `OutputParametricEqBand`, `ParametricEqBandKind`, `PEQ_MIN_BANDS`, `PEQ_MAX_BANDS`, `PEQ_MIN_FREQUENCY_HZ`, `PEQ_MAX_FREQUENCY_HZ`, `OutputDspProfile::normalize_parametric_eq()`.

- [ ] Write tests for factory 15-band defaults, 31-band ceiling, 5/35k configuration range, invalid band counts, and legacy filter migration.
- [ ] Run tests/source contract and confirm RED.
- [ ] Add typed PEQ schema plus serde-compatible defaults and normalization.
- [ ] Normalize loaded SQLite profiles before returning them.
- [ ] Re-run tests/source contract and confirm GREEN.

### Task 2: Realtime DSP compilation

**Files:**
- Modify: `crates/aetherstream-audio/src/live_dsp.rs`
- Modify: `crates/aetherstream-audio/src/output_dsp.rs`
- Test: `crates/aetherstream-audio/tests/live_output_dsp.rs`

**Interfaces:**
- Consumes: normalized `OutputDspProfile.parametric_eq`.
- Produces: PEQ biquad sections in the existing `LiveDspPlan`; no second processor or graph.

- [ ] Write tests for 15 and 31 active PEQ bands and Nyquist-safe skipping.
- [ ] Confirm RED.
- [ ] Compile Peak/Notch/Low Shelf/High Shelf bands into the existing plan.
- [ ] Preserve configured >Nyquist bands but omit their sections at unsupported sample rates.
- [ ] Confirm GREEN and existing response contracts remain present.

### Task 3: DragonGlass setup editor

**Files:**
- Modify: `crates/aetherstream-ui/src/app.rs`
- Test: source contract `scripts/check-v10.2.39-peq.py`

**Interfaces:**
- Consumes: typed PEQ bank.
- Produces: 15/21/25/31 presets, +Band/-Band controls, per-band Enable/Type/Frequency/Gain/Q controls, and live response graph; changes use existing auto-apply action.

- [ ] Add RED source assertions for all controls and ranges.
- [ ] Replace legacy “+ Parametric band” path with dedicated PEQ card.
- [ ] Add logarithmic 5–35k controls and band-count controls constrained to 15–31.
- [ ] Add response graph rendering without a new plotting dependency.
- [ ] Confirm source contract GREEN.

### Task 4: Release/verification packaging

**Files:**
- Modify: workspace/version scripts and README from `10.2.38` to `10.2.39`.
- Create: `scripts/check-v10.2.39-peq.py`.
- Modify: `scripts/verify-release.sh`.
- Create canonical v10.2.39 source, installer, SHA256, package verification, and release manifest artifacts.

**Interfaces:**
- Produces host gates `AETHERSTREAM_PEQ_15_31_BANDS`, `AETHERSTREAM_PEQ_5HZ_35KHZ`, `AETHERSTREAM_PEQ_AUTO_APPLY`, plus preserved one-node HDMI3 gates.

- [ ] Add verifier/source gates and bump version everywhere canonical.
- [ ] Run full static suite including early VERIFY and awk regressions.
- [ ] Build source ZIP and self-contained installer.
- [ ] Re-extract installer and prove source byte identity.
- [ ] Generate SHA256/package verification/release manifest.
