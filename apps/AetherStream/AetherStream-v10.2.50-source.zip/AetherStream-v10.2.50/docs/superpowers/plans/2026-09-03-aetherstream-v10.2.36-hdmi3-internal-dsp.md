# AetherStream v10.2.36 HDMI3 Internal DSP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the HDMI3 smart-filter stream pair with one in-place WirePlumber internal filter graph using the Rust AetherStream DSP and zero added output nodes.

**Architecture:** A Rust LADSPA cdylib hosts `LiveDspProcessor` inside HDMI3's WirePlumber internal filter graph. `aetherstream-audiod` compiles live profiles and publishes fixed-layout atomic shared state; it no longer creates output PipeWire streams.

**Tech Stack:** Rust 1.98, pipewire-rs 0.10.1, WirePlumber 0.5 `node.filter-graph.rules`, LADSPA C ABI, atomics/shared mmap, Tokio, egui.

**Spec:** `docs/superpowers/specs/2026-09-03-aetherstream-hdmi3-internal-dsp-design.md`

## Global Constraints

- Canonical version is 10.2.36.
- HDMI3 remains the physical/default sink.
- AetherStream adds zero output sink/stream nodes.
- No output `wpctl set-default`.
- No smart-filter pair or virtual output.
- Rust DSP and live auto-apply remain authoritative.
- ForgeHX/system-mic behavior remains unchanged.

---

### Task 1: Internal-output regression contract

**Files:**
- Create: `scripts/check-hdmi3-internal-dsp.py`
- Modify: `scripts/verify-release.sh`

**Interfaces:**
- Consumes: current HDMI3 output/runtime source.
- Produces: static gate `AETHERSTREAM_HDMI3_INTERNAL_DSP_CONTRACT`.

- [ ] Write a static regression checker that fails while `run_pipewire`, smart-filter names/properties, or AetherStream output stream constructors remain.
- [ ] Run it against v10.2.35 and verify RED.
- [ ] Keep the gate in the final release verifier.

### Task 2: Shared realtime plan block

**Files:**
- Create: `crates/aetherstream-audio/src/shared_output_dsp.rs`
- Modify: `crates/aetherstream-audio/src/lib.rs`
- Test: `crates/aetherstream-audio/tests/shared_output_dsp.rs`

**Interfaces:**
- Produces: `SharedOutputDspWriter::open_or_create`, `SharedOutputDspReader::try_open`, `publish`, `snapshot`, and `OUTPUT_DSP_SHARED_FILE`.

- [ ] Add tests for plan round-trip, generation changes, and rejection of invalid magic/version.
- [ ] Implement fixed-layout atomic shared state with no locks in `snapshot`.
- [ ] Keep all file/mmap setup outside the audio callback.

### Task 3: Rust in-process LADSPA DSP

**Files:**
- Create: `crates/aetherstream-dsp-ladspa/Cargo.toml`
- Create: `crates/aetherstream-dsp-ladspa/src/lib.rs`
- Modify: `Cargo.toml`

**Interfaces:**
- Consumes: shared plan snapshot and `LiveDspProcessor`.
- Produces: `libaetherstream_hdmi3_dsp.so`, LADSPA label `aetherstream_hdmi3_dsp_stereo`.

- [ ] Add ABI/static tests for four audio ports and the exported descriptor symbol.
- [ ] Implement stereo audio input/output ports with unity fallback.
- [ ] Map shared state on a non-RT helper thread; run callback uses only atomics and DSP math.
- [ ] Preserve smoothing when generation changes.

### Task 4: Remove output streams from audiod

**Files:**
- Modify: `apps/aetherstream-audiod/src/main.rs`
- Modify: `apps/aetherstream-audiod/Cargo.toml`

**Interfaces:**
- Consumes: HDMI3 resolver and shared writer.
- Produces: profile compilation/publication over existing `output-dsp.sock` plus current mic runtime.

- [ ] Remove capture/playback output stream pair and sample FIFO.
- [ ] Initialize/publish a flat HDMI3 plan through shared state.
- [ ] Make `OutputDspRuntimeRequest::Apply` publish the compiled plan and return generation.
- [ ] Add `--print-hdmi3-node-name` helper for installer configuration.

### Task 5: WirePlumber internal graph installation

**Files:**
- Create: `packaging/wireplumber/90-aetherstream-hdmi3-internal-dsp.conf.in`
- Modify: `INSTALL-AETHERSTREAM.sh`

**Interfaces:**
- Consumes: exact HDMI3 node name and installed LADSPA `.so` path.
- Produces: user WirePlumber `node.filter-graph.rules` fragment.

- [ ] Install the cdylib under `/usr/lib/ladspa`.
- [ ] Render the fragment with the exact escaped HDMI3 node name and the canonical LADSPA plugin name from `/usr/lib/ladspa`.
- [ ] Restart WirePlumber only during install/config activation; never from runtime controls.
- [ ] Restart AetherStream services after WirePlumber is back.

### Task 6: Runtime verification and release

**Files:**
- Modify: `scripts/smoke-live-output-dsp-runtime.sh`
- Modify: `scripts/check-live-output-dsp.py`
- Modify: `scripts/check-hdmi3-physical-output.py`
- Modify: `scripts/check-v10.2.36-source.py`
- Modify: `README.md`

**Interfaces:**
- Produces host gates `AETHERSTREAM_HDMI3_INTERNAL_DSP`, `AETHERSTREAM_EXTRA_OUTPUT_STREAMS`, `AETHERSTREAM_SMART_FILTER_NODES`, and final verify.

- [ ] Require zero AetherStream output sinks/nodes and no smart-filter pair.
- [ ] Require HDMI3 default node name unchanged while internal DSP is active.
- [ ] Require plugin active marker and live shared generation update.
- [ ] Preserve Bass/Clarity/RT/system-mic/ForgeHX gates.
- [ ] Bump all release-facing version references to 10.2.36 and package one canonical artifact set.
