# AetherStream v10.2.43 User-Session DSP Plugin Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove root/system-wide LADSPA installation and load the existing Rust DSP plugin entirely from the user session without adding output nodes or switching outputs.

**Architecture:** Install `libaetherstream_hdmi3_dsp.so` under `~/.local/lib/aetherstream/ladspa`. Render the WirePlumber internal-filter graph with the exact absolute plugin path and also publish the user LADSPA directory through the systemd user manager environment for future PipeWire/WirePlumber restarts. Keep the existing internal filter graph, physical-output selection, Bluetooth/WONDERBOOM profiles, and zero-extra-node policy unchanged.

**Tech Stack:** Rust, PipeWire, WirePlumber 0.5 internal filter graphs, LADSPA, Bash, Python static/runtime verification.

**Spec:** Approved in chat: v10.2.43 user-session DSP install correction.

## Global Constraints

- Canonical version: 10.2.43.
- No `sudo` or root install for the DSP plugin.
- User plugin directory: `$HOME/.local/lib/aetherstream/ladspa`.
- Selected physical sink remains the only output node.
- Output default switching remains OFF.
- User-visible virtual outputs = 0; extra output streams = 0; smart-filter nodes = 0.
- Preserve PEQ 15–31 bands / 5 Hz–35 kHz, Bluetooth speaker classes, WONDERBOOM 4 360° profile, and ForgeHX bridge.

---

### Task 1: User-session plugin install contract
- [ ] Add a failing source/runtime contract rejecting `/usr/lib/ladspa` and `sudo install` for the DSP plugin.
- [ ] Require the user LADSPA directory and exact rendered plugin path.
- [ ] Make the contract pass with the smallest installer/config change.

### Task 2: Host verification gates
- [ ] Add `AETHERSTREAM_DSP_PLUGIN_USER_INSTALL`, `AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED`, and `AETHERSTREAM_LADSPA_PATH` gates.
- [ ] Verify the installed plugin file is readable/executable from the user directory and the rendered WirePlumber config references it.

### Task 3: Release/version/package
- [ ] Bump all canonical version references to 10.2.43.
- [ ] Run all static/source/verifier self-tests and early-VERIFY runtime tests.
- [ ] Build source ZIP and self-contained installer.
- [ ] Re-extract and byte-compare payload.
- [ ] Generate package verify, SHA-256, and release manifest.
