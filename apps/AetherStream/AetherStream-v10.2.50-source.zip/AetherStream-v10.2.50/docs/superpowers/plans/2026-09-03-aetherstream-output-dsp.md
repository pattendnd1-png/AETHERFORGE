# AetherStream Native Output DSP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver AetherStream v10.2.28 with a native Rust full-range per-output DSP engine and DragonGlass editor.

**Architecture:** Shared serializable profile types are defined in `aetherstream-core`; real-time DSP math and state live in `aetherstream-audio`; the control model stores active output DSP state; the egui Settings surface edits the same profile schema. AetherStream keeps authoritative PipeWire/system-output ownership and does not require a virtual-device chain.

**Tech Stack:** Rust 2024 / Rust 1.98+, serde, egui 0.36/eframe 0.36, existing typed IPC/control stack, native `f32` biquad DSP, existing AetherStream PipeWire ownership boundary.

**Spec:** `docs/superpowers/specs/2026-09-03-aetherstream-output-dsp-design.md`

## Global Constraints

- Advance canonically from AetherStream v10.2.27 to v10.2.28; never overwrite v10.2.27.
- Rust owns profile logic and DSP sample processing.
- No mandatory virtual sink/source chain.
- Preserve `SYSTEM_VOLUME_OWNER=AETHERSTREAM`, typed Unix-socket ownership and `@DEFAULT_AUDIO_SINK@` behavior.
- Use DragonGlass/AetherForge system theme tokens, not a separate DSP theme.
- Generate `AetherStream-v10.2.28-VERIFY.txt` on the target host.

---

### Task 1: Shared output-DSP profile schema and factory device presets

**Files:**
- Create: `crates/aetherstream-core/src/output_dsp.rs`
- Modify: `crates/aetherstream-core/src/lib.rs`
- Test: `crates/aetherstream-core/tests/output_dsp_profile.rs`

**Interfaces:**
- Produces `OutputDeviceClass`, `OutputFilterKind`, `OutputFilter`, `OutputEnhancement`, `OutputLimiter`, `OutputDspProfile`, `OutputDspProfileError` and `OutputDspProfile::factory`/`validate`.

- [ ] Step 1: write tests that assert every device class has a valid factory profile and that invalid cutoff/Q/gain values reject.
- [ ] Step 2: run the focused test and verify RED.
- [ ] Step 3: implement the minimal schema, validation and factory profiles.
- [ ] Step 4: run focused tests and verify GREEN.

### Task 2: Allocation-free native Rust sample processor

**Files:**
- Create: `crates/aetherstream-audio/src/output_dsp.rs`
- Modify: `crates/aetherstream-audio/src/lib.rs`
- Test: `crates/aetherstream-audio/tests/output_dsp_processor.rs`

**Interfaces:**
- Consumes `OutputDspProfile`.
- Produces `OutputDspProcessor::new`, `reconfigure`, and `process_interleaved`.

- [ ] Step 1: write signal tests for HPF attenuation, LPF attenuation, band-pass/mid-pass behavior, bass boost, clarity boost, limiter ceiling and channel isolation.
- [ ] Step 2: run focused tests and verify RED.
- [ ] Step 3: implement RBJ biquads, cascaded slopes and processing chain.
- [ ] Step 4: run focused tests and verify GREEN.

### Task 3: Per-device control state, persistence, and actions

**Files:**
- Modify: `crates/aetherstream-core/src/action.rs`
- Modify: `crates/aetherstream-control/src/state.rs`
- Modify: `crates/aetherstream-control/src/router.rs`
- Modify: `crates/aetherstream-storage/src/db.rs`
- Modify: `crates/aetherstream-storage/src/migrations.rs`
- Modify: `apps/aetherstream-supervisord/src/main.rs`
- Test: `crates/aetherstream-control/tests/output_dsp_state.rs`
- Test: `crates/aetherstream-storage/tests/output_dsp_store.rs`

**Interfaces:**
- Produces `AetherStreamAction::OutputDspApply` and `AetherStreamAction::OutputDspBypass`.
- Stores `OutputDspState` keyed by logical physical device id and persists profiles in SQLite for reconnect/restart restore.

- [ ] Step 1: add failing routing/state/storage tests.
- [ ] Step 2: verify RED.
- [ ] Step 3: implement action routing, persistent state projection and startup restore.
- [ ] Step 4: verify GREEN.

### Task 4: DragonGlass DSP editor

**Files:**
- Modify: `crates/aetherstream-ui/Cargo.toml`
- Modify: `crates/aetherstream-ui/src/theme.rs`
- Modify: `crates/aetherstream-ui/src/app.rs`
- Test: `crates/aetherstream-ui` unit tests and source contract.

**Interfaces:**
- Consumes shared DSP profiles and emits `OutputDspApply`/`OutputDspBypass`.

- [ ] Step 1: add failing UI/model tests for the full device-class list and DSP editor defaults.
- [ ] Step 2: verify RED.
- [ ] Step 3: add compact DragonGlass profile/filter/bass/clarity/headroom/limiter controls.
- [ ] Step 4: verify GREEN.

### Task 5: Canonical v10.2.28 release gates and package

**Files:**
- Modify version-bearing source/installer/README files from 10.2.27 to 10.2.28.
- Create/update: `scripts/check-v10.2.28-source.py`
- Modify: `scripts/verify-release.sh`
- Create package artifacts in `/mnt/data`.

**Interfaces:**
- Produces v10.2.28 source ZIP, one-line installer, SHA-256 file and package verification file.

- [ ] Step 1: add source-contract checks for native output DSP and DragonGlass DSP UI.
- [ ] Step 2: run fmt, clippy, tests, build and source contract.
- [ ] Step 3: package canonical artifacts and verify embedded payload/checksums.
- [ ] Step 4: run final static/package verification and record results.
