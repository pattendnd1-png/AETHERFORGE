# HDMI3 Physical Loadout Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Bind AetherStream DSP to the physical HDMI3 route without changing the desktop default output.

**Architecture:** Reuse the existing Rust `LiveDspProcessor` inside a non-targetable WirePlumber smart-filter pair associated with HDMI3 by stable `node.name`. Keep microphone/ForgeHX ownership unchanged and migrate saved output state to canonical loadout key `hdmi3`.

**Tech Stack:** Rust, pipewire-rs 0.10.1, WirePlumber smart-filter policy, rtrb, Tokio, SQLite, egui.

**Spec:** `docs/superpowers/specs/2026-09-03-aetherstream-hdmi3-physical-loadout-design.md`

## Global Constraints
- Canonical release is v10.2.34.
- No output `wpctl set-default`.
- No `aetherstream.dsp.sink` default takeover.
- HDMI3 physical node remains the desktop-selected output.
- No PipeWire or WirePlumber restart.
- Existing Bass/Clarity/Gaming/live-auto-apply behavior remains mandatory.

---

### Task 1: HDMI3 identity and filter binding
- [x] Add `HDMI3_LOADOUT_ID = "hdmi3"`.
- [x] Resolve HDMI3 from stable physical node metadata and reject AetherStream nodes.
- [x] Replace the old virtual-sink output properties with non-targetable smart-filter properties and stable target metadata.
- [x] Remove output default/volume takeover.
- [x] Add HDMI3 resolver/parser unit tests.

### Task 2: Loadout persistence and UI
- [x] Default the DragonGlass DSP editor to the `hdmi3` loadout.
- [x] Present the target as physical HDMI3 with no output switching.
- [x] Migrate an existing saved profile into `hdmi3` when the canonical loadout is missing.
- [x] Add migration regression tests.

### Task 3: Runtime and release gates
- [x] Rewrite output/system smoke scripts to assert the physical default sink name never changes.
- [x] Add the HDMI3 physical-output static contract.
- [x] Add six explicit release outputs for switching, target, loadout, selectable virtual output count, auto-apply, and reconnect behavior.
- [ ] Run native Rust fmt/Clippy/tests/build and live PipeWire runtime smoke on the AetherForge host.
