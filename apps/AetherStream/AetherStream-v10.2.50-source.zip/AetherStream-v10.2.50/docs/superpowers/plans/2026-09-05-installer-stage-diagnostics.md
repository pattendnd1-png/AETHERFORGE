# Installer Stage Diagnostics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the AetherStream installer continuously report its real stage and preserve actionable install/build logs even if installation fails before host verification.

**Architecture:** Keep audio/runtime behavior unchanged. Centralize installer stage transitions through one helper that atomically rewrites the VERIFY handoff, append installer output to a dedicated INSTALL log, and filter Arch dependencies so only missing packages reach pacman.

**Tech Stack:** Bash, Python static regression checks, Arch pacman, existing AetherStream verifier.

**Spec:** Approved in chat for v10.2.43.

## Global Constraints
- Canonical version is 10.2.43.
- Preserve WONDERBOOM 4 360° Bluetooth profile and 15–31 band 5 Hz–35 kHz PEQ.
- Preserve one physical output node, zero virtual outputs, zero extra output streams, and output auto-switching OFF.
- VERIFY must exist from startup and update at every installer stage.
- Preserve BUILD log and add INSTALL log in ~/Downloads.

---

### Task 1: Installer stage heartbeat
- [ ] Add failing static/runtime regression for live stage rewrites.
- [ ] Implement `set_stage()` atomic VERIFY update with timestamp.
- [ ] Route every installer stage transition through `set_stage()`.
- [ ] Verify forced stage failure records the actual stage.

### Task 2: Dependency filtering and install log
- [ ] Add failing regression requiring `pacman -Q` skip for installed packages.
- [ ] Add INSTALL log capture from installer startup.
- [ ] Install only missing packages; preserve package availability checks.
- [ ] Verify log and dependency contracts.

### Task 3: Release packaging
- [ ] Bump all canonical version references to 10.2.43.
- [ ] Update README/source checker/verifier gates.
- [ ] Run full static suite and installer self-tests.
- [ ] Package source/installer, re-extract, compare byte identity, generate SHA/manifest/package verify.
