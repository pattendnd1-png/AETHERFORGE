# AetherStream v10.2.40 Bluetooth Speakers Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add first-class Bluetooth-speaker physical-output loadouts, including a dedicated Ultimate Ears WONDERBOOM 4 360° profile, while correcting the v10.2.39 PEQ build failure and preserving one real output node.

**Architecture:** The currently selected PipeWire physical sink remains authoritative. AetherStream identifies HDMI and BlueZ sinks, selects a persistent DSP loadout, and supplies the existing Rust DSP to a WirePlumber internal filter graph without creating or selecting another sink. Bluetooth loadouts prefer the stable BlueZ address.

**Tech Stack:** Rust, PipeWire/BlueZ metadata, WirePlumber internal filter graphs, LADSPA Rust cdylib, egui 0.36, SQLite persistence, Bash/Python release gates.

**Spec:** Approved in chat: Bluetooth speakers of all kinds; Ultimate Ears WONDERBOOM 4 classified as a dedicated 360° Bluetooth speaker; no output switching, virtual output, or alternate output stream; retain 15–31 band PEQ from 5 Hz–35 kHz.

## Global Constraints

- Canonical release version is 10.2.40.
- Never call output `wpctl set-default`.
- User-visible virtual outputs = 0.
- Extra output streams = 0.
- Smart-filter nodes = 0.
- Current physical output remains the selected/default PipeWire sink.
- PEQ remains 15–31 bands, 5 Hz–35 kHz.
- ForgeHX/system-microphone ownership is unchanged.

---

### Task 1: Correct v10.2.39 PEQ build path

**Files:**
- Modify: `crates/aetherstream-ui/src/theme.rs`
- Modify: `crates/aetherstream-ui/src/app.rs`
- Modify: `INSTALL-AETHERSTREAM.sh`
- Test: `scripts/check-v10.2.40-build-hardening.py`

**Interfaces:**
- Consumes: DragonGlass RGBA theme tokens and egui painter calls.
- Produces: `Color32` painter colors and compiler-diagnostic VERIFY handoff.

- [x] Add a failing static regression for raw tuple colors and missing build diagnostics.
- [x] Expose `theme::color` crate-locally and convert PEQ painter colors.
- [x] Capture Cargo release-build output and include compiler tail in early VERIFY failure.
- [x] Verify `AETHERSTREAM_PEQ_COLOR32_BUILD_GUARD=PASS` and `AETHERSTREAM_BUILD_DIAGNOSTICS=PASS`.

### Task 2: Add Bluetooth speaker taxonomy and WONDERBOOM 4

**Files:**
- Modify: `crates/aetherstream-core/src/output_dsp.rs`
- Modify: `crates/aetherstream-core/src/lib.rs`
- Test: `crates/aetherstream-core/tests/output_dsp_profile.rs`
- Test: `scripts/check-v10.2.40-bluetooth-speakers.py`

**Interfaces:**
- Consumes: PipeWire/BlueZ display name and stable address.
- Produces: `OutputDeviceClass::for_bluetooth_speaker_name`, `bluetooth_loadout_id`, WONDERBOOM 4 factory profile.

- [x] Add Bluetooth speaker classes and dedicated `UltimateEarsWonderboom4`.
- [x] Prefer BlueZ address for persistent loadout identity.
- [x] Add factory profiles and dedicated 360° WONDERBOOM 4 classification.
- [x] Add regression tests for classification and stable identity.

### Task 3: Follow selected physical output without switching it

**Files:**
- Modify: `apps/aetherstream-audiod/src/main.rs`
- Modify: `apps/aetherstream-supervisord/src/main.rs`
- Test: audiod/supervisord unit tests

**Interfaces:**
- Consumes: `wpctl inspect @DEFAULT_AUDIO_SINK@` metadata.
- Produces: physical node name, loadout ID, device class, Bluetooth address/codec; profile synchronization for the selected device.

- [x] Resolve the selected physical sink instead of forcing HDMI3.
- [x] Reject AetherStream-created sink names.
- [x] Add physical-output identity CLI fields.
- [x] Add a supervisor watcher that updates the active loadout without `set-default`.
- [x] Preserve HDMI3 canonical compatibility.

### Task 4: Attach DSP internally to physical/BlueZ nodes

**Files:**
- Create: `packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in`
- Modify: `crates/aetherstream-dsp-ladspa/src/lib.rs`
- Modify: `INSTALL-AETHERSTREAM.sh`
- Modify: `scripts/smoke-live-output-dsp-runtime.sh`
- Test: `scripts/check-physical-output-internal-dsp.py`

**Interfaces:**
- Consumes: primary physical node name plus `bluez_output.*` nodes.
- Produces: in-place internal Rust DSP with no additional PipeWire output node.

- [x] Match selected primary physical output and BlueZ output nodes.
- [x] Keep LADSPA ABI/library filename stable while generalizing internal runtime naming.
- [x] Verify default output is unchanged before/after install/runtime.
- [x] Require zero virtual/extra/smart-filter nodes and one selected physical node.

### Task 5: Generalize host verification and package

**Files:**
- Modify: `scripts/verify-release.sh`
- Modify: `README.md`
- Create: canonical v10.2.40 source/install/package verification/checksum/manifest artifacts.

**Interfaces:**
- Consumes: static contracts, Rust tests, actual selected physical output.
- Produces: generic physical-output host gates plus Bluetooth/WONDERBOOM gates and failure diagnostics.

- [x] Make runtime output gates generic; retain HDMI3 compatibility fields only as conditional/static compatibility.
- [x] Add Bluetooth/WONDERBOOM/build-hardening gates.
- [ ] Run final static source suite after documentation.
- [ ] Build exact source archive and self-contained installer.
- [ ] Re-extract installer and compare source byte-for-byte.
- [ ] Generate and verify SHA/package manifest artifacts.
