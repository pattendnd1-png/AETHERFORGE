# AetherStream v10.2.31 Live Output DSP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Route live system output through the native Rust DSP and auto-apply validated UI changes while controls move.

**Architecture:** Compile `OutputDspProfile` into fixed, allocation-free live plans on the control thread. `aetherstream-audiod` publishes a managed PipeWire sink, processes captured F32 samples with a smooth real-time processor, and forwards them to the original physical sink. The supervisor persists profiles and forwards them over a typed Unix socket.

**Tech Stack:** Rust 2024/Rust 1.98+, PipeWire 0.10.1, rtrb 0.4.0, Tokio Unix sockets, postcard IPC, egui/eframe DragonGlass UI.

**Spec:** `docs/superpowers/specs/2026-09-03-aetherstream-live-output-dsp-design.md`

## Global Constraints
- Advance the canonical release from 10.2.30 to 10.2.31; never overwrite 10.2.30.
- Keep AetherStream as system-volume and PipeWire DSP owner.
- Do not require manual virtual-device chaining.
- The real-time callback must not allocate or acquire a blocking mutex.
- Every valid DSP edit auto-applies and auto-persists.
- Bass and clarity must have measured frequency-response regression tests.

---

### Task 1: Fixed live DSP plan and smooth processor
**Files:** create `crates/aetherstream-audio/src/live_dsp.rs`; modify `crates/aetherstream-audio/src/lib.rs`; test `crates/aetherstream-audio/tests/live_output_dsp.rs`.
**Interfaces:** `LiveDspPlan::compile(&OutputDspProfile, f32, usize)` and `LiveDspProcessor::{new,begin_transition,process_sample}`.
- [ ] Write tests for measured bass/clarity gain, bypass unity, and smoothed live transition.
- [ ] Verify the feature-contract test fails before implementation.
- [ ] Implement fixed plan compilation and crossfaded processing.
- [ ] Re-run static/TDD contract and leave host `cargo test` to the target verifier.

### Task 2: Typed audiod control socket
**Files:** create `crates/aetherstream-core/src/output_dsp_runtime.rs`; modify core exports; create `crates/aetherstream-audio/src/control.rs`; test runtime protocol round-trip.
**Interfaces:** `OutputDspRuntimeRequest::Apply`, `OutputDspRuntimeResponse::{Applied,Rejected,Status}`.
- [ ] Write protocol tests first.
- [ ] Implement typed request/response and socket-path helper.
- [ ] Add supervisor client forwarding only after persistence succeeds.

### Task 3: PipeWire live daemon
**Files:** create `apps/aetherstream-audiod/{Cargo.toml,src/main.rs}`; modify workspace and installer.
**Interfaces:** managed sink `aetherstream.dsp.sink`; physical sink resolved before default switch; F32LE capture → Rust DSP → physical playback.
- [ ] Add static contract that requires capture/playback streams, `Audio/Sink`, target physical node, RT process flags, and rtrb queues.
- [ ] Implement audiod with fixed-plan queue and sample FIFO.
- [ ] Restore the physical default on clean shutdown.

### Task 4: Auto-apply DragonGlass editor
**Files:** modify `crates/aetherstream-ui/src/app.rs`; tests in same module.
**Interfaces:** profile changes produce `OutputDspApply` automatically when valid and device id is nonempty.
- [ ] Add failing helper-level tests for bass and clarity edit auto-dispatch.
- [ ] Remove manual Apply requirement and show `LIVE • AUTO-APPLY` state.
- [ ] Keep reset, bypass, Gaming Mode, and all filter controls live.

### Task 5: Supervisor live forwarding and release gate
**Files:** create `apps/aetherstream-supervisord/src/output_dsp_runtime.rs`; modify main; update `scripts/verify-release.sh`, source checker, README, installer.
**Interfaces:** persisted profile → audiod Apply → state projection; runtime failure rejects action without falsifying persisted/live state.
- [ ] Add static/runtime forwarding contract first.
- [ ] Wire supervisor after DB save.
- [ ] Add v10.2.31 host gates: LIVE_PIPEWIRE_DSP, DSP_AUTO_APPLY, BASS_RESPONSE, CLARITY_RESPONSE, DSP_RT_SAFETY.
- [ ] Package source, installer, SHA256 and package verification.
