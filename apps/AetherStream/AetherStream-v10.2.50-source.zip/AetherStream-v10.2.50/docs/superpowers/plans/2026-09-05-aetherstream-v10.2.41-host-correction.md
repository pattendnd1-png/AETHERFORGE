# AetherStream v10.2.43 Host Correction Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Correct the Rust 1.98 Bluetooth classifier Clippy failure and PEQ 35 kHz floating-point boundary failure without changing the physical-output architecture.

**Architecture:** Preserve the selected real HDMI/Bluetooth PipeWire output and the existing internal Rust DSP. Fix only the Bluetooth class predicate and the shared PEQ frequency generator/normalization boundary behavior.

**Tech Stack:** Rust, Cargo, PipeWire/WirePlumber, Python static gates, Bash host verifier.

**Spec:** User-approved AetherStream physical-output + 15–31-band PEQ architecture already present in the repository.

## Global Constraints

- Canonical release version is 10.2.43.
- PEQ remains 15–31 bands, 5 Hz–35 kHz, -24 to +24 dB, Q 0.1–18.0.
- Bluetooth WONDERBOOM 4 remains a dedicated 360° speaker profile.
- Output default switching stays OFF.
- User-visible virtual outputs, extra output streams, and smart-filter nodes stay 0.

### Task 1: Rust 1.98 Bluetooth classifier correction
- [x] Reproduce source pattern flagged by Clippy.
- [x] Replace match-like boolean match with `matches!`.
- [x] Add static host regression gate.

### Task 2: Exact PEQ boundaries
- [x] Pin generated first/last PEQ frequencies to 5.0 / 35,000.0 Hz.
- [x] Route band-count expansion through the same boundary-safe generator.
- [x] Preserve normalization of legacy tiny overshoots.
- [x] Add Rust regression tests for 15/21/25/31 sizes.

### Task 3: Verification and release
- [x] Add `AETHERSTREAM_CLIPPY_MATCHES_MACRO` and `AETHERSTREAM_PEQ_EXACT_BOUNDARIES` host gates.
- [ ] Run complete static checker suite.
- [ ] Package source, self-contained installer, SHA-256 manifest, package verification, and release manifest.
