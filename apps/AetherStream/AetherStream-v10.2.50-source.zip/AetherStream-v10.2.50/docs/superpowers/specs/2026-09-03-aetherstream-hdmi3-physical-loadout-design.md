# AetherStream HDMI3 Physical Loadout Design

## Goal
Keep HDMI3 as the real desktop-selected physical output while applying the existing live Rust DSP transparently, with no AetherStream default-sink switching and no user-selected virtual DSP sink.

## Ownership
WirePlumber keeps normal desktop default-node ownership. AetherStream owns DSP parameters and a transparent smart filter associated with the stable HDMI3 physical `node.name`. FLOW 8/system-volume continues to target `@DEFAULT_AUDIO_SINK@`.

## Routing
Applications continue to target HDMI3. The AetherStream filter pair is marked `filter.smart=true`, uses a common `node.link-group`, is not directly targetable, and declares HDMI3 as `filter.smart.target`. AetherStream never invokes output `wpctl set-default` and never marks its output filter `node.virtual=true`.

## HDMI3 identity
The canonical loadout key is `hdmi3`. Runtime resolution accepts an exact `AETHERSTREAM_HDMI3_NODE_NAME` override or detects common third-HDMI route names (`HDMI / DisplayPort 3`, `hdmi-stereo-extra2`, `hdmi-output-2`). If HDMI3 is unavailable, audiod reports failure and does not switch to another output.

## Persistence
Existing output DSP profiles are preserved. At supervisor startup, if `hdmi3` does not yet exist, the previous `@DEFAULT_AUDIO_SINK@` profile or first saved profile is copied into `hdmi3`; otherwise a Desktop Speaker factory profile is created. `hdmi3` becomes the active output loadout.

## Verification
Static gates reject the legacy `aetherstream.dsp.sink`, output `node.virtual=true`, or output default switching. Runtime smoke verifies the default sink `node.name` is unchanged while audiod runs. Bass/Clarity/Gaming/RT tests remain mandatory.
