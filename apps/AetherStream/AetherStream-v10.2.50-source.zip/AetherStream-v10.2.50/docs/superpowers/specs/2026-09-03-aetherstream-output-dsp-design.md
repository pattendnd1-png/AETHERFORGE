# AetherStream Native Output DSP Design

## Goal
Add a native Rust, per-output DSP subsystem for physical speakers, headphones, IEMs and earbuds, with high-pass, band/mid-pass and low-pass filtering, parametric EQ, bass enhancement, clarity enhancement, headroom and limiting, plus a DragonGlass editor that matches AetherForge.

## Ownership and routing
AetherStream remains the authoritative system audio owner. The DSP model and sample processor live in `aetherstream-audio`; shared serializable profile types live in `aetherstream-core`; control state carries the selected output profile. The normal user workflow continues to target physical outputs. No mandatory virtual sink/source chain is introduced.

## Device classes
Factory starting points cover DesktopSpeaker, BookshelfSpeaker, StudioMonitor, Soundbar, Speaker2_1, Speaker5_1, Speaker7_1, OpenBackHeadphone, ClosedBackHeadphone, GamingHeadset, Iem, WiredEarbud, BluetoothEarbud, BluetoothHeadphone, VehicleAudio, ExternalAudio and Custom. Device-specific profiles can diverge from the factory starting point and persist independently.

## DSP profile
Each profile contains preamp/headroom gain, an ordered list of filters, bass enhancement, clarity enhancement, output gain, limiter ceiling and bypass state. Filter kinds are HighPass, LowPass, BandPass, Peak, Notch, LowShelf and HighShelf. Filters expose frequency, gain and Q; high/low-pass additionally expose slope via cascaded biquads.

## Real-time engine
The processor runs on interleaved `f32` samples and pre-allocates per-channel filter state when configured. Processing order is preamp -> user filters -> bass low-shelf -> clarity presence peak -> output gain -> soft limiter. Parameter/profile rebuilds occur outside the sample loop. The sample loop performs no heap allocation.

## Safety
Profile validation rejects invalid sample rates, channel counts, NaN/inf values, out-of-band frequencies, invalid Q values, excessive gain and limiter ceilings. Factory presets reserve headroom when bass/clarity are boosted. IEM/earbud profiles start conservatively.

## UI / AetherForge theme
The Settings DSP editor uses the existing DragonGlass visual system: smoked translucent surfaces, violet/indigo/blue accent states, pale text/glyphs, compact rounded controls and the global AetherForge font selection inherited from egui. DSP section-specific tokens reuse the system palette instead of defining an unrelated skin.

## Verification
v10.2.28 must pass Rust fmt, clippy, unit tests, workspace build, source-contract checks and package integrity. Verification adds explicit gates for output-DSP model, processing, factory profiles and DragonGlass DSP UI.
