# AetherStream HDMI3 Internal DSP Design

## Goal

AetherStream must process the existing HDMI3 physical sink in place. It must not create, expose, hide, replace, or switch to any additional output sink/stream/node, virtual or otherwise.

## Architecture

WirePlumber 0.5 internal filter graphs attach DSP inside an existing device node and add no graph nodes. AetherStream installs one WirePlumber `node.filter-graph.rules` rule matching the stable HDMI3 physical `node.name`. The rule loads the AetherStream Rust DSP as a LADSPA-compatible in-process shared library because internal filter graphs accept filter-chain graph nodes such as LADSPA plugins.

The Rust DSP plugin contains the existing `LiveDspProcessor`. AetherStream's control service compiles `OutputDspProfile` into a fixed `LiveDspPlan` outside the realtime callback and publishes it through a fixed-layout shared-memory control block under `$XDG_RUNTIME_DIR/aetherstream`. The plugin maps this control block off the realtime path; its audio callback only checks atomic generation/plan words and processes samples. Parameter changes retain the existing smoothing transition.

## Output ownership

- HDMI3 remains the one physical output node used by applications.
- AetherStream never calls output `wpctl set-default`.
- AetherStream creates zero `Audio/Sink` output streams/nodes.
- The prior smart-filter input/playback pair is removed.
- The prior `aetherstream.dsp.sink` path remains forbidden.
- Other physical sinks that the system already owns are not deleted or hidden; this contract means AetherStream adds no extra output option.

## Runtime lifecycle

The installer resolves HDMI3 by stable `node.name`, installs the Rust LADSPA shared library, writes one user WirePlumber fragment matching that exact physical node, and restarts WirePlumber once during installation because `node.filter-graph.rules` is static startup configuration. Runtime profile changes do not restart WirePlumber or PipeWire.

At login/reconnect, WirePlumber reattaches the internal graph whenever the same HDMI3 node is created. The plugin may start in unity/bypass until AetherStream's shared plan becomes available; a non-realtime helper thread maps the control block and the realtime callback never performs filesystem or socket I/O.

## Live controls

Bass, clarity, EQ bands, HPF/LPF, Gaming Mode, preamp, output gain, limiter and bypass continue to auto-apply. The supervisor/audiod control boundary stays typed. `aetherstream-audiod` no longer processes output PCM itself; it owns plan compilation/publication plus the existing system-microphone/ForgeHX runtime.

## Verification

Static and host gates must prove:

- no AetherStream `Audio/Sink` output stream constructors remain;
- no smart-filter pair remains;
- no output `node.virtual=true` remains;
- no output default switching remains;
- the WirePlumber rule uses `node.filter-graph.rules` and matches HDMI3's stable physical node;
- the Rust plugin is loaded internally and reports active;
- zero user-visible/hidden AetherStream output nodes exist;
- HDMI3 remains the same default physical sink while DSP is active;
- shared-plan generation changes on live profile updates;
- Bass/Clarity/RT regression tests remain mandatory;
- ForgeHX/system-mic ownership is unchanged.
