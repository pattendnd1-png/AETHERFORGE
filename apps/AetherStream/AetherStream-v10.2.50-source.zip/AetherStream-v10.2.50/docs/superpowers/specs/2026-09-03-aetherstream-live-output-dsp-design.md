# AetherStream Live Output DSP Design

## Goal
Make the existing output DSP audible in the live system path and make every valid UI edit auto-apply while it is being changed.

## Architecture
A new `aetherstream-audiod` Rust daemon owns the live PipeWire processing endpoint. It remembers the physical sink that was default at startup, exposes an AetherStream-managed `Audio/Sink` endpoint as the new default, runs captured F32 audio through the native Rust DSP engine, and forwards processed audio to the original physical sink. Users do not manually build or select a virtual-device chain; AetherStream creates, selects, and restores the managed endpoint automatically.

The supervisor remains the authority for persisted profiles and sends typed profile updates to `aetherstream-audiod` over a Unix socket. Profile compilation happens off the real-time thread. A wait-free SPSC queue carries fixed DSP plans into the audio callback. The callback performs no allocation or blocking locks. Plan changes crossfade over a short bounded window to avoid zipper noise/clicks.

## Live editing
The DragonGlass DSP editor dispatches `OutputDspApply` automatically whenever the profile changes and validates. Manual Apply is removed. Edits remain persisted by the supervisor, and audiod receives the same profile immediately.

## Bass and clarity verification
Audio tests measure gain in dB at the bass and clarity target bands and also check unrelated bands. Live-update tests prove that a new plan becomes audible without reconstructing the runtime. Bypass remains effectively unity.

## Runtime safety
- Rust 2024 / Rust 1.98+
- PipeWire client bindings: `pipewire` 0.10.1
- Real-time queue: `rtrb` 0.4.0
- F32LE live transport
- No mutex or allocation in the audio process callbacks
- Maximum 64 compiled IIR sections and 32 channels
- Short crossfade smoothing on profile changes
- Original physical default sink is restored on clean shutdown
