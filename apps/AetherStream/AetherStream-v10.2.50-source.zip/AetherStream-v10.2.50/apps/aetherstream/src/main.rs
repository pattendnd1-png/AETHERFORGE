use aetherstream_control::AetherState;
use aetherstream_core::{
    AetherAuthAction, AetherStreamAction, AuthProvider, ClientInstanceId, LinkedOutputConfig, StreamElementsOverlayAction, StreamlabsMediaShareAction,
};
use aetherstream_ipc::{
    read_envelope, write_envelope, ClientHello, ControlRequest, ControlResponse, IpcEnvelope,
    ServiceSnapshot,
};
use aetherstream_ui::UiControlBridge;
use std::path::PathBuf;
use std::sync::mpsc::TryRecvError;
use std::time::Duration;
use tokio::net::UnixStream;

fn supervisor_socket() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
        PathBuf::from(dir).join("aetherstream/supervisor.sock")
    } else {
        PathBuf::from(format!(
            "/tmp/aetherstream-{}/supervisor.sock",
            std::env::var("UID").unwrap_or_else(|_| "user".into())
        ))
    }
}

async fn connect(client: ClientInstanceId) -> Option<(UnixStream, ServiceSnapshot)> {
    let mut stream = UnixStream::connect(supervisor_socket()).await.ok()?;
    write_envelope(
        &mut stream,
        &IpcEnvelope::new(ClientHello {
            client,
            pid: std::process::id(),
        }),
    )
    .await
    .ok()?;
    let reply = read_envelope::<IpcEnvelope<ServiceSnapshot>>(&mut stream)
        .await
        .ok()?;
    Some((stream, reply.payload))
}

async fn control_request(
    client: ClientInstanceId,
    request: ControlRequest,
) -> Option<(ServiceSnapshot, ControlResponse)> {
    let (mut stream, snapshot) = connect(client).await?;
    write_envelope(&mut stream, &IpcEnvelope::new(request))
        .await
        .ok()?;
    let reply = read_envelope::<IpcEnvelope<ControlResponse>>(&mut stream)
        .await
        .ok()?;
    Some((snapshot, reply.payload))
}

fn parse_headless_action(value: &str) -> Option<AetherStreamAction> {
    if let Some(scene) = value.strip_prefix("obs-scene=") {
        return Some(AetherStreamAction::ObsScene(scene.to_owned()));
    }
    if let Some(transition) = value.strip_prefix("obs-transition=") {
        let transition = transition.trim();
        if transition.is_empty() {
            return None;
        }
        return Some(AetherStreamAction::ObsTransition(transition.to_owned()));
    }
    if let Some(active) = value.strip_prefix("twitch-shield=") {
        return Some(AetherStreamAction::TwitchShieldMode(active.parse().ok()?));
    }
    if let Some(action) = value.strip_prefix("se-overlay=") {
        let action = match action {
            "pause" => StreamElementsOverlayAction::Pause,
            "resume" => StreamElementsOverlayAction::Resume,
            "mute" => StreamElementsOverlayAction::Mute,
            "unmute" => StreamElementsOverlayAction::Unmute,
            "skip" => StreamElementsOverlayAction::Skip,
            "play-next" => StreamElementsOverlayAction::PlayNext,
            "reload" => StreamElementsOverlayAction::Reload,
            _ => return None,
        };
        return Some(AetherStreamAction::StreamElementsOverlay(action));
    }
    if let Some(action) = value.strip_prefix("sl-media=") {
        let action = match action {
            "play" => StreamlabsMediaShareAction::Play,
            "pause" => StreamlabsMediaShareAction::Pause,
            "skip" => StreamlabsMediaShareAction::Skip,
            "volume-up" => StreamlabsMediaShareAction::VolumeUp,
            "volume-down" => StreamlabsMediaShareAction::VolumeDown,
            "moderation-on" => StreamlabsMediaShareAction::Moderation(true),
            "moderation-off" => StreamlabsMediaShareAction::Moderation(false),
            _ => return None,
        };
        return Some(AetherStreamAction::StreamlabsMediaShare(action));
    }
    if let Some(provider) = value.strip_prefix("auth-begin=") {
        let provider = match provider {
            "twitch" => AuthProvider::Twitch,
            "streamlabs" => AuthProvider::Streamlabs,
            "streamelements" => AuthProvider::StreamElements,
            "engine" => AuthProvider::BroadcastEngine,
            _ => return None,
        };
        return Some(AetherStreamAction::Auth(AetherAuthAction::BeginLogin(provider)));
    }
    if value == "auth-smart-restore" {
        return Some(AetherStreamAction::Auth(AetherAuthAction::SmartRestore));
    }
    if let Some(payload) = value.strip_prefix("linked-output=") {
        let mut parts = payload.splitn(6, ',');
        let enabled = match parts.next()? {
            "on" => true,
            "off" => false,
            _ => return None,
        };
        let master_normalized_10k = parts.next()?.parse().ok()?;
        let hdmi_trim_db_x100 = parts.next()?.parse().ok()?;
        let bluetooth_trim_db_x100 = parts.next()?.parse().ok()?;
        let hdmi_node_name = parts.next().filter(|value| !value.is_empty()).map(str::to_owned);
        let bluetooth_node_name = parts.next().filter(|value| !value.is_empty()).map(str::to_owned);
        return Some(AetherStreamAction::LinkedOutputConfigure(LinkedOutputConfig {
            enabled,
            hdmi_node_name,
            bluetooth_node_name,
            master_normalized_10k,
            hdmi_trim_db_x100,
            bluetooth_trim_db_x100,
        }));
    }
    if let Some(payload) = value.strip_prefix("audio-gain=") {
        let (bus, gain) = payload.rsplit_once(':')?;
        return Some(AetherStreamAction::AudioGain {
            bus: bus.to_owned(),
            gain_db: gain.parse().ok()?,
        });
    }
    if let Some(payload) = value.strip_prefix("audio-mute=") {
        let (bus, muted) = payload.rsplit_once(':')?;
        return Some(AetherStreamAction::AudioMute {
            bus: bus.to_owned(),
            muted: muted.parse().ok()?,
        });
    }
    if let Some(profile) = value.strip_prefix("deck-profile=") {
        return Some(AetherStreamAction::DeckProfile(profile.to_owned()));
    }
    if let Some(page) = value.strip_prefix("deck-page=") {
        return Some(AetherStreamAction::DeckPage(page.to_owned()));
    }
    match value {
        "recording-toggle" => Some(AetherStreamAction::RecordingToggle),
        _ => None,
    }
}

fn spawn_ui_worker(client: ClientInstanceId) -> UiControlBridge {
    let (bridge, action_rx, state_tx) = UiControlBridge::channel_pair();
    std::thread::Builder::new()
        .name("aetherstream-ui-control".into())
        .spawn(move || {
            let Ok(runtime) = tokio::runtime::Runtime::new() else {
                return;
            };
            let mut last_revision = None;
            loop {
                let mut disconnected = false;
                loop {
                    match action_rx.try_recv() {
                        Ok(action) => {
                            let _ = runtime.block_on(control_request(
                                client,
                                ControlRequest::DispatchAction(action),
                            ));
                        }
                        Err(TryRecvError::Empty) => break,
                        Err(TryRecvError::Disconnected) => {
                            disconnected = true;
                            break;
                        }
                    }
                }
                if disconnected {
                    return;
                }

                if let Some((_, ControlResponse::StateSnapshot(state))) =
                    runtime.block_on(control_request(client, ControlRequest::GetState))
                    && last_revision != Some(state.revision)
                {
                    last_revision = Some(state.revision);
                    if state_tx.send(*state).is_err() {
                        return;
                    }
                }
                std::thread::sleep(Duration::from_millis(16));
            }
        })
        .expect("spawn AetherStream UI control worker");
    bridge
}

fn print_headless_state(client: ClientInstanceId, snapshot: &ServiceSnapshot, state: &AetherState) {
    println!("AETHERSTREAM_CLIENT_ID={client}");
    println!("AETHERSTREAM_SERVICE_COUNT={}", snapshot.services.len());
    println!("AETHERSTREAM_STATE_REVISION={}", state.revision);
    println!(
        "AETHERSTREAM_OBS_SCENE={}",
        state.obs.active_scene.as_deref().unwrap_or("")
    );
    println!(
        "AETHERSTREAM_OBS_TRANSITION={}",
        state.obs.transition.as_deref().unwrap_or("")
    );
    println!(
        "AETHERSTREAM_TWITCH_SHIELD_MODE={}",
        state.creator.shield_mode
    );
    println!(
        "AETHERSTREAM_SE_QUEUE_PAUSED={}",
        state.streamelements_ops.queue_paused
    );
    println!(
        "AETHERSTREAM_SL_MEDIA_PAUSED={}",
        state.streamlabs_ops.media_share_paused
    );
    if let Some(mic) = state.audio.buses.get("Mic") {
        println!("AETHERSTREAM_MIC_GAIN_DB={:.1}", mic.gain_db);
        println!("AETHERSTREAM_MIC_MUTED={}", mic.muted);
    } else {
        println!("AETHERSTREAM_MIC_GAIN_DB=");
        println!("AETHERSTREAM_MIC_MUTED=");
    }
    println!("AETHERSTREAM_LINKED_OUTPUT_ENABLED={}", state.audio.linked_output.enabled);
    println!("AETHERSTREAM_LINKED_OUTPUT_LATENCY_COMPENSATED={}", state.audio.linked_output.latency_compensated);
    println!("AETHERSTREAM_LINKED_OUTPUT_HDMI={}", state.audio.linked_output.hdmi_node_name.as_deref().unwrap_or(""));
    println!("AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH={}", state.audio.linked_output.bluetooth_node_name.as_deref().unwrap_or(""));
    println!("AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY_EXACT={}", state.audio.linked_output.topology_exact);
    println!("AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT={}", state.audio.linked_output.linked_sink_count);
    println!("AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT={}", state.audio.linked_output.member_count);
    println!("AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES={}", state.audio.linked_output.hdmi_route_count);
    println!("AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES={}", state.audio.linked_output.bluetooth_route_count);
    println!("AETHERSTREAM_EXTRANEOUS_VIRTUAL_SINKS={}", state.audio.linked_output.extraneous_virtual_sinks);
    println!("AETHERSTREAM_EXTRANEOUS_VIRTUAL_SOURCES={}", state.audio.linked_output.extraneous_virtual_sources);
    println!("AETHERSTREAM_DUPLICATE_OUTPUT_ROUTES={}", state.audio.linked_output.duplicate_output_routes);
    println!("AETHERSTREAM_ORPHAN_LINKS={}", state.audio.linked_output.orphan_links);
    println!(
        "AETHERSTREAM_DECK_PROFILE={}",
        state.deck.profile.as_deref().unwrap_or("")
    );
    println!(
        "AETHERSTREAM_DECK_PAGE={}",
        state.deck.page.as_deref().unwrap_or("")
    );
    println!(
        "AETHERSTREAM_RECORDING_ACTIVE={}",
        state.recording.active
    );
    for (label, provider) in [
        ("TWITCH", AuthProvider::Twitch),
        ("STREAMLABS", AuthProvider::Streamlabs),
        ("STREAMELEMENTS", AuthProvider::StreamElements),
        ("BROADCAST_ENGINE", AuthProvider::BroadcastEngine),
    ] {
        let status = state
            .auth
            .connections
            .get(&provider)
            .map(|connection| format!("{:?}", connection.state))
            .unwrap_or_else(|| "Disconnected".into());
        println!("AETHERSTREAM_AUTH_{label}={status}");
    }
    println!(
        "AETHERSTREAM_AUTH_SMART_RESTORE={}",
        state.auth.smart_restore_enabled
    );
}

fn main() -> eframe::Result {
    let client = ClientInstanceId::new();
    let runtime = tokio::runtime::Runtime::new().expect("tokio runtime");

    if let Ok(value) = std::env::var("AETHERSTREAM_CONTROL_ACTION") {
        let Some(action) = parse_headless_action(&value) else {
            eprintln!("AETHERSTREAM_CONTROL_ACTION=INVALID");
            return Ok(());
        };
        if let Some((_, response)) = runtime.block_on(control_request(
            client,
            ControlRequest::DispatchAction(action),
        )) {
            match response {
                ControlResponse::ActionAccepted { id } => {
                    println!("AETHERSTREAM_CLIENT_ID={client}");
                    println!("AETHERSTREAM_ACTION_ID={id}");
                    println!("AETHERSTREAM_ACTION=PASS");
                }
                ControlResponse::ActionRejected { reason, .. } => {
                    println!("AETHERSTREAM_ACTION=FAIL");
                    println!("AETHERSTREAM_ACTION_REASON={reason}");
                }
                ControlResponse::StateSnapshot(_) | ControlResponse::StateDelta(_) => {
                    println!("AETHERSTREAM_ACTION=FAIL");
                }
            }
        }
        return Ok(());
    }

    let (snapshot, state) = match runtime.block_on(control_request(client, ControlRequest::GetState)) {
        Some((snapshot, ControlResponse::StateSnapshot(state))) => (snapshot, *state),
        Some((snapshot, ControlResponse::StateDelta(_)))
        | Some((snapshot, ControlResponse::ActionAccepted { .. }))
        | Some((snapshot, ControlResponse::ActionRejected { .. })) => {
            (snapshot, AetherState::default())
        }
        None => (ServiceSnapshot::default(), AetherState::default()),
    };

    if std::env::var_os("AETHERSTREAM_HEADLESS_SMOKE").is_some()
        || std::env::var_os("AETHERSTREAM_CONTROL_GET_STATE").is_some()
    {
        print_headless_state(client, &snapshot, &state);
        return Ok(());
    }

    drop(runtime);
    let bridge = spawn_ui_worker(client);
    let options = eframe::NativeOptions::default();
    eframe::run_native(
        "AetherStream",
        options,
        Box::new(move |_cc| {
            Ok(Box::new(aetherstream_ui::AetherStreamApp::with_bridge(
                client, snapshot, state, bridge,
            )))
        }),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn headless_parser_covers_live_workstation_actions() {
        assert_eq!(
            parse_headless_action("auth-begin=twitch"),
            Some(AetherStreamAction::Auth(AetherAuthAction::BeginLogin(AuthProvider::Twitch)))
        );
        assert_eq!(
            parse_headless_action("auth-smart-restore"),
            Some(AetherStreamAction::Auth(AetherAuthAction::SmartRestore))
        );
        assert_eq!(
            parse_headless_action("audio-gain=Mic:-3.5"),
            Some(AetherStreamAction::AudioGain {
                bus: "Mic".into(),
                gain_db: -3.5,
            })
        );
        assert_eq!(
            parse_headless_action("linked-output=on,7000,0,-300,,bluez_output.AA_BB"),
            Some(AetherStreamAction::LinkedOutputConfigure(LinkedOutputConfig {
                enabled: true,
                hdmi_node_name: None,
                bluetooth_node_name: Some("bluez_output.AA_BB".into()),
                master_normalized_10k: 7000,
                hdmi_trim_db_x100: 0,
                bluetooth_trim_db_x100: -300,
            }))
        );
        assert_eq!(
            parse_headless_action("deck-profile=Forge Master"),
            Some(AetherStreamAction::DeckProfile("Forge Master".into()))
        );
        assert_eq!(
            parse_headless_action("recording-toggle"),
            Some(AetherStreamAction::RecordingToggle)
        );
        assert_eq!(
            parse_headless_action("twitch-shield=true"),
            Some(AetherStreamAction::TwitchShieldMode(true))
        );
        assert_eq!(
            parse_headless_action("obs-transition=Fade"),
            Some(AetherStreamAction::ObsTransition("Fade".into()))
        );
        assert_eq!(
            parse_headless_action("se-overlay=pause"),
            Some(AetherStreamAction::StreamElementsOverlay(
                StreamElementsOverlayAction::Pause
            ))
        );
        assert_eq!(
            parse_headless_action("sl-media=pause"),
            Some(AetherStreamAction::StreamlabsMediaShare(
                StreamlabsMediaShareAction::Pause
            ))
        );
    }
}
