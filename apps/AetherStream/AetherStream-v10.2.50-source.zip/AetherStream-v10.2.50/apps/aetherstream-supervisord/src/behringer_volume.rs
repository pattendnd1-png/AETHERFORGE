use aetherstream_core::AetherStreamAction;
use aetherstream_ipc::read_envelope;
use serde::Deserialize;
use std::os::unix::fs::PermissionsExt;
use std::path::PathBuf;
use std::process::Command;
use tokio::net::UnixListener;
use uuid::Uuid;

pub const BEHRINGER_IPC_PROTOCOL_VERSION: u16 = 1;
pub const SYSTEM_VOLUME_PROTOCOL_VERSION: u16 = 1;

#[derive(Debug, Deserialize)]
pub struct BehringerEnvelope<T> {
    pub protocol_version: u16,
    pub message_id: Uuid,
    pub payload: T,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Deserialize)]
pub struct SystemVolumeRequest {
    pub protocol_version: u16,
    pub normalized_10k: u16,
}

#[must_use]
pub fn system_volume_socket_path() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
        PathBuf::from(dir).join("aetherstream/system-volume.sock")
    } else {
        PathBuf::from(format!(
            "/tmp/aetherstream-{}/system-volume.sock",
            std::env::var("UID").unwrap_or_else(|_| "user".into())
        ))
    }
}

pub fn validate_request(
    envelope: &BehringerEnvelope<SystemVolumeRequest>,
) -> Result<(), &'static str> {
    if envelope.protocol_version != BEHRINGER_IPC_PROTOCOL_VERSION {
        return Err("unsupported Behringer IPC protocol");
    }
    if envelope.payload.protocol_version != SYSTEM_VOLUME_PROTOCOL_VERSION {
        return Err("unsupported system-volume protocol");
    }
    if envelope.payload.normalized_10k > 10_000 {
        return Err("system volume out of range");
    }
    Ok(())
}

#[must_use]
pub const fn request_action(request: SystemVolumeRequest) -> AetherStreamAction {
    AetherStreamAction::SystemOutputVolume {
        normalized_10k: request.normalized_10k,
    }
}

#[must_use]
pub fn volume_percent_argument(normalized_10k: u16) -> String {
    format!("{:.2}%", f32::from(normalized_10k.min(10_000)) / 100.0)
}

pub fn apply_system_output_volume(normalized_10k: u16) -> Result<(), String> {
    if normalized_10k > 10_000 {
        return Err("system volume out of range".into());
    }
    let status = Command::new("wpctl")
        .arg("set-volume")
        .arg("@DEFAULT_AUDIO_SINK@")
        .arg(volume_percent_argument(normalized_10k))
        .status()
        .map_err(|error| format!("failed to execute wpctl: {error}"))?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("wpctl set-volume exited with {status}"))
    }
}

pub async fn run_behringer_system_volume_listener() -> std::io::Result<()> {
    let path = system_volume_socket_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
        std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
    }
    if path.exists() {
        std::fs::remove_file(&path)?;
    }
    let listener = UnixListener::bind(&path)?;
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600))?;

    loop {
        let (mut stream, _) = listener.accept().await?;
        tokio::spawn(async move {
            let Ok(envelope) = read_envelope::<BehringerEnvelope<SystemVolumeRequest>>(&mut stream).await else {
                return;
            };
            if validate_request(&envelope).is_err() {
                return;
            }
            let _message_id = envelope.message_id;
            let action = request_action(envelope.payload);
            if let AetherStreamAction::SystemOutputVolume { normalized_10k } = action {
                let _ = apply_system_output_volume(normalized_10k);
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn system_volume_request_maps_to_audio_action_and_wpctl_percent() {
        let request = SystemVolumeRequest {
            protocol_version: SYSTEM_VOLUME_PROTOCOL_VERSION,
            normalized_10k: 7_300,
        };
        assert_eq!(
            request_action(request),
            AetherStreamAction::SystemOutputVolume {
                normalized_10k: 7_300
            }
        );
        assert_eq!(volume_percent_argument(7_300), "73.00%");
    }

    #[test]
    fn request_validation_rejects_out_of_range_or_protocol_mismatch() {
        let mut envelope = BehringerEnvelope {
            protocol_version: BEHRINGER_IPC_PROTOCOL_VERSION,
            message_id: Uuid::nil(),
            payload: SystemVolumeRequest {
                protocol_version: SYSTEM_VOLUME_PROTOCOL_VERSION,
                normalized_10k: 10_001,
            },
        };
        assert!(validate_request(&envelope).is_err());
        envelope.payload.normalized_10k = 10_000;
        assert!(validate_request(&envelope).is_ok());
        envelope.payload.protocol_version = 99;
        assert!(validate_request(&envelope).is_err());
    }
}
