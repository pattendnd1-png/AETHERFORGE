mod behringer_volume;
mod output_dsp_runtime;

use behringer_volume::{apply_system_output_volume, run_behringer_system_volume_listener};
use aetherstream_audio::{apply_linked_output, linked_output_topology_healthy, load_linked_output_config, refresh_linked_output_levels};
use output_dsp_runtime::apply_output_dsp_profile;
use aetherstream_auth::{AuthError, AuthRuntime, RuntimeConfig};
use aetherstream_control::{
    reduce, ActionRouter, ActionTarget, AetherState, AudioBusState, BroadcastSession,
    SessionOrchestrator, SubscriptionHub, SubscriptionUpdate,
};
use aetherstream_core::{
    bluetooth_loadout_id, AetherAuthAction, AetherStreamAction, AuthConnectionState, AuthProvider, LinkedOutputConfig,
    OutputDeviceClass, OutputDspProfile, Provider, ServiceHealth, UnifiedEvent, UnifiedEventKind,
    HDMI3_LOADOUT_ID,
};
use aetherstream_integrations::translate_action;
use aetherstream_ipc::{
    read_envelope, write_envelope, ClientHello, ControlRequest, ControlResponse, IpcEnvelope,
};
use aetherstream_storage::{LinuxSecretStore, StateDb};
use aetherstream_supervisor::ClientRegistry;
use std::os::unix::fs::PermissionsExt;
use std::path::PathBuf;
use std::process::Command;
use std::sync::Arc;
use std::time::Duration;
use tokio::net::UnixListener;
use tokio::sync::Mutex;
use uuid::Uuid;

fn socket_path() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
        PathBuf::from(dir).join("aetherstream/supervisor.sock")
    } else {
        PathBuf::from(format!(
            "/tmp/aetherstream-{}/supervisor.sock",
            std::env::var("UID").unwrap_or_else(|_| "user".into())
        ))
    }
}

fn auth_state_db_path() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_STATE_HOME") {
        PathBuf::from(dir).join("aetherstream/state.db")
    } else if let Some(home) = std::env::var_os("HOME") {
        PathBuf::from(home).join(".local/state/aetherstream/state.db")
    } else {
        PathBuf::from("/tmp/aetherstream-state.db")
    }
}

fn output_dsp_db_path() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_STATE_HOME") {
        PathBuf::from(dir).join("aetherstream/output-dsp.db")
    } else if let Some(home) = std::env::var_os("HOME") {
        PathBuf::from(home).join(".local/state/aetherstream/output-dsp.db")
    } else {
        PathBuf::from("/tmp/aetherstream-output-dsp.db")
    }
}


#[derive(Clone, Debug, Eq, PartialEq)]
struct PhysicalOutputIdentity {
    node_name: String,
    loadout_id: String,
    description: String,
    device_class: OutputDeviceClass,
    bluetooth_codec: Option<String>,
}

fn parse_wpctl_string(text: &str, key: &str) -> Option<String> {
    text.lines().find_map(|line| {
        if !line.contains(key) {
            return None;
        }
        let (_, value) = line.split_once('=')?;
        let value = value.trim().trim_matches('"').trim();
        (!value.is_empty()).then(|| value.to_owned())
    })
}

fn looks_like_hdmi3(text: &str) -> bool {
    let lower = text.to_ascii_lowercase();
    [
        "hdmi3",
        "hdmi 3",
        "hdmi / displayport 3",
        "hdmi-stereo-extra2",
        "hdmi-output-2",
        "displayport 3",
    ]
    .iter()
    .any(|needle| lower.contains(needle))
}

fn physical_output_identity_from_inspect(inspect: &str) -> Result<PhysicalOutputIdentity, String> {
    let node_name = parse_wpctl_string(inspect, "node.name")
        .ok_or_else(|| "default output has no node.name".to_string())?;
    if node_name.starts_with("aetherstream.") {
        return Err("AetherStream refuses an AetherStream-created output node".into());
    }
    let description = parse_wpctl_string(inspect, "node.description")
        .or_else(|| parse_wpctl_string(inspect, "device.description"))
        .or_else(|| parse_wpctl_string(inspect, "device.product.name"))
        .unwrap_or_else(|| node_name.clone());
    let bluetooth_address = parse_wpctl_string(inspect, "api.bluez5.address");
    let bluetooth_codec = parse_wpctl_string(inspect, "api.bluez5.codec");
    let bluetooth = node_name.starts_with("bluez_output.")
        || bluetooth_address.is_some()
        || bluetooth_codec.is_some()
        || inspect.contains("api.bluez5.profile");
    let (loadout_id, device_class) = if bluetooth {
        (
            bluetooth_loadout_id(bluetooth_address.as_deref(), &node_name),
            OutputDeviceClass::for_bluetooth_speaker_name(&description),
        )
    } else if looks_like_hdmi3(inspect) {
        (HDMI3_LOADOUT_ID.to_owned(), OutputDeviceClass::TvSpeaker)
    } else {
        (
            format!("physical:{}", node_name.replace(|c: char| !c.is_ascii_alphanumeric(), "_")),
            OutputDeviceClass::Custom,
        )
    };
    Ok(PhysicalOutputIdentity {
        node_name,
        loadout_id,
        description,
        device_class,
        bluetooth_codec,
    })
}

fn current_physical_output_identity() -> Result<PhysicalOutputIdentity, String> {
    let output = Command::new("wpctl")
        .args(["inspect", "@DEFAULT_AUDIO_SINK@"])
        .output()
        .map_err(|error| format!("wpctl inspect @DEFAULT_AUDIO_SINK@: {error}"))?;
    if !output.status.success() {
        return Err(String::from_utf8_lossy(&output.stderr).trim().to_owned());
    }
    physical_output_identity_from_inspect(&String::from_utf8_lossy(&output.stdout))
}

struct ControlPlane {
    registry: ClientRegistry,
    state: AetherState,
    subscriptions: SubscriptionHub,
    dsp_db: Option<StateDb>,
}

impl Default for ControlPlane {
    fn default() -> Self {
        let mut registry = ClientRegistry::default();
        let mut state = AetherState::default();
        for service in [
            "authd",
            "eventsubd",
            "obsd",
            "elementsd",
            "labsd",
            "deckd",
            "audiod",
            "avd",
        ] {
            registry.set_service_health(service, ServiceHealth::Offline);
            state.services.insert(service.into(), ServiceHealth::Offline);
        }
        Self {
            registry,
            state,
            subscriptions: SubscriptionHub::default(),
            dsp_db: None,
        }
    }
}

fn normalize_output_dsp_loadout(
    mut profiles: std::collections::BTreeMap<String, aetherstream_core::OutputDspProfile>,
) -> (std::collections::BTreeMap<String, aetherstream_core::OutputDspProfile>, String) {
    if !profiles.contains_key(HDMI3_LOADOUT_ID) {
        let profile = profiles
            .get("@DEFAULT_AUDIO_SINK@")
            .cloned()
            .or_else(|| profiles.values().next().cloned())
            .unwrap_or_else(|| {
                aetherstream_core::OutputDspProfile::factory(
                    aetherstream_core::OutputDeviceClass::DesktopSpeaker,
                )
            });
        profiles.insert(HDMI3_LOADOUT_ID.into(), profile);
    }
    (profiles, HDMI3_LOADOUT_ID.into())
}

impl ControlPlane {
    fn persistent() -> Result<Self, String> {
        let path = output_dsp_db_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).map_err(|error| error.to_string())?;
        }
        let db = StateDb::open(&path).map_err(|error| error.to_string())?;
        let profiles = db
            .load_output_dsp_profiles()
            .map_err(|error| error.to_string())?;
        let (profiles, active_device_id) = normalize_output_dsp_loadout(profiles);
        if let Some(profile) = profiles.get(HDMI3_LOADOUT_ID) {
            db.save_output_dsp_profile(HDMI3_LOADOUT_ID, profile)
                .map_err(|error| error.to_string())?;
        }
        let mut control = Self::default();
        control.state.audio.output_dsp.active_device_id = Some(active_device_id);
        control.state.audio.output_dsp.profiles = profiles;
        control.dsp_db = Some(db);
        Ok(control)
    }

    fn project_auth_connection(&mut self, connection: aetherstream_core::AccountConnection) {
        let previous = self.state.clone();
        let provider = connection.provider;
        let changed = self.state.auth.connections.get(&provider) != Some(&connection);
        if changed {
            self.state.auth.connections.insert(provider, connection);
            self.state.revision = self.state.revision.saturating_add(1);
            self.subscriptions.publish(&previous, &self.state);
        }
    }

    fn project_auth_failure(&mut self, provider: AuthProvider, error: &AuthError) {
        let mut connection = self
            .state
            .auth
            .connections
            .get(&provider)
            .cloned()
            .unwrap_or_else(|| aetherstream_core::AccountConnection::disconnected(provider));
        connection.state = match error {
            AuthError::Denied | AuthError::Expired => AuthConnectionState::AuthenticationRequired,
            _ => AuthConnectionState::NeedsAttention,
        };
        connection.status_detail = Some(error.to_string());
        connection.user_code = None;
        connection.verification_uri = None;
        self.project_auth_connection(connection);
    }

    fn set_restore_status(&mut self, status: String) {
        let previous = self.state.clone();
        if self.state.auth.last_restore_status.as_deref() != Some(status.as_str()) {
            self.state.auth.last_restore_status = Some(status);
            self.state.revision = self.state.revision.saturating_add(1);
            self.subscriptions.publish(&previous, &self.state);
        }
    }

    fn commit_projection(&mut self, action: &AetherStreamAction) -> Result<(), String> {
        let target = ActionRouter::target(action);
        if matches!(
            target,
            ActionTarget::Twitch
                | ActionTarget::Obs
                | ActionTarget::StreamElements
                | ActionTarget::Streamlabs
        ) {
            let operation = translate_action(action).map_err(|error| error.to_string())?;
            if operation.is_none() {
                return Err("provider action has no canonical operation translation".into());
            }
        }

        let previous = self.state.clone();
        match action {
            AetherStreamAction::Auth(auth_action) => {
                match auth_action {
                    AetherAuthAction::BeginLogin(provider) => {
                        let connection = self
                            .state
                            .auth
                            .connections
                            .entry(*provider)
                            .or_insert_with(|| aetherstream_core::AccountConnection::disconnected(*provider));
                        connection.user_code = None;
                        connection.verification_uri = None;
                        connection.manual_code_available = false;
                        match provider {
                            AuthProvider::Twitch => {
                                connection.state = AuthConnectionState::Connecting;
                                connection.status_detail = Some("Requesting Twitch Device Code from auth runtime".into());
                            }
                            AuthProvider::Streamlabs => {
                                connection.state = AuthConnectionState::AwaitingUser;
                                connection.status_detail = Some("Streamlabs browser OAuth callback pending".into());
                                connection.manual_code_available = true;
                            }
                            AuthProvider::StreamElements => {
                                connection.state = AuthConnectionState::AwaitingUser;
                                connection.status_detail = Some("StreamElements browser OAuth callback pending".into());
                                connection.manual_code_available = true;
                            }
                            AuthProvider::BroadcastEngine => {
                                connection.state = AuthConnectionState::Connecting;
                                connection.status_detail = Some("Connecting OBS-compatible broadcast engine".into());
                            }
                        }
                    }
                    AetherAuthAction::SubmitManualCode { provider, code } => {
                        if code.trim().is_empty() {
                            return Err("manual authorization code is empty".into());
                        }
                        let connection = self
                            .state
                            .auth
                            .connections
                            .entry(*provider)
                            .or_insert_with(|| aetherstream_core::AccountConnection::disconnected(*provider));
                        connection.state = AuthConnectionState::Connecting;
                        connection.status_detail = Some("One-time authorization code submitted to auth service".into());
                        connection.manual_code_available = false;
                    }
                    AetherAuthAction::Disconnect(provider) => {
                        let connection = self
                            .state
                            .auth
                            .connections
                            .entry(*provider)
                            .or_insert_with(|| aetherstream_core::AccountConnection::disconnected(*provider));
                        *connection = aetherstream_core::AccountConnection::disconnected(*provider);
                    }
                    AetherAuthAction::SetDefault { provider, account } => {
                        for connection in self.state.auth.connections.values_mut() {
                            if connection.provider == *provider {
                                connection.is_default = connection.account == Some(*account);
                            }
                        }
                    }
                    AetherAuthAction::SmartRestore => {
                        self.state.auth.smart_restore_enabled = true;
                        self.state.auth.last_restore_status = Some("Smart restore requested".into());
                    }
                    AetherAuthAction::ConnectBroadcastEngine => {
                        let engine_state = match self.state.services.get("obsd") {
                            Some(ServiceHealth::Connected) => AuthConnectionState::Connected,
                            Some(ServiceHealth::AuthRequired) => AuthConnectionState::AuthenticationRequired,
                            _ => AuthConnectionState::Connecting,
                        };
                        let connection = self
                            .state
                            .auth
                            .connections
                            .entry(AuthProvider::BroadcastEngine)
                            .or_insert_with(|| aetherstream_core::AccountConnection::disconnected(AuthProvider::BroadcastEngine));
                        connection.state = engine_state;
                        connection.status_detail = Some("OBS-compatible broadcast engine connection requested".into());
                    }
                    AetherAuthAction::DisconnectBroadcastEngine => {
                        let connection = self
                            .state
                            .auth
                            .connections
                            .entry(AuthProvider::BroadcastEngine)
                            .or_insert_with(|| aetherstream_core::AccountConnection::disconnected(AuthProvider::BroadcastEngine));
                        *connection = aetherstream_core::AccountConnection::disconnected(AuthProvider::BroadcastEngine);
                    }
                }
                self.state.revision = self.state.revision.saturating_add(1);
            }
            AetherStreamAction::ObsScene(scene) => {
                let mut event = UnifiedEvent::new(Provider::Obs, UnifiedEventKind::ObsSceneChanged);
                event.provider_payload = serde_json::json!({"scene": scene});
                reduce(&mut self.state, &event).map_err(|error| error.to_string())?;
            }
            AetherStreamAction::ObsTransition(transition) => {
                if self.state.obs.transition.as_deref() != Some(transition.as_str()) {
                    self.state.obs.transition = Some(transition.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::ObsSourceVisibility { source, visible } => {
                let changed = self.state.obs.sources.get(source).copied() != Some(*visible);
                if changed {
                    self.state.obs.sources.insert(source.clone(), *visible);
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::ObsReplayBufferSave => {
                self.state.obs.replay_saves = self.state.obs.replay_saves.saturating_add(1);
                self.state.revision = self.state.revision.saturating_add(1);
            }
            AetherStreamAction::TwitchCreatePoll(spec) => {
                if self.state.creator.active_poll.as_deref() != Some(spec.title.as_str()) {
                    self.state.creator.active_poll = Some(spec.title.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::TwitchCreatePrediction(spec) => {
                if self.state.creator.active_prediction.as_deref() != Some(spec.title.as_str()) {
                    self.state.creator.active_prediction = Some(spec.title.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::TwitchRaid(target) => {
                let target = target.trim();
                if self.state.creator.raid_target.as_deref() != Some(target) {
                    self.state.creator.raid_target = Some(target.to_owned());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::TwitchShieldMode(active) => {
                if self.state.creator.shield_mode != *active {
                    self.state.creator.shield_mode = *active;
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::TwitchModeration(moderation) => {
                let summary = format!("{moderation:?}");
                if self.state.creator.last_moderation.as_deref() != Some(summary.as_str()) {
                    self.state.creator.last_moderation = Some(summary);
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::StreamElementsTestAlert(kind) => {
                let summary = format!("test:{kind}");
                if self.state.streamelements_ops.last_action.as_deref() != Some(summary.as_str()) {
                    self.state.streamelements_ops.last_action = Some(summary);
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::StreamElementsOverlay(overlay_action) => {
                use aetherstream_core::StreamElementsOverlayAction;
                let mut changed = false;
                match overlay_action {
                    StreamElementsOverlayAction::Pause => {
                        changed = !self.state.streamelements_ops.queue_paused;
                        self.state.streamelements_ops.queue_paused = true;
                    }
                    StreamElementsOverlayAction::Resume => {
                        changed = self.state.streamelements_ops.queue_paused;
                        self.state.streamelements_ops.queue_paused = false;
                    }
                    StreamElementsOverlayAction::Mute => {
                        changed = !self.state.streamelements_ops.muted;
                        self.state.streamelements_ops.muted = true;
                    }
                    StreamElementsOverlayAction::Unmute => {
                        changed = self.state.streamelements_ops.muted;
                        self.state.streamelements_ops.muted = false;
                    }
                    StreamElementsOverlayAction::Skip
                    | StreamElementsOverlayAction::PlayNext
                    | StreamElementsOverlayAction::Reload => {}
                }
                let summary = format!("{overlay_action:?}");
                if self.state.streamelements_ops.last_action.as_deref() != Some(summary.as_str()) {
                    self.state.streamelements_ops.last_action = Some(summary);
                    changed = true;
                }
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::StreamlabsSkipAlert => {
                if self.state.streamlabs_ops.last_action.as_deref() != Some("Skip") {
                    self.state.streamlabs_ops.last_action = Some("Skip".into());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::StreamlabsAlert(alert_action) => {
                use aetherstream_core::StreamlabsAlertAction;
                let mut changed = false;
                match alert_action {
                    StreamlabsAlertAction::Pause => {
                        changed = !self.state.streamlabs_ops.alert_queue_paused;
                        self.state.streamlabs_ops.alert_queue_paused = true;
                    }
                    StreamlabsAlertAction::Resume => {
                        changed = self.state.streamlabs_ops.alert_queue_paused;
                        self.state.streamlabs_ops.alert_queue_paused = false;
                    }
                    StreamlabsAlertAction::Mute => {
                        changed = !self.state.streamlabs_ops.alert_muted;
                        self.state.streamlabs_ops.alert_muted = true;
                    }
                    StreamlabsAlertAction::Unmute => {
                        changed = self.state.streamlabs_ops.alert_muted;
                        self.state.streamlabs_ops.alert_muted = false;
                    }
                    StreamlabsAlertAction::Skip | StreamlabsAlertAction::Test(_) => {}
                }
                let summary = format!("{alert_action:?}");
                if self.state.streamlabs_ops.last_action.as_deref() != Some(summary.as_str()) {
                    self.state.streamlabs_ops.last_action = Some(summary);
                    changed = true;
                }
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::StreamlabsMediaShare(media_action) => {
                use aetherstream_core::StreamlabsMediaShareAction;
                let mut changed = false;
                match media_action {
                    StreamlabsMediaShareAction::Play => {
                        changed = self.state.streamlabs_ops.media_share_paused;
                        self.state.streamlabs_ops.media_share_paused = false;
                    }
                    StreamlabsMediaShareAction::Pause => {
                        changed = !self.state.streamlabs_ops.media_share_paused;
                        self.state.streamlabs_ops.media_share_paused = true;
                    }
                    StreamlabsMediaShareAction::Moderation(enabled) => {
                        changed = self.state.streamlabs_ops.media_share_moderation != *enabled;
                        self.state.streamlabs_ops.media_share_moderation = *enabled;
                    }
                    StreamlabsMediaShareAction::Skip
                    | StreamlabsMediaShareAction::VolumeUp
                    | StreamlabsMediaShareAction::VolumeDown => {}
                }
                let summary = format!("{media_action:?}");
                if self.state.streamlabs_ops.last_action.as_deref() != Some(summary.as_str()) {
                    self.state.streamlabs_ops.last_action = Some(summary);
                    changed = true;
                }
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::OutputDspApply { device_id, profile } => {
                profile
                    .validate(48_000.0, 2)
                    .map_err(|error| error.to_string())?;
                if let Some(db) = &self.dsp_db {
                    db.save_output_dsp_profile(device_id, profile)
                        .map_err(|error| error.to_string())?;
                }
                let changed = self.state.audio.output_dsp.profiles.get(device_id) != Some(profile)
                    || self.state.audio.output_dsp.active_device_id.as_deref()
                        != Some(device_id.as_str());
                if changed {
                    self.state
                        .audio
                        .output_dsp
                        .profiles
                        .insert(device_id.clone(), profile.clone());
                    self.state.audio.output_dsp.active_device_id = Some(device_id.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::OutputDspBypass { device_id, bypassed } => {
                let mut profile = self
                    .state
                    .audio
                    .output_dsp
                    .profiles
                    .get(device_id)
                    .cloned()
                    .unwrap_or_else(|| {
                        aetherstream_core::OutputDspProfile::factory(
                            aetherstream_core::OutputDeviceClass::Custom,
                        )
                    });
                if profile.bypassed != *bypassed {
                    profile.bypassed = *bypassed;
                    if let Some(db) = &self.dsp_db {
                        db.save_output_dsp_profile(device_id, &profile)
                            .map_err(|error| error.to_string())?;
                    }
                    self.state
                        .audio
                        .output_dsp
                        .profiles
                        .insert(device_id.clone(), profile);
                    self.state.audio.output_dsp.active_device_id = Some(device_id.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::SystemOutputVolume { normalized_10k } => {
                apply_system_output_volume(*normalized_10k)?;
            }
            AetherStreamAction::LinkedOutputConfigure(config) => {
                if config.master_normalized_10k > 15_000 {
                    return Err("linked output master volume out of range".into());
                }
                if !(-1_200..=0).contains(&config.hdmi_trim_db_x100)
                    || !(-1_200..=0).contains(&config.bluetooth_trim_db_x100)
                {
                    return Err("linked output trims must be between -12.00 dB and 0.00 dB".into());
                }
                let linked = &mut self.state.audio.linked_output;
                let changed = linked.enabled != config.enabled
                    || linked.hdmi_node_name != config.hdmi_node_name
                    || linked.bluetooth_node_name != config.bluetooth_node_name
                    || linked.master_normalized_10k != config.master_normalized_10k
                    || linked.hdmi_trim_db_x100 != config.hdmi_trim_db_x100
                    || linked.bluetooth_trim_db_x100 != config.bluetooth_trim_db_x100;
                if changed {
                    linked.enabled = config.enabled;
                    linked.hdmi_node_name = config.hdmi_node_name.clone();
                    linked.bluetooth_node_name = config.bluetooth_node_name.clone();
                    linked.master_normalized_10k = config.master_normalized_10k;
                    linked.hdmi_trim_db_x100 = config.hdmi_trim_db_x100;
                    linked.bluetooth_trim_db_x100 = config.bluetooth_trim_db_x100;
                    linked.latency_compensated = false;
                    linked.status_detail = Some("runtime apply requested".into());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::AudioGain { bus, gain_db } => {
                let changed = if let Some(entry) = self.state.audio.buses.get_mut(bus) {
                    if (entry.gain_db - *gain_db).abs() > f32::EPSILON {
                        entry.gain_db = *gain_db;
                        true
                    } else {
                        false
                    }
                } else {
                    self.state.audio.buses.insert(
                        bus.clone(),
                        AudioBusState {
                            gain_db: *gain_db,
                            ..Default::default()
                        },
                    );
                    true
                };
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::AudioMute { bus, muted } => {
                let changed = {
                    let entry = self.state.audio.buses.entry(bus.clone()).or_default();
                    if entry.muted != *muted {
                        entry.muted = *muted;
                        true
                    } else {
                        false
                    }
                };
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::AudioSolo { bus, soloed } => {
                let changed = {
                    let entry = self.state.audio.buses.entry(bus.clone()).or_default();
                    if entry.soloed != *soloed {
                        entry.soloed = *soloed;
                        true
                    } else {
                        false
                    }
                };
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::AudioMonitor { bus, enabled } => {
                let changed = {
                    let entry = self.state.audio.buses.entry(bus.clone()).or_default();
                    if entry.monitor != *enabled {
                        entry.monitor = *enabled;
                        true
                    } else {
                        false
                    }
                };
                if changed {
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::DeckProfile(profile) => {
                if self.state.deck.profile.as_deref() != Some(profile.as_str()) {
                    self.state.deck.profile = Some(profile.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::DeckPage(page) => {
                if self.state.deck.page.as_deref() != Some(page.as_str()) {
                    self.state.deck.page = Some(page.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::MediaOpenProject(project) => {
                if self.state.media.project.as_deref() != Some(project.as_str()) {
                    self.state.media.project = Some(project.clone());
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::RecordingToggle => {
                self.state.recording.active = !self.state.recording.active;
                self.state.revision = self.state.revision.saturating_add(1);
            }
            AetherStreamAction::SessionLoad(id) => {
                if self.state.active_session != Some(*id) {
                    self.state.active_session = Some(*id);
                    self.state.revision = self.state.revision.saturating_add(1);
                }
            }
            AetherStreamAction::Macro(actions) => {
                for nested in actions {
                    self.commit_projection(nested)?;
                }
                return Ok(());
            }
            AetherStreamAction::ObsMute { .. }
            | AetherStreamAction::TwitchCreateClip
            | AetherStreamAction::TwitchMarker(_)
            | AetherStreamAction::Workspace(_)
            | AetherStreamAction::MultiviewLayout(_)
            | AetherStreamAction::DspPreset(_)
            | AetherStreamAction::RecordingFinalize
            | AetherStreamAction::SessionSave(_)
            | AetherStreamAction::SessionGoLive
            | AetherStreamAction::SessionEnd => {}
        }
        if self.state.revision != previous.revision {
            self.subscriptions.publish(&previous, &self.state);
        }
        Ok(())
    }
}

async fn apply_linked_output_runtime(control: Arc<Mutex<ControlPlane>>, config: LinkedOutputConfig) {
    let apply_config = config.clone();
    let result = tokio::task::spawn_blocking(move || apply_linked_output(&apply_config)).await;
    let mut control = control.lock().await;
    let previous = control.state.clone();
    let linked = &mut control.state.audio.linked_output;
    match result {
        Ok(Ok(applied)) => {
            linked.enabled = applied.enabled;
            linked.hdmi_node_name = applied.hdmi_node_name;
            linked.bluetooth_node_name = applied.bluetooth_node_name;
            linked.latency_compensated = applied.latency_compensated;
            linked.topology_exact = applied.enabled && applied.topology.is_exact();
            linked.linked_sink_count = applied.topology.linked_sink_count.min(u16::MAX as usize) as u16;
            linked.member_count = applied.topology.member_count.min(u16::MAX as usize) as u16;
            linked.hdmi_route_count = applied.topology.hdmi_route_count.min(u16::MAX as usize) as u16;
            linked.bluetooth_route_count = applied.topology.bluetooth_route_count.min(u16::MAX as usize) as u16;
            linked.extraneous_virtual_sinks = applied.topology.extraneous_virtual_sinks.min(u16::MAX as usize) as u16;
            linked.extraneous_virtual_sources = applied.topology.extraneous_virtual_sources.min(u16::MAX as usize) as u16;
            linked.duplicate_output_routes = applied.topology.duplicate_output_routes.min(u16::MAX as usize) as u16;
            linked.orphan_links = applied.topology.orphan_links.min(u16::MAX as usize) as u16;
            linked.status_detail = Some(if applied.enabled { "linked output active; exact two-member topology verified".into() } else { "linked output disabled; linked namespace clean".into() });
        }
        Ok(Err(error)) => {
            linked.latency_compensated = false;
            linked.topology_exact = false;
            linked.status_detail = Some(format!("linked output apply failed: {error}"));
        }
        Err(error) => {
            linked.latency_compensated = false;
            linked.topology_exact = false;
            linked.status_detail = Some(format!("linked output task failed: {error}"));
        }
    }
    control.state.revision = control.state.revision.saturating_add(1);
    let next = control.state.clone();
    control.subscriptions.publish(&previous, &next);
}

async fn run_linked_output_watcher(control: Arc<Mutex<ControlPlane>>) {
    loop {
        if let Ok(Some(config)) = load_linked_output_config() {
            if config.enabled {
                if !linked_output_topology_healthy(&config) {
                    apply_linked_output_runtime(Arc::clone(&control), config).await;
                } else {
                    // Re-assert master/trim levels after a Bluetooth reconnect without
                    // restarting services or replacing a healthy combine sink.
                    let refresh = config.clone();
                    let _ = tokio::task::spawn_blocking(move || refresh_linked_output_levels(&refresh)).await;
                }
            }
        }
        tokio::time::sleep(Duration::from_secs(2)).await;
    }
}

async fn sync_selected_physical_output(control: Arc<Mutex<ControlPlane>>) {
    let Ok(identity) = current_physical_output_identity() else {
        return;
    };
    if let Some(codec) = identity.bluetooth_codec.as_deref() {
        eprintln!("AETHERSTREAM_BLUETOOTH_CODEC={codec}");
    }
    let profile = {
        let mut control = control.lock().await;
        if control.state.audio.output_dsp.active_device_id.as_deref()
            == Some(identity.loadout_id.as_str())
        {
            return;
        }
        let profile = control
            .state
            .audio
            .output_dsp
            .profiles
            .get(&identity.loadout_id)
            .cloned()
            .unwrap_or_else(|| {
                let mut profile = OutputDspProfile::factory(identity.device_class);
                profile.name = format!("{} — {}", identity.description, identity.device_class.label());
                profile
            });
        if let Some(db) = &control.dsp_db {
            let _ = db.save_output_dsp_profile(&identity.loadout_id, &profile);
        }
        control
            .state
            .audio
            .output_dsp
            .profiles
            .insert(identity.loadout_id.clone(), profile.clone());
        control.state.audio.output_dsp.active_device_id = Some(identity.loadout_id.clone());
        control.state.revision = control.state.revision.saturating_add(1);
        profile
    };
    push_live_output_dsp(control, identity.loadout_id, profile).await;
}

async fn run_physical_output_watcher(control: Arc<Mutex<ControlPlane>>) {
    let mut last_node = None::<String>;
    loop {
        if let Ok(identity) = current_physical_output_identity() {
            if last_node.as_deref() != Some(identity.node_name.as_str()) {
                last_node = Some(identity.node_name);
                sync_selected_physical_output(Arc::clone(&control)).await;
            }
        }
        tokio::time::sleep(Duration::from_secs(1)).await;
    }
}

async fn push_live_output_dsp(
    control: Arc<Mutex<ControlPlane>>,
    device_id: String,
    profile: aetherstream_core::OutputDspProfile,
) {
    let result = apply_output_dsp_profile(device_id, profile).await;
    let mut control = control.lock().await;
    let health = if result.is_ok() {
        ServiceHealth::Connected
    } else {
        ServiceHealth::Degraded
    };
    if control.state.services.get("audiod") != Some(&health) {
        control.state.services.insert("audiod".into(), health);
        control.registry.set_service_health("audiod", health);
        control.state.revision = control.state.revision.saturating_add(1);
    }
}

async fn begin_provider_login(
    control: Arc<Mutex<ControlPlane>>,
    runtime: Arc<AuthRuntime<LinuxSecretStore>>,
    provider: AuthProvider,
) {
    match provider {
        AuthProvider::Twitch => match runtime.begin_twitch().await {
            Ok((session, connection)) => {
                control.lock().await.project_auth_connection(connection);
                match runtime.complete_twitch(session).await {
                    Ok(connection) => control.lock().await.project_auth_connection(connection),
                    Err(error) => control.lock().await.project_auth_failure(provider, &error),
                }
            }
            Err(error) => control.lock().await.project_auth_failure(provider, &error),
        },
        AuthProvider::Streamlabs => match runtime.begin_streamlabs().await {
            Ok((session, connection)) => {
                control.lock().await.project_auth_connection(connection);
                match runtime.complete_streamlabs(session).await {
                    Ok(connection) => control.lock().await.project_auth_connection(connection),
                    Err(error) => control.lock().await.project_auth_failure(provider, &error),
                }
            }
            Err(error) => control.lock().await.project_auth_failure(provider, &error),
        },
        AuthProvider::StreamElements => match runtime.begin_streamelements().await {
            Ok((session, connection)) => {
                control.lock().await.project_auth_connection(connection);
                match runtime.complete_streamelements(session).await {
                    Ok(connection) => control.lock().await.project_auth_connection(connection),
                    Err(error) => control.lock().await.project_auth_failure(provider, &error),
                }
            }
            Err(error) => control.lock().await.project_auth_failure(provider, &error),
        },
        AuthProvider::BroadcastEngine => {}
    }
}

async fn submit_manual_provider_code(
    control: Arc<Mutex<ControlPlane>>,
    runtime: Arc<AuthRuntime<LinuxSecretStore>>,
    provider: AuthProvider,
    code: String,
) {
    let result = match provider {
        AuthProvider::Streamlabs => runtime.exchange_streamlabs_code(&code).await,
        AuthProvider::StreamElements => runtime.exchange_streamelements_code(&code).await,
        AuthProvider::Twitch | AuthProvider::BroadcastEngine => {
            Err(AuthError::Configuration("manual authorization code is not supported for this provider".into()))
        }
    };
    match result {
        Ok(connection) => control.lock().await.project_auth_connection(connection),
        Err(error) => control.lock().await.project_auth_failure(provider, &error),
    }
}

async fn run_smart_restore(
    control: Arc<Mutex<ControlPlane>>,
    runtime: Arc<AuthRuntime<LinuxSecretStore>>,
) {
    let outcome = runtime.run_smart_restore().await;
    for connection in outcome.connections {
        control.lock().await.project_auth_connection(connection);
    }
    let engine_connection = {
        let control = control.lock().await;
        let mut connection = control
            .state
            .auth
            .connections
            .get(&AuthProvider::BroadcastEngine)
            .cloned()
            .unwrap_or_else(|| aetherstream_core::AccountConnection::disconnected(AuthProvider::BroadcastEngine));
        connection.state = match control.state.services.get("obsd") {
            Some(ServiceHealth::Connected) => AuthConnectionState::Connected,
            Some(ServiceHealth::AuthRequired) => AuthConnectionState::AuthenticationRequired,
            _ => AuthConnectionState::Disconnected,
        };
        connection.status_detail = Some("Broadcast Engine restore checked".into());
        connection
    };
    let mut control = control.lock().await;
    control.project_auth_connection(engine_connection);
    control.set_restore_status(format!(
        "Smart restore: {} connected, {} need attention",
        outcome.restored, outcome.needs_attention
    ));
}

async fn run_auth_action(
    control: Arc<Mutex<ControlPlane>>,
    runtime: Arc<AuthRuntime<LinuxSecretStore>>,
    action: AetherAuthAction,
) {
    match action {
        AetherAuthAction::BeginLogin(provider) => begin_provider_login(control, runtime, provider).await,
        AetherAuthAction::SubmitManualCode { provider, code } => {
            submit_manual_provider_code(control, runtime, provider, code).await;
        }
        AetherAuthAction::Disconnect(provider) => {
            if let Err(error) = runtime.disconnect(provider) {
                control.lock().await.project_auth_failure(provider, &error);
            }
        }
        AetherAuthAction::SetDefault { provider, account } => {
            if let Err(error) = runtime.set_default(provider, account) {
                control.lock().await.project_auth_failure(provider, &error);
            }
        }
        AetherAuthAction::SmartRestore => run_smart_restore(control, runtime).await,
        AetherAuthAction::ConnectBroadcastEngine | AetherAuthAction::DisconnectBroadcastEngine => {}
    }
}

fn session_graph_smoke() -> Result<(), String> {
    let session = BroadcastSession::fixture();
    let mut state = AetherState::default();
    state.services.insert("obs".into(), ServiceHealth::Connected);
    let orchestrator = SessionOrchestrator;
    if !orchestrator.preflight(&session, &state).may_continue() {
        return Err("fixture preflight blocked".into());
    }
    let commands = orchestrator.go_live_commands(&session);
    if commands.is_empty() {
        return Err("go-live command graph is empty".into());
    }
    println!("AETHERSTREAM_SESSION_GRAPH_SMOKE=PASS");
    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    if std::env::args().any(|arg| arg == "--session-graph-smoke") {
        session_graph_smoke().map_err(std::io::Error::other)?;
        return Ok(());
    }

    let path = socket_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
        std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
    }
    if path.exists() {
        std::fs::remove_file(&path)?;
    }

    let listener = UnixListener::bind(&path)?;
    let control = Arc::new(Mutex::new(
        ControlPlane::persistent().map_err(std::io::Error::other)?,
    ));
    sync_selected_physical_output(Arc::clone(&control)).await;
    {
        let control_for_sync = Arc::clone(&control);
        let startup_profile = {
            let control = control.lock().await;
            control
                .state
                .audio
                .output_dsp
                .active_device_id
                .as_ref()
                .and_then(|device_id| {
                    control
                        .state
                        .audio
                        .output_dsp
                        .profiles
                        .get(device_id)
                        .cloned()
                        .map(|profile| (device_id.clone(), profile))
                })
        };
        if let Some((device_id, profile)) = startup_profile {
            tokio::spawn(async move {
                push_live_output_dsp(control_for_sync, device_id, profile).await;
            });
        }
    }
    tokio::spawn(async {
        let _ = run_behringer_system_volume_listener().await;
    });
    {
        let control = Arc::clone(&control);
        tokio::spawn(async move {
            run_physical_output_watcher(control).await;
        });
    }
    {
        let control = Arc::clone(&control);
        tokio::spawn(async move {
            run_linked_output_watcher(control).await;
        });
    }
    let auth_runtime = Arc::new(AuthRuntime::new(
        RuntimeConfig::from_env(),
        LinuxSecretStore,
        auth_state_db_path(),
    ));

    if std::env::var_os("AETHERSTREAM_DISABLE_STARTUP_SMART_RESTORE").is_none() {
        let control = Arc::clone(&control);
        let runtime = Arc::clone(&auth_runtime);
        tokio::spawn(async move {
            run_smart_restore(Arc::clone(&control), Arc::clone(&runtime)).await;
            loop {
                tokio::time::sleep(Duration::from_secs(60 * 60)).await;
                run_smart_restore(Arc::clone(&control), Arc::clone(&runtime)).await;
            }
        });
    }

    loop {
        let (mut stream, _) = listener.accept().await?;
        let control = Arc::clone(&control);
        let auth_runtime = Arc::clone(&auth_runtime);
        tokio::spawn(async move {
            let Ok(hello) = read_envelope::<IpcEnvelope<ClientHello>>(&mut stream).await else {
                return;
            };
            let snapshot = {
                let mut control = control.lock().await;
                control.registry.register(hello.payload.client, hello.payload.pid);
                control.registry.snapshot()
            };
            if write_envelope(&mut stream, &IpcEnvelope::new(snapshot)).await.is_err() {
                return;
            }

            let Ok(request) = read_envelope::<IpcEnvelope<ControlRequest>>(&mut stream).await else {
                return;
            };
            let mut auth_followup = None;
            let mut dsp_followup = None;
            let mut linked_followup = None;
            let response = {
                let mut control = control.lock().await;
                match request.payload {
                    ControlRequest::GetState => ControlResponse::StateSnapshot(Box::new(control.state.clone())),
                    ControlRequest::SubscribeState { since_revision } => {
                        control.registry.subscribe(hello.payload.client, since_revision);
                        match control.subscriptions.update_since(since_revision, &control.state) {
                            SubscriptionUpdate::Snapshot(state) => ControlResponse::StateSnapshot(state),
                            SubscriptionUpdate::Delta(delta) => ControlResponse::StateDelta(delta),
                        }
                    }
                    ControlRequest::DispatchAction(action) => {
                        let id = Uuid::new_v4();
                        let _target = ActionRouter::target(&action);
                        match control.commit_projection(&action) {
                            Ok(()) => {
                                if let AetherStreamAction::Auth(auth_action) = &action {
                                    auth_followup = Some(auth_action.clone());
                                }
                                dsp_followup = match &action {
                                    AetherStreamAction::OutputDspApply { device_id, profile } => {
                                        Some((device_id.clone(), profile.clone()))
                                    }
                                    AetherStreamAction::OutputDspBypass { device_id, .. } => control
                                        .state
                                        .audio
                                        .output_dsp
                                        .profiles
                                        .get(device_id)
                                        .cloned()
                                        .map(|profile| (device_id.clone(), profile)),
                                    _ => None,
                                };
                                if let AetherStreamAction::LinkedOutputConfigure(config) = &action {
                                    linked_followup = Some(config.clone());
                                }
                                ControlResponse::ActionAccepted { id }
                            }
                            Err(reason) => ControlResponse::ActionRejected { id, reason },
                        }
                    }
                }
            };
            if let Some((device_id, profile)) = dsp_followup {
                push_live_output_dsp(Arc::clone(&control), device_id, profile).await;
            }
            if let Some(config) = linked_followup {
                apply_linked_output_runtime(Arc::clone(&control), config).await;
            }
            if let Some(action) = auth_followup {
                let control = Arc::clone(&control);
                let runtime = Arc::clone(&auth_runtime);
                tokio::spawn(async move {
                    run_auth_action(control, runtime, action).await;
                });
            }
            let _ = write_envelope(&mut stream, &IpcEnvelope::new(response)).await;
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn auth_begin_login_projects_safe_shared_state() {
        let mut control = ControlPlane::default();
        control
            .commit_projection(&AetherStreamAction::Auth(AetherAuthAction::BeginLogin(
                AuthProvider::Twitch,
            )))
            .unwrap();
        let connection = control.state.auth.connections.get(&AuthProvider::Twitch).unwrap();
        assert_eq!(connection.state, AuthConnectionState::Connecting);
        assert!(connection.verification_uri.is_none());
        let json = serde_json::to_string(connection).unwrap();
        for forbidden in ["access_token", "refresh_token", "client_secret", "password"] {
            assert!(!json.contains(forbidden));
        }
    }

    #[test]
    fn output_dsp_apply_projects_device_profile() {
        let mut control = ControlPlane::default();
        let profile = aetherstream_core::OutputDspProfile::factory(
            aetherstream_core::OutputDeviceClass::Iem,
        );
        control
            .commit_projection(&AetherStreamAction::OutputDspApply {
                device_id: "alsa-output-iem".into(),
                profile: profile.clone(),
            })
            .unwrap();
        assert_eq!(control.state.revision, 1);
        assert_eq!(
            control.state.audio.output_dsp.profiles.get("alsa-output-iem"),
            Some(&profile)
        );
        assert_eq!(
            control.state.audio.output_dsp.active_device_id.as_deref(),
            Some("alsa-output-iem")
        );
    }

    #[test]
    fn output_dsp_bypass_is_projected_without_losing_profile() {
        let mut control = ControlPlane::default();
        let profile = aetherstream_core::OutputDspProfile::factory(
            aetherstream_core::OutputDeviceClass::ClosedBackHeadphone,
        );
        control
            .commit_projection(&AetherStreamAction::OutputDspApply {
                device_id: "headphones".into(),
                profile,
            })
            .unwrap();
        control
            .commit_projection(&AetherStreamAction::OutputDspBypass {
                device_id: "headphones".into(),
                bypassed: true,
            })
            .unwrap();
        assert!(control.state.audio.output_dsp.profiles["headphones"].bypassed);
        assert_eq!(control.state.revision, 2);
    }

    #[test]
    fn legacy_output_profile_is_migrated_into_hdmi3_loadout() {
        let mut profiles = std::collections::BTreeMap::new();
        let mut profile = aetherstream_core::OutputDspProfile::factory(
            aetherstream_core::OutputDeviceClass::TvSpeaker,
        );
        profile.name = "Living room HDMI".into();
        profiles.insert("@DEFAULT_AUDIO_SINK@".into(), profile.clone());

        let (profiles, active) = normalize_output_dsp_loadout(profiles);
        assert_eq!(active, HDMI3_LOADOUT_ID);
        assert_eq!(profiles.get(HDMI3_LOADOUT_ID), Some(&profile));
    }

    #[test]
    fn hdmi3_loadout_wins_over_legacy_profiles() {
        let mut profiles = std::collections::BTreeMap::new();
        let hdmi3 = aetherstream_core::OutputDspProfile::factory(
            aetherstream_core::OutputDeviceClass::TvSpeaker,
        );
        let legacy = aetherstream_core::OutputDspProfile::factory(
            aetherstream_core::OutputDeviceClass::DesktopSpeaker,
        );
        profiles.insert(HDMI3_LOADOUT_ID.into(), hdmi3.clone());
        profiles.insert("legacy".into(), legacy);

        let (profiles, active) = normalize_output_dsp_loadout(profiles);
        assert_eq!(active, HDMI3_LOADOUT_ID);
        assert_eq!(profiles.get(HDMI3_LOADOUT_ID), Some(&hdmi3));
    }

    #[test]
    fn bluetooth_wonderboom4_identity_uses_bluez_address_and_360_profile() {
        let inspect = r#"node.name = "bluez_output.AA_BB_CC_DD_EE_FF.1"
node.description = "Ultimate Ears WONDERBOOM 4"
api.bluez5.address = "AA:BB:CC:DD:EE:FF"
api.bluez5.codec = "sbc"
audio.channels = "2""#;
        let identity = physical_output_identity_from_inspect(inspect).unwrap();
        assert_eq!(identity.loadout_id, "bluetooth:aa_bb_cc_dd_ee_ff");
        assert_eq!(identity.device_class, OutputDeviceClass::UltimateEarsWonderboom4);
        assert_eq!(identity.bluetooth_codec.as_deref(), Some("sbc"));
    }

    #[test]
    fn hdmi3_identity_stays_on_canonical_hdmi3_loadout() {
        let inspect = r#"node.name = "alsa_output.pci.hdmi-stereo-extra2"
node.description = "HDMI / DisplayPort 3 Output""#;
        let identity = physical_output_identity_from_inspect(inspect).unwrap();
        assert_eq!(identity.loadout_id, HDMI3_LOADOUT_ID);
    }

    #[test]
    fn zero_gain_creates_new_audio_bus_and_revision() {
        let mut control = ControlPlane::default();
        control
            .commit_projection(&AetherStreamAction::AudioGain {
                bus: "Mic".into(),
                gain_db: 0.0,
            })
            .unwrap();
        assert_eq!(control.state.revision, 1);
        assert_eq!(
            control.state.audio.buses.get("Mic").map(|bus| bus.gain_db),
            Some(0.0)
        );
    }
}
