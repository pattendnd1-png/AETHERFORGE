use aetherstream_core::{
    OutputDspProfile, OutputDspRuntimeRequest, OutputDspRuntimeResponse,
};
use aetherstream_ipc::{read_envelope, write_envelope, IpcEnvelope};
use std::path::PathBuf;
use tokio::net::UnixStream;

pub fn output_dsp_runtime_socket_path() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
        PathBuf::from(dir).join("aetherstream/output-dsp.sock")
    } else {
        PathBuf::from(format!(
            "/tmp/aetherstream-{}/output-dsp.sock",
            std::env::var("UID").unwrap_or_else(|_| "user".into())
        ))
    }
}

pub async fn apply_output_dsp_profile(
    device_id: String,
    profile: OutputDspProfile,
) -> Result<u64, String> {
    let mut stream = UnixStream::connect(output_dsp_runtime_socket_path())
        .await
        .map_err(|error| format!("connect audiod output-dsp.sock: {error}"))?;
    write_envelope(
        &mut stream,
        &IpcEnvelope::new(OutputDspRuntimeRequest::Apply {
            device_id,
            profile,
        }),
    )
    .await
    .map_err(|error| error.to_string())?;
    let reply = read_envelope::<IpcEnvelope<OutputDspRuntimeResponse>>(&mut stream)
        .await
        .map_err(|error| error.to_string())?;
    match reply.payload {
        OutputDspRuntimeResponse::Applied { generation, .. } => Ok(generation),
        OutputDspRuntimeResponse::Rejected { reason } => Err(reason),
        OutputDspRuntimeResponse::Status { .. } => {
            Err("audiod returned status to an apply request".into())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn runtime_socket_is_scoped_to_aetherstream() {
        assert!(output_dsp_runtime_socket_path()
            .to_string_lossy()
            .ends_with("aetherstream/output-dsp.sock"));
    }
}
