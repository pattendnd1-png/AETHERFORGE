use aetherstream_audio::{inspect_linked_output_topology, load_linked_output_config, LiveDspPlan, SharedOutputDspWriter, OUTPUT_DSP_SHARED_FILE};
use aetherstream_core::{
    bluetooth_loadout_id, decode_forgehx_mic_packet, OutputDeviceClass, OutputDspProfile,
    OutputDspRuntimeRequest, OutputDspRuntimeResponse, FORGEHX_BRIDGE_PACKET_BYTES,
    HDMI3_LOADOUT_ID, SYSTEM_MICROPHONE_NODE_NAME,
};
use aetherstream_ipc::{read_envelope, write_envelope, IpcEnvelope};
use libspa_sys as spa_sys;
use pipewire as pw;
use pw::{properties::properties, spa};
use rtrb::{Consumer, Producer, RingBuffer};
use spa::param::format::{MediaSubtype, MediaType};
use spa::param::format_utils;
use spa::pod::Pod;
use std::fs;
use std::mem;
use std::os::unix::fs::PermissionsExt;
use std::os::unix::net::UnixDatagram;
use std::path::PathBuf;
use std::process::Command;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};
use tokio::net::UnixListener;

const MANAGED_SOURCE_NAME: &str = SYSTEM_MICROPHONE_NODE_NAME;
const PHYSICAL_MIC_CAPTURE_NAME: &str = "aetherstream.system.microphone.fallback-capture";
const INVALID_NODE_ID: u32 = u32::MAX;
const DEFAULT_RATE: u32 = 48_000;
const DEFAULT_CHANNELS: usize = 2;
const SYSTEM_MIC_RATE: u32 = 48_000;
const SYSTEM_MIC_CHANNELS: usize = 1;
const FORGEHX_BRIDGE_TIMEOUT_MS: u64 = 250;

#[derive(Clone, Debug)]
struct PhysicalSink {
    node_name: String,
    loadout_id: String,
    device_class: OutputDeviceClass,
    bluetooth_address: Option<String>,
    bluetooth_codec: Option<String>,
    rate: u32,
    channels: usize,
}

#[derive(Clone, Debug)]
struct PhysicalSource {
    node_id: u32,
    node_name: String,
    initial_volume: f32,
}

struct MicCaptureData {
    format: spa::param::audio::AudioInfoRaw,
    fallback_tx: Producer<f32>,
}

struct MicSourceData {
    format: spa::param::audio::AudioInfoRaw,
    bridge_rx: Consumer<f32>,
    fallback_rx: Consumer<f32>,
    bridge_active: Arc<AtomicBool>,
}

fn runtime_dir() -> PathBuf {
    if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
        PathBuf::from(dir).join("aetherstream")
    } else {
        PathBuf::from(format!(
            "/tmp/aetherstream-{}",
            std::env::var("UID").unwrap_or_else(|_| "user".into())
        ))
    }
}

fn socket_path() -> PathBuf {
    runtime_dir().join("output-dsp.sock")
}

fn output_dsp_shared_path() -> PathBuf {
    runtime_dir().join(OUTPUT_DSP_SHARED_FILE)
}

fn forgehx_bridge_socket_path() -> PathBuf {
    runtime_dir().join("forgehx-mic.sock")
}

fn forgehx_bridge_active_path() -> PathBuf {
    runtime_dir().join("forgehx-mic.active")
}

fn command_output(args: &[&str]) -> Result<String, String> {
    let output = Command::new("wpctl")
        .args(args)
        .output()
        .map_err(|error| format!("wpctl {:?}: {error}", args))?;
    if !output.status.success() {
        return Err(format!(
            "wpctl {:?} failed: {}",
            args,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout).into_owned())
}

fn parse_node_id(text: &str) -> Option<u32> {
    text.lines().find_map(|line| {
        let trimmed = line.trim();
        let id = trimmed.strip_prefix("id ")?.split(',').next()?.trim();
        id.parse().ok()
    })
}

fn parse_quoted_number<T: std::str::FromStr>(text: &str, key: &str) -> Option<T> {
    text.lines().find_map(|line| {
        if !line.contains(key) {
            return None;
        }
        let (_, value) = line.split_once('=')?;
        value.trim().trim_matches('"').parse().ok()
    })
}

fn parse_quoted_string(text: &str, key: &str) -> Option<String> {
    text.lines().find_map(|line| {
        if !line.contains(key) {
            return None;
        }
        let (_, value) = line.split_once('=')?;
        let value = value.trim().trim_matches('"').trim();
        (!value.is_empty()).then(|| value.to_owned())
    })
}

fn get_volume(node_id: u32) -> Result<f32, String> {
    let output = command_output(&["get-volume", &node_id.to_string()])?;
    output
        .split_whitespace()
        .nth(1)
        .and_then(|value| value.parse().ok())
        .ok_or_else(|| format!("could not parse wpctl volume: {output}"))
}

fn set_volume(node_id: u32, volume: f32) -> Result<(), String> {
    command_output(&[
        "set-volume",
        &node_id.to_string(),
        &format!("{:.6}", volume.clamp(0.0, 1.5)),
    ])
    .map(|_| ())
}

fn set_default_source(node_id: u32) -> Result<(), String> {
    command_output(&["set-default", &node_id.to_string()]).map(|_| ())
}

fn set_pulse_default_source(node_name: &str) -> Result<(), String> {
    let output = Command::new("pactl")
        .args(["set-default-source", node_name])
        .output()
        .map_err(|error| format!("pactl set-default-source: {error}"))?;
    if output.status.success() {
        Ok(())
    } else {
        Err(String::from_utf8_lossy(&output.stderr).trim().to_owned())
    }
}

fn parse_wpctl_list_node_ids(text: &str) -> Vec<u32> {
    text.lines()
        .filter_map(|line| {
            let trimmed = line.trim().trim_start_matches('*').trim();
            let token = trimmed.split_whitespace().next()?.trim_end_matches('.');
            token.parse::<u32>().ok()
        })
        .collect()
}

fn hdmi3_match_score(inspect: &str) -> u32 {
    let lower = inspect.to_ascii_lowercase();
    let mut score = 0_u32;
    for (needle, weight) in [
        ("hdmi3", 120),
        ("hdmi 3", 120),
        ("hdmi / displayport 3", 120),
        ("hdmi-stereo-extra2", 110),
        ("hdmi-output-2", 110),
        ("hdmi 3 output", 100),
        ("displayport 3", 90),
    ] {
        if lower.contains(needle) {
            score = score.max(weight);
        }
    }
    score
}

fn is_bluetooth_sink(inspect: &str, node_name: &str) -> bool {
    node_name.starts_with("bluez_output.")
        || inspect.contains("api.bluez5.address")
        || inspect.contains("api.bluez5.codec")
        || inspect.contains("api.bluez5.profile")
}

fn physical_sink_from_inspect(inspect: &str) -> Result<PhysicalSink, String> {
    let node_name = parse_quoted_string(inspect, "node.name")
        .ok_or_else(|| "wpctl inspect did not return physical output node.name".to_string())?;
    if node_name.starts_with("aetherstream") {
        return Err("refusing to bind output DSP to an AetherStream-created node".into());
    }
    let channels = parse_quoted_number::<usize>(inspect, "audio.channels")
        .unwrap_or(DEFAULT_CHANNELS)
        .clamp(1, 32);
    let rate = parse_quoted_number::<u32>(inspect, "audio.rate")
        .unwrap_or(DEFAULT_RATE)
        .clamp(8_000, 384_000);
    let description = parse_quoted_string(inspect, "node.description")
        .or_else(|| parse_quoted_string(inspect, "device.description"))
        .or_else(|| parse_quoted_string(inspect, "device.product.name"))
        .unwrap_or_else(|| node_name.clone());
    let bluetooth_address = parse_quoted_string(inspect, "api.bluez5.address");
    let bluetooth_codec = parse_quoted_string(inspect, "api.bluez5.codec");
    let bluetooth = is_bluetooth_sink(inspect, &node_name);
    let (loadout_id, device_class) = if bluetooth {
        (
            bluetooth_loadout_id(bluetooth_address.as_deref(), &node_name),
            OutputDeviceClass::for_bluetooth_speaker_name(&description),
        )
    } else if hdmi3_match_score(inspect) >= 90 {
        (HDMI3_LOADOUT_ID.to_owned(), OutputDeviceClass::TvSpeaker)
    } else {
        (
            format!("physical:{}", node_name.replace(|character: char| !character.is_ascii_alphanumeric(), "_")),
            OutputDeviceClass::Custom,
        )
    };
    Ok(PhysicalSink {
        node_name,
        loadout_id,
        device_class,
        bluetooth_address,
        bluetooth_codec,
        rate,
        channels,
    })
}

fn resolve_selected_physical_sink() -> Result<PhysicalSink, String> {
    let inspect = command_output(&["inspect", "@DEFAULT_AUDIO_SINK@"]) ?;
    physical_sink_from_inspect(&inspect)
}

fn resolve_hdmi3_physical_sink() -> Result<PhysicalSink, String> {
    if let Ok(exact_target) = std::env::var("AETHERSTREAM_HDMI3_NODE_NAME") {
        let target = exact_target.trim();
        if !target.is_empty() {
            let listed = command_output(&["list", "audio", "sinks"])?;
            for id in parse_wpctl_list_node_ids(&listed) {
                let inspect = command_output(&["inspect", &id.to_string()])?;
                if parse_quoted_string(&inspect, "node.name").as_deref() == Some(target) {
                    let sink = physical_sink_from_inspect(&inspect)?;
                    if sink.loadout_id == HDMI3_LOADOUT_ID {
                        return Ok(sink);
                    }
                }
            }
            return Err(format!("configured HDMI3 physical node {target:?} is not available; output will not be switched"));
        }
    }

    let listed = command_output(&["list", "audio", "sinks"])?;
    let mut best: Option<(u32, String)> = None;
    for id in parse_wpctl_list_node_ids(&listed) {
        let inspect = command_output(&["inspect", &id.to_string()])?;
        let node_name = parse_quoted_string(&inspect, "node.name").unwrap_or_default();
        if node_name.starts_with("aetherstream") {
            continue;
        }
        let score = hdmi3_match_score(&inspect);
        if score >= 90 && best.as_ref().is_none_or(|(current, _)| score > *current) {
            best = Some((score, inspect));
        }
    }
    if let Some((_, inspect)) = best {
        return physical_sink_from_inspect(&inspect);
    }

    Err(format!(
        "{HDMI3_LOADOUT_ID} physical sink was not found; AetherStream will not switch to another output"
    ))
}

fn resolve_physical_source() -> Result<PhysicalSource, String> {
    let inspect = command_output(&["inspect", "@DEFAULT_AUDIO_SOURCE@"]) ?;
    let node_id = parse_node_id(&inspect)
        .ok_or_else(|| "wpctl inspect did not return the default source node id".to_string())?;
    let node_name = parse_quoted_string(&inspect, "node.name")
        .ok_or_else(|| "wpctl inspect did not return the default source node.name".to_string())?;
    let initial_volume = get_volume(node_id).unwrap_or(1.0);
    Ok(PhysicalSource { node_id, node_name, initial_volume })
}

fn format_pod(rate: u32, channels: usize) -> Vec<u8> {
    let mut audio_info = spa::param::audio::AudioInfoRaw::new();
    audio_info.set_format(spa::param::audio::AudioFormat::F32LE);
    audio_info.set_rate(rate);
    audio_info.set_channels(channels as u32);
    let object = pw::spa::pod::Object {
        type_: spa_sys::SPA_TYPE_OBJECT_Format,
        id: spa_sys::SPA_PARAM_EnumFormat,
        properties: audio_info.into(),
    };
    pw::spa::pod::serialize::PodSerializer::serialize(
        std::io::Cursor::new(Vec::new()),
        &pw::spa::pod::Value::Object(object),
    )
    .expect("serialize F32LE audio format")
    .0
    .into_inner()
}

fn run_forgehx_bridge_receiver(
    mut samples_tx: Producer<f32>,
    bridge_active: Arc<AtomicBool>,
    stop: Arc<AtomicBool>,
) -> Result<(), String> {
    let dir = runtime_dir();
    fs::create_dir_all(&dir).map_err(|error| error.to_string())?;
    fs::set_permissions(&dir, fs::Permissions::from_mode(0o700)).map_err(|error| error.to_string())?;
    let path = forgehx_bridge_socket_path();
    if path.exists() {
        fs::remove_file(&path).map_err(|error| error.to_string())?;
    }
    let socket = UnixDatagram::bind(&path).map_err(|error| format!("bind {}: {error}", path.display()))?;
    socket
        .set_read_timeout(Some(Duration::from_millis(50)))
        .map_err(|error| format!("ForgeHX bridge timeout setup: {error}"))?;
    let mut packet = [0_u8; FORGEHX_BRIDGE_PACKET_BYTES];
    let mut last_valid = None::<Instant>;
    let active_path = forgehx_bridge_active_path();
    let mut was_live = false;
    let _ = fs::remove_file(&active_path);
    while !stop.load(Ordering::Acquire) {
        match socket.recv(&mut packet) {
            Ok(size) => {
                if let Some(frame) = decode_forgehx_mic_packet(&packet[..size]) {
                    for sample in frame.samples {
                        let _ = samples_tx.push(sample);
                    }
                    last_valid = Some(Instant::now());
                    bridge_active.store(true, Ordering::Release);
                }
            }
            Err(error)
                if matches!(
                    error.kind(),
                    std::io::ErrorKind::WouldBlock | std::io::ErrorKind::TimedOut
                ) => {}
            Err(error) => return Err(format!("ForgeHX bridge receive: {error}")),
        }
        let live = last_valid
            .map(|seen| seen.elapsed() <= Duration::from_millis(FORGEHX_BRIDGE_TIMEOUT_MS))
            .unwrap_or(false);
        bridge_active.store(live, Ordering::Release);
        if live != was_live {
            if live {
                let _ = fs::write(&active_path, b"active\n");
            } else {
                let _ = fs::remove_file(&active_path);
            }
            was_live = live;
        }
    }
    bridge_active.store(false, Ordering::Release);
    let _ = fs::remove_file(&active_path);
    let _ = fs::remove_file(path);
    Ok(())
}

fn run_input_pipewire(
    physical_source: PhysicalSource,
    bridge_rx: Consumer<f32>,
    fallback_tx: Producer<f32>,
    fallback_rx: Consumer<f32>,
    bridge_active: Arc<AtomicBool>,
    managed_source_id: Arc<AtomicU32>,
) -> Result<(), pw::Error> {
    pw::init();
    let mainloop = pw::main_loop::MainLoopRc::new(None)?;
    let context = pw::context::ContextRc::new(&mainloop, None)?;
    let core = context.connect_rc(None)?;
    let registry = core.get_registry()?;

    let managed_source_for_registry = Arc::clone(&managed_source_id);
    let _registry_listener = registry
        .add_listener_local()
        .global(move |global| {
            let Some(props) = &global.props else { return; };
            if props.get("node.name") == Some(MANAGED_SOURCE_NAME) {
                managed_source_for_registry.store(global.id, Ordering::Release);
            }
        })
        .register();

    let system_source = pw::stream::StreamRc::new(
        core.clone(),
        "AetherForge system microphone",
        properties! {
            "media.type" => "Audio",
            "media.category" => "Capture",
            "media.role" => "Communication",
            "media.class" => "Audio/Source",
            "node.name" => MANAGED_SOURCE_NAME,
            "node.description" => "AetherForge System Microphone",
            "node.virtual" => "true",
            "node.always-process" => "true",
            "node.pause-on-idle" => "false",
            "audio.rate" => "48000",
            "audio.channels" => "1",
        },
    )?;
    let source_data = MicSourceData {
        format: Default::default(),
        bridge_rx,
        fallback_rx,
        bridge_active,
    };
    let _source_listener = system_source
        .add_local_listener_with_user_data(source_data)
        .param_changed(|_, data, id, param| {
            let Some(param) = param else { return; };
            if id != pw::spa::param::ParamType::Format.as_raw() { return; }
            let Ok((media_type, media_subtype)) = format_utils::parse_format(param) else { return; };
            if media_type != MediaType::Audio || media_subtype != MediaSubtype::Raw { return; }
            let _ = data.format.parse(param);
        })
        .process(|stream, data| {
            let Some(mut buffer) = stream.dequeue_buffer() else { return; };
            let datas = buffer.datas_mut();
            let Some(plane) = datas.first_mut() else { return; };
            let Some(bytes) = plane.data() else { return; };
            let sample_capacity = bytes.len() / mem::size_of::<f32>();
            let use_bridge = data.bridge_active.load(Ordering::Acquire);
            for index in 0..sample_capacity {
                let bridge = data.bridge_rx.pop().ok();
                let fallback = data.fallback_rx.pop().unwrap_or(0.0);
                let sample = if use_bridge { bridge.unwrap_or(fallback) } else { fallback };
                let start = index * 4;
                bytes[start..start + 4].copy_from_slice(&sample.to_le_bytes());
            }
            let chunk = plane.chunk_mut();
            *chunk.offset_mut() = 0;
            *chunk.stride_mut() = mem::size_of::<f32>() as _;
            *chunk.size_mut() = (sample_capacity * mem::size_of::<f32>()) as _;
        })
        .register()?;

    let source_for_capture = system_source.clone();
    let fallback_capture = pw::stream::StreamRc::new(
        core.clone(),
        "AetherForge physical microphone fallback",
        properties! {
            "media.type" => "Audio",
            "media.category" => "Capture",
            "media.role" => "Communication",
            "node.name" => PHYSICAL_MIC_CAPTURE_NAME,
            "node.description" => "AetherForge Physical Microphone Fallback",
            "audio.rate" => "48000",
            "audio.channels" => "1",
        },
    )?;
    let fallback_data = MicCaptureData { format: Default::default(), fallback_tx };
    let _fallback_listener = fallback_capture
        .add_local_listener_with_user_data(fallback_data)
        .param_changed(|_, data, id, param| {
            let Some(param) = param else { return; };
            if id != pw::spa::param::ParamType::Format.as_raw() { return; }
            let Ok((media_type, media_subtype)) = format_utils::parse_format(param) else { return; };
            if media_type != MediaType::Audio || media_subtype != MediaSubtype::Raw { return; }
            let _ = data.format.parse(param);
        })
        .process(move |stream, data| {
            let Some(mut buffer) = stream.dequeue_buffer() else { return; };
            let datas = buffer.datas_mut();
            let Some(plane) = datas.first_mut() else { return; };
            let chunk = plane.chunk();
            let offset = chunk.offset() as usize;
            let size = chunk.size() as usize;
            let Some(bytes) = plane.data() else { return; };
            let end = offset.saturating_add(size).min(bytes.len());
            if offset >= end { return; }
            for raw in bytes[offset..end].chunks_exact(4) {
                let sample = f32::from_le_bytes([raw[0], raw[1], raw[2], raw[3]]);
                let _ = data.fallback_tx.push(sample);
            }
            let _ = source_for_capture.trigger_process();
        })
        .register()?;

    let source_format = format_pod(SYSTEM_MIC_RATE, SYSTEM_MIC_CHANNELS);
    let fallback_format = format_pod(SYSTEM_MIC_RATE, SYSTEM_MIC_CHANNELS);
    let mut source_params = [Pod::from_bytes(&source_format).expect("system mic format pod")];
    let mut fallback_params = [Pod::from_bytes(&fallback_format).expect("fallback mic format pod")];
    system_source.connect(
        spa::utils::Direction::Output,
        None,
        pw::stream::StreamFlags::DRIVER
            | pw::stream::StreamFlags::MAP_BUFFERS
            | pw::stream::StreamFlags::TRIGGER,
        &mut source_params,
    )?;
    fallback_capture.connect(
        spa::utils::Direction::Input,
        Some(physical_source.node_id),
        pw::stream::StreamFlags::AUTOCONNECT
            | pw::stream::StreamFlags::MAP_BUFFERS
            | pw::stream::StreamFlags::RT_PROCESS,
        &mut fallback_params,
    )?;

    mainloop.run();
    Ok(())
}

async fn wait_for_managed_source(managed_source_id: &AtomicU32) -> Result<u32, String> {
    let deadline = Instant::now() + Duration::from_secs(8);
    while Instant::now() < deadline {
        let id = managed_source_id.load(Ordering::Acquire);
        if id != INVALID_NODE_ID { return Ok(id); }
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    Err("AetherStream managed PipeWire source did not publish in time".into())
}

async fn run_control_socket(
    mut shared_writer: SharedOutputDspWriter,
    rate: u32,
    channels: usize,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let dir = runtime_dir();
    fs::create_dir_all(&dir)?;
    fs::set_permissions(&dir, fs::Permissions::from_mode(0o700))?;
    let path = socket_path();
    if path.exists() {
        fs::remove_file(&path)?;
    }
    let listener = UnixListener::bind(&path)?;
    let mut generation = 0_u64;
    let mut active_device_id = None::<String>;

    loop {
        let (mut stream, _) = listener.accept().await?;
        let request = match read_envelope::<IpcEnvelope<OutputDspRuntimeRequest>>(&mut stream).await {
            Ok(request) => request,
            Err(_) => continue,
        };
        let response = match request.payload {
            OutputDspRuntimeRequest::Apply { device_id, profile } => {
                match LiveDspPlan::compile(&profile, rate as f32, channels) {
                    Ok(plan) => {
                        generation = u64::from(shared_writer.publish(&plan));
                        active_device_id = Some(device_id.clone());
                        OutputDspRuntimeResponse::Applied {
                            device_id,
                            generation,
                        }
                    }
                    Err(error) => OutputDspRuntimeResponse::Rejected {
                        reason: error.to_string(),
                    },
                }
            }
            OutputDspRuntimeRequest::Status => OutputDspRuntimeResponse::Status {
                live: true,
                active_device_id: active_device_id.clone(),
                generation,
            },
        };
        let _ = write_envelope(&mut stream, &IpcEnvelope::new(response)).await;
    }
}


fn print_linked_output_topology() -> Result<(), String> {
    let config = load_linked_output_config()?.unwrap_or_default();
    let hdmi = config.hdmi_node_name.as_deref().unwrap_or("");
    let bluetooth = config.bluetooth_node_name.as_deref().unwrap_or("");
    let topology = inspect_linked_output_topology(hdmi, bluetooth)?;
    println!("AETHERSTREAM_LINKED_OUTPUT_CONFIG_ENABLED={}", config.enabled);
    println!("AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT={}", topology.linked_sink_count);
    println!("AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT={}", topology.member_count);
    println!("AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES={}", topology.hdmi_route_count);
    println!("AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES={}", topology.bluetooth_route_count);
    println!("AETHERSTREAM_EXTRANEOUS_VIRTUAL_SINKS={}", topology.extraneous_virtual_sinks);
    println!("AETHERSTREAM_EXTRANEOUS_VIRTUAL_SOURCES={}", topology.extraneous_virtual_sources);
    println!("AETHERSTREAM_DUPLICATE_OUTPUT_ROUTES={}", topology.duplicate_output_routes);
    println!("AETHERSTREAM_ORPHAN_LINKS={}", topology.orphan_links);
    if config.enabled && topology.is_exact() {
        println!("AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY=PASS:EXACT_ONE_SINK_TWO_MEMBERS");
        return Ok(());
    }
    if !topology.has_any_linked_graph() && topology.is_disabled_clean() {
        println!("AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY=PASS:CLEAN_NOT_ACTIVE");
        return Ok(());
    }
    Err(format!("extraneous or incomplete linked-output topology detected: {topology:?}"))
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    if args.iter().any(|arg| arg == "--verify-linked-output-topology") {
        print_linked_output_topology().map_err(std::io::Error::other)?;
        return Ok(());
    }
    let physical = resolve_selected_physical_sink().map_err(std::io::Error::other)?;
    if args.iter().any(|arg| arg == "--print-physical-output-node-name") {
        println!("{}", physical.node_name);
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-physical-output-channels") {
        println!("{}", physical.channels);
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-physical-output-loadout-id") {
        println!("{}", physical.loadout_id);
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-physical-output-class") {
        println!("{}", physical.device_class.label());
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-physical-output-bluetooth-codec") {
        println!("{}", physical.bluetooth_codec.as_deref().unwrap_or("none"));
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-physical-output-bluetooth-address") {
        println!("{}", physical.bluetooth_address.as_deref().unwrap_or("none"));
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-hdmi3-node-name") {
        let hdmi3 = resolve_hdmi3_physical_sink().map_err(std::io::Error::other)?;
        println!("{}", hdmi3.node_name);
        return Ok(());
    }
    if args.iter().any(|arg| arg == "--print-hdmi3-channels") {
        let hdmi3 = resolve_hdmi3_physical_sink().map_err(std::io::Error::other)?;
        println!("{}", hdmi3.channels);
        return Ok(());
    }
    if physical.channels != 2 {
        return Err(std::io::Error::other(format!(
            "physical output internal DSP currently requires stereo audio.channels=2; found {} for {}",
            physical.channels, physical.node_name
        ))
        .into());
    }
    let physical_source = resolve_physical_source().map_err(std::io::Error::other)?;
    let mut shared_writer = SharedOutputDspWriter::open_or_create(&output_dsp_shared_path())?;
    let flat = OutputDspProfile::factory(OutputDeviceClass::Custom);
    let flat_plan = LiveDspPlan::compile(&flat, physical.rate as f32, physical.channels)
        .map_err(std::io::Error::other)?;
    let _ = shared_writer.publish(&flat_plan);

    let mic_fifo_capacity = (SYSTEM_MIC_RATE as usize / 5).max(9_600);
    let (bridge_tx, bridge_rx) = RingBuffer::<f32>::new(mic_fifo_capacity);
    let (fallback_tx, fallback_rx) = RingBuffer::<f32>::new(mic_fifo_capacity);
    let bridge_active = Arc::new(AtomicBool::new(false));
    let bridge_stop = Arc::new(AtomicBool::new(false));
    let bridge_active_for_rx = Arc::clone(&bridge_active);
    let bridge_stop_for_rx = Arc::clone(&bridge_stop);
    let bridge_join = thread::Builder::new()
        .name("aetherstream-forgehx-mic-bridge".into())
        .spawn(move || {
            if let Err(error) = run_forgehx_bridge_receiver(bridge_tx, bridge_active_for_rx, bridge_stop_for_rx) {
                eprintln!("AETHERSTREAM_FORGEHX_BRIDGE=FAIL:{error}");
            }
        })?;

    let output_rate = physical.rate;
    let output_channels = physical.channels;

    let managed_source_id = Arc::new(AtomicU32::new(INVALID_NODE_ID));
    let managed_source_for_thread = Arc::clone(&managed_source_id);
    let bridge_active_for_pw = Arc::clone(&bridge_active);
    let physical_source_for_thread = physical_source.clone();
    thread::Builder::new()
        .name("aetherstream-pipewire-system-mic".into())
        .spawn(move || {
            if let Err(error) = run_input_pipewire(
                physical_source_for_thread,
                bridge_rx,
                fallback_tx,
                fallback_rx,
                bridge_active_for_pw,
                managed_source_for_thread,
            ) {
                eprintln!("AETHERSTREAM_SYSTEM_MIC=FAIL:{error}");
            }
        })?;

    let managed_source = wait_for_managed_source(&managed_source_id)
        .await
        .map_err(std::io::Error::other)?;

    set_volume(managed_source, physical_source.initial_volume).map_err(std::io::Error::other)?;
    set_default_source(managed_source).map_err(std::io::Error::other)?;
    let _ = set_pulse_default_source(MANAGED_SOURCE_NAME);
    tokio::time::sleep(Duration::from_millis(120)).await;
    let _ = set_volume(physical_source.node_id, 1.0);

    let control = tokio::spawn(run_control_socket(shared_writer, output_rate, output_channels));
    #[cfg(unix)]
    {
        let mut terminate = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())?;
        tokio::select! {
            result = tokio::signal::ctrl_c() => { result?; }
            _ = terminate.recv() => {}
        }
    }
    #[cfg(not(unix))]
    tokio::signal::ctrl_c().await?;

    let managed_source_volume = get_volume(managed_source).unwrap_or(physical_source.initial_volume);
    let _ = set_volume(physical_source.node_id, managed_source_volume);
    let _ = set_default_source(physical_source.node_id);
    let _ = set_pulse_default_source(&physical_source.node_name);

    bridge_stop.store(true, Ordering::Release);
    let _ = bridge_join.join();
    control.abort();
    let _ = fs::remove_file(socket_path());
    let _ = fs::remove_file(forgehx_bridge_socket_path());
    let _ = fs::remove_file(forgehx_bridge_active_path());
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_wpctl_default_sink_metadata() {
        let text = r#"id 57, type PipeWire:Interface:Node
    audio.channels = "2"
    audio.rate = "48000"
"#;
        assert_eq!(parse_node_id(text), Some(57));
        assert_eq!(parse_quoted_number::<usize>(text, "audio.channels"), Some(2));
        assert_eq!(parse_quoted_number::<u32>(text, "audio.rate"), Some(48_000));
    }

    #[test]
    fn parses_wpctl_default_source_identity() {
        let text = r#"id 71, type PipeWire:Interface:Node
    node.name = "alsa_input.usb-HyperX-00.mono"
"#;
        assert_eq!(parse_node_id(text), Some(71));
        assert_eq!(parse_quoted_string(text, "node.name").as_deref(), Some("alsa_input.usb-HyperX-00.mono"));
    }
    #[test]
    fn hdmi3_match_accepts_third_hdmi_route_identity() {
        for inspect in [
            r#"node.description = \"HDMI / DisplayPort 3 Output\""#,
            r#"device.profile.name = \"hdmi-stereo-extra2\""#,
            r#"port.name = \"hdmi-output-2\""#,
        ] {
            assert!(hdmi3_match_score(inspect) >= 90, "{inspect}");
        }
    }

    #[test]
    fn wpctl_list_parser_ignores_non_node_lines() {
        let listing = "52\talsa_output.one\n* 61. alsa_output.two\nnot-a-node\n";
        assert_eq!(parse_wpctl_list_node_ids(listing), vec![52, 61]);
    }

    #[test]
    fn bluetooth_wonderboom4_sink_gets_stable_loadout_and_360_class() {
        let inspect = r#"node.name = "bluez_output.AA_BB_CC_DD_EE_FF.1"
node.description = "Ultimate Ears WONDERBOOM 4"
api.bluez5.address = "AA:BB:CC:DD:EE:FF"
api.bluez5.codec = "sbc"
audio.channels = "2"
audio.rate = "48000""#;
        let sink = physical_sink_from_inspect(inspect).unwrap();
        assert_eq!(sink.loadout_id, "bluetooth:aa_bb_cc_dd_ee_ff");
        assert_eq!(sink.device_class, OutputDeviceClass::UltimateEarsWonderboom4);
        assert_eq!(sink.bluetooth_codec.as_deref(), Some("sbc"));
        assert_eq!(sink.channels, 2);
    }

}
