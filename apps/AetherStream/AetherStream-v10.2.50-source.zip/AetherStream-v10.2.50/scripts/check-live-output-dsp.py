#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors = []

def text(rel: str) -> str:
    path = root / rel
    if not path.is_file():
        errors.append(f"missing {rel}")
        return ""
    return path.read_text()

audiod = text("apps/aetherstream-audiod/src/main.rs")
audiod_cargo = text("apps/aetherstream-audiod/Cargo.toml")
live = text("crates/aetherstream-audio/src/live_dsp.rs")
shared = text("crates/aetherstream-audio/src/shared_output_dsp.rs")
plugin = text("crates/aetherstream-dsp-ladspa/src/lib.rs")
plugin_cargo = text("crates/aetherstream-dsp-ladspa/Cargo.toml")
wp = text("packaging/wireplumber/90-aetherstream-hdmi3-internal-dsp.conf.in")
runtime = text("crates/aetherstream-core/src/output_dsp_runtime.rs")
supervisor = text("apps/aetherstream-supervisord/src/output_dsp_runtime.rs")
supervisor_main = text("apps/aetherstream-supervisord/src/main.rs")
app_main = text("apps/aetherstream/src/main.rs")
ui = text("crates/aetherstream-ui/src/app.rs")
tests = text("crates/aetherstream-audio/tests/live_output_dsp.rs")
workspace = text("Cargo.toml")
installer = text("INSTALL-AETHERSTREAM.sh")

for forbidden in [
    "HDMI3_FILTER_INPUT_NAME",
    "HDMI3_FILTER_PLAYBACK_NAME",
    '"filter.smart" => "true"',
    '"media.class" => "Audio/Sink"',
    "fn run_pipewire(",
    "StreamBox::new",
    "aetherstream.dsp.sink",
]:
    if forbidden in audiod:
        errors.append(f"audiod must not construct an output stream: {forbidden}")

for needle in [
    "SharedOutputDspWriter",
    "output_dsp_shared_path",
    "shared_writer.publish(&plan)",
    "--print-hdmi3-node-name",
    "resolve_hdmi3_physical_sink",
]:
    if needle not in audiod:
        errors.append(f"audiod internal output-control contract missing {needle}")

for needle in ['pipewire.workspace = true', 'libspa-sys.workspace = true', 'rtrb.workspace = true']:
    if needle not in audiod_cargo:
        errors.append(f"audiod dependency contract missing {needle}")
for needle in [
    'pipewire = { version = "0.10.1", features = ["v0_3_41"] }',
    '"crates/aetherstream-dsp-ladspa"',
]:
    if needle not in workspace:
        errors.append(f"workspace live DSP contract missing {needle}")
for needle in ['crate-type = ["cdylib", "rlib"]', 'name = "aetherstream_hdmi3_dsp"']:
    if needle not in plugin_cargo:
        errors.append(f"LADSPA crate contract missing {needle}")

for needle in [
    'pub const MAX_LIVE_SECTIONS: usize = 64',
    'sections: [LiveBiquadCoefficients; MAX_LIVE_SECTIONS]',
    'pub struct LiveDspProcessor',
    'pub fn begin_transition',
    'transition_samples_remaining',
    'append_enhancement',
    'append_gaming',
]:
    if needle not in live:
        errors.append(f"live DSP plan missing {needle}")
if 'Mutex' in live or 'RwLock' in live:
    errors.append('live DSP processor must not use blocking locks')
process_start = live.find('pub fn process_sample')
process_end = live.find('\n}\n\nfn append_enhancement', process_start)
process_body = live[process_start:process_end] if process_start >= 0 else ''
for forbidden in ['Vec::', 'Box::', 'Mutex', 'RwLock']:
    if forbidden in process_body:
        errors.append(f"RT sample path contains forbidden {forbidden}")

for needle in [
    "SharedOutputDspWriter",
    "SharedOutputDspReader",
    "OUTPUT_DSP_SHARED_FILE",
    "AtomicU32",
    "Ordering::Acquire",
    "Ordering::Release",
    "snapshot_layout",
]:
    if needle not in shared:
        errors.append(f"shared DSP plan contract missing {needle}")
if 'Mutex' in shared or 'RwLock' in shared:
    errors.append('shared DSP snapshot must not require a blocking lock')

for needle in [
    "aetherstream_hdmi3_dsp_stereo",
    "ladspa_descriptor",
    "LiveDspProcessor",
    "SharedOutputDspReader",
    "AtomicPtr<SharedOutputDspReader>",
    "process_sample(0, left)",
    "process_sample(1, right)",
    "physical-output-internal-dsp.active",
    "run_consumes_published_shared_plan_without_an_output_stream",
]:
    if needle not in plugin:
        errors.append(f"Rust in-process plugin contract missing {needle}")
run_start = plugin.find('unsafe extern "C" fn run(')
run_end = plugin.find('unsafe extern "C" fn deactivate', run_start)
run_body = plugin[run_start:run_end] if run_start >= 0 and run_end > run_start else ''
for forbidden in ["std::fs::", "Unix", "sleep(", "Mutex", "RwLock", "Vec::", "Box::new"]:
    if forbidden in run_body:
        errors.append(f"LADSPA realtime run callback contains forbidden {forbidden}")

for needle in [
    "node.filter-graph.rules",
    "create-filter-graph",
    "type = ladspa",
    "aetherstream_hdmi3_dsp_stereo",
    "__AETHERSTREAM_HDMI3_NODE_NAME__",
]:
    if needle not in wp:
        errors.append(f"WirePlumber internal graph contract missing {needle}")
for forbidden in ["filter.smart", "node.software-dsp.rules", "create-filter =", "node.virtual"]:
    if forbidden in wp:
        errors.append(f"WirePlumber config contains forbidden separate-node mechanism {forbidden}")

for needle in ['OutputDspRuntimeRequest', 'Apply {', 'Status', 'OutputDspRuntimeResponse']:
    if needle not in runtime:
        errors.append(f"typed runtime contract missing {needle}")
for needle in ['output-dsp.sock', 'OutputDspRuntimeRequest::Apply', 'apply_output_dsp_profile']:
    if needle not in supervisor:
        errors.append(f"supervisor runtime bridge missing {needle}")
for needle in ['push_live_output_dsp', 'dsp_followup', 'apply_output_dsp_profile']:
    if needle not in supervisor_main:
        errors.append(f"supervisor live dispatch missing {needle}")
if 'std::thread::sleep(Duration::from_millis(16));' not in app_main:
    errors.append('UI control worker must poll/dispatch at ~60 Hz for live DSP')

for needle in [
    '● LIVE • AUTO-APPLY — valid changes are sent while controls move',
    'auto_apply_output_dsp_action',
    'Auto-save + auto-apply active',
    'bass_edit_dispatches_output_dsp_apply_without_manual_button',
    'clarity_edit_dispatches_output_dsp_apply_without_manual_button',
]:
    if needle not in ui:
        errors.append(f"DragonGlass live editor missing {needle}")
if 'Apply DSP profile' in ui:
    errors.append('manual Apply DSP profile button remains; live DSP must auto-apply')

for needle in [
    'live_bass_boost_measures_in_target_band_without_lifting_presence_band',
    'live_clarity_boost_measures_in_target_band_without_lifting_bass_band',
    'bypass_is_effectively_unity',
    'new_plan_crossfades_instead_of_jumping',
]:
    if needle not in tests:
        errors.append(f"live DSP regression test missing {needle}")

for needle in [
    'LADSPA_DIR="$HOME/.local/lib/aetherstream/ladspa"',
    'libaetherstream_hdmi3_dsp.so',
    '90-aetherstream-hdmi3-internal-dsp.conf',
    'systemctl --user restart wireplumber.service',
]:
    if needle not in installer:
        errors.append(f"installer internal runtime contract missing {needle}")
if 'plugin = "libaetherstream_hdmi3_dsp"' not in wp:
    errors.append('WirePlumber must render the exact user-session Rust DSP plugin path')

if errors:
    print('AETHERSTREAM_LIVE_OUTPUT_DSP_CONTRACT=FAIL')
    for error in errors:
        print(error)
    sys.exit(1)
print('AETHERSTREAM_LIVE_OUTPUT_DSP_CONTRACT=PASS')
