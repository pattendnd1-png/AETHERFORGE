#!/usr/bin/env python3
from pathlib import Path
import re, subprocess, sys, tempfile
root=Path(__file__).resolve().parents[1]
installer=(root/'INSTALL-AETHERSTREAM.sh').read_text()
errors=[]
if 'local required="$1" current="${2:-}" part out="$required"' in installer:
    errors.append('dedupe_colon_path declares out from required in same local statement under set -u')
# behavioral reproduction of the function body actually packaged
m=re.search(r'dedupe_colon_path\(\) \{\n(.*?)\n\}', installer, re.S)
if not m:
    errors.append('dedupe_colon_path function missing')
else:
    script='set -euo pipefail\ndedupe_colon_path() {\n'+m.group(1)+'\n}\ndedupe_colon_path /required "/foo:/required:/bar"\n'
    p=subprocess.run(['bash','-c',script],text=True,capture_output=True)
    if p.returncode != 0:
        errors.append(f'dedupe_colon_path strict-mode runtime failed: {p.stderr.strip() or p.stdout.strip()}')
    elif p.stdout.strip() != '/required,/foo,/bar':
        errors.append(f'dedupe_colon_path output mismatch: {p.stdout.strip()!r}')
if errors:
    for e in errors: print('FAIL:',e)
    sys.exit(1)
print('AETHERSTREAM_V10_2_48_INSTALLER_STRICT_MODE=PASS')
