#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
core = (root / 'crates/aetherstream-core/src/output_dsp.rs').read_text()
errors = []
classifier_start = core.find('pub const fn is_bluetooth_speaker')
classifier_end = core.find('pub const fn label', classifier_start)
classifier = core[classifier_start:classifier_end]
if 'matches!(' not in classifier:
    errors.append('Bluetooth speaker classifier is not using matches! macro')
peq_start = core.find('fn default_parametric_eq_bands()')
peq_end = core.find('fn validate_peq_frequency', peq_start)
peq = core[peq_start:peq_end]
generator_start = core.find('fn peq_log_frequency')
generator_end = core.find('fn default_parametric_eq_bands', generator_start)
generator = core[generator_start:generator_end]
if 'index + 1 >= count' not in generator or 'return PEQ_MAX_FREQUENCY_HZ' not in generator:
    errors.append('PEQ generator does not explicitly pin final band to exact 35 kHz')
if '.clamp(PEQ_MIN_FREQUENCY_HZ, PEQ_MAX_FREQUENCY_HZ)' not in generator:
    errors.append('PEQ generated intermediate frequencies are not boundary-clamped')
set_count_start = core.find('pub fn set_parametric_eq_band_count')
set_count_end = core.find('pub fn normalize_parametric_eq', set_count_start)
if 'peq_log_frequency(index, target)' not in core[set_count_start:set_count_end]:
    errors.append('PEQ band-count expansion bypasses boundary-safe generator')
normalize_start = core.find('pub fn normalize_parametric_eq')
normalize_end = core.find('pub fn validate(', normalize_start)
normalize = core[normalize_start:normalize_end]
if 'band.frequency_hz.clamp(PEQ_MIN_FREQUENCY_HZ, PEQ_MAX_FREQUENCY_HZ)' not in normalize:
    errors.append('legacy PEQ normalization does not clamp tiny boundary overshoots')
if errors:
    print('AETHERSTREAM_V10_2_43_HOST_REGRESSIONS=FAIL')
    for error in errors:
        print(error)
    sys.exit(1)
print('AETHERSTREAM_V10_2_43_HOST_REGRESSIONS=PASS')
print('AETHERSTREAM_CLIPPY_MATCHES_MACRO=PASS')
print('AETHERSTREAM_PEQ_EXACT_BOUNDARIES=PASS')
