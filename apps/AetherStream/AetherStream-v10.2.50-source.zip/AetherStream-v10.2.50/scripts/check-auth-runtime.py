#!/usr/bin/env python3
import pathlib, sys
root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
req = {
 'auth runtime module': ('crates/aetherstream-auth/src/runtime.rs', ['AuthRuntime', 'TwitchDeviceSession', 'StreamlabsOAuthSession', 'StreamElementsAuthSession', 'SmartRestoreOutcome']),
 'auth http module': ('crates/aetherstream-auth/src/http.rs', ['HttpAuthTransport', 'id.twitch.tv/oauth2/device', 'streamlabs.com/api/v2.0/authorize', 'streamlabs.com/api/v2.0/token']),
 'linux secret service': ('crates/aetherstream-storage/src/secret.rs', ['LinuxSecretStore', 'blocking::SecretService', 'EncryptionType::Dh']),
 'supervisor runtime': ('apps/aetherstream-supervisord/src/main.rs', ['AuthRuntime', 'run_smart_restore', 'begin_provider_login', 'submit_manual_provider_code']),
}
errors=[]
for label,(rel,needles) in req.items():
    p=root/rel
    if not p.is_file(): errors.append(f'{label}: missing {rel}'); continue
    text=p.read_text()
    for n in needles:
        if n not in text: errors.append(f'{label}: missing {n!r}')
# secret isolation: production state/core/storage metadata must not define raw secret fields
for rel in ['crates/aetherstream-core/src/action.rs','crates/aetherstream-control/src/state.rs','crates/aetherstream-storage/src/account.rs']:
    p=root/rel
    if p.exists():
        text=p.read_text().lower()
        for bad in ['pub access_token', 'pub refresh_token', 'pub client_secret', 'pub password']:
            if bad in text: errors.append(f'secret isolation: {rel} contains {bad}')
if errors:
    print('AETHERSTREAM_AUTH_RUNTIME_CONTRACT=FAIL')
    for e in errors: print('FAIL',e)
    sys.exit(1)
print('AETHERSTREAM_AUTH_RUNTIME_CONTRACT=PASS')
