#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
errors=[]
theme=(root/'crates/aetherstream-ui/src/theme.rs').read_text()
app=(root/'crates/aetherstream-ui/src/app.rs').read_text()
panels=(root/'crates/aetherstream-ui/src/panels.rs').read_text()
for marker in ['DRAGONGLASS_SURFACE','DRAGONGLASS_CARD','DRAGONGLASS_ACCENT','DRAGONGLASS_CONNECTED','DRAGONGLASS_ATTENTION','DRAGONGLASS_ERROR','DRAGONGLASS_RECORDING','DRAGONGLASS_STREAMING','DRAGONGLASS_LOADING','studio_panel','status_card','state_badge','connection_chip','recording_chip','streaming_chip']:
    if marker not in theme: errors.append(f'DragonGlass visual system missing {marker}')
for marker in ['Preview','Program','Scene rail','Source stack','Transition & broadcast controls','Mixer & DSP','Alert queue','Donations & activity','Media Share','Stream Deck & broadcast health']:
    if marker not in app: errors.append(f'Streamlabs Studio visual state missing {marker}')
start=panels.find('pub const PRIMARY_TABS'); end=panels.find('];',start); block=panels[start:end]
if block.count('"')//2 != 6 or '"OBS"' in block:
    errors.append('visual system must retain exactly six primary tabs with no OBS tab')
if errors:
    print('AETHERSTREAM_VISUAL_SYSTEM_CONTRACT=FAIL'); print('\n'.join(errors)); sys.exit(1)
print('AETHERSTREAM_VISUAL_SYSTEM_CONTRACT=PASS')
