#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"
runtime="$(mktemp -d)"
trap 'kill "${supervisor_pid:-}" 2>/dev/null || true; rm -rf "$runtime"' EXIT
export XDG_RUNTIME_DIR="$runtime"
"$BIN_DIR/aetherstream-supervisord" >"$runtime/supervisor.log" 2>&1 &
supervisor_pid=$!
for _ in {1..60}; do
  [[ -S "$runtime/aetherstream/supervisor.sock" ]] && break
  sleep 0.05
done
[[ -S "$runtime/aetherstream/supervisor.sock" ]]
AETHERSTREAM_CONTROL_ACTION='twitch-shield=true' "$BIN_DIR/aetherstream" >"$runtime/twitch.log"
AETHERSTREAM_CONTROL_ACTION='obs-transition=Fade' "$BIN_DIR/aetherstream" >"$runtime/obs.log"
AETHERSTREAM_CONTROL_ACTION='se-overlay=pause' "$BIN_DIR/aetherstream" >"$runtime/se.log"
AETHERSTREAM_CONTROL_ACTION='sl-media=pause' "$BIN_DIR/aetherstream" >"$runtime/sl.log"
for log in twitch obs se sl; do
  grep -q '^AETHERSTREAM_ACTION=PASS$' "$runtime/$log.log"
done
AETHERSTREAM_CONTROL_GET_STATE=1 "$BIN_DIR/aetherstream" >"$runtime/state.log"
grep -q '^AETHERSTREAM_TWITCH_SHIELD_MODE=true$' "$runtime/state.log"
grep -q '^AETHERSTREAM_OBS_TRANSITION=Fade$' "$runtime/state.log"
grep -q '^AETHERSTREAM_SE_QUEUE_PAUSED=true$' "$runtime/state.log"
grep -q '^AETHERSTREAM_SL_MEDIA_PAUSED=true$' "$runtime/state.log"
echo "AETHERSTREAM_PROVIDER_OPERATIONS_SMOKE=PASS"
