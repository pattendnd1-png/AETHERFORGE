#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
AETHERSTREAM_DOWNLOADS_DIR="$tmp" bash "$ROOT/INSTALL-AETHERSTREAM.sh" --self-test-stage-sequence >"$tmp/stdout" 2>"$tmp/stderr"
verify="$tmp/AetherStream-v10.2.50-VERIFY.txt"
[[ -f "$verify" ]] || { echo 'AETHERSTREAM_INSTALLER_STAGE_RUNTIME=FAIL:verify-file-missing'; exit 1; }
grep -q '^AETHERSTREAM_INSTALLER_STAGE=release-build$' "$verify" || { echo 'AETHERSTREAM_INSTALLER_STAGE_RUNTIME=FAIL:last-stage'; cat "$verify"; exit 1; }
grep -q '^AETHERSTREAM_INSTALLER_STAGE_STARTED=.' "$verify" || { echo 'AETHERSTREAM_INSTALLER_STAGE_RUNTIME=FAIL:timestamp'; exit 1; }
grep -q '^AETHERSTREAM_VERIFY=RUNNING$' "$verify" || { echo 'AETHERSTREAM_INSTALLER_STAGE_RUNTIME=FAIL:status'; exit 1; }
[[ -f "$tmp/AetherStream-v10.2.50-INSTALL.log" ]] || { echo 'AETHERSTREAM_INSTALLER_STAGE_RUNTIME=FAIL:install-log'; exit 1; }
echo 'AETHERSTREAM_INSTALLER_STAGE_RUNTIME=PASS'
