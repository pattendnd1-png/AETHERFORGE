#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
core=(root/'crates/aetherstream-core/src/output_dsp.rs').read_text()
lib=(root/'crates/aetherstream-core/src/lib.rs').read_text()
audiod=(root/'apps/aetherstream-audiod/src/main.rs').read_text()
superv=(root/'apps/aetherstream-supervisord/src/main.rs').read_text()
ui=(root/'crates/aetherstream-ui/src/app.rs').read_text()
wp=(root/'packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in').read_text()
installer=(root/'INSTALL-AETHERSTREAM.sh').read_text()
required_classes=[
'BluetoothPortableSpeaker','Bluetooth360Speaker','BluetoothStereoPortableSpeaker',
'BluetoothDesktopSpeaker','BluetoothBookshelfSpeaker','BluetoothSpeaker2_0','BluetoothSpeaker2_1',
'BluetoothSoundbar','BluetoothSoundbarSubwoofer','BluetoothTvSpeaker','BluetoothSmartSpeaker',
'BluetoothPartySpeaker','BluetoothOutdoorSpeaker','BluetoothPaSpeaker','BluetoothMultiSpeaker',
'UltimateEarsWonderboom4']
missing=[c for c in required_classes if c not in core]
if missing:
 print('MISSING_CLASSES='+','.join(missing)); sys.exit(1)
for needle in [
 'Ultimate Ears WONDERBOOM 4 — 360° Bluetooth speaker',
 'for_bluetooth_speaker_name', 'is_bluetooth_speaker', 'bluetooth_loadout_id']:
 if needle not in core and needle not in lib:
  print('MISSING_CORE='+needle); sys.exit(1)
for alias in ['wonderboom 4','ue wonderboom 4','ultimate ears wonderboom 4']:
 if alias not in core.lower(): print('MISSING_ALIAS='+alias); sys.exit(1)
for needle in ['resolve_selected_physical_sink','api.bluez5.address','api.bluez5.codec','--print-physical-output-loadout-id']:
 if needle not in audiod: print('MISSING_AUDIOD='+needle); sys.exit(1)
for needle in ['run_physical_output_watcher','bluetooth_loadout_id','@DEFAULT_AUDIO_SINK@']:
 if needle not in superv: print('MISSING_SUPERVISOR='+needle); sys.exit(1)
if '"node.name" = "~bluez_output.*"' not in wp:
 print('MISSING_BLUEZ_RULE'); sys.exit(1)
for forbidden in ['wpctl set-default @DEFAULT_AUDIO_SINK@','set_default_sink','aetherstream.dsp.sink']:
 if forbidden in audiod or forbidden in installer:
  print('FORBIDDEN_OUTPUT_SWITCH='+forbidden); sys.exit(1)
if 'PHYSICAL OUTPUT • NO OUTPUT SWITCHING' not in ui:
 print('MISSING_GENERIC_UI'); sys.exit(1)
print('AETHERSTREAM_BLUETOOTH_SPEAKER_CLASSES=PASS')
print('AETHERSTREAM_WONDERBOOM4_360_PROFILE=PASS')
print('AETHERSTREAM_BLUETOOTH_PHYSICAL_OUTPUT=PASS')
print('AETHERSTREAM_BLUETOOTH_AUTO_SWITCHING=OFF')
