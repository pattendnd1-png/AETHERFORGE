#!/usr/bin/env bash
set -euo pipefail
cargo test -p aetherstream-auth twitch_device_response_uses_provider_field_names
cargo test -p aetherstream-auth oauth_scope_accepts_array_or_space_delimited_text
cargo test -p aetherstream-auth runtime_config_never_contains_client_secret_fields
cargo test -p aetherstream-storage debug_output_redacts_secret_bytes
python3 scripts/check-auth-runtime.py .
python3 scripts/check-secret-isolation.py
printf 'AETHERSTREAM_AUTH_RUNTIME_SMOKE=PASS\n'
