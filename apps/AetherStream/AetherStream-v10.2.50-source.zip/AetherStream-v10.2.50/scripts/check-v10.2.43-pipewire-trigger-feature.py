#!/usr/bin/env python3
from pathlib import Path
import tomllib

root = Path(__file__).resolve().parents[1]
data = tomllib.loads((root / "Cargo.toml").read_text())
pipewire = data["workspace"]["dependencies"].get("pipewire")
errors = []
if not isinstance(pipewire, dict):
    errors.append("workspace pipewire dependency must declare explicit features")
else:
    if pipewire.get("version") != "0.10.1":
        errors.append(f"unexpected pipewire version: {pipewire.get('version')!r}")
    features = set(pipewire.get("features", []))
    if "v0_3_41" not in features:
        errors.append("pipewire feature v0_3_41 is required for StreamFlags::TRIGGER and transitively trigger_process")

main = (root / "apps/aetherstream-audiod/src/main.rs").read_text()
for required in ["trigger_process()", "StreamFlags::TRIGGER"]:
    if required not in main:
        errors.append(f"audiod trigger-driven mic graph missing {required}")

if errors:
    print("AETHERSTREAM_PIPEWIRE_TRIGGER_FEATURE=FAIL")
    for error in errors:
        print(f"ERROR={error}")
    raise SystemExit(1)
print("AETHERSTREAM_PIPEWIRE_TRIGGER_FEATURE=PASS")
