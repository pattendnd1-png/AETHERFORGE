#!/usr/bin/env bash
set -euo pipefail
BIN="${1:-target/release/aetherstream-audiod}"
RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/aetherstream"
DSP_SOCKET="$RUNTIME_DIR/output-dsp.sock"
FORGEHX_SOCKET="$RUNTIME_DIR/forgehx-mic.sock"
FORGEHX_ACTIVE="$RUNTIME_DIR/forgehx-mic.active"
LOG="${TMPDIR:-/tmp}/aetherstream-audiod-system-smoke.log"

node_name() {
  wpctl inspect "$1" 2>/dev/null | awk -F= '/node.name/{v=$2; gsub(/^[[:space:]"]+|[[:space:]"]+$/, "", v); print v; exit}'
}

BEFORE_SINK_NAME="$(node_name @DEFAULT_AUDIO_SINK@)"
BEFORE_SOURCE_NAME="$(node_name @DEFAULT_AUDIO_SOURCE@)"
[[ -n "$BEFORE_SINK_NAME" && -n "$BEFORE_SOURCE_NAME" ]] || { echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=FAIL missing-default-device'; exit 1; }
[[ "$BEFORE_SINK_NAME" != aetherstream.* ]] || { echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=FAIL output-default-not-physical'; exit 1; }
[[ "$BEFORE_SOURCE_NAME" != aetherstream.system.microphone ]] || { echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=FAIL source-already-managed'; exit 1; }

"$BIN" >"$LOG" 2>&1 &
pid=$!
cleanup() {
  if kill -0 "$pid" 2>/dev/null; then
    kill -INT "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT

ok=0
for _ in $(seq 1 100); do
  NOW_SINK_NAME="$(node_name @DEFAULT_AUDIO_SINK@)"
  NOW_SOURCE_NAME="$(node_name @DEFAULT_AUDIO_SOURCE@)"
  if [[ -S "$DSP_SOCKET" && -S "$FORGEHX_SOCKET" ]] \
     && [[ "$NOW_SINK_NAME" == "$BEFORE_SINK_NAME" ]] \
     && [[ "$NOW_SOURCE_NAME" == 'aetherstream.system.microphone' ]]; then
    ok=1; break
  fi
  kill -0 "$pid" 2>/dev/null || break
  sleep 0.1
done
[[ "$ok" -eq 1 ]] || { cat "$LOG" >&2 || true; echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=FAIL physical-output-or-system-mic'; exit 1; }

python3 - "$FORGEHX_SOCKET" <<'PYBRIDGE'
import socket, struct, sys
path=sys.argv[1]
header=bytearray(32)
header[:8]=b"AFXHXM01"
header[8:10]=struct.pack("<H",1)
header[12:16]=struct.pack("<I",48000)
header[16:18]=struct.pack("<H",1)
header[18:20]=struct.pack("<H",480)
header[20:28]=struct.pack("<Q",1)
payload=bytes(header)+struct.pack("<480f", *([0.125]*480))
s=socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
s.sendto(payload,path)
PYBRIDGE
bridge_seen=0
for _ in $(seq 1 20); do
  [[ -f "$FORGEHX_ACTIVE" ]] && { bridge_seen=1; break; }
  sleep 0.05
done
[[ "$bridge_seen" -eq 1 ]] || { echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=FAIL forgehx-frame-not-accepted'; exit 1; }

kill -INT "$pid"
wait "$pid"
trap - EXIT
restored=0
for _ in $(seq 1 50); do
  NOW_SINK_NAME="$(node_name @DEFAULT_AUDIO_SINK@)"
  NOW_SOURCE_NAME="$(node_name @DEFAULT_AUDIO_SOURCE@)"
  if [[ "$NOW_SINK_NAME" == "$BEFORE_SINK_NAME" && "$NOW_SOURCE_NAME" == "$BEFORE_SOURCE_NAME" ]]; then
    restored=1; break
  fi
  sleep 0.1
done
[[ "$restored" -eq 1 ]] || { echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=FAIL restore'; exit 1; }
echo 'AETHERSTREAM_SYSTEM_AUDIO_RUNTIME=PASS'
