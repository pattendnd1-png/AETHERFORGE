from pathlib import Path
import sys
text = Path('INSTALL-AETHERSTREAM.sh').read_text()
required = [
    'INSTALL_LOG="$OUT_DIR/AetherStream-v${VERSION}-INSTALL.log"',
    'AETHERSTREAM_INSTALLER_STAGE_STARTED=',
    'set_stage() {',
    'pacman -Q "$package"',
    'set_stage "dependency-check"',
    'set_stage "dependency-install"',
    'set_stage "release-build"',
    'set_stage "physical-output-resolution"',
    'set_stage "dsp-plugin-install"',
    'set_stage "wireplumber-config"',
    'set_stage "wireplumber-restart"',
    'set_stage "host-verification"',
    'set_stage "runtime-install"',
    'set_stage "service-enable"',
    'set_stage "complete"',
    '--self-test-stage-sequence',
]
missing = [s for s in required if s not in text]
if missing:
    print('AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS=FAIL')
    for item in missing:
        print('MISSING=' + item)
    sys.exit(1)
print('AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS=PASS')
