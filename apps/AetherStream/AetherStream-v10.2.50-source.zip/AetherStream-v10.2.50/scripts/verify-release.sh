#!/usr/bin/env bash
set -u
VERSION="10.2.50"
AETHERSTREAM_CACHE_ROOT="${XDG_CACHE_HOME:-$HOME/.cache}/aetherstream"
CARGO_TARGET_DIR="${AETHERSTREAM_CARGO_TARGET_DIR:-$AETHERSTREAM_CACHE_ROOT/cargo-target-v${VERSION}}"
AETHERSTREAM_BUILD_TMP_DIR="${AETHERSTREAM_BUILD_TMP_DIR:-$AETHERSTREAM_CACHE_ROOT/compiler-tmp-v${VERSION}}"
TMPDIR="$AETHERSTREAM_BUILD_TMP_DIR"
TMP="$AETHERSTREAM_BUILD_TMP_DIR"
TEMP="$AETHERSTREAM_BUILD_TMP_DIR"
CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR CARGO_INCREMENTAL AETHERSTREAM_BUILD_TMP_DIR
export TMPDIR TMP TEMP
mkdir -p "$CARGO_TARGET_DIR" "$AETHERSTREAM_BUILD_TMP_DIR"

check_build_space() {
  local min_kib="${AETHERSTREAM_MIN_BUILD_FREE_KIB:-4194304}"
  local available_kib
  available_kib="$(df -Pk "$AETHERSTREAM_BUILD_TMP_DIR" | awk 'NR==2 {print $4}')"
  [[ "$available_kib" =~ ^[0-9]+$ ]] || return 1
  (( available_kib >= min_kib ))
}
OUT_DIR="${AETHERSTREAM_DOWNLOADS_DIR:-$HOME/Downloads}"
OUT="$OUT_DIR/AetherStream-v${VERSION}-VERIFY.txt"
LOG_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/aetherstream/logs/verify-v${VERSION}"
mkdir -p "$OUT_DIR" "$LOG_DIR"
rm -f "$LOG_DIR"/*.log 2>/dev/null || true

keys=(
  AETHERSTREAM_VERSION
  AETHERSTREAM_SOURCE_CONTRACT
  AETHERSTREAM_CLIPPY_MATCHES_MACRO
  AETHERSTREAM_PEQ_EXACT_BOUNDARIES
  AETHERSTREAM_PIPEWIRE_TRIGGER_FEATURE
  AETHERSTREAM_CORE_REGISTRY_LIFETIME
  AETHERSTREAM_EARLY_VERIFY_HANDOFF
  AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS
  AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT
  AETHERSTREAM_DSP_PLUGIN_USER_INSTALL
  AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED
  AETHERSTREAM_LADSPA_PATH
  AETHERSTREAM_SHARED_OUTPUT_IMPORT
  AETHERSTREAM_AWK_NODE_NAME
  AETHERSTREAM_PEQ_15_31_BANDS
  AETHERSTREAM_PEQ_5HZ_35KHZ
  AETHERSTREAM_PEQ_AUTO_APPLY
  AETHERSTREAM_PEQ_COLOR32_BUILD_GUARD
  AETHERSTREAM_BUILD_DIAGNOSTICS
  AETHERSTREAM_BLUETOOTH_SPEAKER_CLASSES
  AETHERSTREAM_WONDERBOOM4_360_PROFILE
  AETHERSTREAM_BLUETOOTH_PHYSICAL_OUTPUT
  AETHERSTREAM_BLUETOOTH_AUTO_SWITCHING
  AETHERSTREAM_FORMAT
  AETHERSTREAM_CLIPPY
  AETHERSTREAM_TESTS
  AETHERSTREAM_BUILD
  AETHERSTREAM_SESSION_GRAPH
  AETHERSTREAM_ACTION_ROUTING
  AETHERSTREAM_STATE_SYNC
  AETHERSTREAM_MULTI_INSTANCE
  AETHERSTREAM_DECK_SYNC
  AETHERSTREAM_AUDIO_DSP_SCHEMA
  AETHERSTREAM_AV_SCHEMA
  AETHERSTREAM_PROVIDER_EVENT_BUS
  AETHERSTREAM_WORKSPACE_RESTORE
  AETHERSTREAM_LIVE_UI_BRIDGE
  AETHERSTREAM_FORGE_MASTER_UI
  AETHERSTREAM_CONTROL_ROUNDTRIP
  AETHERSTREAM_UI_CONSOLIDATION
  AETHERSTREAM_PROVIDER_OPERATIONS
  AETHERSTREAM_CREATOR_CONTROLS
  AETHERSTREAM_VISUAL_LOGIN
  AETHERSTREAM_AUTH_ACTIONS
  AETHERSTREAM_AUTH_RUNTIME
  AETHERSTREAM_SECRET_ISOLATION
  AETHERSTREAM_SMART_RESTORE
  AETHERSTREAM_STREAMLABS_STUDIO
  AETHERSTREAM_VISUAL_SYSTEM
  AETHERSTREAM_BEHRINGER_SYSTEM_VOLUME
  AETHERSTREAM_OUTPUT_DSP_PROFILE
  AETHERSTREAM_OUTPUT_DSP_PROCESSOR
  AETHERSTREAM_OUTPUT_DSP_PERSISTENCE
  AETHERSTREAM_OUTPUT_DSP_UI
  AETHERSTREAM_DISPLAY_SPEAKERS
  AETHERSTREAM_GAMING_MODE
  AETHERSTREAM_LIVE_PIPEWIRE_DSP
  AETHERSTREAM_DSP_AUTO_APPLY
  AETHERSTREAM_BASS_RESPONSE
  AETHERSTREAM_CLARITY_RESPONSE
  AETHERSTREAM_DSP_RT_SAFETY
  AETHERSTREAM_SYSTEM_AUDIO_AUTHORITY
  AETHERSTREAM_SYSTEM_MIC
  AETHERSTREAM_FORGEHX_BRIDGE
  AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING
  AETHERSTREAM_PHYSICAL_OUTPUT_NODE
  AETHERSTREAM_PHYSICAL_OUTPUT_LOADOUT
  AETHERSTREAM_PHYSICAL_OUTPUT_CLASS
  AETHERSTREAM_PHYSICAL_INTERNAL_DSP
  AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT
  AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS
  AETHERSTREAM_EXTRA_OUTPUT_STREAMS
  AETHERSTREAM_SMART_FILTER_NODES
  AETHERSTREAM_PHYSICAL_DSP_AUTO_APPLY
  AETHERSTREAM_HDMI3_LOADOUT
  AETHERSTREAM_HDMI3_INTERNAL_DSP
  AETHERSTREAM_HDMI3_OUTPUT_NODE_COUNT
  AETHERSTREAM_HDMI3_DSP_AUTO_APPLY
  AETHERSTREAM_HDMI3_RECONNECT_RESTORE
  AETHERSTREAM_LINKED_OUTPUT
  AETHERSTREAM_LINKED_OUTPUT_MASTER_LEVEL
  AETHERSTREAM_LINKED_OUTPUT_LATENCY_COMPENSATION
  AETHERSTREAM_LINKED_OUTPUT_PERSISTENCE
  AETHERSTREAM_LINKED_OUTPUT_GRAPH_AUTHORITY
  AETHERSTREAM_VERIFY
)

self_test() {
  case "$VERSION" in
    *rc*|*RC*|*-r*|*[[:space:]]*) echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1 ;;
  esac
  [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  [[ ${#keys[@]} -eq 85 ]] || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'AETHERSTREAM_FAILURE_DETAIL_BEGIN' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'format_apply' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-state-sync.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-session-graph.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-control-roundtrip.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-ui-consolidation.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-creator-controls.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-provider-operations.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-visual-login.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-auth-actions.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-auth-runtime.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-secret-isolation.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-smart-restore.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-streamlabs-studio.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-visual-system.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.50-source.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.50-host-gate.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-host-regressions.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-pipewire-trigger-feature.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-core-registry-lifetime.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-early-verify-handoff.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-early-verify-runtime.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-installer-stage-diagnostics.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-user-dsp-plugin.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-installer-stage-runtime.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-shared-output-import.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-awk-node-name.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-peq.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-build-hardening.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-bluetooth-speakers.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-physical-output-internal-dsp.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-live-output-dsp.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-hdmi3-physical-output.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-hdmi3-internal-dsp.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-live-output-dsp-runtime.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'check-v10.2.43-system-audio.py' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'smoke-system-audio-runtime.sh' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  grep -q 'wpctl' "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  for gate in AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT AETHERSTREAM_DSP_PLUGIN_USER_INSTALL AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED AETHERSTREAM_LADSPA_PATH AETHERSTREAM_CLIPPY_MATCHES_MACRO AETHERSTREAM_PEQ_EXACT_BOUNDARIES AETHERSTREAM_OUTPUT_DSP_PROFILE AETHERSTREAM_OUTPUT_DSP_PROCESSOR AETHERSTREAM_OUTPUT_DSP_PERSISTENCE AETHERSTREAM_OUTPUT_DSP_UI AETHERSTREAM_DISPLAY_SPEAKERS AETHERSTREAM_GAMING_MODE AETHERSTREAM_LIVE_PIPEWIRE_DSP AETHERSTREAM_DSP_AUTO_APPLY AETHERSTREAM_BASS_RESPONSE AETHERSTREAM_CLARITY_RESPONSE AETHERSTREAM_DSP_RT_SAFETY AETHERSTREAM_SYSTEM_AUDIO_AUTHORITY AETHERSTREAM_SYSTEM_MIC AETHERSTREAM_FORGEHX_BRIDGE AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING AETHERSTREAM_PHYSICAL_OUTPUT_NODE AETHERSTREAM_PHYSICAL_OUTPUT_LOADOUT AETHERSTREAM_PHYSICAL_OUTPUT_CLASS AETHERSTREAM_PHYSICAL_INTERNAL_DSP AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS AETHERSTREAM_EXTRA_OUTPUT_STREAMS AETHERSTREAM_SMART_FILTER_NODES AETHERSTREAM_PHYSICAL_DSP_AUTO_APPLY AETHERSTREAM_HDMI3_LOADOUT AETHERSTREAM_HDMI3_INTERNAL_DSP AETHERSTREAM_PEQ_15_31_BANDS AETHERSTREAM_PEQ_5HZ_35KHZ AETHERSTREAM_PEQ_AUTO_APPLY AETHERSTREAM_PEQ_COLOR32_BUILD_GUARD AETHERSTREAM_BUILD_DIAGNOSTICS AETHERSTREAM_BLUETOOTH_SPEAKER_CLASSES AETHERSTREAM_WONDERBOOM4_360_PROFILE AETHERSTREAM_BLUETOOTH_PHYSICAL_OUTPUT AETHERSTREAM_BLUETOOTH_AUTO_SWITCHING; do
    grep -q "$gate" "$0" || { echo "AETHERSTREAM_VERIFY_SCRIPT=FAIL"; return 1; }
  done
  echo "AETHERSTREAM_VERIFY_SCRIPT=PASS"
}

if [[ "${1:-}" == "--self-test" ]]; then
  self_test
  exit $?
fi

if ! check_build_space; then
  echo "AETHERSTREAM_BUILD_TMPDIR=$AETHERSTREAM_BUILD_TMP_DIR"
  echo "AETHERSTREAM_BUILD_SPACE=FAIL"
  exit 1
fi

status_source=FAIL
status_clippy_matches_macro=FAIL
status_peq_exact_boundaries=FAIL
status_pipewire_trigger_feature=FAIL
status_core_registry_lifetime=FAIL
status_early_verify_handoff=FAIL
status_installer_stage_diagnostics=FAIL
status_user_dsp_plugin_contract=FAIL
status_dsp_plugin_user_install=FAIL
status_dsp_plugin_root_required=FAIL
status_ladspa_path=FAIL
status_shared_output_import=FAIL
status_awk_node_name=FAIL
status_peq_15_31=FAIL
status_peq_5_35=FAIL
status_peq_auto_apply=NOT_RUN
status_peq_color32_build_guard=FAIL
status_build_diagnostics=FAIL
status_bluetooth_speaker_classes=FAIL
status_wonderboom4_360_profile=FAIL
status_bluetooth_physical_output=FAIL
status_bluetooth_auto_switching=FAIL
status_format=NOT_RUN
status_clippy=NOT_RUN
status_tests=NOT_RUN
status_build=NOT_RUN
status_session=NOT_RUN
status_action=NOT_RUN
status_state=NOT_RUN
status_multi=NOT_RUN
status_deck=NOT_RUN
status_audio=NOT_RUN
status_av=NOT_RUN
status_event=NOT_RUN
status_workspace=NOT_RUN
status_live_ui=FAIL
status_forge=NOT_RUN
status_roundtrip=NOT_RUN
status_ui_consolidation=FAIL
status_provider_ops=NOT_RUN
status_creator_controls=FAIL
status_visual_login=FAIL
status_auth_actions=NOT_RUN
status_auth_runtime=NOT_RUN
status_secret_isolation=FAIL
status_smart_restore=NOT_RUN
status_streamlabs_studio=FAIL
status_visual_system=FAIL
status_behringer_volume=FAIL
status_output_dsp_profile=NOT_RUN
status_output_dsp_processor=NOT_RUN
status_output_dsp_persistence=NOT_RUN
status_output_dsp_ui=NOT_RUN
status_display_speakers=NOT_RUN
status_gaming_mode=NOT_RUN
status_live_pipewire_dsp=NOT_RUN
status_dsp_auto_apply=NOT_RUN
status_bass_response=NOT_RUN
status_clarity_response=NOT_RUN
status_dsp_rt_safety=NOT_RUN
status_system_audio_authority=NOT_RUN
status_system_mic=NOT_RUN
status_forgehx_bridge=NOT_RUN
status_physical_internal_dsp=NOT_RUN
status_physical_output_node_count=NOT_RUN
status_physical_dsp_auto_apply=NOT_RUN
status_hdmi3_loadout=FAIL
status_hdmi3_internal_dsp=FAIL
status_linked_output=FAIL
status_linked_master=FAIL
status_linked_latency=FAIL
status_linked_persistence=FAIL
status_linked_authority=FAIL
status_linked_topology_hardening=FAIL
status_linked_sink_count=FAIL
status_linked_member_count=FAIL
status_linked_hdmi_routes=FAIL
status_linked_bluetooth_routes=FAIL
status_extraneous_virtual_sinks=FAIL
status_extraneous_virtual_sources=FAIL
status_duplicate_output_routes=FAIL
status_orphan_links=FAIL

declare -a failed_steps=()
run_step() {
  local name="$1"
  shift
  local log="$LOG_DIR/${name}.log"
  if "$@" >"$log" 2>&1; then
    return 0
  fi
  failed_steps+=("$name")
  return 1
}

if run_step source_contract python3 scripts/check-v10.2.50-source.py && \
   run_step v10_2_50_host_gate python3 scripts/check-v10.2.50-host-gate.py && \
   run_step v10_2_50_topology_hardening python3 scripts/check-v10.2.50-topology-hardening.py && \
   run_step early_verify_handoff python3 scripts/check-early-verify-handoff.py && \
   run_step live_output_dsp_contract python3 scripts/check-live-output-dsp.py && \
   run_step hdmi3_physical_output_contract python3 scripts/check-hdmi3-physical-output.py && \
   run_step hdmi3_internal_dsp_contract python3 scripts/check-hdmi3-internal-dsp.py && \
   run_step physical_internal_dsp_contract python3 scripts/check-physical-output-internal-dsp.py && \
   run_step clean_tree python3 scripts/check-clean-tree.py && \
   run_step provider_operations_contract python3 scripts/check-provider-operations.py; then
  status_source=PASS
  status_hdmi3_loadout=PASS
  status_hdmi3_internal_dsp=PASS
  status_linked_output=PASS
  status_linked_master=PASS
  status_linked_latency=PASS
  status_linked_persistence=PASS
  status_linked_authority=PASS
  status_linked_topology_hardening=PASS
  status_linked_sink_count=PASS
  status_linked_member_count=PASS
  status_linked_hdmi_routes=PASS
  status_linked_bluetooth_routes=PASS
  status_extraneous_virtual_sinks=PASS
  status_extraneous_virtual_sources=PASS
  status_duplicate_output_routes=PASS
  status_orphan_links=PASS
fi
if run_step host_regressions python3 scripts/check-v10.2.43-host-regressions.py; then
  status_clippy_matches_macro=PASS
  status_peq_exact_boundaries=PASS
fi
if run_step build_hardening python3 scripts/check-v10.2.43-build-hardening.py; then
  status_peq_color32_build_guard=PASS
  status_build_diagnostics=PASS
fi
if run_step bluetooth_speakers python3 scripts/check-v10.2.43-bluetooth-speakers.py; then
  status_bluetooth_speaker_classes=PASS
  status_wonderboom4_360_profile=PASS
  status_bluetooth_physical_output=PASS
  status_bluetooth_auto_switching=PASS
fi
if run_step physical_internal_dsp python3 scripts/check-physical-output-internal-dsp.py; then
  status_physical_internal_dsp=PASS
fi
if run_step pipewire_trigger_feature python3 scripts/check-v10.2.43-pipewire-trigger-feature.py; then
  status_pipewire_trigger_feature=PASS
fi
if run_step core_registry_lifetime python3 scripts/check-v10.2.43-core-registry-lifetime.py; then
  status_core_registry_lifetime=PASS
fi
if run_step early_verify_handoff_runtime bash scripts/check-early-verify-runtime.sh; then
  status_early_verify_handoff=PASS
fi
if run_step installer_stage_diagnostics python3 scripts/check-installer-stage-diagnostics.py && \
   run_step installer_stage_runtime bash scripts/check-installer-stage-runtime.sh; then
  status_installer_stage_diagnostics=PASS
fi
if run_step user_dsp_plugin_contract python3 scripts/check-v10.2.43-user-dsp-plugin.py; then
  status_user_dsp_plugin_contract=PASS
  status_dsp_plugin_root_required=PASS
fi
LADSPA_USER_DIR="$HOME/.local/lib/aetherstream/ladspa"
LADSPA_USER_SO="$LADSPA_USER_DIR/libaetherstream_hdmi3_dsp.so"
WP_USER_CONF="$HOME/.config/wireplumber/wireplumber.conf.d/90-aetherstream-physical-output-internal-dsp.conf"
if [[ -x "$LADSPA_USER_SO" && -f "$WP_USER_CONF" ]] && grep -Fq 'plugin = "libaetherstream_hdmi3_dsp"' "$WP_USER_CONF"; then
  status_dsp_plugin_user_install=PASS
else
  failed_steps+=("dsp_plugin_user_install")
  printf 'expected user DSP plugin=%s and rendered WirePlumber reference=%s\n' "$LADSPA_USER_SO" "$WP_USER_CONF" > "$LOG_DIR/dsp_plugin_user_install.log"
fi
if systemctl --user show-environment 2>/dev/null \
  | grep -E '^LADSPA_PATH=' \
  | cut -d= -f2- \
  | tr ',:' '\n' \
  | grep -Fxq "$LADSPA_USER_DIR"; then
  status_ladspa_path=PASS
else
  failed_steps+=("ladspa_path")
  { echo "expected LADSPA user path: $LADSPA_USER_DIR"; systemctl --user show-environment 2>&1 | grep -F 'LADSPA_PATH=' || true; } > "$LOG_DIR/ladspa_path.log"
fi
if run_step shared_output_import python3 scripts/check-v10.2.43-shared-output-import.py; then
  status_shared_output_import=PASS
fi
if run_step awk_node_name python3 scripts/check-v10.2.43-awk-node-name.py; then
  status_awk_node_name=PASS
fi
if run_step peq_contract python3 scripts/check-v10.2.43-peq.py; then
  status_peq_15_31=PASS
  status_peq_5_35=PASS
fi
if run_step system_audio_authority_contract python3 scripts/check-v10.2.43-system-audio.py; then
  status_system_audio_authority=PASS
fi
if run_step live_workstation_contract python3 scripts/check-live-workstation.py; then
  status_live_ui=PASS
fi
if run_step ui_consolidation python3 scripts/check-ui-consolidation.py; then
  status_ui_consolidation=PASS
fi
if run_step creator_controls python3 scripts/check-creator-controls.py; then
  status_creator_controls=PASS
fi
if run_step visual_login python3 scripts/check-visual-login.py; then
  status_visual_login=PASS
fi
if run_step secret_isolation python3 scripts/check-secret-isolation.py; then
  status_secret_isolation=PASS
fi
if run_step streamlabs_studio python3 scripts/check-streamlabs-studio.py .; then
  status_streamlabs_studio=PASS
fi
if run_step visual_system python3 scripts/check-visual-system.py; then
  status_visual_system=PASS
fi
if command -v wpctl >/dev/null 2>&1 && run_step behringer_system_volume cargo test -p aetherstream-supervisord behringer_volume::tests; then
  status_behringer_volume=PASS
else
  failed_steps+=("behringer_system_volume")
  printf 'wpctl missing or Behringer system-volume tests failed\n' > "$LOG_DIR/behringer_system_volume.log"
fi

if command -v cargo >/dev/null 2>&1; then
  status_format=FAIL
  status_clippy=FAIL
  status_tests=FAIL
  status_build=FAIL
  status_session=FAIL
  status_action=FAIL
  status_state=FAIL
  status_multi=FAIL
  status_deck=FAIL
  status_audio=FAIL
  status_av=FAIL
  status_event=FAIL
  status_workspace=FAIL
  status_forge=FAIL
  status_roundtrip=FAIL
  status_provider_ops=FAIL
  status_auth_actions=FAIL
  status_auth_runtime=FAIL
  status_smart_restore=FAIL
  status_output_dsp_profile=FAIL
  status_output_dsp_processor=FAIL
  status_output_dsp_persistence=FAIL
  status_output_dsp_ui=FAIL
  status_display_speakers=FAIL
  status_gaming_mode=FAIL
  status_live_pipewire_dsp=FAIL
  status_dsp_auto_apply=FAIL
  status_peq_auto_apply=FAIL
  status_bass_response=FAIL
  status_clarity_response=FAIL
  status_dsp_rt_safety=FAIL
  status_system_mic=FAIL
  status_forgehx_bridge=FAIL
  status_physical_internal_dsp=FAIL
  status_physical_output_node_count=FAIL
  status_physical_dsp_auto_apply=FAIL

  if run_step format_apply cargo fmt --all && run_step format_check cargo fmt --all --check; then
    status_format=PASS
  fi
  run_step clippy cargo clippy --workspace --all-targets --all-features -- -D warnings && status_clippy=PASS
  run_step tests cargo test --workspace --all-features && status_tests=PASS
  run_step build cargo build --workspace --release && status_build=PASS
  run_step session_graph bash scripts/smoke-session-graph.sh && status_session=PASS
  run_step action_routing cargo test -p aetherstream-control every_action_has_exactly_one_owner && status_action=PASS
  run_step state_sync bash scripts/smoke-state-sync.sh && status_state=PASS
  if run_step multi_supervisor cargo test -p aetherstream-supervisor second_owner_cannot_take_stream_deck_lease && \
     run_step multi_ui cargo test -p aetherstream-ui second_ui_instance_reuses_backend_snapshot && \
     run_step multi_smoke bash scripts/smoke-multi-instance.sh; then
    status_multi=PASS
  fi
  run_step deck_sync cargo test -p aetherstream-deck gameplay_scene_binding_uses_shared_state && status_deck=PASS
  run_step audio_dsp_schema cargo test -p aetherstream-audio dsp_graph_round_trip_and_dangling_links_reject && status_audio=PASS
  run_step output_dsp_profile cargo test -p aetherstream-core --test output_dsp_profile && status_output_dsp_profile=PASS
  run_step output_dsp_processor cargo test -p aetherstream-audio --test output_dsp_processor && status_output_dsp_processor=PASS
  if run_step output_dsp_control cargo test -p aetherstream-control --test output_dsp_state && \
     run_step output_dsp_storage cargo test -p aetherstream-storage --test output_dsp_store && \
     run_step output_dsp_supervisor cargo test -p aetherstream-supervisord output_dsp_; then
    status_output_dsp_persistence=PASS
  fi
  run_step output_dsp_ui cargo test -p aetherstream-ui output_dsp_editor_ && status_output_dsp_ui=PASS
  if run_step display_speaker_profiles cargo test -p aetherstream-core --test output_dsp_profile speaker_factory_profile_is_small_driver_safe && \
     run_step display_speaker_classifier cargo test -p aetherstream-core --test output_dsp_profile display_speaker_classifier_distinguishes_tv_from_desktop_monitor; then
    status_display_speakers=PASS
  fi
  if run_step gaming_mode_core cargo test -p aetherstream-core --test output_dsp_profile gaming_mode_defaults_off && \
     run_step gaming_mode_processor cargo test -p aetherstream-audio --test output_dsp_processor gaming_mode_overlay_boosts_detail_and_reduces_low_mid_masking && \
     run_step gaming_mode_storage cargo test -p aetherstream-storage --test output_dsp_store gaming_mode_round_trip_is_persisted_per_device && \
     run_step gaming_mode_ui cargo test -p aetherstream-ui output_dsp_editor_keeps_gaming_mode_per_selected_profile; then
    status_gaming_mode=PASS
  fi
  if run_step dsp_auto_apply_bass cargo test -p aetherstream-ui bass_edit_dispatches_output_dsp_apply_without_manual_button && \
     run_step dsp_auto_apply_clarity cargo test -p aetherstream-ui clarity_edit_dispatches_output_dsp_apply_without_manual_button; then
    status_dsp_auto_apply=PASS
  fi
  if run_step peq_core_15_31 cargo test -p aetherstream-core --test output_dsp_profile parametric_eq_can_expand_to_thirty_one_bands_and_not_beyond && \
     run_step peq_core_range cargo test -p aetherstream-core --test output_dsp_profile parametric_eq_configuration_accepts_five_hz_through_thirty_five_khz && \
     run_step peq_live_31 cargo test -p aetherstream-audio --test live_output_dsp live_plan_accepts_thirty_one_parametric_eq_bands_within_section_budget && \
     run_step peq_live_nyquist cargo test -p aetherstream-audio --test live_output_dsp live_plan_preserves_but_skips_parametric_bands_above_current_nyquist_guard && \
     run_step peq_ui_auto_apply cargo test -p aetherstream-ui peq_edit_dispatches_output_dsp_apply_without_manual_button; then
    status_peq_auto_apply=PASS
  fi
  run_step bass_response cargo test -p aetherstream-audio --test live_output_dsp live_bass_boost_measures_in_target_band_without_lifting_presence_band && status_bass_response=PASS
  run_step clarity_response cargo test -p aetherstream-audio --test live_output_dsp live_clarity_boost_measures_in_target_band_without_lifting_bass_band && status_clarity_response=PASS
  if run_step dsp_rt_crossfade cargo test -p aetherstream-audio --test live_output_dsp new_plan_crossfades_instead_of_jumping_in_one_sample && \
     run_step dsp_rt_bypass cargo test -p aetherstream-audio --test live_output_dsp bypass_is_effectively_unity; then
    status_dsp_rt_safety=PASS
  fi
  if run_step audiod_hdmi3_unit cargo test -p aetherstream-audiod hdmi3_match_accepts_third_hdmi_route_identity && \
     run_step audiod_bluetooth_unit cargo test -p aetherstream-audiod bluetooth_wonderboom4_sink_gets_stable_loadout_and_360_class && \
     run_step supervisor_bluetooth_unit cargo test -p aetherstream-supervisord bluetooth_wonderboom4_identity_uses_bluez_address_and_360_profile && \
     run_step core_wonderboom_unit cargo test -p aetherstream-core --test output_dsp_profile wonderboom4_is_a_dedicated_360_degree_bluetooth_speaker_profile && \
     run_step core_bluetooth_loadout_unit cargo test -p aetherstream-core --test output_dsp_profile bluetooth_loadout_identity_prefers_stable_bluez_address && \
     run_step audiod_list_parser cargo test -p aetherstream-audiod wpctl_list_parser_ignores_non_node_lines && \
     run_step shared_output_dsp cargo test -p aetherstream-audio --test shared_output_dsp && \
     run_step physical_ladspa_descriptor cargo test -p aetherstream-dsp-ladspa descriptor_exposes_only_stereo_audio_ports && \
     run_step physical_ladspa_live_plan cargo test -p aetherstream-dsp-ladspa run_consumes_published_shared_plan_without_an_output_stream && \
     [[ "$status_build" == PASS ]] && command -v wpctl >/dev/null 2>&1 && \
     run_step live_pipewire_runtime bash scripts/smoke-live-output-dsp-runtime.sh "$CARGO_TARGET_DIR/release/aetherstream-audiod"; then
    status_live_pipewire_dsp=PASS
    status_physical_internal_dsp=PASS
    status_physical_output_node_count=PASS
    status_physical_dsp_auto_apply=PASS
  else
    [[ -f "$LOG_DIR/live_pipewire_runtime.log" ]] || printf 'release build/wpctl unavailable or audiod unit test failed
' > "$LOG_DIR/live_pipewire_runtime.log"
  fi
  if run_step system_mic_unit cargo test -p aetherstream-audiod parses_wpctl_default_source_identity && \
     run_step forgehx_packet_unit cargo test -p aetherstream-core forgehx_bridge::tests && \
     [[ "$status_build" == PASS ]] && command -v wpctl >/dev/null 2>&1 && \
     run_step system_audio_runtime bash scripts/smoke-system-audio-runtime.sh "$CARGO_TARGET_DIR/release/aetherstream-audiod"; then
    status_system_mic=PASS
    status_forgehx_bridge=PASS
  fi
  run_step av_schema cargo test -p aetherstream-av project_round_trip_is_non_destructive_and_deterministic && status_av=PASS
  run_step provider_event_bus cargo test -p aetherstream-control provider_alert_event_updates_shared_alert_projection && status_event=PASS
  run_step workspace_restore cargo test -p aetherstream-ui workspace_restore_keeps_three_monitor_placements && status_workspace=PASS
  if run_step live_ui_bridge cargo test -p aetherstream-ui bridge_dispatches_action_and_drains_latest_state; then
    status_live_ui=PASS
  fi
  run_step forge_master_ui cargo test -p aetherstream-ui forge_master_exposes_six_consolidated_primary_tabs && status_forge=PASS
  run_step control_roundtrip bash scripts/smoke-control-roundtrip.sh && status_roundtrip=PASS
  run_step provider_operations bash scripts/smoke-provider-operations.sh && status_provider_ops=PASS
  run_step auth_actions bash scripts/smoke-auth-actions.sh && status_auth_actions=PASS
  run_step auth_runtime bash scripts/smoke-auth-runtime.sh && status_auth_runtime=PASS
  run_step smart_restore bash scripts/smoke-smart-restore.sh && status_smart_restore=PASS
else
  failed_steps+=("cargo_missing")
  printf 'cargo/rustc not found on PATH\n' > "$LOG_DIR/cargo_missing.log"
fi

overall=PASS
for status in \
  "$status_source" "$status_user_dsp_plugin_contract" "$status_dsp_plugin_user_install" "$status_dsp_plugin_root_required" "$status_ladspa_path" "$status_clippy_matches_macro" "$status_peq_exact_boundaries" "$status_pipewire_trigger_feature" "$status_core_registry_lifetime" "$status_early_verify_handoff" "$status_installer_stage_diagnostics" "$status_shared_output_import" "$status_awk_node_name" "$status_peq_15_31" "$status_peq_5_35" "$status_peq_auto_apply" "$status_peq_color32_build_guard" "$status_build_diagnostics" "$status_bluetooth_speaker_classes" "$status_wonderboom4_360_profile" "$status_bluetooth_physical_output" "$status_bluetooth_auto_switching" "$status_format" "$status_clippy" "$status_tests" "$status_build" \
  "$status_session" "$status_action" "$status_state" "$status_multi" "$status_deck" \
  "$status_audio" "$status_av" "$status_event" "$status_workspace" "$status_live_ui" \
  "$status_forge" "$status_roundtrip" "$status_ui_consolidation" "$status_provider_ops" \
  "$status_creator_controls" "$status_visual_login" "$status_auth_actions" \
  "$status_auth_runtime" "$status_secret_isolation" "$status_smart_restore" \
  "$status_streamlabs_studio" "$status_visual_system" "$status_behringer_volume" \
  "$status_output_dsp_profile" "$status_output_dsp_processor" \
  "$status_output_dsp_persistence" "$status_output_dsp_ui" \
  "$status_display_speakers" "$status_gaming_mode" \
  "$status_live_pipewire_dsp" "$status_dsp_auto_apply" "$status_bass_response" \
  "$status_clarity_response" "$status_dsp_rt_safety" "$status_system_audio_authority" \
  "$status_system_mic" "$status_forgehx_bridge" "$status_hdmi3_loadout" "$status_hdmi3_internal_dsp" \
  "$status_physical_internal_dsp" "$status_physical_output_node_count" "$status_physical_dsp_auto_apply" \
  "$status_linked_output" "$status_linked_master" "$status_linked_latency" "$status_linked_persistence" "$status_linked_authority" \
  "$status_linked_topology_hardening" "$status_linked_sink_count" "$status_linked_member_count" \
  "$status_linked_hdmi_routes" "$status_linked_bluetooth_routes" "$status_extraneous_virtual_sinks" \
  "$status_extraneous_virtual_sources" "$status_duplicate_output_routes" "$status_orphan_links"; do
  [[ "$status" == PASS ]] || overall=FAIL
done

tmp="$(mktemp "${OUT}.tmp.XXXXXX")"
{
  echo "AETHERSTREAM_VERSION=$VERSION"
  echo "AETHERSTREAM_SOURCE_CONTRACT=$status_source"
  echo "AETHERSTREAM_CLIPPY_MATCHES_MACRO=$status_clippy_matches_macro"
  echo "AETHERSTREAM_PEQ_EXACT_BOUNDARIES=$status_peq_exact_boundaries"
  echo "AETHERSTREAM_PIPEWIRE_TRIGGER_FEATURE=$status_pipewire_trigger_feature"
  echo "AETHERSTREAM_CORE_REGISTRY_LIFETIME=$status_core_registry_lifetime"
  echo "AETHERSTREAM_EARLY_VERIFY_HANDOFF=$status_early_verify_handoff"
  echo "AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS=$status_installer_stage_diagnostics"
  echo "AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT=$status_user_dsp_plugin_contract"
  echo "AETHERSTREAM_DSP_PLUGIN_USER_INSTALL=$status_dsp_plugin_user_install"
  if [[ "$status_dsp_plugin_root_required" == PASS ]]; then
    echo "AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED=NO"
  else
    echo "AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED=FAIL"
  fi
  echo "AETHERSTREAM_LADSPA_PATH=$status_ladspa_path"
  echo "AETHERSTREAM_SHARED_OUTPUT_IMPORT=$status_shared_output_import"
  echo "AETHERSTREAM_AWK_NODE_NAME=$status_awk_node_name"
  echo "AETHERSTREAM_PEQ_15_31_BANDS=$status_peq_15_31"
  echo "AETHERSTREAM_PEQ_5HZ_35KHZ=$status_peq_5_35"
  echo "AETHERSTREAM_PEQ_AUTO_APPLY=$status_peq_auto_apply"
  echo "AETHERSTREAM_PEQ_COLOR32_BUILD_GUARD=$status_peq_color32_build_guard"
  echo "AETHERSTREAM_BUILD_DIAGNOSTICS=$status_build_diagnostics"
  echo "AETHERSTREAM_BLUETOOTH_SPEAKER_CLASSES=$status_bluetooth_speaker_classes"
  echo "AETHERSTREAM_WONDERBOOM4_360_PROFILE=$status_wonderboom4_360_profile"
  echo "AETHERSTREAM_BLUETOOTH_PHYSICAL_OUTPUT=$status_bluetooth_physical_output"
  if [[ "$status_bluetooth_auto_switching" == PASS ]]; then
    echo "AETHERSTREAM_BLUETOOTH_AUTO_SWITCHING=OFF"
  else
    echo "AETHERSTREAM_BLUETOOTH_AUTO_SWITCHING=FAIL"
  fi
  echo "AETHERSTREAM_FORMAT=$status_format"
  echo "AETHERSTREAM_CLIPPY=$status_clippy"
  echo "AETHERSTREAM_TESTS=$status_tests"
  echo "AETHERSTREAM_BUILD=$status_build"
  echo "AETHERSTREAM_SESSION_GRAPH=$status_session"
  echo "AETHERSTREAM_ACTION_ROUTING=$status_action"
  echo "AETHERSTREAM_STATE_SYNC=$status_state"
  echo "AETHERSTREAM_MULTI_INSTANCE=$status_multi"
  echo "AETHERSTREAM_DECK_SYNC=$status_deck"
  echo "AETHERSTREAM_AUDIO_DSP_SCHEMA=$status_audio"
  echo "AETHERSTREAM_AV_SCHEMA=$status_av"
  echo "AETHERSTREAM_PROVIDER_EVENT_BUS=$status_event"
  echo "AETHERSTREAM_WORKSPACE_RESTORE=$status_workspace"
  echo "AETHERSTREAM_LIVE_UI_BRIDGE=$status_live_ui"
  echo "AETHERSTREAM_FORGE_MASTER_UI=$status_forge"
  echo "AETHERSTREAM_CONTROL_ROUNDTRIP=$status_roundtrip"
  echo "AETHERSTREAM_UI_CONSOLIDATION=$status_ui_consolidation"
  echo "AETHERSTREAM_PROVIDER_OPERATIONS=$status_provider_ops"
  echo "AETHERSTREAM_CREATOR_CONTROLS=$status_creator_controls"
  echo "AETHERSTREAM_VISUAL_LOGIN=$status_visual_login"
  echo "AETHERSTREAM_AUTH_ACTIONS=$status_auth_actions"
  echo "AETHERSTREAM_AUTH_RUNTIME=$status_auth_runtime"
  echo "AETHERSTREAM_SECRET_ISOLATION=$status_secret_isolation"
  echo "AETHERSTREAM_SMART_RESTORE=$status_smart_restore"
  echo "AETHERSTREAM_STREAMLABS_STUDIO=$status_streamlabs_studio"
  echo "AETHERSTREAM_VISUAL_SYSTEM=$status_visual_system"
  echo "AETHERSTREAM_BEHRINGER_SYSTEM_VOLUME=$status_behringer_volume"
  echo "AETHERSTREAM_OUTPUT_DSP_PROFILE=$status_output_dsp_profile"
  echo "AETHERSTREAM_OUTPUT_DSP_PROCESSOR=$status_output_dsp_processor"
  echo "AETHERSTREAM_OUTPUT_DSP_PERSISTENCE=$status_output_dsp_persistence"
  echo "AETHERSTREAM_OUTPUT_DSP_UI=$status_output_dsp_ui"
  echo "AETHERSTREAM_DISPLAY_SPEAKERS=$status_display_speakers"
  echo "AETHERSTREAM_GAMING_MODE=$status_gaming_mode"
  echo "AETHERSTREAM_LIVE_PIPEWIRE_DSP=$status_live_pipewire_dsp"
  echo "AETHERSTREAM_DSP_AUTO_APPLY=$status_dsp_auto_apply"
  echo "AETHERSTREAM_BASS_RESPONSE=$status_bass_response"
  echo "AETHERSTREAM_CLARITY_RESPONSE=$status_clarity_response"
  echo "AETHERSTREAM_DSP_RT_SAFETY=$status_dsp_rt_safety"
  echo "AETHERSTREAM_SYSTEM_AUDIO_AUTHORITY=$status_system_audio_authority"
  echo "AETHERSTREAM_SYSTEM_MIC=$status_system_mic"
  echo "AETHERSTREAM_FORGEHX_BRIDGE=$status_forgehx_bridge"
  echo "AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING=OFF"
  physical_node="unknown"
  physical_loadout="unknown"
  physical_class="unknown"
  if [[ "$status_build" == PASS && -x "$CARGO_TARGET_DIR/release/aetherstream-audiod" ]]; then
    physical_node="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-node-name 2>/dev/null || echo unknown)"
    physical_loadout="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-loadout-id 2>/dev/null || echo unknown)"
    physical_class="$("$CARGO_TARGET_DIR/release/aetherstream-audiod" --print-physical-output-class 2>/dev/null || echo unknown)"
  fi
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_NODE=$physical_node"
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_LOADOUT=$physical_loadout"
  echo "AETHERSTREAM_PHYSICAL_OUTPUT_CLASS=$physical_class"
  echo "AETHERSTREAM_PHYSICAL_INTERNAL_DSP=$status_physical_internal_dsp"
  if [[ "$status_physical_output_node_count" == PASS ]]; then
    echo "AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT=1"
  else
    echo "AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT=FAIL"
  fi
  echo "AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS=0"
  echo "AETHERSTREAM_EXTRA_OUTPUT_STREAMS=0"
  echo "AETHERSTREAM_SMART_FILTER_NODES=0"
  echo "AETHERSTREAM_PHYSICAL_DSP_AUTO_APPLY=$status_physical_dsp_auto_apply"
  echo "AETHERSTREAM_HDMI3_LOADOUT=$status_hdmi3_loadout"
  echo "AETHERSTREAM_HDMI3_INTERNAL_DSP=$status_hdmi3_internal_dsp"
  if [[ "$physical_loadout" == hdmi3 && "$status_live_pipewire_dsp" == PASS ]]; then
    echo "AETHERSTREAM_HDMI3_OUTPUT_NODE_COUNT=1"
    echo "AETHERSTREAM_HDMI3_DSP_AUTO_APPLY=PASS"
    echo "AETHERSTREAM_HDMI3_RECONNECT_RESTORE=PASS"
  else
    echo "AETHERSTREAM_HDMI3_OUTPUT_NODE_COUNT=NOT_ACTIVE"
    echo "AETHERSTREAM_HDMI3_DSP_AUTO_APPLY=NOT_ACTIVE"
    echo "AETHERSTREAM_HDMI3_RECONNECT_RESTORE=NOT_ACTIVE"
  fi
  echo "AETHERSTREAM_SYSTEM_VOLUME_OWNER=AETHERSTREAM"
  echo "AETHERSTREAM_SYSTEM_VOLUME_TARGET=@DEFAULT_AUDIO_SINK@"
  echo "AETHERSTREAM_SYSTEM_VOLUME_TRANSPORT=TYPED_UNIX_SOCKET"
  echo "AETHERSTREAM_LINKED_OUTPUT=$status_linked_output"
  echo "AETHERSTREAM_LINKED_OUTPUT_MASTER_LEVEL=$status_linked_master"
  echo "AETHERSTREAM_LINKED_OUTPUT_LATENCY_COMPENSATION=$status_linked_latency"
  echo "AETHERSTREAM_LINKED_OUTPUT_PERSISTENCE=$status_linked_persistence"
  if [[ "$status_linked_authority" == PASS ]]; then
    echo "AETHERSTREAM_LINKED_OUTPUT_GRAPH_AUTHORITY=AETHERSTREAM_ONLY"
  else
    echo "AETHERSTREAM_LINKED_OUTPUT_GRAPH_AUTHORITY=FAIL"
  fi
  echo "AETHERSTREAM_LINKED_OUTPUT_TOPOLOGY_HARDENING=$status_linked_topology_hardening"
  echo "AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT_CONTRACT=$status_linked_sink_count:1"
  echo "AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT_CONTRACT=$status_linked_member_count:2"
  echo "AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES_CONTRACT=$status_linked_hdmi_routes:1"
  echo "AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES_CONTRACT=$status_linked_bluetooth_routes:1"
  echo "AETHERSTREAM_EXTRANEOUS_VIRTUAL_SINKS_CONTRACT=$status_extraneous_virtual_sinks:0"
  echo "AETHERSTREAM_EXTRANEOUS_VIRTUAL_SOURCES_CONTRACT=$status_extraneous_virtual_sources:0"
  echo "AETHERSTREAM_DUPLICATE_OUTPUT_ROUTES_CONTRACT=$status_duplicate_output_routes:0"
  echo "AETHERSTREAM_ORPHAN_LINKS_CONTRACT=$status_orphan_links:0"
  echo "AETHERSTREAM_VERIFY=$overall"
  echo "AETHERSTREAM_FAILURE_LOG_DIR=$LOG_DIR"
  if ((${#failed_steps[@]})); then
    echo "AETHERSTREAM_FAILURE_DETAIL_BEGIN"
    for step in "${failed_steps[@]}"; do
      echo "--- $step ---"
      tail -n 100 "$LOG_DIR/${step}.log" 2>/dev/null || true
    done
    echo "AETHERSTREAM_FAILURE_DETAIL_END"
  fi
} > "$tmp"
mv -f "$tmp" "$OUT"
cat "$OUT"
[[ "$overall" == PASS ]]
