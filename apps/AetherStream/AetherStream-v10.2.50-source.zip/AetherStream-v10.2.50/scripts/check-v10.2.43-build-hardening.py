#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
ui=(root/'crates/aetherstream-ui/src/app.rs').read_text()
theme=(root/'crates/aetherstream-ui/src/theme.rs').read_text()
installer=(root/'INSTALL-AETHERSTREAM.sh').read_text()
# egui 0.36 painter/Stroke APIs require Color32, not the theme's RGBA tuple token.
for bad in [
 'egui::Stroke::new(1.0, theme::DRAGONGLASS_MUTED)',
 'egui::Stroke::new(0.5, theme::DRAGONGLASS_MUTED)',
 'egui::Stroke::new(2.0, theme::DRAGONGLASS_ACCENT)',
 'egui::FontId::monospace(10.0),\n        theme::DRAGONGLASS_MUTED,']:
 if bad in ui:
  print('PEQ_COLOR32_REGRESSION=FAIL'); sys.exit(1)
if 'pub(crate) fn color(' not in theme:
 print('THEME_COLOR_HELPER=FAIL'); sys.exit(1)
for needle in ['AETHERSTREAM_BUILD_LOG=', 'AETHERSTREAM_COMPILER_DETAIL_BEGIN', 'PIPESTATUS[0]', 'tee "$BUILD_LOG"']:
 if needle not in installer:
  print('BUILD_DIAGNOSTICS=FAIL:'+needle); sys.exit(1)
print('AETHERSTREAM_PEQ_COLOR32_BUILD_GUARD=PASS')
print('AETHERSTREAM_BUILD_DIAGNOSTICS=PASS')
