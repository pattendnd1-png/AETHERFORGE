#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
set +e
AETHERSTREAM_DOWNLOADS_DIR="$tmp" bash "$ROOT/INSTALL-AETHERSTREAM.sh" --self-test-early-verify >"$tmp/stdout" 2>"$tmp/stderr"
rc=$?
set -e
verify="$tmp/AetherStream-v10.2.50-VERIFY.txt"
[[ $rc -ne 0 ]] || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:forced-failure-returned-zero'; exit 1; }
[[ -f "$verify" ]] || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:verify-file-missing'; exit 1; }
grep -q '^AETHERSTREAM_VERSION=10.2.50$' "$verify" || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:version'; exit 1; }
grep -q '^AETHERSTREAM_INSTALLER_STAGE=self-test-forced-failure$' "$verify" || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:stage'; exit 1; }
grep -q '^AETHERSTREAM_INSTALLER_STAGE_STARTED=.' "$verify" || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:stage-started'; exit 1; }
grep -q '^AETHERSTREAM_INSTALL_LOG=' "$verify" || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:install-log-field'; exit 1; }
[[ -f "$tmp/AetherStream-v10.2.50-INSTALL.log" ]] || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:install-log-missing'; exit 1; }
grep -q '^AETHERSTREAM_EARLY_VERIFY_HANDOFF=PASS$' "$verify" || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:handoff'; exit 1; }
grep -q '^AETHERSTREAM_VERIFY=FAIL$' "$verify" || { echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=FAIL:status'; exit 1; }
echo 'AETHERSTREAM_EARLY_VERIFY_RUNTIME=PASS'
