#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
errors=[]
def read(rel):
 p=root/rel
 if not p.is_file(): errors.append(f'missing {rel}'); return ''
 return p.read_text()
audiod=read('apps/aetherstream-audiod/src/main.rs')
plugin=read('crates/aetherstream-dsp-ladspa/src/lib.rs')
wp=read('packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in')
installer=read('INSTALL-AETHERSTREAM.sh')
for needle in ['resolve_selected_physical_sink','--print-physical-output-node-name','--print-physical-output-loadout-id']:
 if needle not in audiod: errors.append(f'audiod missing {needle}')
for needle in ['node.filter-graph.rules','create-filter-graph','__AETHERSTREAM_PRIMARY_NODE_NAME__','"node.name" = "~bluez_output.*"','plugin = "libaetherstream_hdmi3_dsp"']:
 if needle not in wp: errors.append(f'physical filter graph missing {needle}')
for forbidden in ['filter.smart','node.software-dsp.rules','node.virtual','create-filter =']:
 if forbidden in wp: errors.append(f'forbidden separate-node mechanism {forbidden}')
for forbidden in ['aetherstream.dsp.sink','set_default_sink','wpctl set-default']:
 if forbidden in audiod+installer: errors.append(f'forbidden output switching/node {forbidden}')
for needle in ['physical-output-internal-dsp.active','AetherStream Physical Output Internal DSP','LiveDspProcessor','SharedOutputDspReader']:
 if needle not in plugin: errors.append(f'plugin missing {needle}')
for needle in ['90-aetherstream-physical-output-internal-dsp.conf','PHYSICAL_NODE_NAME','PHYSICAL_LOADOUT_ID','DEFAULT_BEFORE']:
 if needle not in installer: errors.append(f'installer missing {needle}')
if errors:
 print('AETHERSTREAM_PHYSICAL_INTERNAL_DSP_CONTRACT=FAIL')
 for e in errors: print(e)
 sys.exit(1)
print('AETHERSTREAM_PHYSICAL_INTERNAL_DSP_CONTRACT=PASS')
print('AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS=0')
print('AETHERSTREAM_EXTRA_OUTPUT_STREAMS=0')
