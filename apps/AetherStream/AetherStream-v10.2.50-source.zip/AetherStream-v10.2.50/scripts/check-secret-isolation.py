#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
secret=(root/'crates/aetherstream-storage/src/secret.rs').read_text()
if 'LinuxSecretStore' not in secret or 'blocking::SecretService' not in secret or 'EncryptionType::Dh' not in secret:
    errors.append('Linux Secret Service backend is not canonical')
if 'SecretBytes([REDACTED;' not in secret:
    errors.append('SecretBytes Debug output is not redacted')
for rel in [
    'crates/aetherstream-core/src/action.rs',
    'crates/aetherstream-control/src/state.rs',
    'crates/aetherstream-ipc/src/protocol.rs',
    'crates/aetherstream-storage/src/account.rs',
    'crates/aetherstream-ui/src/app.rs',
]:
    text=(root/rel).read_text().lower()
    for pattern in [r'pub\s+access_token\s*:', r'pub\s+refresh_token\s*:', r'pub\s+client_secret\s*:', r'pub\s+password\s*:']:
        if re.search(pattern,text):
            errors.append(f'{rel} exposes secret-bearing field {pattern}')

config=(root/'CONFIGURE-AUTH.sh').read_text()
if 'AETHERSTREAM_STREAMLABS_CLIENT_SECRET' in config or 'AETHERSTREAM_STREAMELEMENTS_CLIENT_SECRET' in config:
    errors.append('auth configurator writes client secrets to environment')
if 'secret-tool store' not in config:
    errors.append('auth configurator does not provision Linux Secret Service')
# Runtime must load client secrets from SecretStore, never config fields/env values.
runtime=(root/'crates/aetherstream-auth/src/runtime.rs').read_text()
for forbidden in ['pub streamlabs_client_secret', 'pub streamelements_client_secret', 'AETHERSTREAM_STREAMLABS_CLIENT_SECRET', 'AETHERSTREAM_STREAMELEMENTS_CLIENT_SECRET']:
    if forbidden in runtime:
        errors.append(f'auth runtime leaks client secret configuration: {forbidden}')
for required in ['client_secret_key', 'self.secrets', 'Linux Secret Service']:
    if required not in runtime and required != 'Linux Secret Service':
        errors.append(f'auth runtime missing secret-store marker: {required}')
if errors:
    print('AETHERSTREAM_SECRET_ISOLATION_CONTRACT=FAIL')
    print('\n'.join(errors)); sys.exit(1)
print('AETHERSTREAM_SECRET_ISOLATION_CONTRACT=PASS')
