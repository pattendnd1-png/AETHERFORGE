#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors = []

def read(rel):
    p = root / rel
    if not p.is_file():
        errors.append(f"missing {rel}")
        return ""
    return p.read_text()

audiod = read("apps/aetherstream-audiod/src/main.rs")
workspace = read("Cargo.toml")
plugin = read("crates/aetherstream-dsp-ladspa/src/lib.rs")
plugin_cargo = read("crates/aetherstream-dsp-ladspa/Cargo.toml")
shared = read("crates/aetherstream-audio/src/shared_output_dsp.rs")
wp = read("packaging/wireplumber/90-aetherstream-hdmi3-internal-dsp.conf.in")
installer = read("INSTALL-AETHERSTREAM.sh")

for forbidden in [
    "HDMI3_FILTER_INPUT_NAME",
    "HDMI3_FILTER_PLAYBACK_NAME",
    "HDMI3_FILTER_LINK_GROUP",
    '"filter.smart" => "true"',
    '"media.class" => "Audio/Sink"',
    "fn run_pipewire(",
    "StreamBox::new",
    "aetherstream.dsp.sink",
]:
    if forbidden in audiod:
        errors.append(f"audiod still creates an output stream/filter node: {forbidden}")

for needle in [
    '"crates/aetherstream-dsp-ladspa"',
    'crate-type = ["cdylib", "rlib"]',
    'aetherstream_hdmi3_dsp_stereo',
    'ladspa_descriptor',
    'LiveDspProcessor',
    'SharedOutputDspReader',
]:
    hay = workspace + plugin + plugin_cargo
    if needle not in hay:
        errors.append(f"Rust internal DSP plugin contract missing {needle}")

for needle in [
    "SharedOutputDspWriter",
    "SharedOutputDspReader",
    "OUTPUT_DSP_SHARED_FILE",
    "AtomicU32",
    "snapshot",
]:
    if needle not in shared:
        errors.append(f"shared realtime plan contract missing {needle}")

for needle in [
    "node.filter-graph.rules",
    "create-filter-graph",
    "type = ladspa",
    "aetherstream_hdmi3_dsp_stereo",
    "__AETHERSTREAM_HDMI3_NODE_NAME__",
    'plugin = "libaetherstream_hdmi3_dsp"',
]:
    if needle not in wp:
        errors.append(f"WirePlumber internal graph template missing {needle}")

for forbidden in ["filter.smart", "node.software-dsp.rules", "create-filter ="]:
    if forbidden in wp:
        errors.append(f"WirePlumber template uses forbidden separate-filter mechanism {forbidden}")

for needle in [
    'LADSPA_DIR="$HOME/.local/lib/aetherstream/ladspa"',
    'plugin = "libaetherstream_hdmi3_dsp"',
    "libaetherstream_hdmi3_dsp.so",
    "90-aetherstream-hdmi3-internal-dsp.conf",
    "--print-hdmi3-node-name",
]:
    if needle not in installer + wp + audiod:
        errors.append(f"installer/internal graph DSP contract missing {needle}")

if errors:
    print("AETHERSTREAM_HDMI3_INTERNAL_DSP_CONTRACT=FAIL")
    for error in errors:
        print(error)
    sys.exit(1)
print("AETHERSTREAM_HDMI3_INTERNAL_DSP_CONTRACT=PASS")
