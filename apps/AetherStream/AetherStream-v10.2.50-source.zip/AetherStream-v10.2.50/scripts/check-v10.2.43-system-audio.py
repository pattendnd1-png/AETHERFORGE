#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
audiod = (root/'apps/aetherstream-audiod/src/main.rs').read_text()
bridge = (root/'crates/aetherstream-core/src/forgehx_bridge.rs').read_text()
unit = (root/'packaging/systemd/aetherstream-audiod.service').read_text()
checks = {
 'managed system microphone': 'aetherstream.system.microphone' in audiod,
 'ForgeHX bridge socket': 'forgehx-mic.sock' in audiod,
 'ForgeHX live marker': 'forgehx-mic.active' in audiod,
 'fixed bridge magic': 'AFXHXM01' in bridge,
 'physical source fallback': 'resolve_physical_source' in audiod and 'fallback' in audiod.lower(),
 'managed source default': 'wait_for_managed_source' in audiod,
 'restore physical source': 'physical_source.node_id' in audiod and 'set_default_source' in audiod,
 'persistent full-system service': 'full-system audio authority' in unit.lower() and 'WantedBy=default.target' in unit,
}
failed=[name for name, ok in checks.items() if not ok]
if failed:
    print('AETHERSTREAM_SYSTEM_AUDIO_AUTHORITY=FAIL:' + ','.join(failed))
    raise SystemExit(1)
print('AETHERSTREAM_SYSTEM_AUDIO_AUTHORITY=PASS')
