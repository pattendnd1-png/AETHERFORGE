#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors=[]

def need(path, tokens):
    text=(root/path).read_text() if (root/path).exists() else ''
    if not text:
        errors.append(f'missing {path}')
        return
    for token in tokens:
        if token not in text:
            errors.append(f'{path}: missing {token}')

need(Path('crates/aetherstream-core/src/action.rs'), [
    'TwitchPollSpec', 'TwitchPredictionSpec', 'TwitchModerationAction',
    'StreamElementsOverlayAction', 'StreamlabsAlertAction', 'StreamlabsMediaShareAction',
    'TwitchCreatePoll', 'TwitchCreatePrediction', 'TwitchModeration',
    'ObsTransition', 'ObsSourceVisibility', 'ObsReplayBufferSave',
    'StreamElementsOverlay', 'StreamlabsAlert', 'StreamlabsMediaShare',
])
need(Path('crates/aetherstream-control/src/router.rs'), [
    'TwitchCreatePoll', 'ObsTransition', 'StreamElementsOverlay', 'StreamlabsMediaShare'
])

need(Path('crates/aetherstream-integrations/src/operation.rs'), [
    'ProviderOperation', 'ProviderOperationError', 'translate_action', 'required_scopes'
])
need(Path('crates/aetherstream-integrations/src/twitch.rs'), [
    'translate_twitch_action', 'channel:manage:polls', 'channel:manage:predictions',
    'moderator:manage:shield_mode', 'moderator:manage:banned_users'
])
need(Path('crates/aetherstream-integrations/src/obs.rs'), ['translate_obs_action'])
need(Path('crates/aetherstream-integrations/src/streamelements.rs'), ['translate_streamelements_action'])
need(Path('crates/aetherstream-integrations/src/streamlabs.rs'), ['translate_streamlabs_action'])


need(Path('crates/aetherstream-control/src/state.rs'), [
    'CreatorOpsState', 'StreamElementsOpsState', 'StreamlabsOpsState',
    'creator:', 'streamelements_ops:', 'streamlabs_ops:', 'transition:', 'sources:', 'replay_saves:'
])
need(Path('apps/aetherstream-supervisord/src/main.rs'), [
    'translate_action', 'TwitchCreatePoll', 'ObsTransition', 'StreamElementsOverlay', 'StreamlabsMediaShare'
])
need(Path('apps/aetherstream/src/main.rs'), [
    'twitch-shield=', 'obs-transition=', 'se-overlay=', 'sl-media=',
    'AETHERSTREAM_TWITCH_SHIELD_MODE', 'AETHERSTREAM_OBS_TRANSITION',
    'AETHERSTREAM_SE_QUEUE_PAUSED', 'AETHERSTREAM_SL_MEDIA_PAUSED'
])
need(Path('scripts/smoke-provider-operations.sh'), [
    'twitch-shield=true', 'obs-transition=Fade', 'se-overlay=pause', 'sl-media=pause',
    'AETHERSTREAM_PROVIDER_OPERATIONS_SMOKE=PASS'
])
need(Path('scripts/verify-release.sh'), [
    'AETHERSTREAM_PROVIDER_OPERATIONS', 'smoke-provider-operations.sh'
])


supervisor=(root/'apps/aetherstream-supervisord/src/main.rs').read_text()
if '}\n}\n}\n\nfn session_graph_smoke' in supervisor:
    errors.append('supervisor control-plane impl has an extra closing brace')

if errors:
    print('AETHERSTREAM_PROVIDER_OPERATIONS_CONTRACT=FAIL')
    for e in errors: print(e)
    sys.exit(1)
print('AETHERSTREAM_PROVIDER_OPERATIONS_CONTRACT=PASS')
