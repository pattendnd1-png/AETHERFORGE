#!/usr/bin/env python3
from pathlib import Path
import sys
text=(Path(__file__).resolve().parents[1]/'apps/aetherstream-audiod/src/main.rs').read_text()
needle='''let fallback_capture = pw::stream::StreamRc::new(\n        core.clone(),'''
if needle not in text:
    print('AETHERSTREAM_CORE_REGISTRY_LIFETIME=FAIL')
    print('fallback_capture must clone CoreRc while RegistryBox borrows the original core')
    sys.exit(1)
print('AETHERSTREAM_CORE_REGISTRY_LIFETIME=PASS')
