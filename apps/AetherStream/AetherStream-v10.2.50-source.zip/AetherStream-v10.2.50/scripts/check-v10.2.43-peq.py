#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
errors = []
core = (root/'crates/aetherstream-core/src/output_dsp.rs').read_text()
live = (root/'crates/aetherstream-audio/src/live_dsp.rs').read_text()
ui = (root/'crates/aetherstream-ui/src/app.rs').read_text()
storage = (root/'crates/aetherstream-storage/src/db.rs').read_text()
for needle in [
    'PEQ_MIN_BANDS: usize = 15', 'PEQ_MAX_BANDS: usize = 31',
    'PEQ_MIN_FREQUENCY_HZ: f32 = 5.0', 'PEQ_MAX_FREQUENCY_HZ: f32 = 35_000.0',
    'pub struct OutputParametricEqBand', 'pub enum ParametricEqBandKind',
    'pub parametric_eq: Vec<OutputParametricEqBand>', 'normalize_parametric_eq',
    'fn peq_log_frequency', 'return PEQ_MAX_FREQUENCY_HZ',
    'peq_log_frequency(index, target)',
]:
    if needle not in core: errors.append(f'missing core PEQ contract: {needle}')
for needle in ['profile.parametric_eq', 'append_parametric_eq', 'sample_rate_hz * 0.49']:
    if needle not in live: errors.append(f'missing live PEQ contract: {needle}')
for needle in ['15-band', '21-band', '25-band', '31-band', '5.0..=35_000.0', '+ Band', '- Band', 'Parametric EQ — 15–31 bands']:
    if needle not in ui: errors.append(f'missing UI PEQ contract: {needle}')
if 'normalize_parametric_eq()' not in storage:
    errors.append('storage does not normalize legacy PEQ profiles')
# one-node output invariants must remain in shipped source
for bad in ['aetherstream.dsp.sink', 'aetherstream.hdmi3.filter.input', 'aetherstream.hdmi3.filter.playback']:
    if bad in (root/'apps/aetherstream-audiod/src/main.rs').read_text():
        errors.append(f'legacy/extra output path returned: {bad}')
if errors:
    print('AETHERSTREAM_PEQ_15_31_BANDS=FAIL')
    for e in errors: print(e)
    sys.exit(1)
print('AETHERSTREAM_PEQ_15_31_BANDS=PASS')
print('AETHERSTREAM_PEQ_5HZ_35KHZ=PASS')
print('AETHERSTREAM_PEQ_ONE_NODE_HDMI3=PASS')

tests = (root/'crates/aetherstream-core/tests/output_dsp_profile.rs').read_text()
for needle in ['generated_parametric_eq_sizes_pin_exact_frequency_boundaries', 'legacy_peq_float_overshoot_normalizes_to_exact_upper_boundary']:
    if needle not in tests:
        print(f'AETHERSTREAM_PEQ_BOUNDARY_REGRESSION=FAIL:{needle}')
        sys.exit(1)
print('AETHERSTREAM_PEQ_EXACT_BOUNDARIES=PASS')
