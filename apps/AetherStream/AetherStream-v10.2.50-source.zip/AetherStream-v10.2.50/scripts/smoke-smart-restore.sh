#!/usr/bin/env bash
set -euo pipefail
cargo test -p aetherstream-auth smart_restore_with_no_accounts_is_empty_and_offline_safe
python3 scripts/check-smart-restore.py
printf 'AETHERSTREAM_SMART_RESTORE_SMOKE=PASS\n'
