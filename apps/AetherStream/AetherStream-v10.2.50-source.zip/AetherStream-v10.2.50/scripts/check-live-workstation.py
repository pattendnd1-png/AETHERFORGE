#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
checks = {
    'bridge module': ('crates/aetherstream-ui/src/bridge.rs', 'pub struct UiControlBridge'),
    'bridge dispatch': ('crates/aetherstream-ui/src/bridge.rs', 'pub fn dispatch'),
    'bridge state drain': ('crates/aetherstream-ui/src/bridge.rs', 'pub fn drain_latest'),
    'ui worker': ('apps/aetherstream/src/main.rs', 'fn spawn_ui_worker'),
    'ui bridge wiring': ('crates/aetherstream-ui/src/app.rs', 'with_bridge'),
    'obs live controls': ('crates/aetherstream-ui/src/app.rs', 'AetherStreamAction::ObsScene'),
    'mixer live controls': ('crates/aetherstream-ui/src/app.rs', 'AetherStreamAction::AudioGain'),
    'recording live control': ('crates/aetherstream-ui/src/app.rs', 'AetherStreamAction::RecordingToggle'),
    'deck live controls': ('crates/aetherstream-ui/src/app.rs', 'AetherStreamAction::DeckProfile'),
    'control smoke': ('scripts/smoke-control-roundtrip.sh', 'AETHERSTREAM_CONTROL_ROUNDTRIP_SMOKE=PASS'),
}
errors=[]
for name,(rel,needle) in checks.items():
    p=root/rel
    if not p.is_file(): errors.append(f'{name}: missing {rel}'); continue
    if needle not in p.read_text(): errors.append(f'{name}: missing {needle}')
if errors:
    print('AETHERSTREAM_LIVE_WORKSTATION_CONTRACT=FAIL')
    print('\n'.join(errors))
    sys.exit(1)
print('AETHERSTREAM_LIVE_WORKSTATION_CONTRACT=PASS')
