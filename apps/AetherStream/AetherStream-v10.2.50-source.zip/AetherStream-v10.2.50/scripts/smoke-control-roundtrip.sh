#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"
runtime="$(mktemp -d)"
trap 'kill "${supervisor_pid:-}" 2>/dev/null || true; rm -rf "$runtime"' EXIT
export XDG_RUNTIME_DIR="$runtime"
"$BIN_DIR/aetherstream-supervisord" >"$runtime/supervisor.log" 2>&1 &
supervisor_pid=$!
for _ in {1..60}; do
  [[ -S "$runtime/aetherstream/supervisor.sock" ]] && break
  sleep 0.05
done
[[ -S "$runtime/aetherstream/supervisor.sock" ]]
AETHERSTREAM_CONTROL_ACTION='audio-gain=Mic:-3.5' "$BIN_DIR/aetherstream" >"$runtime/audio.log"
AETHERSTREAM_CONTROL_ACTION='audio-mute=Mic:true' "$BIN_DIR/aetherstream" >"$runtime/mute.log"
AETHERSTREAM_CONTROL_ACTION='deck-profile=Forge Master' "$BIN_DIR/aetherstream" >"$runtime/deck.log"
AETHERSTREAM_CONTROL_ACTION='deck-page=Audio' "$BIN_DIR/aetherstream" >"$runtime/page.log"
AETHERSTREAM_CONTROL_ACTION='recording-toggle' "$BIN_DIR/aetherstream" >"$runtime/record.log"
for log in audio mute deck page record; do
  grep -q '^AETHERSTREAM_ACTION=PASS$' "$runtime/$log.log"
done
AETHERSTREAM_CONTROL_GET_STATE=1 "$BIN_DIR/aetherstream" >"$runtime/state.log"
grep -q '^AETHERSTREAM_MIC_GAIN_DB=-3.5$' "$runtime/state.log"
grep -q '^AETHERSTREAM_MIC_MUTED=true$' "$runtime/state.log"
grep -q '^AETHERSTREAM_DECK_PROFILE=Forge Master$' "$runtime/state.log"
grep -q '^AETHERSTREAM_DECK_PAGE=Audio$' "$runtime/state.log"
grep -q '^AETHERSTREAM_RECORDING_ACTIVE=true$' "$runtime/state.log"
echo "AETHERSTREAM_CONTROL_ROUNDTRIP_SMOKE=PASS"
