#!/usr/bin/env python3
from pathlib import Path
import sys

text = Path('INSTALL-AETHERSTREAM.sh').read_text()
required = [
    'AETHERSTREAM_INSTALLER_STAGE=',
    'AETHERSTREAM_VERIFY=RUNNING',
    'AETHERSTREAM_VERIFY=FAIL',
    'write_running_verify',
    'set_stage() {',
    'AETHERSTREAM_INSTALLER_STAGE_STARTED=',
    'AETHERSTREAM_INSTALL_LOG=',
    'write_early_failure_verify',
    'VERIFY_FINALIZED=0',
    '--self-test-early-verify',
]
missing = [token for token in required if token not in text]
if missing:
    print('AETHERSTREAM_EARLY_VERIFY_HANDOFF=FAIL')
    for token in missing:
        print(f'MISSING={token}')
    sys.exit(1)

initial = text.find('set_stage "startup"')
build = text.find('cargo build --workspace --release')
if initial == -1 or build == -1 or initial > build:
    print('AETHERSTREAM_EARLY_VERIFY_HANDOFF=FAIL')
    print('REASON=verify-file-not-created-before-build')
    sys.exit(1)

print('AETHERSTREAM_EARLY_VERIFY_HANDOFF=PASS')
