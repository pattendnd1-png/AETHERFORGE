#!/usr/bin/env python3
from pathlib import Path
import re
import sys
import tomllib

root = Path(__file__).resolve().parents[1]
errors = []
for path in root.rglob("*"):
    rel = path.relative_to(root)
    if any(part in {".git", ".worktrees", "target"} for part in rel.parts):
        continue
    if path.name.endswith(("~", ".bak", ".orig", ".rej")):
        errors.append(f"stale file: {rel}")
    if re.search(r"(?i)(?:^|[-_.])(?:rc\d*|r\d+|rev\d+)(?:[-_.]|$)", path.name):
        errors.append(f"revision/RC artifact: {rel}")

workspace = tomllib.loads((root / "Cargo.toml").read_text())["workspace"]
members = workspace["members"]
if len(members) != len(set(members)):
    errors.append("duplicate workspace member")
package_names = []
for manifest in root.rglob("Cargo.toml"):
    if ".worktrees" in manifest.parts:
        continue
    data = tomllib.loads(manifest.read_text())
    if "package" in data:
        name = data["package"].get("name")
        if name:
            package_names.append(name)
if len(package_names) != len(set(package_names)):
    errors.append("duplicate crate package name")

for rel in ["README.md", "INSTALL-AETHERSTREAM.sh", "scripts/verify-release.sh"]:
    text = (root / rel).read_text()
    versions = set(re.findall(r"(?<![\d.])10\.\d+\.\d+(?![\d.])", text))
    stale = sorted(version for version in versions if version not in {"10.2.43", "10.2.45", "10.2.46", "10.2.47", "10.2.48", "10.2.49", "10.2.50"})
    if stale:
        errors.append(f"{rel}: stale versions {stale}")

if errors:
    print("AETHERSTREAM_CLEAN_TREE=FAIL")
    for error in errors:
        print(error)
    sys.exit(1)
print("AETHERSTREAM_CLEAN_TREE=PASS")
