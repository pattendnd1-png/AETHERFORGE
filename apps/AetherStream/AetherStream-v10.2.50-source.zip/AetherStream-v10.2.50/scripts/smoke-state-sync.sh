#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"
runtime="$(mktemp -d)"
trap 'kill "${supervisor_pid:-}" 2>/dev/null || true; rm -rf "$runtime"' EXIT
export XDG_RUNTIME_DIR="$runtime"
export AETHERSTREAM_DISABLE_STARTUP_SMART_RESTORE=1
"$BIN_DIR/aetherstream-supervisord" >"$runtime/supervisor.log" 2>&1 &
supervisor_pid=$!
for _ in {1..60}; do
  [[ -S "$runtime/aetherstream/supervisor.sock" ]] && break
  sleep 0.05
done
[[ -S "$runtime/aetherstream/supervisor.sock" ]]
AETHERSTREAM_CONTROL_GET_STATE=1 "$BIN_DIR/aetherstream" >"$runtime/a-before.log"
rev_before="$(sed -n 's/^AETHERSTREAM_STATE_REVISION=//p' "$runtime/a-before.log")"
AETHERSTREAM_CONTROL_ACTION='obs-scene=Gameplay' "$BIN_DIR/aetherstream" >"$runtime/action.log"
grep -q '^AETHERSTREAM_ACTION=PASS$' "$runtime/action.log"
AETHERSTREAM_CONTROL_GET_STATE=1 "$BIN_DIR/aetherstream" >"$runtime/a-after.log"
AETHERSTREAM_CONTROL_GET_STATE=1 "$BIN_DIR/aetherstream" >"$runtime/b-after.log"
rev_a="$(sed -n 's/^AETHERSTREAM_STATE_REVISION=//p' "$runtime/a-after.log")"
rev_b="$(sed -n 's/^AETHERSTREAM_STATE_REVISION=//p' "$runtime/b-after.log")"
scene_a="$(sed -n 's/^AETHERSTREAM_OBS_SCENE=//p' "$runtime/a-after.log")"
scene_b="$(sed -n 's/^AETHERSTREAM_OBS_SCENE=//p' "$runtime/b-after.log")"
id_a="$(sed -n 's/^AETHERSTREAM_CLIENT_ID=//p' "$runtime/a-after.log")"
id_b="$(sed -n 's/^AETHERSTREAM_CLIENT_ID=//p' "$runtime/b-after.log")"
[[ -n "$rev_before" ]]
[[ "$rev_a" == "$rev_b" ]]
[[ "$rev_a" -eq $((rev_before + 1)) ]]
[[ "$scene_a" == "Gameplay" && "$scene_b" == "Gameplay" ]]
[[ -n "$id_a" && -n "$id_b" && "$id_a" != "$id_b" ]]
echo "AETHERSTREAM_STATE_SYNC_SMOKE=PASS"
