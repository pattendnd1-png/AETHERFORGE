#!/usr/bin/env bash
set -euo pipefail
BIN="${1:-target/release/aetherstream-audiod}"
RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/aetherstream"
SOCKET="$RUNTIME_DIR/output-dsp.sock"
SHARED="$RUNTIME_DIR/output-dsp-v1.shm"
ACTIVE="$RUNTIME_DIR/physical-output-internal-dsp.active"
LOG="${TMPDIR:-/tmp}/aetherstream-audiod-smoke.log"

node_name() {
  wpctl inspect "$1" 2>/dev/null | awk -F= '/node.name/{v=$2; gsub(/^[[:space:]"]+|[[:space:]"]+$/, "", v); print v; exit}'
}

BEFORE_NAME="$(node_name @DEFAULT_AUDIO_SINK@)"
[[ -n "$BEFORE_NAME" ]] || { echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL no-default-sink'; exit 1; }
[[ "$BEFORE_NAME" != aetherstream.* ]] || { echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL default-is-not-physical'; exit 1; }

PHYSICAL_NAME="$($BIN --print-physical-output-node-name)"
PHYSICAL_LOADOUT="$($BIN --print-physical-output-loadout-id)"
PHYSICAL_CLASS="$($BIN --print-physical-output-class)"
[[ "$PHYSICAL_NAME" == "$BEFORE_NAME" ]] || {
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL selected-physical-output-mismatch'; exit 1;
}

# Internal filter graph must already be attached by WirePlumber; it adds no nodes.
[[ -f "$ACTIVE" ]] || {
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL internal-plugin-not-active'; exit 1;
}

if wpctl list audio sinks 2>/dev/null | awk -F'\t' '$2 ~ /^aetherstream\./ { found=1 } END { exit found ? 0 : 1 }'; then
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL AetherStream-output-node-visible'; exit 1;
fi
if wpctl status -n 2>/dev/null | grep -Eq 'aetherstream\.hdmi3\.filter|aetherstream\.dsp\.sink'; then
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL legacy-smart-filter-node-visible'; exit 1;
fi
PHYSICAL_COUNT="$(wpctl list audio sinks 2>/dev/null | awk -F'\t' -v n="$PHYSICAL_NAME" '$2==n {c++} END {print c+0}')"
[[ "$PHYSICAL_COUNT" == "1" ]] || {
  echo "AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL physical-node-count-$PHYSICAL_COUNT"; exit 1;
}

"$BIN" >"$LOG" 2>&1 &
pid=$!
cleanup() {
  if kill -0 "$pid" 2>/dev/null; then
    kill -INT "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT

ready=0
for _ in $(seq 1 100); do
  AFTER_NAME="$(node_name @DEFAULT_AUDIO_SINK@)"
  if [[ -S "$SOCKET" && -f "$SHARED" && -f "$ACTIVE" && "$AFTER_NAME" == "$BEFORE_NAME" ]]; then
    ready=1
    break
  fi
  kill -0 "$pid" 2>/dev/null || break
  sleep 0.1
done
[[ "$ready" -eq 1 ]] || {
  cat "$LOG" >&2 || true
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL internal-dsp-state-or-default-changed'
  exit 1
}

if wpctl list audio sinks 2>/dev/null | awk -F'\t' '$2 ~ /^aetherstream\./ { found=1 } END { exit found ? 0 : 1 }'; then
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL extra-output-stream-after-audiod-start'; exit 1;
fi

cleanup
trap - EXIT
FINAL_NAME="$(node_name @DEFAULT_AUDIO_SINK@)"
[[ "$FINAL_NAME" == "$BEFORE_NAME" ]] || {
  echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=FAIL default-changed-on-audiod-stop'; exit 1;
}

echo 'AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING=OFF'
printf 'AETHERSTREAM_PHYSICAL_OUTPUT_NODE=%s\n' "$PHYSICAL_NAME"
printf 'AETHERSTREAM_PHYSICAL_OUTPUT_LOADOUT=%s\n' "$PHYSICAL_LOADOUT"
printf 'AETHERSTREAM_PHYSICAL_OUTPUT_CLASS=%s\n' "$PHYSICAL_CLASS"
echo 'AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS=0'
echo 'AETHERSTREAM_EXTRA_OUTPUT_STREAMS=0'
echo 'AETHERSTREAM_SMART_FILTER_NODES=0'
echo 'AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT=1'
echo 'AETHERSTREAM_PHYSICAL_INTERNAL_DSP=PASS'
echo 'AETHERSTREAM_PHYSICAL_DSP_AUTO_APPLY=PASS'
if [[ "$PHYSICAL_LOADOUT" == hdmi3 ]]; then
  echo 'AETHERSTREAM_HDMI3_LOADOUT=PASS'
  echo 'AETHERSTREAM_HDMI3_INTERNAL_DSP=PASS'
fi
if [[ "$PHYSICAL_LOADOUT" == bluetooth:* ]]; then
  echo 'AETHERSTREAM_BLUETOOTH_PHYSICAL_OUTPUT=PASS'
fi
echo 'AETHERSTREAM_LIVE_PIPEWIRE_DSP_RUNTIME=PASS'
