#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors: list[str] = []
panels = (root / 'crates/aetherstream-ui/src/panels.rs').read_text()
app = (root / 'crates/aetherstream-ui/src/app.rs').read_text()

expected = ['Home', 'Live', 'Streamlabs', 'StreamElements', 'A/V Studio', 'Settings']
start = panels.find('pub const PRIMARY_TABS')
end = panels.find('];', start)
block = panels[start:end] if start >= 0 and end > start else ''
for tab in expected:
    if f'"{tab}"' not in block:
        errors.append(f'missing primary tab {tab}')
for forbidden in ['OBS', 'Player', 'Multiview', 'Chat', 'Moderation', 'Mixer', 'DSP', 'Alerts', 'Activity', 'Recording', 'Replay', 'Deck', 'Health']:
    if f'"{forbidden}"' in block:
        errors.append(f'redundant primary tab remains: {forbidden}')
if block.count('"') // 2 != 6:
    errors.append('primary tab count is not exactly six')
for marker in ['fn render_streamlabs_workspace', 'Streamlabs Studio', 'Broadcast Engine']:
    if marker not in app:
        errors.append(f'missing consolidated broadcast marker: {marker}')
if 'fn render_obs_workspace' in app:
    errors.append('OBS renderer still exists as a separate workspace')

if errors:
    print('AETHERSTREAM_UI_CONSOLIDATION=FAIL')
    print('\n'.join(errors))
    sys.exit(1)
print('AETHERSTREAM_UI_CONSOLIDATION=PASS')
