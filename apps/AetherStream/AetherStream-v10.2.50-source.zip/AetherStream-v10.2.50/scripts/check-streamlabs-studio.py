#!/usr/bin/env python3
import pathlib, sys
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
app=(root/'crates/aetherstream-ui/src/app.rs').read_text()
theme=(root/'crates/aetherstream-ui/src/theme.rs').read_text()
errors=[]
for tab in ['Home','Live','Streamlabs','StreamElements','A/V Studio','Settings']:
    if f'"{tab}"' not in app: errors.append(f'missing tab {tab}')
if '"OBS" => ' in app or 'has_panel("OBS") {' in app: errors.append('OBS remains a primary tab')
for needle in ['Preview', 'Program', 'Scene rail', 'Source stack', 'Transition', 'Mixer', 'Replay', 'Media Share', 'Alert queue', 'Broadcast Engine']:
    if needle not in app: errors.append(f'missing Streamlabs Studio visual/control {needle}')
for needle in ['DRAGONGLASS_ERROR','DRAGONGLASS_RECORDING','DRAGONGLASS_STREAMING','DRAGONGLASS_LOADING','status_card','studio_panel']:
    if needle not in theme: errors.append(f'missing visual token/helper {needle}')
if errors:
    print('AETHERSTREAM_STREAMLABS_STUDIO_CONTRACT=FAIL')
    for e in errors: print('FAIL', e)
    sys.exit(1)
print('AETHERSTREAM_STREAMLABS_STUDIO_CONTRACT=PASS')
