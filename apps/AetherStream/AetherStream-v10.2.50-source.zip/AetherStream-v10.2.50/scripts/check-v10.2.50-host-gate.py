#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors = []

def text(rel: str) -> str:
    p = root / rel
    if not p.is_file():
        errors.append(f"missing {rel}")
        return ""
    return p.read_text()

ladspa = text("crates/aetherstream-dsp-ladspa/src/lib.rs")
plugin_check = text("scripts/check-v10.2.43-user-dsp-plugin.py")
verify = text("scripts/verify-release.sh")
installer = text("INSTALL-AETHERSTREAM.sh")
wp = text("packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in")

# Rust 1.98 -D warnings must accept the LADSPA crate.
if "if reader_slot.load(Ordering::Acquire).is_null() {\n                    if let Ok(reader)" in ladspa:
    errors.append("LADSPA reader worker still has clippy::collapsible-if")
if "if !reader_ptr.is_null() {\n        if let Some((generation, plan))" in ladspa:
    errors.append("LADSPA run path still has nested collapsible-if")

# The user-DSP contract must describe the current cache-target/rootless installer, not stale target/release text.
for needle in [
    'install -Dm755 "$CARGO_TARGET_DIR/release/libaetherstream_hdmi3_dsp.so" "$LADSPA_SO"',
    'systemctl --user set-environment "LADSPA_PATH=$MERGED_LADSPA_PATH"',
]:
    if needle not in plugin_check:
        errors.append(f"DSP plugin verifier missing current contract: {needle}")
for stale in [
    'install -Dm755 target/release/libaetherstream_hdmi3_dsp.so "$LADSPA_SO"',
    'systemctl --user set-environment "LADSPA_PATH=$LADSPA_DIR${LADSPA_PATH:+,$LADSPA_PATH}"',
]:
    if stale in plugin_check:
        errors.append(f"DSP plugin verifier still requires stale installer text: {stale}")


# PipeWire LADSPA filter-chain resolves plugin names through LADSPA_PATH and appends .so.
if 'plugin = "libaetherstream_hdmi3_dsp"' not in wp:
    errors.append("WirePlumber graph does not use the LADSPA plugin basename")
if '__AETHERSTREAM_DSP_PLUGIN_PATH__' in wp:
    errors.append("WirePlumber graph still embeds an absolute LADSPA .so path")
if 'current="${current//:/,}"' not in installer:
    errors.append("installer does not normalize legacy colon LADSPA_PATH entries to PipeWire comma syntax")
if "IFS=',' read -r -a parts" not in installer:
    errors.append("installer does not parse PipeWire comma-separated LADSPA_PATH")
if r"tr ',:' '\n'" not in verify:
    errors.append("verify-release does not accept comma/colon LADSPA_PATH tokenization")

# Runtime smoke tests must use CARGO_TARGET_DIR when provided.
smokes = [
    "scripts/smoke-session-graph.sh",
    "scripts/smoke-state-sync.sh",
    "scripts/smoke-control-roundtrip.sh",
    "scripts/smoke-multi-instance.sh",
    "scripts/smoke-provider-operations.sh",
    "scripts/smoke-auth-actions.sh",
]
for rel in smokes:
    body = text(rel)
    if 'BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"' not in body:
        errors.append(f"{rel} does not derive BIN_DIR from CARGO_TARGET_DIR")
    if "target/release/" in body:
        errors.append(f"{rel} still hard-codes target/release")

# The verify script must run the new regression gate.
if "run_step v10_2_50_host_gate python3 scripts/check-v10.2.50-host-gate.py" not in verify:
    errors.append("verify-release.sh does not execute v10.2.50 host-gate regression")

# Installer must still remain rootless for the plugin and keep the cache target contract.
for needle in [
    'CARGO_TARGET_DIR="${AETHERSTREAM_CARGO_TARGET_DIR:-$AETHERSTREAM_CACHE_ROOT/cargo-target-v${VERSION}}"',
    'install -Dm755 "$CARGO_TARGET_DIR/release/libaetherstream_hdmi3_dsp.so" "$LADSPA_SO"',
]:
    if needle not in installer:
        errors.append(f"installer lost required host-gate behavior: {needle}")

if errors:
    print("AETHERSTREAM_V10_2_50_HOST_GATE=FAIL")
    for error in errors:
        print("ERROR=" + error)
    sys.exit(1)
print("AETHERSTREAM_V10_2_50_HOST_GATE=PASS")
