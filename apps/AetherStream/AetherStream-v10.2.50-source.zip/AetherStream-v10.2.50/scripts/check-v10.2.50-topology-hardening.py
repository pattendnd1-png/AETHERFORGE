#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
linked = (root / 'crates/aetherstream-audio/src/linked_output.rs').read_text()
supervisor = (root / 'apps/aetherstream-supervisord/src/main.rs').read_text()
verify = (root / 'scripts/verify-release.sh').read_text()

checks = {
    'topology_struct': 'pub struct LinkedOutputTopology' in linked,
    'exact_sink_count': 'linked_sink_count' in linked,
    'exact_member_count': 'member_count' in linked,
    'hdmi_route_count': 'hdmi_route_count' in linked,
    'bluetooth_route_count': 'bluetooth_route_count' in linked,
    'extraneous_virtual_sinks': 'extraneous_virtual_sinks' in linked,
    'extraneous_virtual_sources': 'extraneous_virtual_sources' in linked,
    'duplicate_routes': 'duplicate_output_routes' in linked,
    'orphan_links': 'orphan_links' in linked,
    'topology_parser': 'inspect_linked_output_topology_from_text' in linked,
    'topology_runtime': 'pub fn inspect_linked_output_topology(' in linked,
    'health_check': 'linked_output_topology_healthy' in linked,
    'serialized_apply': 'LINKED_OUTPUT_APPLY_LOCK' in linked,
    'repair_watcher': 'linked_output_topology_healthy(&config)' in supervisor,
    'rollback_on_invalid': 'linked output topology validation failed' in linked,
    'cleanup_extraneous_modules': 'module-loopback' in linked and 'module-null-sink' in linked,
    'verify_sink_count': 'AETHERSTREAM_LINKED_OUTPUT_SINK_COUNT' in verify,
    'verify_member_count': 'AETHERSTREAM_LINKED_OUTPUT_MEMBER_COUNT' in verify,
    'verify_hdmi_routes': 'AETHERSTREAM_LINKED_OUTPUT_HDMI_ROUTES' in verify,
    'verify_bt_routes': 'AETHERSTREAM_LINKED_OUTPUT_BLUETOOTH_ROUTES' in verify,
    'verify_extra_sinks': 'AETHERSTREAM_EXTRANEOUS_VIRTUAL_SINKS' in verify,
    'verify_extra_sources': 'AETHERSTREAM_EXTRANEOUS_VIRTUAL_SOURCES' in verify,
    'verify_duplicate_routes': 'AETHERSTREAM_DUPLICATE_OUTPUT_ROUTES' in verify,
    'verify_orphan_links': 'AETHERSTREAM_ORPHAN_LINKS' in verify,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f'TOPOLOGY_HARDENING_{name.upper()}={"PASS" if ok else "FAIL"}')
if failed:
    print('TOPOLOGY_HARDENING=FAIL:' + ','.join(failed))
    sys.exit(1)
print('TOPOLOGY_HARDENING=PASS')
