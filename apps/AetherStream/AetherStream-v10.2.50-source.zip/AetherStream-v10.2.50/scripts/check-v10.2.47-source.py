#!/usr/bin/env python3
from pathlib import Path
import re
import sys
import tomllib

root = Path(__file__).resolve().parents[1]
errors: list[str] = []

workspace_text = (root / "Cargo.toml").read_text()
workspace = tomllib.loads(workspace_text)
if workspace.get("workspace", {}).get("package", {}).get("version") != "10.2.47":
    errors.append("workspace version is not 10.2.47")

# v10.2.43 PipeWire trigger API feature regression.
pipewire_dep = workspace.get("workspace", {}).get("dependencies", {}).get("pipewire")
if not isinstance(pipewire_dep, dict):
    errors.append("workspace pipewire dependency must declare explicit trigger features")
else:
    if pipewire_dep.get("version") != "0.10.1":
        errors.append("workspace pipewire dependency must remain on 0.10.1")
    if "v0_3_41" not in set(pipewire_dep.get("features", [])):
        errors.append("workspace pipewire dependency missing v0_3_41 trigger feature")

members = workspace.get("workspace", {}).get("members", [])
if members.count("crates/aetherstream-control") != 1:
    errors.append("aetherstream-control must exist exactly once in workspace")

required_files = [
    "crates/aetherstream-control/Cargo.toml",
    "crates/aetherstream-control/src/session.rs",
    "crates/aetherstream-control/src/state.rs",
    "crates/aetherstream-control/src/reducer.rs",
    "crates/aetherstream-control/src/router.rs",
    "crates/aetherstream-control/src/orchestrator.rs",
    "crates/aetherstream-control/src/subscription.rs",
    "crates/aetherstream-storage/src/session.rs",
    "scripts/smoke-state-sync.sh",
    "scripts/smoke-session-graph.sh",
    "scripts/smoke-control-roundtrip.sh",
    "scripts/check-live-workstation.py",
    "scripts/check-ui-consolidation.py",
    "crates/aetherstream-ui/src/bridge.rs",
    "crates/aetherstream-integrations/src/operation.rs",
    "crates/aetherstream-integrations/src/twitch.rs",
    "scripts/check-provider-operations.py",
    "scripts/check-creator-controls.py",
    "scripts/smoke-provider-operations.sh",
    "scripts/check-visual-login.py",
    "scripts/smoke-auth-actions.sh",
    "crates/aetherstream-auth/src/flow.rs",
    "crates/aetherstream-storage/src/account.rs",
    "crates/aetherstream-auth/src/http.rs",
    "crates/aetherstream-auth/src/runtime.rs",
    "scripts/check-auth-runtime.py",
    "scripts/check-secret-isolation.py",
    "scripts/check-smart-restore.py",
    "scripts/check-streamlabs-studio.py",
    "scripts/check-visual-system.py",
    "scripts/smoke-auth-runtime.sh",
    "scripts/smoke-smart-restore.sh",
    "CONFIGURE-AUTH.sh",
    "crates/aetherstream-core/src/output_dsp.rs",
    "crates/aetherstream-core/tests/output_dsp_profile.rs",
    "crates/aetherstream-audio/src/output_dsp.rs",
    "crates/aetherstream-audio/tests/output_dsp_processor.rs",
    "crates/aetherstream-control/tests/output_dsp_state.rs",
    "crates/aetherstream-storage/tests/output_dsp_store.rs",
    "docs/superpowers/specs/2026-09-03-aetherstream-output-dsp-design.md",
    "docs/superpowers/plans/2026-09-03-aetherstream-output-dsp.md",
    "crates/aetherstream-audio/src/live_dsp.rs",
    "crates/aetherstream-audio/tests/live_output_dsp.rs",
    "crates/aetherstream-core/src/output_dsp_runtime.rs",
    "apps/aetherstream-audiod/Cargo.toml",
    "apps/aetherstream-audiod/src/main.rs",
    "scripts/check-v10.2.43-core-registry-lifetime.py",
    "crates/aetherstream-core/src/forgehx_bridge.rs",
    "scripts/check-v10.2.43-system-audio.py",
    "scripts/check-v10.2.43-pipewire-trigger-feature.py",
    "scripts/check-early-verify-handoff.py",
    "scripts/check-early-verify-runtime.sh",
    "scripts/check-installer-stage-diagnostics.py",
    "scripts/check-installer-stage-runtime.sh",
    "scripts/check-v10.2.43-user-dsp-plugin.py",
    "scripts/check-v10.2.43-shared-output-import.py",
    "scripts/check-v10.2.43-awk-node-name.py",
    "scripts/check-v10.2.43-peq.py",
    "scripts/check-v10.2.43-host-regressions.py",
    "scripts/smoke-system-audio-runtime.sh",
    "docs/superpowers/specs/2026-09-03-system-audio-forgehx-bridge-design.md",
    "docs/superpowers/plans/2026-09-03-system-audio-forgehx-bridge.md",
    "apps/aetherstream-supervisord/src/output_dsp_runtime.rs",
    "scripts/check-live-output-dsp.py",
    "scripts/check-hdmi3-physical-output.py",
    "scripts/smoke-live-output-dsp-runtime.sh",
    "packaging/systemd/aetherstream-audiod.service",
    "docs/superpowers/specs/2026-09-03-aetherstream-live-output-dsp-design.md",
    "docs/superpowers/plans/2026-09-03-aetherstream-v10.2.32-live-output-dsp.md",
]
for rel in required_files:
    if not (root / rel).is_file():
        errors.append(f"missing required file: {rel}")

rust_files = [p for p in root.rglob("*.rs") if "target" not in p.parts]
field_reassign_pattern = re.compile(
    r"let\s+mut\s+(\w+)\s*=\s*[A-Za-z0-9_:<>]+::default\(\);\s*\1\.\w+\s*=",
    re.S,
)
for rust_file in rust_files:
    if field_reassign_pattern.search(rust_file.read_text()):
        errors.append(f"field_reassign_with_default regression remains: {rust_file.relative_to(root)}")

action_defs = sum(len(re.findall(r"pub\s+enum\s+AetherStreamAction\b", p.read_text())) for p in rust_files)
event_defs = sum(len(re.findall(r"pub\s+enum\s+UnifiedEventKind\b", p.read_text())) for p in rust_files)
if action_defs != 1:
    errors.append(f"expected one canonical AetherStreamAction enum, found {action_defs}")
if event_defs != 1:
    errors.append(f"expected one canonical UnifiedEventKind enum, found {event_defs}")


subscription_text = (root / "crates/aetherstream-control/src/subscription.rs").read_text()
if "Snapshot(Box<AetherState>)" not in subscription_text:
    errors.append("SubscriptionUpdate snapshot must box AetherState")
if "Snapshot(AetherState)" in subscription_text:
    errors.append("inline SubscriptionUpdate AetherState snapshot remains")

reducer_text = (root / "crates/aetherstream-control/src/reducer.rs").read_text()
if re.search(r"if let Some\(profile\).*?\{\s*if state\.recording\.profile", reducer_text, re.S):
    errors.append("collapsible recording-profile reducer conditional remains")

ipc_text = (root / "crates/aetherstream-ipc/src/protocol.rs").read_text()
if "StateSnapshot(Box<AetherState>)" not in ipc_text:
    errors.append("ControlResponse state snapshot must box AetherState")
if "allow(clippy::large_enum_variant)" in ipc_text:
    errors.append("large_enum_variant suppression remains in IPC protocol")

core_identity = (root / "crates/aetherstream-core/src/identity.rs").read_text()
if "uuid_id!(SessionId);" not in core_identity:
    errors.append("SessionId missing from core identity")

session_text = (root / "crates/aetherstream-control/src/session.rs").read_text()
start = session_text.find("pub struct BroadcastSession")
end = session_text.find("impl BroadcastSession", start)
session_fields = session_text[start:end].lower() if start >= 0 and end > start else ""
for forbidden in ["access_token", "refresh_token", "oauth_secret", "password:"]:
    if forbidden in session_fields:
        errors.append(f"session model contains secret-bearing field: {forbidden}")

router = (root / "crates/aetherstream-control/src/router.rs").read_text()
for required in ["AudioGain", "DeckProfile", "SessionGoLive", "Macro", "TwitchCreatePoll", "ObsTransition", "StreamElementsOverlay", "StreamlabsMediaShare", "AetherStreamAction::Auth"]:
    if required not in router:
        errors.append(f"action router missing {required}")

verify = (root / "scripts/verify-release.sh").read_text()
required_gates = [
    "AETHERSTREAM_SESSION_GRAPH",
    "AETHERSTREAM_ACTION_ROUTING",
    "AETHERSTREAM_STATE_SYNC",
    "AETHERSTREAM_MULTI_INSTANCE",
    "AETHERSTREAM_DECK_SYNC",
    "AETHERSTREAM_AUDIO_DSP_SCHEMA",
    "AETHERSTREAM_AV_SCHEMA",
    "AETHERSTREAM_PROVIDER_EVENT_BUS",
    "AETHERSTREAM_WORKSPACE_RESTORE",
    "AETHERSTREAM_LIVE_UI_BRIDGE",
    "AETHERSTREAM_FORGE_MASTER_UI",
    "AETHERSTREAM_CONTROL_ROUNDTRIP",
    "AETHERSTREAM_UI_CONSOLIDATION",
    "AETHERSTREAM_PROVIDER_OPERATIONS",
    "AETHERSTREAM_CREATOR_CONTROLS",
    "AETHERSTREAM_VISUAL_LOGIN",
    "AETHERSTREAM_AUTH_ACTIONS",
    "AETHERSTREAM_AUTH_RUNTIME",
    "AETHERSTREAM_SECRET_ISOLATION",
    "AETHERSTREAM_SMART_RESTORE",
    "AETHERSTREAM_STREAMLABS_STUDIO",
    "AETHERSTREAM_VISUAL_SYSTEM",
    "AETHERSTREAM_SYSTEM_AUDIO_AUTHORITY",
    "AETHERSTREAM_SYSTEM_MIC",
    "AETHERSTREAM_FORGEHX_BRIDGE",
    "AETHERSTREAM_AWK_NODE_NAME",
]
for gate in required_gates:
    if gate not in verify:
        errors.append(f"verification gate missing {gate}")
if verify.count("status_ui_consolidation=FAIL") != 1:
    errors.append("UI consolidation verifier state must not be reset after static contract check")

ui_bridge = (root / "crates/aetherstream-ui/src/bridge.rs").read_text()
if "impl Default for UiControlBridge" in ui_bridge:
    errors.append("UiControlBridge Default must be derived, not manually implemented")
if "TryRecvError" in ui_bridge or re.search(r"loop\s*\{\s*match receiver\.try_recv\(\)", ui_bridge, re.S):
    errors.append("UiControlBridge state drain must use while-let try_recv loop")
ui_app = (root / "crates/aetherstream-ui/src/app.rs").read_text()
auth_runtime = (root / "crates/aetherstream-auth/src/runtime.rs").read_text()
if re.search(r"AccountMetadataStore,\s*SecretBytes,\s*SecretKey", auth_runtime):
    errors.append("unused SecretBytes auth-runtime import regression remains")
if "fn render_obs(&mut self, ui: &mut egui::Ui)" in ui_app:
    errors.append("orphan render_obs UI method regression remains")
if ".default_width(" in ui_app:
    errors.append("egui Panel default_width API regression remains; use Panel::default_size")
if re.search(r'_\s*=>\s*ui\.label\("AetherStream shared workstation"\)\s*,', ui_app):
    errors.append("fallback tab renderer must return unit, not egui::Response")
app_main = (root / "apps/aetherstream/src/main.rs").read_text()
for required in ["UiControlBridge", "dispatch", "drain_latest"]:
    if required not in ui_bridge:
        errors.append(f"live UI bridge missing {required}")
for required in ["AetherStreamAction::ObsScene", "AetherStreamAction::AudioGain", "AetherStreamAction::RecordingToggle", "AetherStreamAction::DeckProfile"]:
    if required not in ui_app:
        errors.append(f"Forge Master live control missing {required}")
if "spawn_ui_worker" not in app_main:
    errors.append("desktop does not spawn shared-state UI worker")
if re.search(
    r"if let Some\(\(_, ControlResponse::StateSnapshot\(state\)\)\)\s*=.*?\{\s*if last_revision != Some\(state\.revision\)",
    app_main,
    re.S,
):
    errors.append("collapsible UI state-refresh conditional remains")

provider_ops = (root / "scripts/check-provider-operations.py").read_text()
creator_controls = (root / "scripts/check-creator-controls.py").read_text()
for required in ["ProviderOperation", "translate_action", "smoke-provider-operations.sh"]:
    if required not in provider_ops:
        errors.append(f"provider operations contract missing {required}")
for required in ["TwitchCreatePoll", "ObsTransition", "StreamElementsOverlay", "StreamlabsMediaShare"]:
    if required not in creator_controls:
        errors.append(f"creator controls contract missing {required}")

panels_text = (root / "crates/aetherstream-ui/src/panels.rs").read_text()
primary_start = panels_text.find("pub const PRIMARY_TABS")
primary_end = panels_text.find("];", primary_start)
primary_block = panels_text[primary_start:primary_end] if primary_start >= 0 and primary_end > primary_start else ""
for required in ["Home", "Live", "Streamlabs", "StreamElements", "A/V Studio", "Settings"]:
    if f'"{required}"' not in primary_block:
        errors.append(f"consolidated primary tab missing {required}")
if primary_block.count('"') // 2 != 6:
    errors.append("consolidated UI must expose exactly six primary tabs")
if '"OBS"' in primary_block:
    errors.append("OBS must not remain a primary tab")

installer = (root / "INSTALL-AETHERSTREAM.sh").read_text()
for required in [
    "VERSION=\"10.2.47\"",
    "AETHERSTREAM_BUILD_TMP_DIR",
    "TMPDIR=",
    "TMP=",
    "TEMP=",
    "export CARGO_TARGET_DIR CARGO_INCREMENTAL AETHERSTREAM_BUILD_TMP_DIR",
    "export TMPDIR TMP TEMP",
    "df -Pk",
    "build-space-preflight",
    "AetherStream-v${VERSION}-VERIFY.txt",
    "write_running_verify",
    "set_stage() {",
    "AetherStream-v${VERSION}-INSTALL.log",
    'pacman -Q "$package"',
    "write_early_failure_verify",
    "--self-test-early-verify",
    "AETHERSTREAM_VERIFY=RUNNING",
    "AETHERSTREAM_VERIFY=FAIL",
]:
    if required not in installer:
        errors.append(f"install contract missing {required}")

for required in [
    "AETHERSTREAM_BUILD_TMP_DIR",
    "TMPDIR=",
    "TMP=",
    "TEMP=",
    "export CARGO_TARGET_DIR CARGO_INCREMENTAL AETHERSTREAM_BUILD_TMP_DIR",
    "export TMPDIR TMP TEMP",
    "df -Pk",
]:
    if required not in verify:
        errors.append(f"verify compiler-temp contract missing {required}")

awk_parser = "awk -F= '/node.name/{v=$2; gsub(/^[[:space:]\"]+|[[:space:]\"]+$/, \"\", v); print v; exit}'"
for rel in ["INSTALL-AETHERSTREAM.sh", "scripts/smoke-live-output-dsp-runtime.sh", "scripts/smoke-system-audio-runtime.sh"]:
    text = (root / rel).read_text()
    node_lines = [line for line in text.splitlines() if "awk -F=" in line and "/node.name/" in line]
    if len(node_lines) != 1 or awk_parser not in node_lines[0]:
        errors.append(f"{rel}: non-portable node.name awk parser")
    if node_lines and r'\\\"' in node_lines[0]:
        errors.append(f"{rel}: escaped quote remains in awk regex")
if "AETHERSTREAM_AWK_NODE_NAME" not in verify:
    errors.append("verification gate missing AETHERSTREAM_AWK_NODE_NAME")
if "AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS" not in verify:
    errors.append("verification gate missing AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS")
for gate in [
    "AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT",
    "AETHERSTREAM_DSP_PLUGIN_USER_INSTALL",
    "AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED",
    "AETHERSTREAM_LADSPA_PATH",
]:
    if gate not in verify:
        errors.append(f"verification gate missing {gate}")
for required in [
    'LADSPA_DIR="$HOME/.local/lib/aetherstream/ladspa"',
    'AETHERSTREAM_DSP_PLUGIN_PATH="$LADSPA_SO"',
    'dedupe_colon_path',
    'systemctl --user set-environment "LADSPA_PATH=$MERGED_LADSPA_PATH"',
]:
    if required not in installer:
        errors.append(f"user-session DSP install contract missing {required}")
for forbidden in [
    'LADSPA_DIR="/usr/lib/ladspa"',
    'sudo install -Dm755 target/release/libaetherstream_hdmi3_dsp.so',
]:
    if forbidden in installer:
        errors.append(f"root DSP installation remains: {forbidden}")

for rel in ["README.md", "INSTALL-AETHERSTREAM.sh", "scripts/verify-release.sh", "scripts/check-clean-tree.py"]:
    text = (root / rel).read_text()
    versions = set(re.findall(r"(?<![\d.])10\.\d+\.\d+(?![\d.])", text))
    stale = sorted(version for version in versions if version not in {"10.2.43", "10.2.45", "10.2.46", "10.2.47"})
    if stale:
        errors.append(f"{rel}: stale release versions {stale}")

versioned_script_pattern = re.compile(r"10\.\d+\.\d+")
stale_scripts = []
for script in (root / "scripts").iterdir():
    if not script.is_file():
        continue
    match = versioned_script_pattern.search(script.name)
    if match and match.group(0) not in {"10.2.43", "10.2.45", "10.2.46", "10.2.47"}:
        stale_scripts.append(str(script.relative_to(root)))
if stale_scripts:
    errors.append(f"stale versioned scripts remain: {sorted(stale_scripts)}")



# v10.2.32 native output-DSP + display-speaker + gaming-mode contract.
core_dsp = (root / "crates/aetherstream-core/src/output_dsp.rs").read_text()
audio_dsp = (root / "crates/aetherstream-audio/src/output_dsp.rs").read_text()
control_state = (root / "crates/aetherstream-control/src/state.rs").read_text()
storage_db = (root / "crates/aetherstream-storage/src/db.rs").read_text()
storage_migrations = (root / "crates/aetherstream-storage/src/migrations.rs").read_text()
ui_theme = (root / "crates/aetherstream-ui/src/theme.rs").read_text()
auth_action = (root / "crates/aetherstream-core/src/action.rs").read_text()
supervisor_main = (root / "apps/aetherstream-supervisord/src/main.rs").read_text()

for required in [
    "DesktopSpeaker", "BookshelfSpeaker", "StudioMonitor",
    "DesktopMonitorSpeaker", "TvSpeaker", "Soundbar", "Speaker2_1", "Speaker5_1", "Speaker7_1", "OpenBackHeadphone",
    "ClosedBackHeadphone", "GamingHeadset", "Iem", "WiredEarbud",
    "BluetoothEarbud", "BluetoothHeadphone", "BluetoothPortableSpeaker", "Bluetooth360Speaker", "BluetoothStereoPortableSpeaker", "BluetoothDesktopSpeaker", "BluetoothBookshelfSpeaker", "BluetoothSpeaker2_0", "BluetoothSpeaker2_1", "BluetoothSoundbar", "BluetoothSoundbarSubwoofer", "BluetoothTvSpeaker", "BluetoothSmartSpeaker", "BluetoothPartySpeaker", "BluetoothOutdoorSpeaker", "BluetoothPaSpeaker", "BluetoothMultiSpeaker", "UltimateEarsWonderboom4", "VehicleAudio",
    "ExternalAudio", "Custom", "HighPass", "LowPass", "BandPass",
    "Peak", "Notch", "LowShelf", "HighShelf", "OutputLimiter",
    "OutputGamingMode", "pub gaming: OutputGamingMode",
    "pub const ALL: [Self; 35]", "for_display_speakers", "pub fn factory",
]:
    if required not in core_dsp:
        errors.append(f"output DSP profile contract missing {required}")


for required in [
    "PEQ_MIN_BANDS", "PEQ_MAX_BANDS", "PEQ_MIN_FREQUENCY_HZ", "PEQ_MAX_FREQUENCY_HZ",
    "OutputParametricEqBand", "ParametricEqBandKind", "parametric_eq", "normalize_parametric_eq",
]:
    if required not in core_dsp:
        errors.append(f"v10.2.43 PEQ schema missing {required}")

classifier_start = core_dsp.find("pub const fn is_bluetooth_speaker")
classifier_end = core_dsp.find("pub const fn label", classifier_start)
if classifier_start < 0 or "matches!(" not in core_dsp[classifier_start:classifier_end]:
    errors.append("v10.2.43 Bluetooth classifier must use matches! for Rust 1.98 Clippy")
for required in [
    "fn peq_log_frequency",
    "return PEQ_MAX_FREQUENCY_HZ",
    "peq_log_frequency(index, target)",
    "generated_parametric_eq_sizes_pin_exact_frequency_boundaries",
    "legacy_peq_float_overshoot_normalizes_to_exact_upper_boundary",
]:
    combined_peq = core_dsp + (root / "crates/aetherstream-core/tests/output_dsp_profile.rs").read_text()
    if required not in combined_peq:
        errors.append(f"v10.2.43 PEQ boundary regression missing {required}")

for required in [
    "OutputDspProcessor", "process_interleaved", "reconfigure",
    "first_order_coefficients", "biquad_coefficients", "soft_limit",
    "OutputFilterKind::LowShelf", "OutputFilterKind::Peak",
    "append_gaming_mode", "profile.gaming.enabled",
]:
    if required not in audio_dsp:
        errors.append(f"native Rust DSP processor missing {required}")
if "samples.len() % self.channels != 0" in audio_dsp:
    errors.append("manual_is_multiple_of Clippy regression remains in output DSP buffer guard")
if "!samples.len().is_multiple_of(self.channels)" not in audio_dsp:
    errors.append("output DSP buffer guard must use usize::is_multiple_of")
if "Vec::" in audio_dsp[audio_dsp.find("pub fn process_interleaved"):audio_dsp.find("fn rebuild")]:
    errors.append("output DSP sample loop must not allocate Vec storage")

for required in ["OutputDspState", "output_dsp: OutputDspState"]:
    if required not in control_state:
        errors.append(f"output DSP state contract missing {required}")
for required in ["save_output_dsp_profile", "load_output_dsp_profiles"]:
    if required not in storage_db:
        errors.append(f"output DSP persistence missing {required}")
if "output_dsp_profiles" not in storage_migrations:
    errors.append("output DSP SQLite migration missing output_dsp_profiles")
for required in ["OutputDspApply", "OutputDspBypass"]:
    if required not in auth_action or f"AetherStreamAction::{required}" not in router:
        errors.append(f"output DSP canonical action/routing missing {required}")
for required in ["OutputDspApply", "OutputDspBypass", "load_output_dsp_profiles"]:
    if required not in supervisor_main:
        errors.append(f"output DSP supervisor projection missing {required}")

for required in [
    "Audio devices & full-range DSP", "Bass boost", "Clarity boost",
    "Gaming mode", "profile.gaming.enabled", "Crossover & protection filters",
    "Parametric EQ — 15–31 bands", "15-band", "21-band", "25-band", "31-band",
    "+ Band", "- Band", "+ High-pass", "+ Mid-pass", "+ Low-pass",
    "● LIVE • AUTO-APPLY — valid changes are sent while controls move", "OutputDeviceClass::ALL",
]:
    if required not in ui_app:
        errors.append(f"DragonGlass DSP editor missing {required}")
for required in [
    "DRAGONGLASS_ACCENT_DEEP", "DRAGONGLASS_BASS", "DRAGONGLASS_CLARITY",
    "DRAGONGLASS_GAMING", "dsp_card", "CornerRadius::same(8)",
]:
    if required not in ui_theme:
        errors.append(f"DragonGlass DSP theme missing {required}")

for gate in [
    "AETHERSTREAM_OUTPUT_DSP_PROFILE",
    "AETHERSTREAM_OUTPUT_DSP_PROCESSOR",
    "AETHERSTREAM_OUTPUT_DSP_PERSISTENCE",
    "AETHERSTREAM_OUTPUT_DSP_UI",
]:
    if gate not in verify:
        errors.append(f"verification gate missing {gate}")

core_dsp_tests = (root / "crates/aetherstream-core/tests/output_dsp_profile.rs").read_text()
audio_dsp_tests = (root / "crates/aetherstream-audio/tests/output_dsp_processor.rs").read_text()
storage_dsp_tests = (root / "crates/aetherstream-storage/tests/output_dsp_store.rs").read_text()
for required in [
    "tv_speaker_factory_profile_is_small_driver_safe",
    "desktop_monitor_speaker_factory_profile_is_small_driver_safe",
    "display_speaker_classifier_distinguishes_tv_from_desktop_monitor",
    "gaming_mode_defaults_off",
]:
    if required not in core_dsp_tests:
        errors.append(f"v10.2.32 core DSP regression test missing {required}")
if "gaming_mode_overlay_boosts_detail_and_reduces_low_mid_masking" not in audio_dsp_tests:
    errors.append("v10.2.32 gaming processor regression test missing")
if "gaming_mode_round_trip_is_persisted_per_device" not in storage_dsp_tests:
    errors.append("v10.2.32 gaming persistence regression test missing")
for gate in ["AETHERSTREAM_DISPLAY_SPEAKERS", "AETHERSTREAM_GAMING_MODE"]:
    if gate not in verify:
        errors.append(f"verification gate missing {gate}")

# v10.2.43 live output DSP / auto-apply contract.
live_contract = (root / "scripts/check-live-output-dsp.py").read_text()
live_audio = (root / "crates/aetherstream-audio/src/live_dsp.rs").read_text()
shared_audio = (root / "crates/aetherstream-audio/src/shared_output_dsp.rs").read_text()
if "use crate::live_dsp::{LiveBiquadCoefficients, LiveDspPlan, MAX_LIVE_CHANNELS, MAX_LIVE_SECTIONS};" not in shared_audio:
    errors.append("v10.2.43 shared output DSP must import LiveBiquadCoefficients from crate::live_dsp")
if "use crate::{LiveBiquadCoefficients, LiveDspPlan, MAX_LIVE_CHANNELS, MAX_LIVE_SECTIONS};" in shared_audio:
    errors.append("v10.2.43 shared output DSP still imports LiveBiquadCoefficients from crate root")
plugin_audio = (root / "crates/aetherstream-dsp-ladspa/src/lib.rs").read_text()
plugin_cargo = (root / "crates/aetherstream-dsp-ladspa/Cargo.toml").read_text()
wp_internal = (root / "packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in").read_text()
live_tests = (root / "crates/aetherstream-audio/tests/live_output_dsp.rs").read_text()
audiod_main = (root / "apps/aetherstream-audiod/src/main.rs").read_text()
audiod_unit = (root / "packaging/systemd/aetherstream-audiod.service").read_text()
supervisor_runtime = (root / "apps/aetherstream-supervisord/src/output_dsp_runtime.rs").read_text()
for required in [
    "resolve_selected_physical_sink", "resolve_hdmi3_physical_sink", "HDMI3_LOADOUT_ID", "SharedOutputDspWriter",
    "output_dsp_shared_path", "shared_writer.publish(&plan)", "output-dsp.sock",
]:
    if required not in audiod_main:
        errors.append(f"internal HDMI3 audiod control path missing {required}")
for forbidden in [
    "HDMI3_FILTER_INPUT_NAME", "HDMI3_FILTER_PLAYBACK_NAME", "filter.smart",
    '"media.class" => "Audio/Sink"', "fn run_pipewire(", "StreamBox::new",
    "aetherstream.dsp.sink",
]:
    if forbidden in audiod_main:
        errors.append(f"audiod still creates a forbidden output stream/node: {forbidden}")
if "let fallback_capture = pw::stream::StreamRc::new(\n        core.clone()," not in audiod_main:
    errors.append("physical microphone fallback must clone CoreRc while registry borrows original core")
if "AETHERSTREAM_CORE_REGISTRY_LIFETIME" not in verify:
    errors.append("verification gate missing AETHERSTREAM_CORE_REGISTRY_LIFETIME")
for required in [
    "SharedOutputDspWriter", "SharedOutputDspReader", "OUTPUT_DSP_SHARED_FILE",
    "AtomicU32", "snapshot_layout",
]:
    if required not in shared_audio:
        errors.append(f"shared output DSP contract missing {required}")
for required in [
    "aetherstream_hdmi3_dsp_stereo", "ladspa_descriptor", "LiveDspProcessor",
    "SharedOutputDspReader", "physical-output-internal-dsp.active",
]:
    if required not in plugin_audio:
        errors.append(f"Rust LADSPA internal DSP missing {required}")
if 'crate-type = ["cdylib", "rlib"]' not in plugin_cargo:
    errors.append("Rust internal DSP plugin must build as cdylib + rlib")
for required in [
    "node.filter-graph.rules", "create-filter-graph", "type = ladspa",
    "aetherstream_hdmi3_dsp_stereo", "__AETHERSTREAM_PRIMARY_NODE_NAME__", "__AETHERSTREAM_DSP_PLUGIN_PATH__", '"node.name" = "~bluez_output.*"',
]:
    if required not in wp_internal:
        errors.append(f"WirePlumber internal graph missing {required}")
for forbidden in ["filter.smart", "node.software-dsp.rules", "node.virtual"]:
    if forbidden in wp_internal:
        errors.append(f"WirePlumber config uses forbidden separate-node DSP mechanism: {forbidden}")
for gate in [
    "AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING", "AETHERSTREAM_PHYSICAL_OUTPUT",
    "AETHERSTREAM_HDMI3_LOADOUT", "AETHERSTREAM_HDMI3_INTERNAL_DSP",
    "AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS", "AETHERSTREAM_EXTRA_OUTPUT_STREAMS",
    "AETHERSTREAM_SMART_FILTER_NODES", "AETHERSTREAM_HDMI3_OUTPUT_NODE_COUNT",
    "AETHERSTREAM_HDMI3_DSP_AUTO_APPLY", "AETHERSTREAM_HDMI3_RECONNECT_RESTORE",
]:
    if gate not in verify:
        errors.append(f"HDMI3 verification gate missing {gate}")

for required in [
    "MAX_LIVE_SECTIONS", "sections: [LiveBiquadCoefficients; MAX_LIVE_SECTIONS]",
    "begin_transition", "transition_samples_remaining",
]:
    if required not in live_audio:
        errors.append(f"live DSP RT plan missing {required}")
if "Mutex" in live_audio or "RwLock" in live_audio:
    errors.append("live DSP RT plan contains blocking lock")
for required in [
    "live_bass_boost_measures_in_target_band_without_lifting_presence_band",
    "live_clarity_boost_measures_in_target_band_without_lifting_bass_band",
    "bypass_is_effectively_unity", "new_plan_crossfades_instead_of_jumping_in_one_sample",
]:
    if required not in live_tests:
        errors.append(f"live response regression test missing {required}")
for required in ["output-dsp.sock", "OutputDspRuntimeRequest::Apply", "apply_output_dsp_profile"]:
    if required not in supervisor_runtime:
        errors.append(f"supervisor live DSP bridge missing {required}")
for required in ["aetherstream-audiod", "Restart=on-failure"]:
    if required not in audiod_unit:
        errors.append(f"audiod systemd contract missing {required}")
if "Apply DSP profile" in ui_app:
    errors.append("manual output DSP Apply button remains in v10.2.32")
app_main = (root / "apps/aetherstream/src/main.rs").read_text()
if "std::thread::sleep(Duration::from_millis(16));" not in app_main:
    errors.append("live DSP UI worker latency contract is not 16 ms")
if "push_live_output_dsp(Arc::clone(&control), device_id, profile).await;" not in supervisor_main:
    errors.append("live DSP supervisor followup is not ordered/awaited")
for gate in [
    "AETHERSTREAM_LIVE_PIPEWIRE_DSP", "AETHERSTREAM_DSP_AUTO_APPLY",
    "AETHERSTREAM_BASS_RESPONSE", "AETHERSTREAM_CLARITY_RESPONSE",
    "AETHERSTREAM_DSP_RT_SAFETY",
]:
    if gate not in verify:
        errors.append(f"verification gate missing {gate}")
if "AETHERSTREAM_LIVE_OUTPUT_DSP_CONTRACT" not in live_contract:
    errors.append("live output DSP static contract lacks final PASS endpoint")

auth_config = (root / "CONFIGURE-AUTH.sh").read_text()
systemd_service = (root / "packaging/systemd/aetherstream-supervisord.service").read_text()
for required in ["secret-tool store", "aetherstream:Streamlabs:default:client-secret", "auth.env"]:
    if required not in auth_config:
        errors.append(f"secure auth configurator missing {required}")
if "EnvironmentFile=-%h/.config/aetherstream/auth.env" not in systemd_service:
    errors.append("supervisor does not load non-secret OAuth application configuration")

auth_runtime = (root / "crates/aetherstream-auth/src/runtime.rs").read_text()
auth_http = (root / "crates/aetherstream-auth/src/http.rs").read_text()
secret_store = (root / "crates/aetherstream-storage/src/secret.rs").read_text()
for required in ["AuthRuntime", "run_smart_restore", "restore_twitch_with_refresh", "restore_streamlabs_with_refresh"]:
    if required not in auth_runtime:
        errors.append(f"auth runtime missing {required}")
for required in ['#[serde(rename = "expires_in")]', '#[serde(rename = "interval")]', "twitch_validate", "streamlabs_exchange_code"]:
    combined = (root / "crates/aetherstream-auth/src/device_code.rs").read_text() + auth_http + auth_runtime
    if required not in combined:
        errors.append(f"auth provider runtime missing {required}")
for required in ["LinuxSecretStore", "SecretBytes([REDACTED;", "blocking::SecretService"]:
    if required not in secret_store:
        errors.append(f"secret isolation backend missing {required}")

visual_login = (root / "scripts/check-visual-login.py").read_text()
for required in ["AuthProvider", "Streamlabs Studio", "Smart restore", "DRAGONGLASS_ACCENT"]:
    if required not in visual_login:
        errors.append(f"visual/login contract missing {required}")

auth_action = (root / "crates/aetherstream-core/src/action.rs").read_text()
for required in ["AuthProvider", "AetherAuthAction", "AccountConnection", "Auth(AetherAuthAction)"]:
    if required not in auth_action:
        errors.append(f"auth action model missing {required}")
if "fn render_obs_workspace" in ui_app:
    errors.append("separate OBS workspace renderer remains")
for required in ["Streamlabs Studio", "Settings → Accounts", "Twitch Device Code"]:
    if required not in ui_app:
        errors.append(f"v10.2.32 UI missing {required}")


behringer_volume = (root / "apps/aetherstream-supervisord/src/behringer_volume.rs").read_text()
for required in [
    "SystemVolumeRequest", "system-volume.sock", "BEHRINGER_IPC_PROTOCOL_VERSION",
    "SYSTEM_VOLUME_PROTOCOL_VERSION", "@DEFAULT_AUDIO_SINK@", "wpctl",
    "run_behringer_system_volume_listener", "apply_system_output_volume"
]:
    if required not in behringer_volume:
        errors.append(f"Behringer system-volume bridge missing {required}")
if "SystemOutputVolume { normalized_10k: u16 }" not in auth_action:
    errors.append("canonical AetherStreamAction missing SystemOutputVolume")
if "AetherStreamAction::SystemOutputVolume { .. }" not in router:
    errors.append("system output volume does not route to Audio owner")
supervisor_main = (root / "apps/aetherstream-supervisord/src/main.rs").read_text()
for required in ["run_behringer_system_volume_listener", "apply_system_output_volume", "AetherStreamAction::SystemOutputVolume"]:
    if required not in supervisor_main:
        errors.append(f"supervisor system-volume execution missing {required}")
if "AETHERSTREAM_BEHRINGER_SYSTEM_VOLUME" not in verify:
    errors.append("verification gate missing AETHERSTREAM_BEHRINGER_SYSTEM_VOLUME")


for required in [
    "BluetoothPortableSpeaker", "Bluetooth360Speaker", "BluetoothStereoPortableSpeaker",
    "BluetoothDesktopSpeaker", "BluetoothBookshelfSpeaker", "BluetoothSpeaker2_0",
    "BluetoothSpeaker2_1", "BluetoothSoundbar", "BluetoothSoundbarSubwoofer",
    "BluetoothTvSpeaker", "BluetoothSmartSpeaker", "BluetoothPartySpeaker",
    "BluetoothOutdoorSpeaker", "BluetoothPaSpeaker", "BluetoothMultiSpeaker",
    "UltimateEarsWonderboom4", "for_bluetooth_speaker_name", "is_bluetooth_speaker",
    "bluetooth_loadout_id",
]:
    if required not in core_dsp:
        errors.append(f"v10.2.43 Bluetooth speaker contract missing {required}")
for required in [
    "resolve_selected_physical_sink", "--print-physical-output-loadout-id",
    "api.bluez5.address", "api.bluez5.codec",
]:
    if required not in audiod_main:
        errors.append(f"v10.2.43 physical output runtime missing {required}")
if '"node.name" = "~bluez_output.*"' not in wp_internal:
    errors.append("v10.2.43 WirePlumber graph must match Bluetooth physical sinks")

# v10.2.47 linked HDMI + Bluetooth output contract.
linked_audio = (root / "crates/aetherstream-audio/src/linked_output.rs").read_text()
linked_action = (root / "crates/aetherstream-core/src/action.rs").read_text()
linked_supervisor = (root / "apps/aetherstream-supervisord/src/main.rs").read_text()
linked_app = (root / "apps/aetherstream/src/main.rs").read_text()
linked_audiod = (root / "apps/aetherstream-audiod/src/main.rs").read_text()
for required in ["LinkedOutputConfig", "LinkedOutputConfigure"]:
    if required not in linked_action:
        errors.append(f"v10.2.47 linked output action missing {required}")
for required in ["module-combine-sink", "latency_compensate=true", "aetherstream_linked_hdmi_bluetooth", "refresh_linked_output_levels"]:
    if required not in linked_audio:
        errors.append(f"v10.2.47 linked output backend missing {required}")
for required in ["apply_linked_output_runtime", "run_linked_output_watcher", "refresh_linked_output_levels"]:
    if required not in linked_supervisor:
        errors.append(f"v10.2.47 linked output supervisor missing {required}")
if "linked-output=" not in linked_app:
    errors.append("v10.2.47 headless linked-output action parser missing")
if 'starts_with("aetherstream")' not in linked_audiod:
    errors.append("v10.2.47 audiod must exclude all AetherStream-created sinks from physical output selection")

# v10.2.47 linked-output installer quiesce hotfix contract.
installer = (root / "INSTALL-AETHERSTREAM.sh").read_text()
for required in [
    "WAS_SUPERVISORD_ACTIVE=0",
    'set_stage "stop-previous-supervisord"',
    "systemctl --user stop aetherstream-supervisord.service",
    "WAS_SUPERVISORD_ACTIVE -eq 1",
    "systemctl --user start aetherstream-supervisord.service",
    'set_stage "linked-output-quiesce-wait"',
    "AETHERSTREAM_LINKED_OUTPUT_QUIESCE=FAIL:linked-sink-remained-default",
]:
    if required not in installer:
        errors.append(f"v10.2.47 supervisor quiesce contract missing {required}")
audiod = (root / "apps/aetherstream-audiod/src/main.rs").read_text()
if "refusing to bind output DSP to an AetherStream-created node" not in audiod:
    errors.append("v10.2.47 must preserve physical-DSP anti-recursion guard")

if errors:
    print("AETHERSTREAM_SOURCE_CONTRACT=FAIL")
    for error in errors:
        print(error)
    sys.exit(1)
print("AETHERSTREAM_SOURCE_CONTRACT=PASS")
