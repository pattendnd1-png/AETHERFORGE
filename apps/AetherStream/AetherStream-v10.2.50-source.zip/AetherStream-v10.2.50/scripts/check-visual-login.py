#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors: list[str] = []

panels = (root / 'crates/aetherstream-ui/src/panels.rs').read_text()
app = (root / 'crates/aetherstream-ui/src/app.rs').read_text()
theme = (root / 'crates/aetherstream-ui/src/theme.rs').read_text()
action = (root / 'crates/aetherstream-core/src/action.rs').read_text()
router = (root / 'crates/aetherstream-control/src/router.rs').read_text()
state = (root / 'crates/aetherstream-control/src/state.rs').read_text()
auth_lib = (root / 'crates/aetherstream-auth/src/lib.rs').read_text()

primary_start = panels.find('pub const PRIMARY_TABS')
primary_end = panels.find('];', primary_start)
primary = panels[primary_start:primary_end] if primary_start >= 0 and primary_end > primary_start else ''
expected = ['Home', 'Live', 'Streamlabs', 'StreamElements', 'A/V Studio', 'Settings']
for tab in expected:
    if f'"{tab}"' not in primary:
        errors.append(f'missing six-tab primary workspace: {tab}')
if '"OBS"' in primary:
    errors.append('OBS remains a user-facing primary tab')
if primary.count('"') // 2 != 6:
    errors.append('primary navigation is not exactly six tabs')

for marker in [
    'Streamlabs Studio',
    'Preview',
    'Program',
    'Scene rail',
    'Source stack',
    'Transition & broadcast controls',
    'Mixer & DSP',
    'Alert queue',
    'Media Share',
    'Broadcast Engine',
]:
    if marker not in app:
        errors.append(f'Streamlabs Studio integration missing marker: {marker}')
if 'fn render_obs_workspace' in app:
    errors.append('separate OBS workspace renderer remains')

for marker in [
    'DRAGONGLASS_SURFACE',
    'DRAGONGLASS_CARD',
    'DRAGONGLASS_ACCENT',
    'DRAGONGLASS_CONNECTED',
    'DRAGONGLASS_ATTENTION',
    'connection_chip',
    'glass_card',
]:
    if marker not in theme:
        errors.append(f'DragonGlass visual token/helper missing: {marker}')

for marker in ['AuthProvider', 'AuthAction', 'AuthConnectionState', 'AccountConnection']:
    if marker not in action:
        errors.append(f'auth domain marker missing: {marker}')
if 'Auth(AetherAuthAction)' not in action:
    errors.append('canonical AetherStreamAction auth variant missing')
if 'ActionTarget::Auth' not in router:
    errors.append('auth actions do not route to single Auth owner')
if 'pub auth: AuthState' not in state or 'StateChange::Auth' not in state:
    errors.append('safe auth state is not part of revisioned shared state')

for marker in ['OAuthLoginMode', 'SmartRestorePlan', 'BrowserCallback', 'ManualCodeFallback']:
    if marker not in auth_lib:
        errors.append(f'auth broker flow marker missing: {marker}')

for marker in [
    'Twitch Device Code',
    'Open Twitch activation',
    'Streamlabs account',
    'StreamElements account',
    'Smart restore',
    'Settings → Accounts',
]:
    if marker not in app:
        errors.append(f'login/account UI marker missing: {marker}')

# Safe-state surface must not define obvious secret-bearing fields.
safe_text = '\n'.join([action, state])
for forbidden in ['access_token:', 'refresh_token:', 'client_secret:', 'password:']:
    if forbidden in safe_text:
        errors.append(f'secret-bearing field leaked into safe action/state model: {forbidden}')

if errors:
    print('AETHERSTREAM_VISUAL_LOGIN_CONTRACT=FAIL')
    print('\n'.join(errors))
    sys.exit(1)
print('AETHERSTREAM_VISUAL_LOGIN_CONTRACT=PASS')
