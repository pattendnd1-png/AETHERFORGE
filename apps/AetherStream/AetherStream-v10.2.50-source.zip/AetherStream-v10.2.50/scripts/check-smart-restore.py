#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
errors=[]
runtime=(root/'crates/aetherstream-auth/src/runtime.rs').read_text()
supervisor=(root/'apps/aetherstream-supervisord/src/main.rs').read_text()
account=(root/'crates/aetherstream-storage/src/account.rs').read_text()
for marker in ['run_smart_restore', 'restore_account', 'restore_twitch_with_refresh', 'restore_streamlabs_with_refresh', 'twitch_validate', 'twitch_refresh', 'streamlabs_refresh', 'restore_enabled']:
    if marker not in runtime: errors.append(f'auth runtime missing smart restore marker: {marker}')
for marker in ['default_for', 'restore_enabled']:
    if marker not in account: errors.append(f'account metadata missing smart restore marker: {marker}')
for marker in ['run_smart_restore', 'Duration::from_secs(60 * 60)', 'tokio::spawn']:
    if marker not in supervisor: errors.append(f'supervisor missing restore scheduling marker: {marker}')
if errors:
    print('AETHERSTREAM_SMART_RESTORE_CONTRACT=FAIL'); print('\n'.join(errors)); sys.exit(1)
print('AETHERSTREAM_SMART_RESTORE_CONTRACT=PASS')
