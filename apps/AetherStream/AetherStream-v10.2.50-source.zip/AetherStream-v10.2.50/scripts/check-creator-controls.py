#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
app=(root/'crates/aetherstream-ui/src/app.rs').read_text()
panels=(root/'crates/aetherstream-ui/src/panels.rs').read_text()
errors=[]
verify=(root/'scripts/verify-release.sh').read_text()
if 'AETHERSTREAM_CREATOR_CONTROLS' not in verify:
    errors.append('verification missing AETHERSTREAM_CREATOR_CONTROLS')
for token in [
    'CreatorDrafts', 'poll_title', 'prediction_title', 'raid_target', 'moderation_target',
    'TwitchCreatePoll', 'TwitchCreatePrediction', 'TwitchModeration',
    'ObsTransition', 'ObsSourceVisibility', 'ObsReplayBufferSave',
    'StreamElementsOverlay', 'StreamlabsAlert', 'StreamlabsMediaShare',
    'active_poll', 'active_prediction', 'last_moderation',
    'streamelements_ops', 'streamlabs_ops',
]:
    if token not in app:
        errors.append(f'UI missing {token}')
start=panels.find('pub const PRIMARY_TABS')
end=panels.find('];', start)
block=panels[start:end] if start>=0 and end>start else ''
if block.count('"')//2 != 6:
    errors.append('primary tab count is not exactly six')
if errors:
    print('AETHERSTREAM_CREATOR_CONTROLS_CONTRACT=FAIL')
    for error in errors: print(error)
    sys.exit(1)
print('AETHERSTREAM_CREATOR_CONTROLS_CONTRACT=PASS')
