#!/usr/bin/env python3
from pathlib import Path
import sys
p = Path('crates/aetherstream-audio/src/shared_output_dsp.rs')
text = p.read_text()
good = 'use crate::live_dsp::{LiveBiquadCoefficients, LiveDspPlan, MAX_LIVE_CHANNELS, MAX_LIVE_SECTIONS};'
bad = 'use crate::{LiveBiquadCoefficients, LiveDspPlan, MAX_LIVE_CHANNELS, MAX_LIVE_SECTIONS};'
if good not in text or bad in text:
    print('AETHERSTREAM_SHARED_OUTPUT_IMPORT=FAIL')
    print('REASON=LiveBiquadCoefficients-must-be-imported-from-crate-live_dsp')
    sys.exit(1)
print('AETHERSTREAM_SHARED_OUTPUT_IMPORT=PASS')
