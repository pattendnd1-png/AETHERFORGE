from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
installer = (root / "INSTALL-AETHERSTREAM.sh").read_text()
wp = (root / "packaging/wireplumber/90-aetherstream-physical-output-internal-dsp.conf.in").read_text()
verify = (root / "scripts/verify-release.sh").read_text()
errors = []
required_installer = [
    'LADSPA_DIR="$HOME/.local/lib/aetherstream/ladspa"',
    'install -Dm755 "$CARGO_TARGET_DIR/release/libaetherstream_hdmi3_dsp.so" "$LADSPA_SO"',
    'systemctl --user set-environment "LADSPA_PATH=$MERGED_LADSPA_PATH"',
]
for needle in required_installer:
    if needle not in installer:
        errors.append(f"installer missing {needle}")
for forbidden in [
    'LADSPA_DIR="/usr/lib/ladspa"',
    'sudo install -Dm755',
]:
    if forbidden in installer:
        errors.append(f"root DSP install remains: {forbidden}")
if 'plugin = "libaetherstream_hdmi3_dsp"' not in wp:
    errors.append("WirePlumber graph must resolve the user plugin basename via LADSPA_PATH")
for gate in [
    "AETHERSTREAM_DSP_PLUGIN_USER_INSTALL",
    "AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED",
    "AETHERSTREAM_LADSPA_PATH",
]:
    if gate not in verify:
        errors.append(f"verify gate missing {gate}")
if errors:
    print("AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT=FAIL")
    for error in errors:
        print("ERROR=" + error)
    sys.exit(1)
print("AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT=PASS")
