#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"
runtime="$(mktemp -d)"
trap 'kill "${supervisor_pid:-}" 2>/dev/null || true; rm -rf "$runtime"' EXIT
export XDG_RUNTIME_DIR="$runtime"
export AETHERSTREAM_DISABLE_STARTUP_SMART_RESTORE=1
"$BIN_DIR/aetherstream-supervisord" >"$runtime/supervisor.log" 2>&1 &
supervisor_pid=$!
for _ in {1..60}; do
  [[ -S "$runtime/aetherstream/supervisor.sock" ]] && break
  sleep 0.05
done
[[ -S "$runtime/aetherstream/supervisor.sock" ]]
AETHERSTREAM_CONTROL_ACTION='auth-smart-restore' "$BIN_DIR/aetherstream" >"$runtime/restore.log"
AETHERSTREAM_CONTROL_ACTION='auth-begin=twitch' "$BIN_DIR/aetherstream" >"$runtime/twitch.log"
AETHERSTREAM_CONTROL_ACTION='auth-begin=streamlabs' "$BIN_DIR/aetherstream" >"$runtime/streamlabs.log"
for log in restore twitch streamlabs; do
  grep -q '^AETHERSTREAM_ACTION=PASS$' "$runtime/$log.log"
done
AETHERSTREAM_CONTROL_GET_STATE=1 "$BIN_DIR/aetherstream" >"$runtime/state.log"
grep -q '^AETHERSTREAM_AUTH_TWITCH=' "$runtime/state.log"
grep -q '^AETHERSTREAM_AUTH_STREAMLABS=' "$runtime/state.log"
grep -q '^AETHERSTREAM_AUTH_SMART_RESTORE=true$' "$runtime/state.log"
echo "AETHERSTREAM_AUTH_ACTIONS_SMOKE=PASS"
