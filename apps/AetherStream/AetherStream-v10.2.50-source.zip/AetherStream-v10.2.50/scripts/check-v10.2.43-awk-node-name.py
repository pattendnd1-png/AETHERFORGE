#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
files = [
    root / "INSTALL-AETHERSTREAM.sh",
    root / "scripts/smoke-live-output-dsp-runtime.sh",
    root / "scripts/smoke-system-audio-runtime.sh",
]
expected = '''awk -F= '/node.name/{v=$2; gsub(/^[[:space:]"]+|[[:space:]"]+$/, "", v); print v; exit}' '''.strip()
errors=[]
for path in files:
    text=path.read_text()
    node_lines=[line for line in text.splitlines() if 'awk -F=' in line and '/node.name/' in line]
    if len(node_lines) != 1:
        errors.append(f"{path.relative_to(root)}: expected exactly one node.name awk parser, found {len(node_lines)}")
        continue
    line=node_lines[0]
    if expected not in line:
        errors.append(f"{path.relative_to(root)}: node.name awk parser is not POSIX-safe canonical form")
    if r'\"' in line:
        errors.append(f"{path.relative_to(root)}: non-portable escaped quote remains in awk regex")

program='/node.name/{v=$2; gsub(/^[[:space:]"]+|[[:space:]"]+$/, "", v); print v; exit}'
sample='node.name = "alsa_output.pci-0000_03_00.1.hdmi-stereo-extra3"\n'
try:
    proc=subprocess.run(['awk','-F=',program], input=sample, text=True, capture_output=True, check=False)
except FileNotFoundError:
    errors.append('awk is unavailable for parser portability self-test')
else:
    if proc.returncode != 0:
        errors.append(f'awk parser exited {proc.returncode}: {proc.stderr.strip()}')
    if proc.stderr.strip():
        errors.append(f'awk parser emitted stderr warning: {proc.stderr.strip()}')
    if proc.stdout.strip() != 'alsa_output.pci-0000_03_00.1.hdmi-stereo-extra3':
        errors.append(f'awk parser produced unexpected output: {proc.stdout.strip()!r}')

if errors:
    for error in errors:
        print(f'AETHERSTREAM_AWK_NODE_NAME_ERROR={error}')
    print('AETHERSTREAM_AWK_NODE_NAME=FAIL')
    sys.exit(1)
print('AETHERSTREAM_AWK_NODE_NAME=PASS')
