#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"
runtime="$(mktemp -d)"
trap 'kill "${supervisor_pid:-}" 2>/dev/null || true; rm -rf "$runtime"' EXIT
export XDG_RUNTIME_DIR="$runtime"
"$BIN_DIR/aetherstream-supervisord" >"$runtime/supervisor.log" 2>&1 &
supervisor_pid=$!
for _ in {1..50}; do [[ -S "$runtime/aetherstream/supervisor.sock" ]] && break; sleep 0.05; done
[[ -S "$runtime/aetherstream/supervisor.sock" ]]
AETHERSTREAM_HEADLESS_SMOKE=1 "$BIN_DIR/aetherstream" >"$runtime/ui-a.log"
AETHERSTREAM_HEADLESS_SMOKE=1 "$BIN_DIR/aetherstream" >"$runtime/ui-b.log"
a="$(sed -n 's/^AETHERSTREAM_CLIENT_ID=//p' "$runtime/ui-a.log")"
b="$(sed -n 's/^AETHERSTREAM_CLIENT_ID=//p' "$runtime/ui-b.log")"
[[ -n "$a" && -n "$b" && "$a" != "$b" ]]
kill "$supervisor_pid"
wait "$supervisor_pid" 2>/dev/null || true
echo "AETHERSTREAM_MULTI_INSTANCE_SMOKE=PASS"
