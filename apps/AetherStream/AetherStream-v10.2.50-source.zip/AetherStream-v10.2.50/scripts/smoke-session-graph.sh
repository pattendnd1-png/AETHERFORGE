#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
BIN_DIR="${CARGO_TARGET_DIR:-$root/target}/release"
"$BIN_DIR/aetherstream-supervisord" --session-graph-smoke | grep -q '^AETHERSTREAM_SESSION_GRAPH_SMOKE=PASS$'
echo "AETHERSTREAM_SESSION_GRAPH_SMOKE=PASS"
