#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors = []

def read(rel):
    p = root / rel
    if not p.is_file():
        errors.append(f"missing {rel}")
        return ""
    return p.read_text()

audiod = read("apps/aetherstream-audiod/src/main.rs")
ui = read("crates/aetherstream-ui/src/app.rs")
core = read("crates/aetherstream-core/src/output_dsp.rs")
smoke = read("scripts/smoke-live-output-dsp-runtime.sh")
verify = read("scripts/verify-release.sh")
supervisor = read("apps/aetherstream-supervisord/src/main.rs")
wp = read("packaging/wireplumber/90-aetherstream-hdmi3-internal-dsp.conf.in")

for needle in ['HDMI3_LOADOUT_ID', 'resolve_hdmi3_physical_sink', 'physical.node_name']:
    if needle not in audiod:
        errors.append(f"audiod HDMI3 physical contract missing {needle}")
for forbidden in [
    'aetherstream.dsp.sink',
    'HDMI3_FILTER_INPUT_NAME',
    'HDMI3_FILTER_PLAYBACK_NAME',
    'filter.smart',
    'fn run_pipewire(',
    'StreamBox::new',
]:
    if forbidden in audiod:
        errors.append(f"audiod still creates/references a forbidden output node: {forbidden}")

for needle in ['node.filter-graph.rules', 'create-filter-graph', '"media.class" = "Audio/Sink"']:
    if needle not in wp:
        errors.append(f"HDMI3 internal graph missing {needle}")
for forbidden in ['filter.smart', 'node.software-dsp.rules', 'node.virtual']:
    if forbidden in wp:
        errors.append(f"HDMI3 config still uses separate/virtual filter behavior: {forbidden}")

if 'pub const HDMI3_LOADOUT_ID: &str = "hdmi3"' not in core:
    errors.append('core HDMI3 loadout id missing')
for needle in ['device_id: HDMI3_LOADOUT_ID.into()', 'PHYSICAL OUTPUT • NO OUTPUT SWITCHING', 'NO OUTPUT SWITCHING']:
    if needle not in ui:
        errors.append(f"UI HDMI3 loadout contract missing {needle}")

for needle in [
    'AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING=OFF',
    'AETHERSTREAM_HDMI3_LOADOUT=PASS',
    'AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS=0',
    'AETHERSTREAM_EXTRA_OUTPUT_STREAMS=0',
    'AETHERSTREAM_SMART_FILTER_NODES=0',
    'AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT=1',
    'AETHERSTREAM_HDMI3_INTERNAL_DSP=PASS',
]:
    if needle not in smoke:
        errors.append(f"runtime smoke missing {needle}")

for needle in ['normalize_output_dsp_loadout', 'profiles.insert(HDMI3_LOADOUT_ID.into(), profile)']:
    if needle not in supervisor:
        errors.append(f"HDMI3 persistence migration missing {needle}")

for key in [
    'AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING',
    'AETHERSTREAM_PHYSICAL_OUTPUT',
    'AETHERSTREAM_HDMI3_LOADOUT',
    'AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS',
    'AETHERSTREAM_HDMI3_INTERNAL_DSP',
    'AETHERSTREAM_EXTRA_OUTPUT_STREAMS',
    'AETHERSTREAM_SMART_FILTER_NODES',
    'AETHERSTREAM_HDMI3_OUTPUT_NODE_COUNT',
]:
    if key not in verify:
        errors.append(f"release verifier missing {key}")

if errors:
    print('AETHERSTREAM_HDMI3_PHYSICAL_OUTPUT_CONTRACT=FAIL')
    for error in errors:
        print(error)
    sys.exit(1)
print('AETHERSTREAM_HDMI3_PHYSICAL_OUTPUT_CONTRACT=PASS')
