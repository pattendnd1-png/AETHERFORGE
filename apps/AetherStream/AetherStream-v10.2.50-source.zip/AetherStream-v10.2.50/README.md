# AetherStream v10.2.50

## v10.2.50 — exact linked HDMI + Bluetooth topology hardening

- Enforces exactly one intentional `aetherstream_linked_hdmi_bluetooth` combine sink when linked output is active.
- Enforces exactly two physical member legs: one HDMI/DisplayPort sink and one Bluetooth sink.
- Rejects duplicate combine modules, extra linked virtual sinks/sources, linked loopbacks/remap/null sinks, duplicate output routes, and orphan member links.
- Serializes linked-output rebuilds so reconnect and explicit Control Center actions cannot race into duplicate graph creation.
- The watcher now validates the exact topology instead of merely asking whether any linked module exists; non-exact graphs are repaired through the same authoritative AetherStream path.
- A failed post-create topology validation rolls the linked namespace back and restores HDMI as the direct default rather than leaving a half-built graph.
- Disabling linked output must leave the linked namespace completely clean.
- The installer performs a live post-service topology probe and fails on partial/extraneous topology; a temporarily disconnected Bluetooth device is accepted only when the linked namespace is completely clean.
- Control Center coordinated release consumes the topology telemetry but never creates PipeWire nodes itself.
- Preserves shared master level, attenuation-only device trims, latency compensation, Bluetooth persistence, DSP anti-recursion, cache-backed compiler temp, and AetherStream-only graph authority.

## v10.2.46 — compiler temporary-storage hotfix

Immediate donor: v10.2.45. Native C/C++ build helpers such as `cc-rs` now inherit `TMPDIR`, `TMP`, and `TEMP` from a versioned AetherStream user-cache directory instead of consuming `/tmp`. The installer and verifier also require sufficient free space in that cache filesystem before starting heavy Cargo work. Linked HDMI + Bluetooth behavior is unchanged.

AetherStream is the Rust-first full-system audio authority plus Twitch, Streamlabs, StreamElements, Stream Deck+, audio DSP and A/V workstation for Linux/AetherForge.

## v10.2.46 — linked HDMI + Bluetooth output

AetherStream v10.2.46 adds the authoritative linked HDMI + Bluetooth output graph. The AetherStream supervisor owns one PipeWire Pulse combine sink, keeps one shared master level, supports attenuation-only per-device trims, enables latency compensation, persists the physical sink identities, and repairs the linked path after a Bluetooth reconnect without restarting the audio service. Control Center configures this policy through the typed AetherStream action boundary; it does not create PipeWire graph nodes itself.


### Physical-output invariant

- AetherStream never switches the system output.
- The output selected by PipeWire/WirePlumber remains the real physical output.
- No AetherStream virtual sink, loopback sink, smart-filter node pair, hidden replacement sink, or alternate output stream is created.
- The Rust DSP is loaded into the existing physical output with WirePlumber `node.filter-graph.rules` / `create-filter-graph`, which adds no separate output node.
- HDMI3 remains a supported canonical loadout; Bluetooth speakers use the same one-node in-place DSP architecture.

### Bluetooth speakers

Bluetooth playback nodes (`bluez_output.*`) are treated as first-class physical outputs. AetherStream derives a persistent loadout identity from the BlueZ device address when available, falls back to the stable PipeWire node identity, and records the exposed codec/profile metadata without changing the selected output.

First-class speaker classes include:

- Bluetooth portable speaker
- Bluetooth 360° speaker
- Bluetooth stereo portable speaker
- Bluetooth desktop speaker
- Bluetooth bookshelf speakers
- Bluetooth 2.0 speakers
- Bluetooth 2.1 speakers
- Bluetooth soundbar
- Bluetooth soundbar + subwoofer
- Bluetooth TV speaker
- Bluetooth smart/home speaker
- Bluetooth party speaker
- Bluetooth outdoor speaker
- Bluetooth PA speaker
- Bluetooth multi-speaker / stereo pair
- Ultimate Ears WONDERBOOM 4 — dedicated 360° Bluetooth speaker profile

The WONDERBOOM 4 reference profile is an AetherStream factory starting point, not a claim of an Ultimate Ears published correction curve. Each real Bluetooth device keeps its own persistent editable profile.

### 15–31 band parametric EQ

- Dedicated PEQ bank: minimum 15 bands, expandable to 31.
- Frequency setup range: 5 Hz–35 kHz.
- Gain: -24 dB to +24 dB.
- Q: 0.1–18.0.
- Band types: Peak, Notch, Low Shelf, High Shelf.
- Quick selectors: 15 / 21 / 25 / 31 plus `+ Band` / `- Band`.
- HPF/LPF protection remains separate and does not consume PEQ bands.
- Existing Peak/Notch/Shelf filters migrate into the PEQ bank and are padded to 15 bands without replacing the SQLite schema.
- Bands above the active output Nyquist guard are preserved and remain inactive until the selected sample rate can represent them.
- PEQ, Bass, Clarity, Gaming Mode, limiter and bypass remain live auto-apply controls.

### Installer stage / diagnostics correction

The installer now updates `~/Downloads/AetherStream-v10.2.46-VERIFY.txt` atomically every time it enters a new stage, instead of leaving the handoff stuck at `startup`. Each running checkpoint records the current stage, its start timestamp, the install-log path, the build-log path, and `AETHERSTREAM_VERIFY=RUNNING`.

Stages are: `startup`, `dependency-check`, `dependency-install`, `stop-previous-audiod`, `release-build`, `physical-output-resolution`, `dsp-plugin-install`, `wireplumber-config`, `wireplumber-restart`, `host-verification`, `runtime-install`, `service-enable`, and `complete`.

Arch dependency setup now checks `pacman -Q` first and sends only missing, repository-available packages to `pacman -S --needed`. Already-installed packages are not needlessly handed back to pacman.

Installer output is retained in `~/Downloads/AetherStream-v10.2.46-INSTALL.log`; release-build output remains in `~/Downloads/AetherStream-v10.2.46-BUILD.log`. If any pre-verification stage fails, the VERIFY file records the exact failing stage and exit code. If Cargo fails, the VERIFY file also embeds the last compiler diagnostics. A successful host verification snapshot is preserved through runtime installation and restored into the final `complete` VERIFY file rather than being overwritten by stage heartbeats.

The earlier Rust 1.98 `matches!()` correction, PEQ exact-boundary normalization, PEQ `Color32` build guard, Bluetooth/WONDERBOOM profiles, and build-diagnostic capture remain preserved.

### WirePlumber integration

The installer places the Rust LADSPA library entirely in the user session at `~/.local/lib/aetherstream/ladspa/libaetherstream_hdmi3_dsp.so`; no root/system-wide DSP-plugin installation is required. The installer publishes that directory as `LADSPA_PATH` in the systemd user manager and renders the exact absolute plugin path into:

`~/.config/wireplumber/wireplumber.conf.d/90-aetherstream-physical-output-internal-dsp.conf`

The rule targets the currently selected primary physical `node.name` plus Bluetooth `bluez_output.*` nodes. Runtime DSP changes do not restart PipeWire or WirePlumber. The installer may restart WirePlumber once when installing the configuration and verifies that the default physical output name did not change.

Current internal LADSPA processing requires a stereo PipeWire sink (`audio.channels=2`). It fails closed rather than inventing another output path or changing the hardware channel layout.

### Full-system microphone / ForgeHX

- AetherStream remains the single system-facing microphone publisher.
- ForgeHX remains the physical microphone capture/DSP provider and feeds post-DSP PCM to AetherStream.
- Bluetooth output support does not alter or duplicate the microphone path.

### Verification

Host verification requires the existing Rust/system gates plus:

- `AETHERSTREAM_INSTALLER_STAGE_DIAGNOSTICS=PASS`
- `AETHERSTREAM_USER_DSP_PLUGIN_CONTRACT=PASS`
- `AETHERSTREAM_DSP_PLUGIN_USER_INSTALL=PASS`
- `AETHERSTREAM_DSP_PLUGIN_ROOT_REQUIRED=NO`
- `AETHERSTREAM_LADSPA_PATH=PASS`
- `AETHERSTREAM_EARLY_VERIFY_HANDOFF=PASS`
- `AETHERSTREAM_CLIPPY_MATCHES_MACRO=PASS`
- `AETHERSTREAM_PEQ_EXACT_BOUNDARIES=PASS`
- `AETHERSTREAM_PEQ_15_31_BANDS=PASS`
- `AETHERSTREAM_PEQ_5HZ_35KHZ=PASS`
- `AETHERSTREAM_PEQ_COLOR32_BUILD_GUARD=PASS`
- `AETHERSTREAM_BUILD_DIAGNOSTICS=PASS`
- `AETHERSTREAM_BLUETOOTH_SPEAKER_CLASSES=PASS`
- `AETHERSTREAM_WONDERBOOM4_360_PROFILE=PASS`
- `AETHERSTREAM_BLUETOOTH_AUTO_SWITCHING=OFF`
- `AETHERSTREAM_OUTPUT_DEFAULT_SWITCHING=OFF`
- `AETHERSTREAM_PHYSICAL_INTERNAL_DSP=PASS`
- `AETHERSTREAM_PHYSICAL_OUTPUT_NODE_COUNT=1`
- `AETHERSTREAM_USER_VISIBLE_VIRTUAL_OUTPUTS=0`
- `AETHERSTREAM_EXTRA_OUTPUT_STREAMS=0`
- `AETHERSTREAM_SMART_FILTER_NODES=0`
- `AETHERSTREAM_SYSTEM_MIC=PASS`
- `AETHERSTREAM_FORGEHX_BRIDGE=PASS`

HDMI3 compatibility gates remain present but are runtime-active only when HDMI3 is the selected output.

## Install

Use the canonical self-contained installer from `~/Downloads`:

`bash "$HOME/Downloads/AetherStream-v10.2.46-INSTALL.sh"`

Host verification writes `~/Downloads/AetherStream-v10.2.46-VERIFY.txt`. The full installer transcript is retained at `~/Downloads/AetherStream-v10.2.46-INSTALL.log`.

If the release build fails, compiler output is retained at `~/Downloads/AetherStream-v10.2.46-BUILD.log` and copied into the VERIFY failure details.

## Rollback / state

No database schema replacement is required. Existing output profiles remain preserved. Removing the AetherStream physical-output WirePlumber fragment and restarting WirePlumber removes the internal output DSP without needing to restore a default output, because AetherStream never changes it.


## v10.2.46 host-gate hardening
- Fixes the linked-output Clippy `trim_split_whitespace` error.
- Moves Cargo verification/build artifacts out of `/tmp` into the user cache and disables incremental compilation for lower peak disk use.
- Deduplicates the user LADSPA path before exporting it to the systemd user environment.
- Preserves the linked HDMI + Bluetooth output architecture and AetherStream-only PipeWire graph ownership.
