#!/usr/bin/env bash
set -euo pipefail
config_dir="${XDG_CONFIG_HOME:-$HOME/.config}/aetherstream"
env_file="$config_dir/auth.env"
mkdir -p "$config_dir"
chmod 700 "$config_dir"

if ! command -v secret-tool >/dev/null 2>&1; then
  printf 'AETHERSTREAM_AUTH_CONFIG=FAIL secret-tool not found (install libsecret)\n' >&2
  exit 1
fi

read -r -p 'Twitch client ID (public; blank keeps current): ' twitch_client_id
read -r -p 'Streamlabs client ID (public; blank keeps current): ' streamlabs_client_id
read -r -p 'StreamElements client ID (optional; blank keeps current): ' streamelements_client_id
read -r -p 'StreamElements authorize URL (registered integration only; blank keeps current): ' streamelements_authorize_url
read -r -p 'StreamElements token URL (registered integration only; blank keeps current): ' streamelements_token_url

# Preserve any existing values, then update only values supplied in this run.
declare -A values=()
if [[ -f "$env_file" ]]; then
  while IFS='=' read -r key value; do
    [[ "$key" =~ ^AETHERSTREAM_[A-Z0-9_]+$ ]] || continue
    values["$key"]="$value"
  done < "$env_file"
fi
[[ -z "$twitch_client_id" ]] || values[AETHERSTREAM_TWITCH_CLIENT_ID]="$twitch_client_id"
[[ -z "$streamlabs_client_id" ]] || values[AETHERSTREAM_STREAMLABS_CLIENT_ID]="$streamlabs_client_id"
[[ -z "$streamelements_client_id" ]] || values[AETHERSTREAM_STREAMELEMENTS_CLIENT_ID]="$streamelements_client_id"
[[ -z "$streamelements_authorize_url" ]] || values[AETHERSTREAM_STREAMELEMENTS_AUTHORIZE_URL]="$streamelements_authorize_url"
[[ -z "$streamelements_token_url" ]] || values[AETHERSTREAM_STREAMELEMENTS_TOKEN_URL]="$streamelements_token_url"

{
  printf '# AetherStream non-secret OAuth application configuration.\n'
  for key in "${!values[@]}"; do
    printf '%s=%s\n' "$key" "${values[$key]}"
  done | sort
} > "$env_file"
chmod 600 "$env_file"

read -r -s -p 'Streamlabs client secret (blank keeps current): ' streamlabs_secret
printf '\n'
if [[ -n "$streamlabs_secret" ]]; then
  printf '%s' "$streamlabs_secret" | secret-tool store \
    --label='AetherStream Streamlabs client secret' \
    application aetherstream key 'aetherstream:Streamlabs:default:client-secret'
fi
unset streamlabs_secret

read -r -s -p 'StreamElements client secret (optional; blank keeps current): ' elements_secret
printf '\n'
if [[ -n "$elements_secret" ]]; then
  printf '%s' "$elements_secret" | secret-tool store \
    --label='AetherStream StreamElements client secret' \
    application aetherstream key 'aetherstream:StreamElements:default:client-secret'
fi
unset elements_secret

systemctl --user restart aetherstream-supervisord.service 2>/dev/null || true
printf 'AETHERSTREAM_AUTH_CONFIG=PASS\nAETHERSTREAM_AUTH_ENV=%s\n' "$env_file"
